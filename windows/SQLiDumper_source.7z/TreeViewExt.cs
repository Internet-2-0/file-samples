using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class TreeViewExt : TreeView
{
	internal sealed class Class41
	{
		public static int int_0;

		public static int int_1;

		public static bool Boolean_0
		{
			get
			{
				OperatingSystem oSVersion = Environment.OSVersion;
				return oSVersion.Platform == PlatformID.Win32NT && (oSVersion.Version.Major > 5 || (oSVersion.Version.Major == 5 && oSVersion.Version.Minor == 1));
			}
		}

		public static bool Boolean_1
		{
			get
			{
				OperatingSystem oSVersion = Environment.OSVersion;
				return oSVersion.Platform == PlatformID.Win32NT && oSVersion.Version.Major >= 6;
			}
		}

		[DllImport("user32.dll")]
		public static extern IntPtr SendMessage(IntPtr intptr_0, int int_2, IntPtr intptr_1, IntPtr intptr_2);
	}

	private static int int_0;

	private static int int_1;

	private static int int_2;

	private static int int_3;

	public TreeViewExt()
	{
		SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		if (!Class41.Boolean_1)
		{
			SetStyle(ControlStyles.UserPaint, value: true);
		}
	}

	private void method_0()
	{
		int num = 0;
		if (DoubleBuffered)
		{
			num |= 4;
		}
		if (num != 0)
		{
			Class41.SendMessage(base.Handle, 4396, (IntPtr)4, (IntPtr)num);
		}
	}

	protected override void OnHandleCreated(EventArgs e)
	{
		base.OnHandleCreated(e);
		method_0();
		if (!Class41.Boolean_0)
		{
			Class41.SendMessage(base.Handle, 4381, IntPtr.Zero, (IntPtr)ColorTranslator.ToWin32(BackColor));
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		if (GetStyle(ControlStyles.UserPaint))
		{
			Message m = default(Message);
			m.HWnd = base.Handle;
			m.Msg = 792;
			m.WParam = e.Graphics.GetHdc();
			m.LParam = (IntPtr)4;
			DefWndProc(ref m);
			e.Graphics.ReleaseHdc(m.WParam);
		}
		base.OnPaint(e);
	}
}
