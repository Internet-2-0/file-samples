namespace DataBase;

public enum OracleTopN
{
	ROWNUM,
	RANK,
	DENSE_RANK
}
