namespace DataBase;

public enum Types
{
	None,
	Unknown,
	MySQL_Unknown,
	MySQL_No_Error,
	MySQL_With_Error,
	MSSQL_Unknown,
	MSSQL_No_Error,
	MSSQL_With_Error,
	Oracle_Unknown,
	Oracle_No_Error,
	Oracle_With_Error,
	PostgreSQL_Unknown,
	PostgreSQL_No_Error,
	PostgreSQL_With_Error,
	MsAccess,
	Sybase
}
