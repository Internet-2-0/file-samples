namespace DataBase;

public enum Schema
{
	INFO,
	DATABASES,
	TABLES,
	COLUMNS,
	ROWS
}
