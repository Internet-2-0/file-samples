namespace DataBase;

public enum InjectionFormat
{
	None,
	Integer,
	String
}
