namespace DataBase;

public enum InjectionType
{
	None,
	Union,
	Error
}
