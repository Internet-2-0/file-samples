namespace DataBase;

public enum MySQLCollactions : byte
{
	None,
	UnHex,
	Binary,
	CastAsChar,
	Compress,
	ConvertUtf8,
	ConvertLatin1,
	Aes_descrypt
}
