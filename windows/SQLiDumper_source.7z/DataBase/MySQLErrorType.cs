namespace DataBase;

public enum MySQLErrorType : byte
{
	UpdateXML,
	DuplicateEntry,
	ExtractValue
}
