namespace DataBase;

public enum OracleErrorType : byte
{
	NONE,
	GET_HOST_ADDRESS,
	DRITHSX_SN,
	GETMAPPINGXPATH
}
