namespace DataBase;

public enum PostgreSQLCollactions : byte
{
	None,
	SubStr,
	StrPos,
	Get_Byte
}
