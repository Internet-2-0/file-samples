namespace DataBase;

public enum PostgreSQLErrorType : byte
{
	NONE,
	CAST_INT
}
