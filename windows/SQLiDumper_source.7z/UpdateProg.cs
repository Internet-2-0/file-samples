using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
public class UpdateProg : Form
{
	private IContainer icontainer_0;

	[AccessedThroughProperty("Cancel_Button")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _Cancel_Button;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_0;

	internal virtual Button Cancel_Button
	{
		[CompilerGenerated]
		get
		{
			return _Cancel_Button;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_0;
			Button cancel_Button = _Cancel_Button;
			if (cancel_Button != null)
			{
				cancel_Button.Click -= value2;
			}
			_Cancel_Button = value;
			cancel_Button = _Cancel_Button;
			if (cancel_Button != null)
			{
				cancel_Button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("prbDownload")]
	internal virtual ProgressBar prbDownload
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public bool Cancel
	{
		[CompilerGenerated]
		get
		{
			return bool_0;
		}
		[CompilerGenerated]
		set
		{
			bool_0 = value;
		}
	}

	public UpdateProg()
	{
		InitializeComponent();
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.Cancel_Button = new System.Windows.Forms.Button();
		this.prbDownload = new System.Windows.Forms.ProgressBar();
		base.SuspendLayout();
		this.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.Cancel_Button.Location = new System.Drawing.Point(370, 9);
		this.Cancel_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.Cancel_Button.Name = "Cancel_Button";
		this.Cancel_Button.Size = new System.Drawing.Size(96, 30);
		this.Cancel_Button.TabIndex = 4;
		this.Cancel_Button.Text = "Cancel";
		this.prbDownload.Location = new System.Drawing.Point(9, 6);
		this.prbDownload.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.prbDownload.Name = "prbDownload";
		this.prbDownload.Size = new System.Drawing.Size(354, 35);
		this.prbDownload.TabIndex = 5;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(472, 49);
		base.ControlBox = false;
		base.Controls.Add(this.prbDownload);
		base.Controls.Add(this.Cancel_Button);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		base.MinimizeBox = false;
		base.Name = "UpdateProg";
		base.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
		this.Text = "Updater";
		base.ResumeLayout(false);
	}

	private void method_0(object sender, EventArgs e)
	{
		Cancel = true;
		Cancel_Button.Enabled = false;
	}
}
