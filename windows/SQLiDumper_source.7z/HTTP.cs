using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Web;
using Chilkat;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

internal sealed class HTTP
{
	private Stopwatch __Elapsed;

	private long __Size;

	public long DW_SIZE;

	public Http o { get; set; }

	public int Status { get; set; }

	public string StatusString { get; set; }

	public HttpResponse Response { get; set; }

	public HttpRequest Request { get; set; }

	public string Proxy { get; set; }

	public bool FollowRedirects { get; set; }

	public string Elapsed { get; set; }

	public bool WasRedirected { get; set; }

	public bool ProxyChecked { get; set; }

	public HTTP()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Expected O, but got Unknown
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Expected O, but got Unknown
		FollowRedirects = true;
		o = new Http();
		o.UserAgent = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtUserAgent));
		o.Accept = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtAccept));
		o.ConnectTimeout = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPTimeout));
		o.ReadTimeout = o.ConnectTimeout;
		o.FollowRedirects = FollowRedirects;
		o.AutoAddHostHeader = true;
		o.AllowGzip = true;
		o.SendCookies = true;
		o.SaveCookies = true;
		o.CookieDir = "memory";
		o.UseIEProxy = false;
		o.MaxConnections = 500;
		o.MaxResponseSize = 5242880u;
		o.EnableEvents = true;
		o.KeepEventLog = false;
		o.OnReceiveRate += new ReceiveRateEventHandler(OnReceiveRate);
	}

	private void OnReceiveRate(object sender, DataRateEventArgs e)
	{
		__Size = e.ByteCount;
	}

	public string CheckProxy()
	{
		ProxyChecked = true;
		Class35 g_SOCKS = Globals.G_SOCKS;
		Http http_ = o;
		string string_ = Proxy;
		g_SOCKS.method_12(ref http_, ref string_);
		Proxy = string_;
		o = http_;
		return Proxy;
	}

	public string QuickGet(string sUrl)
	{
		if (!ProxyChecked)
		{
			CheckProxy();
		}
		return ChilkatDoWork(sUrl, new List<Class24>());
	}

	public string QuickPost(string sUrl, List<Class24> r)
	{
		if (!ProxyChecked)
		{
			CheckProxy();
		}
		return ChilkatDoWork(sUrl, r);
	}

	private string ChilkatDoWork(string sUrl, List<Class24> lPost)
	{
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Expected O, but got Unknown
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Expected O, but got Unknown
		string text = "";
		StatusString = "";
		Status = 0;
		__Size = 0L;
		long long_ = Globals.GMain.method_207(sUrl, Proxy);
		__Elapsed = Stopwatch.StartNew();
		if (lPost.Count == 0)
		{
			try
			{
				StringBuilder val = new StringBuilder();
				try
				{
					o.QuickGetSb(sUrl, val);
					text = val.ToString();
				}
				finally
				{
					((IDisposable)val)?.Dispose();
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
			WasRedirected = o.WasRedirected;
			Status = o.LastStatus;
			if (string.IsNullOrEmpty(text))
			{
				text = o.LastResponseBody;
			}
		}
		else
		{
			Request = new HttpRequest();
			Request.UsePost();
			Request.SendCharset = true;
			foreach (Class24 item in lPost)
			{
				Request.AddParam(item.Name, Class23.smethod_6(item.Value));
			}
			try
			{
				Response = o.PostUrlEncoded(sUrl, Request);
			}
			catch (Exception projectError2)
			{
				ProjectData.SetProjectError(projectError2);
				ProjectData.ClearProjectError();
			}
			if (Response != null)
			{
				text = Response.BodyStr;
				Status = Response.StatusCode;
			}
			else
			{
				text = "";
			}
		}
		o.CloseAllConnections();
		__Elapsed.Stop();
		if (__Size <= 0)
		{
		}
		if ((Status > 0) & (Status != 999999))
		{
			HttpStatusCode status = default(HttpStatusCode);
			try
			{
				status = (HttpStatusCode)Status;
			}
			catch (Exception projectError3)
			{
				ProjectData.SetProjectError(projectError3);
				ProjectData.ClearProjectError();
			}
			if (Operators.CompareString(Status.ToString(), status.ToString(), TextCompare: false) == 0)
			{
				StatusString = Conversions.ToString(Status);
			}
			else
			{
				StatusString = Conversions.ToString(Status) + " " + status;
			}
		}
		else
		{
			StatusString = GetConnectFailReason();
		}
		Elapsed = Strings.FormatNumber(__Elapsed.Elapsed.TotalMilliseconds / 1000.0, 2);
		Globals.GMain.method_206(long_, sUrl, Globals.FormatBytes(__Size), Elapsed, StatusString, "");
		if (Globals.GStatistics != null)
		{
			Globals.GStatistics.method_1(Class26.Enum1.const_3, StatusString, 1);
		}
		if (!string.IsNullOrEmpty(text))
		{
			text = HttpUtility.HtmlDecode(text).Trim();
		}
		return text;
	}

	private string GetConnectFailReason()
	{
		return o.ConnectFailReason switch
		{
			98 => "Async operation in progress", 
			99 => "Product is not unlocked", 
			100 => "TLS Error", 
			101 => "Failed to send client hello", 
			102 => "Unexpected handshake message", 
			103 => "Failed to read server hello", 
			104 => "No server certificate", 
			105 => "Unexpected TLS protocol version", 
			106 => "Server certificate verify failed (the server certificate is expired or the cert's signature verification failed)", 
			107 => "Unacceptable TLS protocol version", 
			109 => "Failed to read handshake messages", 
			110 => "Failed to send client certificate handshake message", 
			111 => "Failed to send client key exchange handshake message", 
			112 => "Client certificate's private key not accessible", 
			113 => "Failed to send client cert verify handshake message", 
			114 => "Failed to send change cipher spec handshake message", 
			115 => "Failed to send finished handshake message", 
			116 => "Server's Finished message is invalid", 
			50 => "HTTP proxy authentication failure", 
			1 => "Empty hostname", 
			2 => "DNS lookup failed", 
			3 => "DNS timeout", 
			4 => "Timeout", 
			5 => "Internal failure", 
			6 => "Timed Out", 
			7 => "Rejected", 
			_ => "Unknown\\Blocked", 
		};
	}

	public void Dispose()
	{
		if (Request != null)
		{
			Request.Dispose();
		}
		if (Response != null)
		{
			Response.Dispose();
		}
		if (o != null)
		{
			o.Dispose();
		}
	}
}
