using System;
using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.Win32;
using ns0;

internal sealed class Program : MarshalByRefObject
{
	private static void smethod_2(object sender, NetworkAvailabilityEventArgs e)
	{
		Globals.NETWORK_AVAILABLE = e.IsAvailable;
	}

	[STAThread]
	public static void Main()
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		Form form = default(Form);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 206:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0016;
						case 4:
						case 5:
							goto IL_0018;
						case 6:
							goto IL_0020;
						case 7:
							goto IL_0029;
						case 8:
							goto IL_0032;
						case 9:
							goto IL_003b;
						case 10:
							goto IL_0049;
						case 11:
							goto IL_005c;
						case 12:
							goto IL_006e;
						case 13:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 14:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_0049:
					num = 10;
					form.Size = Class6.lol.Size;
					goto IL_005c;
					IL_005c:
					num = 11;
					form.Opacity = 0.8;
					goto IL_006e;
					IL_003b:
					num = 9;
					form.BackgroundImage = Class6.lol;
					goto IL_0049;
					IL_006e:
					num = 12;
					form.ShowInTaskbar = false;
					break;
					IL_000a:
					num = 2;
					if (!Debugger.IsAttached)
					{
						goto IL_0016;
					}
					goto IL_0018;
					IL_0016:
					num = 3;
					goto IL_0018;
					IL_0018:
					num = 5;
					form = new Form();
					goto IL_0020;
					IL_0020:
					num = 6;
					form.StartPosition = FormStartPosition.CenterScreen;
					goto IL_0029;
					IL_0029:
					num = 7;
					form.TopMost = true;
					goto IL_0032;
					IL_0032:
					num = 8;
					form.FormBorderStyle = FormBorderStyle.None;
					goto IL_003b;
					end_IL_0001_2:
					break;
				}
				num = 13;
				Application.Run(form);
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 206;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	public static object smethod_0()
	{
		System.Threading.ThreadPool threadPool = (System.Threading.ThreadPool)(object)new ThreadPool(300);
		Versioned.CallByName(Globals.GMain, "Tag", CallType.Set, "c4rl0s@jabber.ru");
		return Globals.GMain;
	}

	public static bool smethod_3()
	{
		bool result = default(bool);
		try
		{
			bool flag = default(bool);
			bool flag2 = default(bool);
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Classes\\Installer\\Dependencies"))
			{
				string[] subKeyNames = registryKey.GetSubKeyNames();
				foreach (string name in subKeyNames)
				{
					using RegistryKey registryKey2 = registryKey.OpenSubKey(name);
					string text = (string)registryKey2.GetValue("DisplayName");
					if (!string.IsNullOrEmpty(text))
					{
						if (text.Contains("Microsoft Visual C++ 2015 Redistributable (x64)"))
						{
							flag = true;
						}
						if (text.Contains("Microsoft Visual C++ 2015 Redistributable (x86)"))
						{
							flag2 = true;
						}
					}
				}
			}
			if (flag && flag2)
			{
				result = true;
				return result;
			}
			MessageBox.Show("Please Install 'Microsoft Visual C++ 2015 Redistributable' x64 and x86", "SQLi Dumper Dependencies", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			Globals.ShellUrl("https://www.microsoft.com/en-us/download/details.aspx?id=48145");
			result = false;
			return result;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, "IsVC2015RedistInstalled", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
		return result;
	}

	private static void smethod_4(object sender, ThreadExceptionEventArgs e)
	{
		DialogResult dialogResult = DialogResult.Cancel;
		try
		{
			dialogResult = smethod_6("SQLi Dumper Error", e.Exception);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			try
			{
				MessageBox.Show("SQLi Dumper Error", "SQLi Dumper", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Hand);
			}
			finally
			{
				Application.Exit();
			}
			ProjectData.ClearProjectError();
		}
		if (dialogResult == DialogResult.Abort)
		{
			Application.Exit();
		}
	}

	private static void smethod_5(object sender, UnhandledExceptionEventArgs e)
	{
		try
		{
			Exception ex = (Exception)e.ExceptionObject;
			using (StreamWriter streamWriter = File.AppendText(Class2.Class0_0.Info.DirectoryPath + "\\ErrLog.log"))
			{
				streamWriter.WriteLine("[" + DateAndTime.Now.ToString() + "]" + ex.ToString());
			}
			MessageBox.Show("Ops, an error was thrown, but not handled. The error was: \r\n" + ex.Message + "\r\n(For me information about this exception, please see 'ErrLog.log')", "SQLi Dumper Error, Please Report Bug", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		catch (Exception ex2)
		{
			ProjectData.SetProjectError(ex2);
			Exception ex3 = ex2;
			try
			{
				MessageBox.Show("Fatal Non-UI Error", "Fatal Non-UI Error. Could not write the error to the event log. Reason: " + ex3.Message, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			finally
			{
				Application.Exit();
			}
			ProjectData.ClearProjectError();
		}
	}

	private static DialogResult smethod_6(string string_0, Exception exception_0)
	{
		string text = "An application error occurred. Please contact the adminstrator with the following information:\n\n";
		text = text + exception_0.Message + "\n\nStack Trace:\n" + exception_0.StackTrace;
		return MessageBox.Show(text, string_0, MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Hand);
	}

	public static bool smethod_1(string[] arg)
	{
		return true;
	}

	[STAThread]
	public static void MyMethod()
	{
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(defaultValue: true);
		Application.ThreadException += smethod_4;
		Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
		AppDomain.CurrentDomain.UnhandledException += smethod_5;
		Application.Run((MainForm)smethod_0());
	}
}
