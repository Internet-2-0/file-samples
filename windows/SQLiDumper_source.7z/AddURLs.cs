using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class AddURLs : Form
{
	private IContainer icontainer_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("txtURLs")]
	[CompilerGenerated]
	private TextBox _txtURLs;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnOK")]
	[CompilerGenerated]
	private Button _btnOK;

	[CompilerGenerated]
	[AccessedThroughProperty("btnCancel")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _btnCancel;

	internal virtual TextBox txtURLs
	{
		[CompilerGenerated]
		get
		{
			return _txtURLs;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_2;
			TextBox textBox = _txtURLs;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtURLs = value;
			textBox = _txtURLs;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	internal virtual Button btnOK
	{
		[CompilerGenerated]
		get
		{
			return _btnOK;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_0;
			Button button = _btnOK;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnOK = value;
			button = _btnOK;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual Button btnCancel
	{
		[CompilerGenerated]
		get
		{
			return _btnCancel;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_1;
			Button button = _btnCancel;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnCancel = value;
			button = _btnCancel;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	public AddURLs()
	{
		base.Load += AddURLs_Load;
		InitializeComponent();
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.txtURLs = new System.Windows.Forms.TextBox();
		this.btnOK = new System.Windows.Forms.Button();
		this.btnCancel = new System.Windows.Forms.Button();
		base.SuspendLayout();
		this.txtURLs.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtURLs.Location = new System.Drawing.Point(12, 12);
		this.txtURLs.MaxLength = 999999999;
		this.txtURLs.Multiline = true;
		this.txtURLs.Name = "txtURLs";
		this.txtURLs.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.txtURLs.Size = new System.Drawing.Size(381, 453);
		this.txtURLs.TabIndex = 0;
		this.txtURLs.WordWrap = false;
		this.btnOK.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.btnOK.Enabled = false;
		this.btnOK.Location = new System.Drawing.Point(282, 472);
		this.btnOK.Margin = new System.Windows.Forms.Padding(4);
		this.btnOK.Name = "btnOK";
		this.btnOK.Size = new System.Drawing.Size(111, 30);
		this.btnOK.TabIndex = 1;
		this.btnOK.Text = "OK";
		this.btnOK.UseVisualStyleBackColor = true;
		this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.btnCancel.Location = new System.Drawing.Point(168, 472);
		this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
		this.btnCancel.Name = "btnCancel";
		this.btnCancel.Size = new System.Drawing.Size(111, 30);
		this.btnCancel.TabIndex = 2;
		this.btnCancel.Text = "Cancel";
		this.btnCancel.UseVisualStyleBackColor = true;
		base.AcceptButton = this.btnOK;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.CancelButton = this.btnCancel;
		base.ClientSize = new System.Drawing.Size(404, 513);
		base.Controls.Add(this.txtURLs);
		base.Controls.Add(this.btnOK);
		base.Controls.Add(this.btnCancel);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		this.MinimumSize = new System.Drawing.Size(269, 382);
		base.Name = "AddURLs";
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Add URL's";
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void method_0(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.OK;
		Close();
	}

	private void method_1(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.Cancel;
		Close();
	}

	private void method_2(object sender, EventArgs e)
	{
		string[] lines = txtURLs.Lines;
		int num = 0;
		while (true)
		{
			if (num < lines.Length)
			{
				string string_ = lines[num];
				if (Class23.smethod_13(string_))
				{
					break;
				}
				num = checked(num + 1);
				continue;
			}
			btnOK.Enabled = false;
			return;
		}
		btnOK.Enabled = true;
	}

	private void AddURLs_Load(object sender, EventArgs e)
	{
		btnCancel.Text = Globals.translate_0.GetStr("PathAdd", "Cancel_Button", "Cancel");
		btnOK.Text = Globals.translate_0.GetStr("PathAdd", "OK_Button", "OK");
	}
}
