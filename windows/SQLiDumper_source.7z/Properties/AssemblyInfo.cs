using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using ns0;

[assembly: AssemblyDescription("c4rl0s@jabber.ru")]
[assembly: AssemblyCompany("fLaSh")]
[assembly: AssemblyProduct("SQLi Dumper")]
[assembly: AssemblyTitle("SQLi Dumper")]
[assembly: AssemblyFileVersion("10.1.0.0")]
[assembly: AssemblyInfo("")]
[assembly: AssemblyTrademark("by fLaSh")]
[assembly: AssemblyCopyright("c4rl0s.pt@gmail.com")]
[assembly: Guid("daf4b611-3132-4bf3-8579-98ff04ad6758")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("10.1.0.0")]
