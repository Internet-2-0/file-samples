using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
public class WafAdd : Form
{
	private IContainer icontainer_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("OK_Button")]
	[CompilerGenerated]
	private Button _OK_Button;

	[AccessedThroughProperty("txtEnding")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtEnding;

	[AccessedThroughProperty("txtOutset")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private TextBox _txtOutset;

	internal virtual Button OK_Button
	{
		[CompilerGenerated]
		get
		{
			return _OK_Button;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_2;
			Button oK_Button = _OK_Button;
			if (oK_Button != null)
			{
				oK_Button.Click -= value2;
			}
			_OK_Button = value;
			oK_Button = _OK_Button;
			if (oK_Button != null)
			{
				oK_Button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("Cancel_Button")]
	internal virtual Button Cancel_Button
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label1")]
	internal virtual Label Label1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtEnding
	{
		[CompilerGenerated]
		get
		{
			return _txtEnding;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_0;
			EventHandler value3 = method_1;
			TextBox textBox = _txtEnding;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
				textBox.Leave -= value3;
			}
			_txtEnding = value;
			textBox = _txtEnding;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
				textBox.Leave += value3;
			}
		}
	}

	[field: AccessedThroughProperty("Label10")]
	internal virtual Label Label10
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtOutset
	{
		[CompilerGenerated]
		get
		{
			return _txtOutset;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_0;
			EventHandler value3 = method_1;
			TextBox textBox = _txtOutset;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
				textBox.Leave -= value3;
			}
			_txtOutset = value;
			textBox = _txtOutset;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
				textBox.Leave += value3;
			}
		}
	}

	public WafAdd()
	{
		InitializeComponent();
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.OK_Button = new System.Windows.Forms.Button();
		this.Cancel_Button = new System.Windows.Forms.Button();
		this.Label1 = new System.Windows.Forms.Label();
		this.txtEnding = new System.Windows.Forms.TextBox();
		this.Label10 = new System.Windows.Forms.Label();
		this.txtOutset = new System.Windows.Forms.TextBox();
		base.SuspendLayout();
		this.OK_Button.Enabled = false;
		this.OK_Button.Location = new System.Drawing.Point(248, 77);
		this.OK_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.OK_Button.Name = "OK_Button";
		this.OK_Button.Size = new System.Drawing.Size(132, 30);
		this.OK_Button.TabIndex = 45;
		this.OK_Button.Text = "OK";
		this.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.Cancel_Button.Location = new System.Drawing.Point(106, 77);
		this.Cancel_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.Cancel_Button.Name = "Cancel_Button";
		this.Cancel_Button.Size = new System.Drawing.Size(132, 30);
		this.Cancel_Button.TabIndex = 46;
		this.Cancel_Button.Text = "Cancel";
		this.Label1.Location = new System.Drawing.Point(9, 43);
		this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label1.Name = "Label1";
		this.Label1.Size = new System.Drawing.Size(90, 26);
		this.Label1.TabIndex = 48;
		this.Label1.Text = "Ending";
		this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtEnding.Location = new System.Drawing.Point(106, 43);
		this.txtEnding.Name = "txtEnding";
		this.txtEnding.Size = new System.Drawing.Size(274, 26);
		this.txtEnding.TabIndex = 44;
		this.Label10.Location = new System.Drawing.Point(9, 11);
		this.Label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label10.Name = "Label10";
		this.Label10.Size = new System.Drawing.Size(90, 26);
		this.Label10.TabIndex = 47;
		this.Label10.Text = "Outset";
		this.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtOutset.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
		this.txtOutset.Location = new System.Drawing.Point(106, 11);
		this.txtOutset.Name = "txtOutset";
		this.txtOutset.Size = new System.Drawing.Size(274, 26);
		this.txtOutset.TabIndex = 43;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.CancelButton = this.Cancel_Button;
		base.ClientSize = new System.Drawing.Size(388, 115);
		base.Controls.Add(this.OK_Button);
		base.Controls.Add(this.Cancel_Button);
		base.Controls.Add(this.Label1);
		base.Controls.Add(this.txtEnding);
		base.Controls.Add(this.Label10);
		base.Controls.Add(this.txtOutset);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
		base.MinimizeBox = false;
		base.Name = "WafAdd";
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Add WAF";
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void method_0(object sender, EventArgs e)
	{
		OK_Button.Enabled = !string.IsNullOrEmpty(txtOutset.Text) | !string.IsNullOrEmpty(txtEnding.Text);
	}

	private void method_1(object sender, EventArgs e)
	{
		NewLateBinding.LateSet(sender, null, "Text", new object[1] { NewLateBinding.LateGet(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null), null, "Replace", new object[2] { " ", "" }, null, null, null) }, null, null);
	}

	private void method_2(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.OK;
		Close();
	}
}
