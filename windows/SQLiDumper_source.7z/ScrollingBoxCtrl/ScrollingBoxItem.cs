using System.Drawing;

namespace ScrollingBoxCtrl;

public class ScrollingBoxItem
{
	internal RectangleF rectangleF_0;

	public ScrollingBoxItem()
	{
		rectangleF_0 = new RectangleF(0f, 0f, 0f, 0f);
	}
}
