using System;
using System.ComponentModel;
using System.Drawing;
using System.Timers;
using System.Windows.Forms;

namespace ScrollingBoxCtrl;

[ToolboxBitmap("ScrollBoxToolIcon")]
public class ScrollingBox : Control
{
	private System.Timers.Timer timer_0;

	private ScrollingBoxCollection scrollingBoxCollection_0;

	private ArrowDirection arrowDirection_0;

	private bool bool_0;

	private StringFormat stringFormat_0;

	private int int_0;

	private Point point_0;

	private bool bool_1;

	[Browsable(false)]
	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
		}
	}

	[Browsable(false)]
	public ScrollingBoxCollection Items
	{
		get
		{
			return scrollingBoxCollection_0;
		}
		set
		{
			scrollingBoxCollection_0 = value;
		}
	}

	[Browsable(true)]
	[DefaultValue(true)]
	public bool ScrollEnabled
	{
		get
		{
			return timer_0.Enabled;
		}
		set
		{
			int_0 = 0;
			timer_0.Enabled = value;
		}
	}

	[DefaultValue(2)]
	[Browsable(true)]
	public StringAlignment Alignment
	{
		get
		{
			return stringFormat_0.Alignment;
		}
		set
		{
			stringFormat_0.Alignment = value;
			method_0();
			Invalidate();
		}
	}

	public ScrollingBox()
	{
		SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		scrollingBoxCollection_0 = new ScrollingBoxCollection();
		scrollingBoxCollection_0.OnCollectionChanged += scrollingBoxCollection_0_OnCollectionChanged;
		arrowDirection_0 = ArrowDirection.Up;
		bool_0 = false;
		stringFormat_0 = new StringFormat();
		int_0 = 0;
		point_0 = default(Point);
		bool_1 = false;
		timer_0 = new System.Timers.Timer();
		timer_0.Elapsed += timer_0_Elapsed;
		timer_0.Interval = 25.0;
		timer_0.Enabled = true;
	}

	private void scrollingBoxCollection_0_OnCollectionChanged(object sender, EventArgs e)
	{
		method_0();
	}

	private void method_0()
	{
		SizeF sizeF = default(SizeF);
		Graphics graphics = CreateGraphics();
		checked
		{
			int num = base.Width - base.Padding.Left - base.Padding.Right;
			int num2 = scrollingBoxCollection_0.Count - 1;
			for (int i = 0; i <= num2; i++)
			{
				ScrollingBoxItem scrollingBoxItem = scrollingBoxCollection_0[i];
				scrollingBoxItem.rectangleF_0.X = base.Padding.Left;
				scrollingBoxItem.rectangleF_0.Width = num;
				if (scrollingBoxItem is ScrollingBoxText)
				{
					ScrollingBoxText scrollingBoxText = (ScrollingBoxText)scrollingBoxItem;
					sizeF = graphics.MeasureString(scrollingBoxText.Text, Font, num, stringFormat_0);
				}
				else if (scrollingBoxItem is ScrollingBoxImage)
				{
					ScrollingBoxImage scrollingBoxImage = (ScrollingBoxImage)scrollingBoxItem;
					sizeF = scrollingBoxImage.Image.Size;
					scrollingBoxImage.rectangleF_0.Width = sizeF.Width;
					switch (Alignment)
					{
					case StringAlignment.Near:
						scrollingBoxItem.rectangleF_0.X = base.Padding.Left;
						break;
					case StringAlignment.Center:
						scrollingBoxItem.rectangleF_0.X = (float)((double)num / 2.0 - (double)(sizeF.Width / 2f) + (double)base.Padding.Left);
						break;
					case StringAlignment.Far:
						scrollingBoxItem.rectangleF_0.X = (float)base.Width - sizeF.Width - (float)base.Padding.Right;
						break;
					}
				}
				scrollingBoxItem.rectangleF_0.Height = sizeF.Height;
				if (i == 0)
				{
					if (!bool_1)
					{
						scrollingBoxItem.rectangleF_0.Y = base.Height;
						bool_1 = true;
					}
				}
				else
				{
					scrollingBoxItem.rectangleF_0.Y = scrollingBoxCollection_0[i - 1].rectangleF_0.Y + scrollingBoxCollection_0[i - 1].rectangleF_0.Height;
				}
			}
		}
	}

	private void method_1()
	{
		checked
		{
			int num = scrollingBoxCollection_0.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				ScrollingBoxItem scrollingBoxItem = scrollingBoxCollection_0[i];
				if (arrowDirection_0 == ArrowDirection.Up)
				{
					if (scrollingBoxItem.rectangleF_0.Y + scrollingBoxItem.rectangleF_0.Height < 0f)
					{
						if (i == 0)
						{
							scrollingBoxItem.rectangleF_0.Y = scrollingBoxCollection_0[scrollingBoxCollection_0.Count - 1].rectangleF_0.Y + (float)base.Height + scrollingBoxItem.rectangleF_0.Height;
						}
						else
						{
							scrollingBoxItem.rectangleF_0.Y = scrollingBoxCollection_0[i - 1].rectangleF_0.Y + scrollingBoxCollection_0[i - 1].rectangleF_0.Height;
						}
					}
					else
					{
						scrollingBoxItem.rectangleF_0.Y -= 1f;
					}
				}
				else
				{
					if (arrowDirection_0 != ArrowDirection.Down)
					{
						continue;
					}
					if (scrollingBoxItem.rectangleF_0.Y > (float)base.Height)
					{
						if (i == scrollingBoxCollection_0.Count - 1)
						{
							scrollingBoxItem.rectangleF_0.Y = scrollingBoxCollection_0[0].rectangleF_0.Y - (float)base.Height - scrollingBoxItem.rectangleF_0.Height;
						}
						else
						{
							scrollingBoxItem.rectangleF_0.Y = scrollingBoxCollection_0[i + 1].rectangleF_0.Y - scrollingBoxItem.rectangleF_0.Height;
						}
					}
					else
					{
						scrollingBoxItem.rectangleF_0.Y += 1f;
					}
				}
			}
			Invalidate();
		}
	}

	private void timer_0_Elapsed(object sender, ElapsedEventArgs e)
	{
		method_1();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		SolidBrush brush = new SolidBrush(ForeColor);
		RectangleF rectangleF = new RectangleF(e.ClipRectangle.X, e.ClipRectangle.Y, e.ClipRectangle.Width, e.ClipRectangle.Height);
		if (!bool_0)
		{
			graphics.Clear(BackColor);
		}
		else
		{
			graphics.DrawImageUnscaled(BackgroundImage, 0, 0);
		}
		checked
		{
			int num = scrollingBoxCollection_0.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				ScrollingBoxItem scrollingBoxItem = scrollingBoxCollection_0[i];
				if (rectangleF.IntersectsWith(scrollingBoxItem.rectangleF_0))
				{
					if (scrollingBoxItem is ScrollingBoxText)
					{
						graphics.DrawString(((ScrollingBoxText)scrollingBoxItem).Text, Font, brush, scrollingBoxItem.rectangleF_0, stringFormat_0);
					}
					else if (scrollingBoxItem is ScrollingBoxImage)
					{
						graphics.DrawImage(((ScrollingBoxImage)scrollingBoxItem).Image, scrollingBoxItem.rectangleF_0);
					}
				}
			}
			ControlPaint.DrawBorder(graphics, base.ClientRectangle, ControlPaint.Dark(BackColor), ButtonBorderStyle.Solid);
		}
	}

	protected override void OnPaintBackground(PaintEventArgs pevent)
	{
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		method_0();
		Invalidate();
	}

	protected override void OnFontChanged(EventArgs e)
	{
		base.OnFontChanged(e);
		method_0();
		Invalidate();
	}

	protected override void OnBackgroundImageChanged(EventArgs e)
	{
		base.OnBackgroundImageChanged(e);
		if (BackgroundImage == null)
		{
			bool_0 = false;
		}
		else
		{
			bool_0 = true;
		}
	}

	protected override void OnPaddingChanged(EventArgs e)
	{
		base.OnPaddingChanged(e);
		method_0();
		Invalidate();
	}
}
