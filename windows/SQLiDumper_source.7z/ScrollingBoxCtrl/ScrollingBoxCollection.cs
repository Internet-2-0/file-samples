using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;

namespace ScrollingBoxCtrl;

public class ScrollingBoxCollection : CollectionBase
{
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private EventHandler eventHandler_0;

	public ScrollingBoxItem this[int index]
	{
		get
		{
			return (ScrollingBoxItem)base.InnerList[index];
		}
		set
		{
			base.InnerList[index] = value;
		}
	}

	public event EventHandler OnCollectionChanged
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange(ref eventHandler_0, value2, eventHandler2);
			}
			while ((object)eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange(ref eventHandler_0, value2, eventHandler2);
			}
			while ((object)eventHandler != eventHandler2);
		}
	}

	public int Add(ScrollingBoxItem value)
	{
		int result = base.InnerList.Add(value);
		eventHandler_0?.Invoke(this, new EventArgs());
		return result;
	}

	public int Add(string Text)
	{
		return Add(new ScrollingBoxText(Text));
	}

	public void InsertAt(int index, ScrollingBoxItem value)
	{
		base.InnerList.Insert(index, value);
		eventHandler_0?.Invoke(this, new EventArgs());
	}

	public void Remove(ScrollingBoxItem value)
	{
		base.InnerList.Remove(value);
		eventHandler_0?.Invoke(this, new EventArgs());
	}
}
