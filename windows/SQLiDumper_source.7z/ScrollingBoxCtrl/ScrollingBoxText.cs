namespace ScrollingBoxCtrl;

public class ScrollingBoxText : ScrollingBoxItem
{
	private string string_0;

	public string Text
	{
		get
		{
			return string_0;
		}
		set
		{
			string_0 = value;
		}
	}

	public ScrollingBoxText(string Text)
	{
		string_0 = Text;
	}
}
