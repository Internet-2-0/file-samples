using System.Drawing;

namespace ScrollingBoxCtrl;

public class ScrollingBoxImage : ScrollingBoxItem
{
	private Image image_0;

	public Image Image
	{
		get
		{
			return image_0;
		}
		set
		{
			image_0 = value;
		}
	}

	public ScrollingBoxImage(Image Image)
	{
		image_0 = Image;
	}
}
