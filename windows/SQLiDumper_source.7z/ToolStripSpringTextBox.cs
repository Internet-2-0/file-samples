using System;
using System.Drawing;
using System.Windows.Forms;

public class ToolStripSpringTextBox : ToolStripComboBox
{
	private delegate void Delegate14(object sender, EventArgs e);

	private ComboBoxStyle comboBoxStyle_0;

	public ToolStripSpringTextBox(int Style = 0)
	{
		base.Leave += ToolStripSpringTextBox_Leave;
		base.GotFocus += ToolStripSpringTextBox_GotFocus;
		base.DropDownStyle = (ComboBoxStyle)Style;
	}

	private void ToolStripSpringTextBox_Leave(object sender, EventArgs e)
	{
		base.SelectionStart = 0;
	}

	private void ToolStripSpringTextBox_GotFocus(object sender, EventArgs e)
	{
		base.SelectionStart = 0;
	}

	public override Size GetPreferredSize(Size constrainingSize)
	{
		if (base.IsOnOverflow | (base.Owner.Orientation == Orientation.Vertical))
		{
			return DefaultSize;
		}
		int num = base.Owner.DisplayRectangle.Width;
		checked
		{
			if (base.Owner.OverflowButton.Visible)
			{
				num = num - base.Owner.OverflowButton.Width - base.Owner.OverflowButton.Margin.Horizontal;
			}
			int num2 = 0;
			foreach (ToolStripItem item in base.Owner.Items)
			{
				if (!item.IsOnOverflow)
				{
					if (item is ToolStripSpringTextBox)
					{
						num2++;
						num -= item.Margin.Horizontal;
					}
					else
					{
						num = num - item.Width - item.Margin.Horizontal;
					}
				}
			}
			if (num2 > 1)
			{
				num = (int)Math.Round((double)num / (double)num2);
			}
			if (num < DefaultSize.Width)
			{
				num = DefaultSize.Width;
			}
			Size preferredSize = base.GetPreferredSize(constrainingSize);
			preferredSize.Width = num;
			return preferredSize;
		}
	}
}
