using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class DumpGrid : Form
{
	private delegate void Delegate31();

	private delegate string Delegate32(List<string> lValues);

	private delegate bool Delegate33(string sID, int iColumn, string sValue);

	private delegate string Delegate34(string sID);

	private IContainer icontainer_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuListView")]
	private ContextMenuStrip _mnuListView;

	[AccessedThroughProperty("dtgData")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private DataGridView _dtgData;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnExpTXT")]
	[CompilerGenerated]
	private ToolStripButton _btnExpTXT;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnClipboard")]
	[CompilerGenerated]
	private ToolStripButton _btnClipboard;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("ID")]
	[CompilerGenerated]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_1;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private List<string> list_0;

	private DumpExporter dumpExporter_0;

	private Dumper dumper_0;

	private static string string_2;

	internal virtual ContextMenuStrip mnuListView
	{
		[CompilerGenerated]
		get
		{
			return _mnuListView;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_7;
			ContextMenuStrip contextMenuStrip = _mnuListView;
			if (contextMenuStrip != null)
			{
				contextMenuStrip.Opening -= value2;
			}
			_mnuListView = value;
			contextMenuStrip = _mnuListView;
			if (contextMenuStrip != null)
			{
				contextMenuStrip.Opening += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuClipboard")]
	internal virtual ToolStripMenuItem mnuClipboard
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuClipboardAll")]
	internal virtual ToolStripMenuItem mnuClipboardAll
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuNewWindowsSP")]
	internal virtual ToolStripSeparator mnuNewWindowsSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("munClipboardCell")]
	internal virtual ToolStripMenuItem munClipboardCell
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual DataGridView dtgData
	{
		[CompilerGenerated]
		get
		{
			return _dtgData;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DataGridViewRowPostPaintEventHandler value2 = method_9;
			DataGridView dataGridView = _dtgData;
			if (dataGridView != null)
			{
				dataGridView.RowPostPaint -= value2;
			}
			_dtgData = value;
			dataGridView = _dtgData;
			if (dataGridView != null)
			{
				dataGridView.RowPostPaint += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStrip5")]
	internal virtual ToolStrip ToolStrip5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnFullView")]
	public virtual ToolStripButton btnFullView
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSP")]
	internal virtual ToolStripSeparator tsSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnExpTXT
	{
		[CompilerGenerated]
		get
		{
			return _btnExpTXT;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_6;
			ToolStripButton toolStripButton = _btnExpTXT;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnExpTXT = value;
			toolStripButton = _btnExpTXT;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tsSP2")]
	internal virtual ToolStripSeparator tsSP2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnClipboard
	{
		[CompilerGenerated]
		get
		{
			return _btnClipboard;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_8;
			ToolStripButton toolStripButton = _btnClipboard;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnClipboard = value;
			toolStripButton = _btnClipboard;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("btnCloseGrid")]
	public virtual ToolStripButton btnCloseGrid
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnCloseAllGrids")]
	public virtual ToolStripButton btnCloseAllGrids
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnCloseAllButThis")]
	public virtual ToolStripButton btnCloseAllButThis
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_0 = value;
		}
	}

	[field: AccessedThroughProperty("btnAutoScroll")]
	internal virtual ToolStripButton btnAutoScroll
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator15")]
	internal virtual ToolStripSeparator ToolStripSeparator15
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator3")]
	internal virtual ToolStripSeparator ToolStripSeparator3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtResult")]
	internal virtual TextBox txtResult
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSP3")]
	internal virtual ToolStripSeparator tsSP3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal string DataBase
	{
		[CompilerGenerated]
		get
		{
			return string_0;
		}
		[CompilerGenerated]
		set
		{
			string_0 = value;
		}
	}

	internal string Table
	{
		[CompilerGenerated]
		get
		{
			return string_1;
		}
		[CompilerGenerated]
		set
		{
			string_1 = value;
		}
	}

	internal List<string> Columns
	{
		[CompilerGenerated]
		get
		{
			return list_0;
		}
		[CompilerGenerated]
		set
		{
			list_0 = value;
		}
	}

	public DumpGrid(Dumper o)
	{
		base.FormClosing += DumpGrid_FormClosing;
		InitializeComponent();
		dtgData.AllowDrop = false;
		dtgData.AllowUserToAddRows = false;
		dtgData.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
		dtgData.AllowUserToResizeRows = false;
		dtgData.SelectionMode = DataGridViewSelectionMode.CellSelect;
		dtgData.ShowCellErrors = false;
		dtgData.ShowRowErrors = false;
		btnFullView.Tag = this;
		btnCloseAllGrids.Tag = this;
		btnCloseAllButThis.Tag = this;
		btnCloseGrid.Tag = this;
		dumper_0 = o;
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new System.ComponentModel.Container();
		this.mnuListView = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuClipboard = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuClipboardAll = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuNewWindowsSP = new System.Windows.Forms.ToolStripSeparator();
		this.munClipboardCell = new System.Windows.Forms.ToolStripMenuItem();
		this.dtgData = new System.Windows.Forms.DataGridView();
		this.DataGridViewTextBoxColumn_0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.ToolStrip5 = new System.Windows.Forms.ToolStrip();
		this.btnFullView = new System.Windows.Forms.ToolStripButton();
		this.tsSP = new System.Windows.Forms.ToolStripSeparator();
		this.btnAutoScroll = new System.Windows.Forms.ToolStripButton();
		this.tsSP2 = new System.Windows.Forms.ToolStripSeparator();
		this.btnExpTXT = new System.Windows.Forms.ToolStripButton();
		this.tsSP3 = new System.Windows.Forms.ToolStripSeparator();
		this.btnClipboard = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
		this.btnCloseGrid = new System.Windows.Forms.ToolStripButton();
		this.btnCloseAllButThis = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
		this.btnCloseAllGrids = new System.Windows.Forms.ToolStripButton();
		this.txtResult = new System.Windows.Forms.TextBox();
		this.mnuListView.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgData).BeginInit();
		this.ToolStrip5.SuspendLayout();
		base.SuspendLayout();
		this.mnuListView.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuListView.Items.AddRange(new System.Windows.Forms.ToolStripItem[4] { this.mnuClipboard, this.mnuClipboardAll, this.mnuNewWindowsSP, this.munClipboardCell });
		this.mnuListView.Name = "mnuListView";
		this.mnuListView.ShowImageMargin = false;
		this.mnuListView.Size = new System.Drawing.Size(210, 100);
		this.mnuClipboard.Name = "mnuClipboard";
		this.mnuClipboard.Size = new System.Drawing.Size(209, 30);
		this.mnuClipboard.Text = "&Clipboard";
		this.mnuClipboardAll.Name = "mnuClipboardAll";
		this.mnuClipboardAll.Size = new System.Drawing.Size(209, 30);
		this.mnuClipboardAll.Text = "Clipboard &All Rows";
		this.mnuNewWindowsSP.Name = "mnuNewWindowsSP";
		this.mnuNewWindowsSP.Size = new System.Drawing.Size(206, 6);
		this.munClipboardCell.Name = "munClipboardCell";
		this.munClipboardCell.Size = new System.Drawing.Size(209, 30);
		this.munClipboardCell.Text = "Clipboard &Cell(s)";
		this.dtgData.AllowDrop = true;
		this.dtgData.AllowUserToAddRows = false;
		this.dtgData.BackgroundColor = System.Drawing.SystemColors.Window;
		this.dtgData.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.dtgData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.dtgData.Columns.AddRange(this.DataGridViewTextBoxColumn_0);
		this.dtgData.Dock = System.Windows.Forms.DockStyle.Fill;
		this.dtgData.Location = new System.Drawing.Point(0, 32);
		this.dtgData.Name = "dtgData";
		this.dtgData.RowHeadersWidth = 60;
		this.dtgData.ShowCellErrors = false;
		this.dtgData.ShowCellToolTips = false;
		this.dtgData.ShowEditingIcon = false;
		this.dtgData.ShowRowErrors = false;
		this.dtgData.Size = new System.Drawing.Size(825, 463);
		this.dtgData.TabIndex = 15;
		this.DataGridViewTextBoxColumn_0.HeaderText = "ID";
		this.DataGridViewTextBoxColumn_0.Name = "ID";
		this.DataGridViewTextBoxColumn_0.Visible = false;
		this.ToolStrip5.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.ToolStrip5.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.ToolStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[12]
		{
			this.btnFullView, this.tsSP, this.btnAutoScroll, this.tsSP2, this.btnExpTXT, this.tsSP3, this.btnClipboard, this.ToolStripSeparator15, this.btnCloseGrid, this.btnCloseAllButThis,
			this.ToolStripSeparator3, this.btnCloseAllGrids
		});
		this.ToolStrip5.Location = new System.Drawing.Point(0, 0);
		this.ToolStrip5.Name = "ToolStrip5";
		this.ToolStrip5.Size = new System.Drawing.Size(825, 32);
		this.ToolStrip5.TabIndex = 17;
		this.ToolStrip5.Text = "ToolStrip5";
		this.btnFullView.CheckOnClick = true;
		this.btnFullView.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnFullView.Image = ns0.Class6.ViewLandscape_16x_24;
		this.btnFullView.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnFullView.Name = "btnFullView";
		this.btnFullView.Size = new System.Drawing.Size(109, 29);
		this.btnFullView.Text = "&Full View";
		this.tsSP.Name = "tsSP";
		this.tsSP.Size = new System.Drawing.Size(6, 32);
		this.btnAutoScroll.CheckOnClick = true;
		this.btnAutoScroll.Image = ns0.Class6.Download_grey_inverse_24;
		this.btnAutoScroll.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnAutoScroll.Name = "btnAutoScroll";
		this.btnAutoScroll.Size = new System.Drawing.Size(127, 29);
		this.btnAutoScroll.Text = "&Auto Scroll";
		this.tsSP2.Name = "tsSP2";
		this.tsSP2.Size = new System.Drawing.Size(6, 32);
		this.btnExpTXT.Image = ns0.Class6.SaveFileDialogControl_16x_24;
		this.btnExpTXT.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnExpTXT.Name = "btnExpTXT";
		this.btnExpTXT.Size = new System.Drawing.Size(133, 29);
		this.btnExpTXT.Text = "&Export Data";
		this.tsSP3.Name = "tsSP3";
		this.tsSP3.Size = new System.Drawing.Size(6, 32);
		this.btnClipboard.Image = ns0.Class6.clipboard_16xLG;
		this.btnClipboard.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnClipboard.Name = "btnClipboard";
		this.btnClipboard.Size = new System.Drawing.Size(118, 29);
		this.btnClipboard.Text = "&Clipboard";
		this.ToolStripSeparator15.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator15.Name = "ToolStripSeparator15";
		this.ToolStripSeparator15.Size = new System.Drawing.Size(6, 32);
		this.btnCloseGrid.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnCloseGrid.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnCloseGrid.Image = ns0.Class6.CloseSolution_inverse_16x_24;
		this.btnCloseGrid.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnCloseGrid.Name = "btnCloseGrid";
		this.btnCloseGrid.Size = new System.Drawing.Size(121, 29);
		this.btnCloseGrid.Text = "&Close Grid";
		this.btnCloseAllButThis.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnCloseAllButThis.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnCloseAllButThis.Image = ns0.Class6.CloseDocumentGroup_16x_24;
		this.btnCloseAllButThis.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnCloseAllButThis.Name = "btnCloseAllButThis";
		this.btnCloseAllButThis.Size = new System.Drawing.Size(175, 29);
		this.btnCloseAllButThis.Text = "&Close All But This";
		this.ToolStripSeparator3.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator3.Name = "ToolStripSeparator3";
		this.ToolStripSeparator3.Size = new System.Drawing.Size(6, 25);
		this.btnCloseAllGrids.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnCloseAllGrids.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnCloseAllGrids.Image = ns0.Class6.CloseGroup_16x_24;
		this.btnCloseAllGrids.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnCloseAllGrids.Name = "btnCloseAllGrids";
		this.btnCloseAllGrids.Size = new System.Drawing.Size(154, 29);
		this.btnCloseAllGrids.Text = "&Close All Grids";
		this.txtResult.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtResult.Font = new System.Drawing.Font("Courier New", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtResult.Location = new System.Drawing.Point(0, 32);
		this.txtResult.MaxLength = 999999999;
		this.txtResult.Multiline = true;
		this.txtResult.Name = "txtResult";
		this.txtResult.ReadOnly = true;
		this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.txtResult.Size = new System.Drawing.Size(825, 463);
		this.txtResult.TabIndex = 18;
		this.txtResult.Visible = false;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 21f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = System.Drawing.SystemColors.Control;
		base.ClientSize = new System.Drawing.Size(825, 495);
		base.Controls.Add(this.txtResult);
		base.Controls.Add(this.dtgData);
		base.Controls.Add(this.ToolStrip5);
		this.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
		base.MaximizeBox = false;
		base.Name = "DumpGrid";
		base.ShowInTaskbar = false;
		this.Text = "Dump";
		this.mnuListView.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.dtgData).EndInit();
		this.ToolStrip5.ResumeLayout(false);
		this.ToolStrip5.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private string method_0(string string_3)
	{
		if (string.IsNullOrEmpty(string_3))
		{
			return "";
		}
		if (string_3.StartsWith("?~!"))
		{
			string_3 = string_3.Substring("?~!".Length);
		}
		if (string_3.EndsWith("?~!"))
		{
			string_3 = string_3.Substring(0, checked(string_3.Length - "?~!".Length));
		}
		if (string_3.Equals("'"))
		{
			string_3 = "";
		}
		return string_3;
	}

	private string method_1()
	{
		string result;
		try
		{
			result = Text.Substring(checked(Text.LastIndexOf("/") + 1)).Replace("/", "");
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			result = "";
			ProjectData.ClearProjectError();
		}
		return result;
	}

	internal void method_2()
	{
		if (dtgData.InvokeRequired)
		{
			dtgData.Invoke(new Delegate31(method_2));
		}
		else
		{
			if (Columns == null)
			{
				return;
			}
			foreach (string column in Columns)
			{
				DataGridViewTextBoxColumn dataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
				dataGridViewTextBoxColumn.HeaderText = column;
				dtgData.Columns.Add(dataGridViewTextBoxColumn);
			}
		}
	}

	internal string method_3(List<string> list_1)
	{
		if (base.InvokeRequired)
		{
			return Conversions.ToString(Invoke(new Delegate32(method_3), list_1));
		}
		if (txtResult.Visible)
		{
			txtResult.Text = list_1[0];
			return "";
		}
		checked
		{
			string[] array = new string[list_1.Count + 1];
			array[0] = Guid.NewGuid().ToString();
			int num = list_1.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				array[i + 1] = method_0(list_1[i]);
			}
			dtgData.Rows.Add(array);
			if ((dtgData.Rows.Count > 2) & btnAutoScroll.Checked)
			{
				try
				{
					dtgData.FirstDisplayedScrollingRowIndex = dtgData.Rows.Count - 1;
				}
				catch (Exception projectError)
				{
					ProjectData.SetProjectError(projectError);
					ProjectData.ClearProjectError();
				}
			}
			return array[0];
		}
	}

	internal bool method_4(string string_3)
	{
		if (base.InvokeRequired)
		{
			return Conversions.ToBoolean(Invoke((Delegate34)([SpecialName] [DebuggerHidden] (string string_3) => Conversions.ToString(method_4(string_3))), string_3));
		}
		checked
		{
			int num = dtgData.Rows.Count - 1;
			if (num <= 0)
			{
				return false;
			}
			bool flag = default(bool);
			do
			{
				DataGridViewRow dataGridViewRow = dtgData.Rows[num];
				if (!dataGridViewRow.Cells["ID"].Value.ToString().Equals(string_3))
				{
					num--;
					continue;
				}
				int num2 = dataGridViewRow.Cells.Count - 1;
				for (int i = 1; i <= num2; i++)
				{
					flag = ((i != 1) ? (flag & string.IsNullOrEmpty(dataGridViewRow.Cells[i].Value.ToString().Trim())) : string.IsNullOrEmpty(dataGridViewRow.Cells[i].Value.ToString().Trim()));
				}
				return flag;
			}
			while (num >= 0);
			bool result = default(bool);
			return result;
		}
	}

	internal bool method_5(string string_3, int int_0, string string_4)
	{
		if (base.InvokeRequired)
		{
			return Conversions.ToBoolean(Invoke(new Delegate33(method_5), string_3, int_0, string_4));
		}
		checked
		{
			int num = dtgData.Rows.Count - 1;
			do
			{
				DataGridViewRow dataGridViewRow = dtgData.Rows[num];
				if (!dataGridViewRow.Cells["ID"].Value.ToString().Equals(string_3))
				{
					num--;
					continue;
				}
				dataGridViewRow.Cells[int_0 + 1].Value = method_0(string_4);
				return true;
			}
			while (num >= 0);
			bool result = default(bool);
			return result;
		}
	}

	internal void method_6(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				if (txtResult.Visible)
				{
					using (SaveFileDialog saveFileDialog = new SaveFileDialog())
					{
						saveFileDialog.FileName = method_1();
						if (saveFileDialog.ShowDialog() == DialogResult.OK)
						{
							File.WriteAllText(saveFileDialog.FileName, txtResult.Text);
						}
						return;
					}
				}
				if (dtgData.Columns.Count != 0)
				{
					dumpExporter_0 = new DumpExporter(dtgData, Class23.smethod_11(dumper_0.txtURL.Text) + " - " + DataBase + "." + Table + ".txt", dumper_0.txtURL.Text, dumper_0);
					dumpExporter_0.Text = Text;
					dumpExporter_0.StartPosition = FormStartPosition.Manual;
					dumpExporter_0.Top = (int)Math.Round((double)Globals.GMain.Top + (double)Globals.GMain.Height / 2.0 - (double)dumpExporter_0.Height / 2.0);
					dumpExporter_0.Left = (int)Math.Round((double)Globals.GMain.Left + (double)Globals.GMain.Width / 2.0 - (double)dumpExporter_0.Width / 2.0);
					dumpExporter_0.Show(Globals.GMain);
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Class2.Class0_0.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_7(object sender, CancelEventArgs e)
	{
		e.Cancel = dtgData.RowCount == 0;
	}

	private void method_8(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				if (txtResult.Visible)
				{
					Clipboard.SetText(txtResult.Text);
					return;
				}
				string text = "";
				int num = dtgData.SelectedCells.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					DataGridViewCell dataGridViewCell = dtgData.SelectedCells[i];
					text = ((i != 0) ? (text + "\r\n" + dataGridViewCell.Value.ToString()) : dataGridViewCell.Value.ToString());
					dataGridViewCell = null;
				}
				if (!string.IsNullOrEmpty(text))
				{
					Clipboard.SetText(text);
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Class2.Class0_0.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_9(object sender, DataGridViewRowPostPaintEventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					break;
				case 181:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
							goto end_IL_0001_3;
						}
						goto default;
					}
					end_IL_0001_2:
					break;
				}
				num = 2;
				checked
				{
					using (SolidBrush brush = new SolidBrush(dtgData.RowHeadersDefaultCellStyle.ForeColor))
					{
						e.Graphics.DrawString((e.RowIndex + 1).ToString(CultureInfo.CurrentUICulture), dtgData.DefaultCellStyle.Font, brush, e.RowBounds.Location.X + 14, e.RowBounds.Location.Y + 4);
					}
					break;
				}
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 181;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void DumpGrid_FormClosing(object sender, FormClosingEventArgs e)
	{
		if (dumpExporter_0 != null)
		{
			dumpExporter_0.Dispose();
			dumpExporter_0 = null;
		}
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerHidden]
	private string method_10(string string_3)
	{
		return Conversions.ToString(method_4(string_3));
	}
}
