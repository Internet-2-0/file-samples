using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ScrollingBoxCtrl;
using Taskbar;

[StandardModule]
internal sealed class Globals
{
	public delegate object DGetObjectValue(object c);

	public delegate void DSetObjectValue(object c, object value);

	public enum SearchHost : byte
	{
		Google,
		DuckDuckGo,
		Bing,
		Yahoo,
		Ask,
		AOL,
		WOW,
		StartPage,
		Yandex,
		Rambler,
		Search
	}

	public enum WebServer : byte
	{
		UNKNOW,
		LINUX,
		WINDOWS
	}

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	private struct LVITEM
	{
		public int mask;

		public int iItem;

		public int iSubItem;

		public int state;

		public int stateMask;

		[MarshalAs(UnmanagedType.LPTStr)]
		public string pszText;

		public int cchTextMax;

		public int iImage;

		public IntPtr lParam;

		public int iIndent;

		public int iGroupId;

		public int cColumns;

		public IntPtr puColumns;
	}

	private sealed class ShellT
	{
		private string __URL;

		public ShellT(string url)
		{
			int try0006_dispatch = -1;
			int num = default(int);
			int num2 = default(int);
			int num3 = default(int);
			Thread thread = default(Thread);
			while (true)
			{
				try
				{
					/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
					switch (try0006_dispatch)
					{
					default:
						num = 1;
						__URL = url;
						goto IL_0010;
					case 103:
						{
							num2 = num;
							switch ((num3 <= -2) ? 1 : num3)
							{
							case 1:
								break;
							default:
								goto end_IL_0006;
							}
							int num4 = num2 + 1;
							num2 = 0;
							switch (num4)
							{
							case 1:
								break;
							case 2:
								goto IL_0010;
							case 3:
								goto IL_0018;
							case 4:
								goto IL_002c;
							case 5:
								goto end_IL_0006_2;
							default:
								goto end_IL_0006;
							case 6:
								goto end_IL_0006_3;
							}
							goto default;
						}
						IL_0010:
						ProjectData.ClearProjectError();
						num3 = -2;
						goto IL_0018;
						IL_0018:
						num = 3;
						thread = new Thread(IShell);
						goto IL_002c;
						IL_002c:
						num = 4;
						thread.IsBackground = true;
						break;
						end_IL_0006_2:
						break;
					}
					num = 5;
					thread.Start();
					break;
					end_IL_0006:;
				}
				catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
				{
					ProjectData.SetProjectError((Exception)obj);
					try0006_dispatch = 103;
					continue;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				continue;
				end_IL_0006_3:
				break;
			}
			if (num2 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		private void IShell()
		{
			int try0001_dispatch = -1;
			int num3 = default(int);
			int num2 = default(int);
			int num = default(int);
			while (true)
			{
				try
				{
					/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
					switch (try0001_dispatch)
					{
					default:
						ProjectData.ClearProjectError();
						num3 = -2;
						break;
					case 54:
						{
							num2 = num;
							switch ((num3 <= -2) ? 1 : num3)
							{
							case 1:
								break;
							default:
								goto end_IL_0001;
							}
							int num4 = num2 + 1;
							num2 = 0;
							switch (num4)
							{
							case 1:
								break;
							case 2:
								goto end_IL_0001_2;
							default:
								goto end_IL_0001;
							case 3:
								goto end_IL_0001_3;
							}
							goto default;
						}
						end_IL_0001_2:
						break;
					}
					num = 2;
					Process.Start(__URL);
					break;
					end_IL_0001:;
				}
				catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
				{
					ProjectData.SetProjectError((Exception)obj);
					try0001_dispatch = 54;
					continue;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				continue;
				end_IL_0001_3:
				break;
			}
			if (num2 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}
	}

	private sealed class LongExtensions
	{
		private static readonly long[] numberOfBytesInUnit;

		private static readonly Func<long, string>[] bytesToUnitConverters;

		private LongExtensions()
		{
		}

		static LongExtensions()
		{
			numberOfBytesInUnit = new long[6] { 1024L, 1048576L, 1073741824L, 1099511627776L, 1125899906842624L, 1152921504606846976L };
			Func<long, int, string> func = [SpecialName] (long bytes, int shift) => ((double)(bytes >> shift) / 1024.0).ToString("0.###");
			bytesToUnitConverters = new Func<long, string>[7]
			{
				[SpecialName] (long bytes) => bytes + " B",
				[SpecialName] (long bytes) => func(bytes, 0) + " KiB",
				[SpecialName] (long bytes) => func(bytes, 10) + " MiB",
				[SpecialName] (long bytes) => func(bytes, 20) + " GiB",
				[SpecialName] (long bytes) => func(bytes, 30) + " TiB",
				[SpecialName] (long bytes) => func(bytes, 40) + " PiB",
				[SpecialName] (long bytes) => func(bytes, 50) + " EiB"
			};
		}

		public static string ToReadableByteSizeString(long bytes)
		{
			if (bytes <= 0)
			{
				return "0 B";
			}
			int num = 0;
			while (true)
			{
				if (num < numberOfBytesInUnit.Length)
				{
					if (bytes < numberOfBytesInUnit[num])
					{
						break;
					}
					num = checked(num + 1);
					continue;
				}
				return bytesToUnitConverters[num](bytes);
			}
			return bytesToUnitConverters[num](bytes);
		}
	}

	public static string JABBER_KEY;

	public static bool IS_DUMP_INSTANCE;

	public static bool NETWORK_AVAILABLE;

	public static string[] COMMAND_LINE_ARGS;

	public static string CHANGE_LOG_10_1;

	public static string CHANGE_LOG_10_0;

	public static string CHANGE_LOG_9_9;

	public static string CHANGE_LOG_9_8;

	public static string CHANGE_LOG_9_7;

	public static string CHANGE_LOG_9_6;

	public static string CHANGE_LOG_9_5;

	public static string CHANGE_LOG_9_4;

	public static string CHANGE_LOG_9_3;

	public static string CHANGE_LOG_9_2;

	public static string CHANGE_LOG_9_1;

	public static string CHANGE_LOG;

	public static Manager G_Taskbar;

	public static DataGP G_DataGP;

	public static string G_KEY;

	public static Class35 G_SOCKS;

	public static Class40 GTrash;

	public static Class37 GQueue;

	public static Class29 DG_SQLi;

	public static Class29 DG_SQLiNoInjectable;

	public static Class29 DG_FileInclusao;

	public static Class26 GStatistics;

	public static Updater GUpdater;

	public static Translate translate_0;

	public static long CountryBegin;

	public static string[] CountryName;

	public static string[] CountryCode;

	public static readonly string APP_PATH;

	public static readonly string XML_PATH;

	public static readonly string TXT_PATH;

	public static readonly string LNG_PATH;

	public static readonly string SCHEMA_PATH;

	public static readonly string QUEUE_PATH;

	public static readonly string NOTEPAD_PATH;

	public static readonly string SOCKS_PATH;

	public static readonly string CHECKED_PATH;

	public static readonly string TRASH_PATH;

	public static readonly string DIC_LOGIN_FINDER;

	public static readonly Version VERSION;

	public static readonly string APP_VERSION;

	public static MainForm GMain;

	private static int GWL_EXSTYLE;

	private static int WS_EX_CLIENTEDGE;

	private static int WS_EX_STATICEDGE;

	private static int SWP_FRAMECHANGED;

	private static int SWP_NOACTIVATE;

	private static int SWP_NOMOVE;

	private static int SWP_NOSIZE;

	private static int SWP_NOZORDER;

	private static int SWP_DRAWFRAME;

	private static int SWP_FLAGS;

	private static int WM_NCLBUTTONDOWN;

	private static int HT_CAPTION;

	private static int LVM_FIRST;

	private static int LVM_SETITEMSTATE;

	static Globals()
	{
		JABBER_KEY = "c4rl0s@jabber.ru";
		IS_DUMP_INSTANCE = false;
		NETWORK_AVAILABLE = true;
		CountryBegin = 16776960L;
		CountryName = new string[253]
		{
			"Unknown", "Asia/Pacific Region", "Europe", "Andorra", "United Arab Emirates", "Afghanistan", "Antigua and Barbuda", "Anguilla", "Albania", "Armenia",
			"Netherlands Antilles", "Angola", "Antarctica", "Argentina", "American Samoa", "Austria", "Australia", "Aruba", "Azerbaijan", "Bosnia and Herzegovina",
			"Barbados", "Bangladesh", "Belgium", "Burkina Faso", "Bulgaria", "Bahrain", "Burundi", "Benin", "Bermuda", "Brunei Darussalam",
			"Bolivia", "Brazil", "Bahamas", "Bhutan", "Bouvet Island", "Botswana", "Belarus", "Belize", "Canada", "Cocos (Keeling) Islands",
			"Congo, The Democratic Republic of the", "Central African Republic", "Congo", "Switzerland", "Cote D'Ivoire", "Cook Islands", "Chile", "Cameroon", "China", "Colombia",
			"Costa Rica", "Cuba", "Cape Verde", "Christmas Island", "Cyprus", "Czech Republic", "Germany", "Djibouti", "Denmark", "Dominica",
			"Dominican Republic", "Algeria", "Ecuador", "Estonia", "Egypt", "Western Sahara", "Eritrea", "Spain", "Ethiopia", "Finland",
			"Fiji", "Falkland Islands (Malvinas)", "Micronesia, Federated States of", "Faroe Islands", "France", "France, Metropolitan", "Gabon", "United Kingdom", "Grenada", "Georgia",
			"French Guiana", "Ghana", "Gibraltar", "Greenland", "Gambia", "Guinea", "Guadeloupe", "Equatorial Guinea", "Greece", "South Georgia and the South Sandwich Islands",
			"Guatemala", "Guam", "Guinea-Bissau", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti", "Hungary",
			"Indonesia", "Ireland", "Israel", "India", "British Indian Ocean Territory", "Iraq", "Iran, Islamic Republic of", "Iceland", "Italy", "Jamaica",
			"Jordan", "Japan", "Kenya", "Kyrgyzstan", "Cambodia", "Kiribati", "Comoros", "Saint Kitts and Nevis", "Korea, Democratic People's Republic of", "Korea, Republic of",
			"Kuwait", "Cayman Islands", "Kazakstan", "Lao People's Democratic Republic", "Lebanon", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Liberia", "Lesotho",
			"Lithuania", "Luxembourg", "Latvia", "Libyan Arab Jamahiriya", "Morocco", "Monaco", "Moldova, Republic of", "Madagascar", "Marshall Islands", "Macedonia, the Former Yugoslav Republic of",
			"Mali", "Myanmar", "Mongolia", "Macao", "Northern Mariana Islands", "Martinique", "Mauritania", "Montserrat", "Malta", "Mauritius",
			"Maldives", "Malawi", "Mexico", "Malaysia", "Mozambique", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria",
			"Nicaragua", "Netherlands", "Norway", "Nepal", "Nauru", "Niue", "New Zealand", "Oman", "Panama", "Peru",
			"French Polynesia", "Papua New Guinea", "Philippines", "Pakistan", "Poland", "Saint Pierre and Miquelon", "Pitcairn", "Puerto Rico", "Palestinian Territory, Occupied", "Portugal",
			"Palau", "Paraguay", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saudi Arabia", "Solomon Islands", "Seychelles",
			"Sudan", "Sweden", "Singapore", "Saint Helena", "Slovenia", "Svalbard and Jan Mayen", "Slovakia", "Sierra Leone", "San Marino", "Senegal",
			"Somalia", "Suriname", "Sao Tome and Principe", "El Salvador", "Syrian Arab Republic", "Swaziland", "Turks and Caicos Islands", "Chad", "French Southern Territories", "Togo",
			"Thailand", "Tajikistan", "Tokelau", "Turkmenistan", "Tunisia", "Tonga", "Timor-Leste", "Turkey", "Trinidad and Tobago", "Tuvalu",
			"Taiwan, Province of China", "Tanzania, United Republic of", "Ukraine", "Uganda", "United States Minor Outlying Islands", "United States", "Uruguay", "Uzbekistan", "Holy See (Vatican City State)", "Saint Vincent and the Grenadines",
			"Venezuela", "Virgin Islands, British", "Virgin Islands, U.S.", "Vietnam", "Vanuatu", "Wallis and Futuna", "Samoa", "Yemen", "Mayotte", "Yugoslavia",
			"South Africa", "Zambia", "Montenegro", "Zimbabwe", "Anonymous Proxy", "Satellite Provider", "Other", "Aland Islands", "Guernsey", "Isle of Man",
			"Jersey", "Saint Barthelemy", "Saint Martin"
		};
		CountryCode = new string[253]
		{
			"--", "AP", "EU", "AD", "AE", "AF", "AG", "AI", "AL", "AM",
			"AN", "AO", "AQ", "AR", "AS", "AT", "AU", "AW", "AZ", "BA",
			"BB", "BD", "BE", "BF", "BG", "BH", "BI", "BJ", "BM", "BN",
			"BO", "BR", "BS", "BT", "BV", "BW", "BY", "BZ", "CA", "CC",
			"CD", "CF", "CG", "CH", "CI", "CK", "CL", "CM", "CN", "CO",
			"CR", "CU", "CV", "CX", "CY", "CZ", "DE", "DJ", "DK", "DM",
			"DO", "DZ", "EC", "EE", "EG", "EH", "ER", "ES", "ET", "FI",
			"FJ", "FK", "FM", "FO", "FR", "FX", "GA", "GB", "GD", "GE",
			"GF", "GH", "GI", "GL", "GM", "GN", "GP", "GQ", "GR", "GS",
			"GT", "GU", "GW", "GY", "HK", "HM", "HN", "HR", "HT", "HU",
			"ID", "IE", "IL", "IN", "IO", "IQ", "IR", "IS", "IT", "JM",
			"JO", "JP", "KE", "KG", "KH", "KI", "KM", "KN", "KP", "KR",
			"KW", "KY", "KZ", "LA", "LB", "LC", "LI", "LK", "LR", "LS",
			"LT", "LU", "LV", "LY", "MA", "MC", "MD", "MG", "MH", "MK",
			"ML", "MM", "MN", "MO", "MP", "MQ", "MR", "MS", "MT", "MU",
			"MV", "MW", "MX", "MY", "MZ", "NA", "NC", "NE", "NF", "NG",
			"NI", "NL", "NO", "NP", "NR", "NU", "NZ", "OM", "PA", "PE",
			"PF", "PG", "PH", "PK", "PL", "PM", "PN", "PR", "PS", "PT",
			"PW", "PY", "QA", "RE", "RO", "RU", "RW", "SA", "SB", "SC",
			"SD", "SE", "SG", "SH", "SI", "SJ", "SK", "SL", "SM", "SN",
			"SO", "SR", "ST", "SV", "SY", "SZ", "TC", "TD", "TF", "TG",
			"TH", "TJ", "TK", "TM", "TN", "TO", "TL", "TR", "TT", "TV",
			"TW", "TZ", "UA", "UG", "UM", "US", "UY", "UZ", "VA", "VC",
			"VE", "VG", "VI", "VN", "VU", "WF", "WS", "YE", "YT", "RS",
			"ZA", "ZM", "ME", "ZW", "A1", "A2", "O1", "AX", "GG", "IM",
			"JE", "BL", "MF"
		};
		APP_PATH = Application.StartupPath;
		XML_PATH = APP_PATH + "\\Settings.xml";
		TXT_PATH = APP_PATH + "\\TXT\\";
		LNG_PATH = APP_PATH + "\\LNG\\";
		SCHEMA_PATH = APP_PATH + "\\XML\\";
		QUEUE_PATH = TXT_PATH + "Queue.txt";
		NOTEPAD_PATH = TXT_PATH + "Notepad.txt";
		SOCKS_PATH = TXT_PATH + "Proxies.txt";
		CHECKED_PATH = TXT_PATH + "Checkeds.txt";
		TRASH_PATH = TXT_PATH + "Trash.txt";
		DIC_LOGIN_FINDER = TXT_PATH + "DicLoginFinder.txt";
		VERSION = new Version(10, 1, 0);
		APP_VERSION = string.Concat(Class2.Class0_0.Info.ProductName, " AngelSecurityTeam", null, null, null, null);
		GMain = new MainForm();
	}

	[DllImport("user32.dll")]
	public static extern int SendMessage(IntPtr hWnd, int wMsg, bool wParam, int lParam);

	[DllImport("user32.dll")]
	public static extern bool LockWindowUpdate(IntPtr hWndLock);

	[DllImport("user32.dll")]
	private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

	[DllImport("user32.dll")]
	private static extern uint GetWindowLong(IntPtr hWnd, int nIndex);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int int_0, int int_1, int cx, int cy, uint uFlags);

	[DllImport("user32.dll")]
	public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

	[DllImport("user32.dll")]
	private static extern bool ReleaseCapture();

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern int SetProcessWorkingSetSize(IntPtr hProcess, int dwMinimumWorkingSetSize, int dwMaximumWorkingSetSize);

	[DllImport("psapi.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern int EmptyWorkingSet(IntPtr hwProc);

	[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "SendMessage")]
	private static extern IntPtr SendMessage_1(IntPtr hWnd, int msg, int wParam, ref LVITEM lvi);

	public static void SelectAllItemsLVW(ListViewExt lvw)
	{
		SetItemState(lvw, -1, 2, 2);
	}

	private static void SetItemState(ListViewExt list, int itemIndex, int mask, int value)
	{
		LVITEM lvi = default(LVITEM);
		lvi.stateMask = mask;
		lvi.state = value;
		SendMessage_1(list.Handle, 4139, itemIndex, ref lvi);
	}

	public static bool LockWindowUpdateForced(bool bState)
	{
		return SendMessage(GMain.Handle, 11, bState, 0) > 0;
	}

	public static void ReleaseMemory()
	{
		try
		{
			GC.Collect();
			GC.WaitForPendingFinalizers();
			if (Environment.OSVersion.Platform == PlatformID.Win32NT)
			{
				EmptyWorkingSet(Process.GetCurrentProcess().Handle);
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	public static void ListBoxSelectAll(ListBox l, bool b)
	{
		SendMessage(l.Handle, 389, b, -1);
	}

	public static void AddMouseMove(object sender, MouseEventArgs e)
	{
		if (e.Button != MouseButtons.Left)
		{
			return;
		}
		Form form = null;
		if (sender is ToolStripLabel)
		{
			sender = ((ToolStripLabel)sender).GetCurrentParent().FindForm();
		}
		else if (sender is ToolStripStatusLabel)
		{
			sender = ((ToolStripStatusLabel)sender).GetCurrentParent().FindForm();
		}
		checked
		{
			if ((sender is Form) & (GMain != null))
			{
				form = ((sender == GMain.DumperForm) ? GMain : ((sender == GMain.LoginFinderForm) ? GMain : ((sender == GMain.DumperForm) ? GMain : ((sender != GMain.AnalizerForm) ? ((Form)sender) : GMain))));
			}
			else if (sender is Control)
			{
				Form form2 = ((Control)sender).FindForm();
				int num = Application.OpenForms.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (form2 == null)
					{
						break;
					}
					form = form2;
					if (form is MainForm)
					{
						break;
					}
					form2 = form2.ParentForm;
				}
			}
			else
			{
				form = GMain;
			}
			if (form != null)
			{
				ReleaseCapture();
				SendMessage(form.Handle, 161, 2, 0);
			}
		}
	}

	public static void AddMouseMoveForm(Form f)
	{
		f.MouseDown += AddMouseMove;
		foreach (object value in Class50.smethod_6(f).Values)
		{
			object objectValue = RuntimeHelpers.GetObjectValue(value);
			bool flag;
			if ((flag = true) == objectValue is Panel || flag == objectValue is Label || flag == objectValue is PictureBox || flag == objectValue is ProgressBar || flag == objectValue is GroupBox || flag == objectValue is ScrollingBox || flag == objectValue is ToolStrip)
			{
				if (objectValue is ToolStrip)
				{
					foreach (ToolStripItem item in ((ToolStrip)objectValue).Items)
					{
						bool flag2;
						if ((flag2 = true) == item is ToolStripStatusLabel || flag2 == item is ToolStripLabel || flag2 == item is ToolStripSeparator || flag2 == item is ToolStripProgressBar)
						{
							item.MouseDown += AddMouseMove;
						}
					}
				}
				if (objectValue is Control)
				{
					((Control)objectValue).MouseDown += AddMouseMove;
				}
			}
			if (objectValue is ToolStrip)
			{
				ToolStrip toolStrip = (ToolStrip)objectValue;
				toolStrip.ImageScalingSize = new Size(16, 16);
				toolStrip.BackgroundImageLayout = ImageLayout.None;
				toolStrip.RenderMode = ToolStripRenderMode.System;
				toolStrip.AutoSize = false;
				toolStrip.Height = 23;
				foreach (ToolStripItem item2 in ((ToolStrip)objectValue).Items)
				{
					item2.AutoSize = true;
					item2.BackgroundImageLayout = ImageLayout.None;
				}
				toolStrip.RenderMode = ToolStripRenderMode.ManagerRenderMode;
				toolStrip = null;
			}
			else if (objectValue is MenuStrip)
			{
				MenuStrip menuStrip = (MenuStrip)objectValue;
				menuStrip.ImageScalingSize = new Size(16, 16);
				menuStrip.RenderMode = ToolStripRenderMode.ManagerRenderMode;
				menuStrip = null;
			}
			else if (objectValue is ContextMenuStrip)
			{
				ContextMenuStrip contextMenuStrip = (ContextMenuStrip)objectValue;
				contextMenuStrip.ImageScalingSize = new Size(16, 16);
				contextMenuStrip.RenderMode = ToolStripRenderMode.ManagerRenderMode;
				contextMenuStrip = null;
			}
			else if (objectValue is StatusStrip)
			{
				StatusStrip statusStrip = (StatusStrip)objectValue;
				statusStrip.ImageScalingSize = new Size(16, 16);
				statusStrip.RenderMode = ToolStripRenderMode.ManagerRenderMode;
				statusStrip.AutoSize = true;
				statusStrip = null;
			}
			else if (!(objectValue is Button) && objectValue is DataGridView)
			{
				((DataGridView)objectValue).BorderStyle = BorderStyle.None;
			}
		}
	}

	public static object GetObjectValue(object c)
	{
		if (!GMain.bool_2)
		{
			return null;
		}
		if (GMain.InvokeRequired)
		{
			return GMain.Invoke(new DGetObjectValue(GetObjectValue), c);
		}
		bool flag;
		if ((flag = true) == c is ComboBox)
		{
			return ((ComboBox)c).SelectedIndex;
		}
		if (flag == c is ToolStripComboBox)
		{
			return ((ToolStripComboBox)c).Text;
		}
		if (flag == c is TextBox)
		{
			return ((TextBox)c).Text;
		}
		if (flag == c is Label)
		{
			return ((Label)c).Text;
		}
		if (flag == c is CheckBox)
		{
			return ((CheckBox)c).Checked;
		}
		if (flag == c is RadioButton)
		{
			return ((RadioButton)c).Checked;
		}
		if (flag == c is ToolStripButton)
		{
			return ((ToolStripButton)c).Checked;
		}
		if (flag == c is ToolStripLabel)
		{
			return ((ToolStripLabel)c).Text;
		}
		if (flag == c is NumericUpDown)
		{
			return ((NumericUpDown)c).Value;
		}
		if (flag == c is TrackBar)
		{
			return ((TrackBar)c).Value;
		}
		if (flag == c is TreeViewExt)
		{
			return ((TreeViewExt)c).Handle;
		}
		if (flag == c is ListBox)
		{
			return ((ListBox)c).Items;
		}
		if (flag == c is DataGridView)
		{
			return ((DataGridView)c).Rows;
		}
		if (flag == c is ListViewExt)
		{
			ListViewItem[] array = new ListViewItem[checked(((ListViewExt)c).Items.Count - 1 + 1)];
			((ListViewExt)c).Items.CopyTo(array, 0);
			return array;
		}
		if (flag == c is ToolStripSpringTextBox)
		{
			return ((ToolStripSpringTextBox)c).Text;
		}
		throw new Exception("Bad Changed GetObjectValue");
	}

	public static void SetObjectValue(object c, object v)
	{
		if (GMain.InvokeRequired)
		{
			GMain.Invoke(new DSetObjectValue(SetObjectValue), c, v);
			return;
		}
		bool flag;
		if ((flag = true) == c is ComboBox)
		{
			((ComboBox)c).SelectedIndex = Conversions.ToInteger(v);
			return;
		}
		if (flag == c is ToolStripComboBox)
		{
			((ToolStripComboBox)c).SelectedItem = RuntimeHelpers.GetObjectValue(v);
			return;
		}
		if (flag == c is TextBox)
		{
			((TextBox)c).Text = Conversions.ToString(v);
			return;
		}
		if (flag == c is Label)
		{
			((Label)c).Text = Conversions.ToString(v);
			return;
		}
		if (flag == c is CheckBox)
		{
			((CheckBox)c).Checked = Conversions.ToBoolean(v);
			return;
		}
		if (flag == c is RadioButton)
		{
			((RadioButton)c).Checked = Conversions.ToBoolean(v);
			return;
		}
		if (flag == c is ToolStripButton)
		{
			((ToolStripButton)c).Checked = Conversions.ToBoolean(v);
			return;
		}
		if (flag == c is ToolStripLabel)
		{
			if (v is string)
			{
				((ToolStripLabel)c).Text = Conversions.ToString(v);
			}
			else
			{
				((ToolStripLabel)c).Image = (Image)v;
			}
			return;
		}
		if (flag == c is NumericUpDown)
		{
			((NumericUpDown)c).Value = Conversions.ToDecimal(v);
			return;
		}
		if (flag == c is TrackBar)
		{
			((TrackBar)c).Value = Conversions.ToInteger(v);
			return;
		}
		if (flag == c is WebBrowser)
		{
			((WebBrowser)c).DocumentText = Conversions.ToString(v);
			return;
		}
		if (flag == c is TabPage)
		{
			((TabPage)c).Text = Conversions.ToString(v);
			return;
		}
		throw new Exception("Bad Changed SetObjectValue");
	}

	public static void SetFlatBorder(Control c)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		long num5 = default(long);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 166:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_001b;
						case 4:
							goto IL_002d;
						case 5:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 6:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					num5 = GetWindowLong(c.Handle, -20);
					goto IL_001b;
					IL_001b:
					num = 3;
					num5 = (num5 & -513) | 0x20000;
					goto IL_002d;
					IL_002d:
					num = 4;
					SetWindowLong(c.Handle, -20, checked((int)num5));
					break;
					end_IL_0001_2:
					break;
				}
				num = 5;
				SetWindowPos(c.Handle, IntPtr.Zero, (int)IntPtr.Zero, (int)IntPtr.Zero, (int)IntPtr.Zero, (int)IntPtr.Zero, 55u);
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 166;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	public static int FormatPercentage(int curValue, int totalValue)
	{
		return checked((int)Math.Round(Math.Round((double)(100 * curValue) / (double)totalValue)));
	}

	public static string FormatNumbers(int i, bool bIgnoreZero = true)
	{
		try
		{
			string text = Strings.FormatNumber(i, 0);
			if (bIgnoreZero && text.Equals("0"))
			{
				text = "";
			}
			return text;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return "";
	}

	public static string FormatStr(string value)
	{
		if (string.IsNullOrEmpty(value))
		{
			return "";
		}
		StringBuilder stringBuilder = new StringBuilder();
		string[] array = value.Split(' ');
		foreach (string text in array)
		{
			bool flag = false;
			if (text.Length > 2)
			{
				char[] array2 = text.ToCharArray();
				int num = 0;
				if (num < array2.Length)
				{
					char c = array2[num];
					flag = char.IsLetter(c) & char.IsLower(c);
				}
			}
			if (flag)
			{
				stringBuilder.Append(CultureInfo.CurrentCulture.TextInfo.ToTitleCase(text));
			}
			else
			{
				stringBuilder.Append(text);
			}
			stringBuilder.Append(' ');
		}
		return stringBuilder.ToString();
	}

	public static bool ValideIP(string sIP)
	{
		try
		{
			sIP = sIP.Split(':')[0].Trim();
			Match match = Regex.Match(sIP, "^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$", RegexOptions.IgnoreCase);
			return match.Success;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return false;
	}

	public static string FormatBytes(double bytes)
	{
		if (bytes >= 1125899906842624.0)
		{
			return Conversions.ToString(Math.Round(bytes / 1125899906842624.0, 2)) + " PiB";
		}
		if (bytes >= 1099511627776.0)
		{
			return Conversions.ToString(Math.Round(bytes / 1099511627776.0, 2)) + " TiB";
		}
		if (bytes >= 1073741824.0)
		{
			return Conversions.ToString(Math.Round(bytes / 1073741824.0, 2)) + " GiB";
		}
		if (bytes >= 1048576.0)
		{
			return Conversions.ToString(Math.Round(bytes / 1048576.0, 2)) + " MiB";
		}
		if (bytes >= 1024.0)
		{
			return Conversions.ToString(Math.Round(bytes / 1024.0, 0)) + " KiB";
		}
		return Conversions.ToString(bytes) + " Bytes";
	}

	public static void ShellUrl(string url)
	{
		new ShellT(url);
	}
}
