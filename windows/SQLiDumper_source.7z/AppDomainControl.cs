using System;
using System.Collections.Generic;
using Microsoft.VisualBasic.CompilerServices;

public class AppDomainControl
{
	public static int MAX_CALLER;

	private List<HTTPExt> FreeSlot;

	private List<HTTPExt> InUseSlot;

	public int ProcessCreated { get; set; }

	public AppDomainControl()
	{
		FreeSlot = new List<HTTPExt>();
		InUseSlot = new List<HTTPExt>();
	}

	public HTTPExt GetHTTP()
	{
		checked
		{
			HTTPExt hTTPExt;
			lock (FreeSlot)
			{
				if (FreeSlot.Count == 0)
				{
					ProcessCreated++;
					hTTPExt = new HTTPExt(bFullIsolated: true);
					InUseSlot.Add(hTTPExt);
				}
				else
				{
					hTTPExt = FreeSlot[0];
					FreeSlot.Remove(hTTPExt);
					InUseSlot.Add(hTTPExt);
				}
			}
			return hTTPExt;
		}
	}

	public void Abort()
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					break;
				case 136:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
							goto end_IL_0001_3;
						}
						goto default;
					}
					end_IL_0001_2:
					break;
				}
				num = 2;
				lock (InUseSlot)
				{
					foreach (HTTPExt item in InUseSlot)
					{
						item?.Abort();
					}
				}
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 136;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	public void Terminate()
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 245:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 4:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					lock (FreeSlot)
					{
						foreach (HTTPExt item in FreeSlot)
						{
							if (item != null)
							{
								item.Dispose();
								HTTPExt current = null;
							}
						}
					}
					break;
					end_IL_0001_2:
					break;
				}
				num = 3;
				lock (InUseSlot)
				{
					foreach (HTTPExt item2 in InUseSlot)
					{
						if (item2 != null)
						{
							item2.Dispose();
							HTTPExt current2 = null;
						}
					}
				}
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 245;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	public void Dispose(HTTPExt h)
	{
		if (h == null)
		{
			return;
		}
		InUseSlot.Remove(h);
		if (h.TotalRequest > 100 || h.TotalRequestFailed > 100)
		{
			h.Dispose();
			h = null;
			return;
		}
		lock (FreeSlot)
		{
			FreeSlot.Add(h);
		}
	}

	public int GetTotalRunning()
	{
		return InUseSlot.Count;
	}

	public int GetProcessCreated()
	{
		return ProcessCreated;
	}
}
