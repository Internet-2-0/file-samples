using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

public class ToolStripControl : ToolStripControlHost
{
	private NumericUpDown numericUpDown_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private EventHandler eventHandler_0;

	public decimal Value
	{
		get
		{
			return numericUpDown_0.Value;
		}
		set
		{
			numericUpDown_0.Value = value;
		}
	}

	public new NumericUpDown Control => numericUpDown_0;

	public Control NumericUpDownControl => Control;

	public event EventHandler ValueChanged
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange(ref eventHandler_0, value2, eventHandler2);
			}
			while ((object)eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = eventHandler_0;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange(ref eventHandler_0, value2, eventHandler2);
			}
			while ((object)eventHandler != eventHandler2);
		}
	}

	public ToolStripControl(NumericUpDown n)
		: base(n)
	{
		numericUpDown_0 = n;
	}

	private void method_0(object sender, EventArgs e)
	{
		base.Visible = ((NumericUpDown)sender).Visible;
	}

	protected override void OnSubscribeControlEvents(Control control)
	{
		base.OnSubscribeControlEvents(control);
		((NumericUpDown)control).ValueChanged += OnValueChanged;
	}

	protected override void OnUnsubscribeControlEvents(Control control)
	{
		base.OnUnsubscribeControlEvents(control);
		((NumericUpDown)control).ValueChanged += OnValueChanged;
		((NumericUpDown)control).VisibleChanged += method_0;
	}

	public void OnValueChanged(object sender, EventArgs e)
	{
		eventHandler_0?.Invoke(this, e);
	}
}
