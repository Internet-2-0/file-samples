using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using Taskbar;

[DesignerGenerated]
public class DumpLoading : Form
{
	private delegate void Delegate37(string s);

	private delegate void Delegate38(ProgressBarStyle i);

	private delegate void Delegate39(object sender, EventArgs e);

	private delegate void Delegate40(int perc, ref bool bCancel);

	public delegate void OnPauseEventHandler(bool bPaused);

	public delegate void OnCancelEventHandler();

	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbPause")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _tsbPause;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("tsbStop")]
	private ToolStripButton _tsbStop;

	private bool bool_0;

	private bool bool_1;

	private Form form_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private OnPauseEventHandler onPauseEventHandler_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private OnCancelEventHandler onCancelEventHandler_0;

	[field: AccessedThroughProperty("prgStatus")]
	internal virtual ProgressBar prgStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbBack")]
	internal virtual GroupBox grbBack
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton tsbPause
	{
		[CompilerGenerated]
		get
		{
			return _tsbPause;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_3;
			ToolStripButton toolStripButton = _tsbPause;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_tsbPause = value;
			toolStripButton = _tsbPause;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton tsbStop
	{
		[CompilerGenerated]
		get
		{
			return _tsbStop;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_4;
			ToolStripButton toolStripButton = _tsbStop;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_tsbStop = value;
			toolStripButton = _tsbStop;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tstMain")]
	public virtual ToolStrip tstMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal bool Boolean_0 => bool_0;

	internal bool Boolean_1 => bool_1;

	public event OnPauseEventHandler OnPause
	{
		[CompilerGenerated]
		add
		{
			OnPauseEventHandler onPauseEventHandler = onPauseEventHandler_0;
			OnPauseEventHandler onPauseEventHandler2;
			do
			{
				onPauseEventHandler2 = onPauseEventHandler;
				OnPauseEventHandler value2 = (OnPauseEventHandler)Delegate.Combine(onPauseEventHandler2, value);
				onPauseEventHandler = Interlocked.CompareExchange(ref onPauseEventHandler_0, value2, onPauseEventHandler2);
			}
			while ((object)onPauseEventHandler != onPauseEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			OnPauseEventHandler onPauseEventHandler = onPauseEventHandler_0;
			OnPauseEventHandler onPauseEventHandler2;
			do
			{
				onPauseEventHandler2 = onPauseEventHandler;
				OnPauseEventHandler value2 = (OnPauseEventHandler)Delegate.Remove(onPauseEventHandler2, value);
				onPauseEventHandler = Interlocked.CompareExchange(ref onPauseEventHandler_0, value2, onPauseEventHandler2);
			}
			while ((object)onPauseEventHandler != onPauseEventHandler2);
		}
	}

	public event OnCancelEventHandler OnCancel
	{
		[CompilerGenerated]
		add
		{
			OnCancelEventHandler onCancelEventHandler = onCancelEventHandler_0;
			OnCancelEventHandler onCancelEventHandler2;
			do
			{
				onCancelEventHandler2 = onCancelEventHandler;
				OnCancelEventHandler value2 = (OnCancelEventHandler)Delegate.Combine(onCancelEventHandler2, value);
				onCancelEventHandler = Interlocked.CompareExchange(ref onCancelEventHandler_0, value2, onCancelEventHandler2);
			}
			while ((object)onCancelEventHandler != onCancelEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			OnCancelEventHandler onCancelEventHandler = onCancelEventHandler_0;
			OnCancelEventHandler onCancelEventHandler2;
			do
			{
				onCancelEventHandler2 = onCancelEventHandler;
				OnCancelEventHandler value2 = (OnCancelEventHandler)Delegate.Remove(onCancelEventHandler2, value);
				onCancelEventHandler = Interlocked.CompareExchange(ref onCancelEventHandler_0, value2, onCancelEventHandler2);
			}
			while ((object)onCancelEventHandler != onCancelEventHandler2);
		}
	}

	public DumpLoading(Form fOwner, ProgressBarStyle pBarStyle = ProgressBarStyle.Blocks)
	{
		base.Load += DumpLoading_Load;
		form_0 = fOwner;
		InitializeComponent();
		prgStatus.Value = 0;
		prgStatus.Maximum = 100;
		prgStatus.Style = pBarStyle;
		prgStatus.BringToFront();
		prgStatus.Visible = true;
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.grbBack = new System.Windows.Forms.GroupBox();
		this.prgStatus = new System.Windows.Forms.ProgressBar();
		this.tstMain = new System.Windows.Forms.ToolStrip();
		this.tsbPause = new System.Windows.Forms.ToolStripButton();
		this.tsbStop = new System.Windows.Forms.ToolStripButton();
		this.grbBack.SuspendLayout();
		this.tstMain.SuspendLayout();
		base.SuspendLayout();
		this.grbBack.Controls.Add(this.prgStatus);
		this.grbBack.Controls.Add(this.tstMain);
		this.grbBack.Dock = System.Windows.Forms.DockStyle.Bottom;
		this.grbBack.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.grbBack.ForeColor = System.Drawing.SystemColors.ControlText;
		this.grbBack.Location = new System.Drawing.Point(0, 33);
		this.grbBack.MinimumSize = new System.Drawing.Size(0, 16);
		this.grbBack.Name = "grbBack";
		this.grbBack.Size = new System.Drawing.Size(636, 45);
		this.grbBack.TabIndex = 0;
		this.grbBack.TabStop = false;
		this.grbBack.Text = "Loading, please wait..";
		this.prgStatus.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.prgStatus.Location = new System.Drawing.Point(10, 15);
		this.prgStatus.Name = "prgStatus";
		this.prgStatus.Size = new System.Drawing.Size(484, 19);
		this.prgStatus.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
		this.prgStatus.TabIndex = 0;
		this.tstMain.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.tstMain.AutoSize = false;
		this.tstMain.Dock = System.Windows.Forms.DockStyle.None;
		this.tstMain.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tstMain.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tstMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.tsbPause, this.tsbStop });
		this.tstMain.Location = new System.Drawing.Point(4, 13);
		this.tstMain.Name = "tstMain";
		this.tstMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tstMain.Size = new System.Drawing.Size(628, 25);
		this.tstMain.TabIndex = 1;
		this.tstMain.Text = "ToolStrip1";
		this.tsbPause.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.tsbPause.CheckOnClick = true;
		this.tsbPause.Image = ns0.Class6.Pause_16x_24;
		this.tsbPause.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.tsbPause.Name = "tsbPause";
		this.tsbPause.Size = new System.Drawing.Size(85, 22);
		this.tsbPause.Text = "&Pause";
		this.tsbStop.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.tsbStop.Image = ns0.Class6.Stop_16x_24;
		this.tsbStop.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.tsbStop.Name = "tsbStop";
		this.tsbStop.Size = new System.Drawing.Size(91, 22);
		this.tsbStop.Text = "&Cancel";
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 21f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = System.Drawing.SystemColors.Control;
		base.ClientSize = new System.Drawing.Size(636, 78);
		base.ControlBox = false;
		base.Controls.Add(this.grbBack);
		this.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Name = "DumpLoading";
		base.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
		this.grbBack.ResumeLayout(false);
		this.tstMain.ResumeLayout(false);
		this.tstMain.PerformLayout();
		base.ResumeLayout(false);
	}

	internal void method_0(int int_0, ref bool bool_2)
	{
		if (base.InvokeRequired)
		{
			Invoke(new Delegate40(method_0), int_0, bool_2);
			return;
		}
		if (int_0 > 0)
		{
			prgStatus.Value = int_0;
			if (!Globals.GMain.Boolean_1)
			{
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Normal);
				Globals.G_Taskbar.SetProgressValue(int_0, 100);
			}
		}
		bool_2 = bool_0;
	}

	internal void method_1(ProgressBarStyle progressBarStyle_0)
	{
		if (prgStatus.InvokeRequired)
		{
			prgStatus.Invoke(new Delegate38(method_1), progressBarStyle_0);
			return;
		}
		prgStatus.Style = progressBarStyle_0;
		if (!Globals.GMain.Boolean_1)
		{
			if (prgStatus.Style == ProgressBarStyle.Marquee)
			{
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Indeterminate);
			}
			else
			{
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Normal);
			}
		}
	}

	internal void method_2(string string_0)
	{
		if (grbBack.InvokeRequired)
		{
			grbBack.Invoke(new Delegate37(method_2), string_0);
		}
		else
		{
			grbBack.Text = string_0;
		}
	}

	private void method_3(object sender, EventArgs e)
	{
		if (base.InvokeRequired)
		{
			Invoke(new Delegate39(method_3), sender, e);
			return;
		}
		bool_1 = tsbPause.Checked;
		onPauseEventHandler_0?.Invoke(bool_1);
		if (!Globals.GMain.Boolean_1)
		{
			if (bool_1)
			{
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Paused);
			}
			else
			{
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Normal);
			}
		}
	}

	private void method_4(object sender, EventArgs e)
	{
		if (base.InvokeRequired)
		{
			Invoke(new Delegate39(method_4), sender, e);
		}
		else
		{
			tsbPause.Checked = false;
			tstMain.Enabled = false;
			bool_1 = false;
			bool_0 = true;
			onCancelEventHandler_0?.Invoke();
		}
	}

	private void DumpLoading_Load(object sender, EventArgs e)
	{
		prgStatus.BringToFront();
	}
}
