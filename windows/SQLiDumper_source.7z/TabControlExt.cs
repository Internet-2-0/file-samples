using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
[DesignTimeVisible(true)]
public class TabControlExt : UserControl
{
	[Description("Provides data for the MdiTabControl.TabControl.GetTabRegion event.")]
	public class GetTabRegionEventArgs : EventArgs
	{
		private Point[] __Points;

		private int __TabWidth;

		private int __TabHeight;

		private bool __Selected;

		[Description("Returns whether the tab is selected or not.")]
		public int Selected => 0 - (__Selected ? 1 : 0);

		[Description("Returns the tab width.")]
		public int TabWidth => __TabWidth;

		[Description("Returns the tab height.")]
		public int TabHeight => __TabHeight;

		[Description("Gets or sets an array of System.Drawing.Point structures that represents the points through which the tab path is constructed.")]
		public Point[] Points
		{
			get
			{
				return __Points;
			}
			set
			{
				__Points = value;
			}
		}

		private GetTabRegionEventArgs()
		{
		}

		[Description("Initializes a new instance of the MdiTabControl.TabControl.GetTabRegionEventArgs class.")]
		public GetTabRegionEventArgs(Point[] Points, int Width, int Height, bool Selected)
		{
			__Points = Points;
			__TabWidth = Width;
			__TabHeight = Height;
			__Selected = Selected;
		}
	}

	[Description("Provides data for the MdiTabControl.TabControl.TabPaint event.")]
	public class TabPaintEventArgs : PaintEventArgs
	{
		private bool __Handled;

		private bool __Selected;

		private bool __Hot;

		private GraphicsPath __GraphicPath;

		private int __TabWidth;

		private int __TabHeight;

		[Description("Returns the tab's hot state.")]
		public bool Hot => __Hot;

		[Description("Returns whether the tab is selected or not.")]
		public bool Selected => __Selected;

		[Description("Gets or sets a value that indicates whether the event handler has completely handled the paint or whether the system should continue its own processing.")]
		public bool Handled
		{
			get
			{
				return __Handled;
			}
			set
			{
				__Handled = value;
			}
		}

		[Description("Returns the tab width.")]
		public int TabWidth => __TabWidth;

		[Description("Returns the tab height.")]
		public int TabHeight => __TabHeight;

		[Description("Represents a series of connected lines and curves which the tab path is constructed.")]
		public GraphicsPath GraphicPath => __GraphicPath;

		[Description("Initializes a new instance of the MdiTabControl.TabControl.GetTabRegionEventArgs class.")]
		public TabPaintEventArgs(Graphics graphics, Rectangle clipRect, bool Selected, bool Hot, GraphicsPath GraphicPath, int Width, int Height)
			: base(graphics, clipRect)
		{
			__Handled = false;
			__Selected = false;
			__Hot = false;
			__Selected = Selected;
			__Hot = Hot;
			__GraphicPath = GraphicPath;
			__TabWidth = Width;
			__TabHeight = Height;
		}
	}

	[Description("Contains a collection of MdiTabControl.__TabPage objects.")]
	public class __TabPageCollection : CollectionBase
	{
		public delegate void GetTabRegionEventHandler(object sender, GetTabRegionEventArgs e);

		public delegate void TabPaint__BackgroundEventHandler(object sender, TabPaintEventArgs e);

		public delegate void TabPaintBorderEventHandler(object sender, TabPaintEventArgs e);

		public delegate void OnVisibleChangedEventHandler(object sender, bool b);

		private TabPageExt __TabPage;

		private TabControlExt __TabControl;

		private bool __IsReorder;

		private bool __EnabledToolTip;

		public bool EnabledToolTip
		{
			get
			{
				return __EnabledToolTip;
			}
			set
			{
				__EnabledToolTip = value;
				if (value)
				{
					__TabControl.TabToolTip.SetToolTip(__TabPage, __TabPage.Form.Text);
				}
				else
				{
					__TabControl.TabToolTip.RemoveAll();
				}
			}
		}

		[Description("Gets a __TabPage in the position Index from the collection.")]
		public TabPageExt this[int Index]
		{
			get
			{
				if (base.List.Count > 0)
				{
					return (TabPageExt)base.List[Index];
				}
				TabPageExt result = default(TabPageExt);
				return result;
			}
		}

		[Description("Gets a __TabPage associated with the Form from the collection.")]
		public TabPageExt this[Form Form]
		{
			get
			{
				int num = this.get_IndexOf(Form);
				if (num == -1)
				{
					return null;
				}
				return (TabPageExt)base.List[num];
			}
		}

		[Description("Returns the index of the specified __TabPage in the collection.")]
		public int IndexOf
		{
			get
			{
				return base.List.IndexOf(__TabPage);
			}
			set
			{
				__IsReorder = true;
				base.List.Remove(__TabPage);
				base.List.Insert(value, __TabPage);
				__TabControl.Arrange__Items();
				__IsReorder = false;
			}
		}

		[Description("Returns the index of the specified __TabPage associated with the Form in the collection.")]
		public int IndexOf
		{
			get
			{
				int result = -1;
				checked
				{
					int num = base.List.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						if (((TabPageExt)base.List[i]).Form.Equals(Form))
						{
							result = i;
							break;
						}
					}
					return result;
				}
			}
		}

		public event GetTabRegionEventHandler GetTabRegion;

		[Description("Occurs when the Tab __Background has been painted.")]
		public event TabPaint__BackgroundEventHandler TabPaint__Background;

		[Description("Occurs when the Tab Border has been painted.")]
		public event TabPaintBorderEventHandler TabPaintBorder;

		public event OnVisibleChangedEventHandler OnVisibleChanged;

		public __TabPageCollection(TabControlExt Owner)
		{
			__IsReorder = false;
			__EnabledToolTip = true;
			__TabControl = Owner;
		}

		[Description("Create a new TabPage and adds it to the collection whit the Form associated and returns the created __TabPage.")]
		public TabPageExt Add(object Form, string sText = "", Bitmap icon = null)
		{
			__TabPage = new TabPageExt(RuntimeHelpers.GetObjectValue(Form), sText, icon);
			__TabPage.SuspendLayout();
			__TabControl.SuspendLayout();
			__TabControl.__AddingPage = true;
			__TabPage.BackHighColor = __TabControl.TabBackHighColor;
			__TabPage.BackHighColorDisabled = __TabControl.TabBackHighColorDisabled;
			__TabPage.BackLowColor = __TabControl.TabBackLowColor;
			__TabPage.BackLowColorDisabled = __TabControl.TabBackLowColorDisabled;
			__TabPage.BorderColor = __TabControl.BorderColor;
			__TabPage.BorderColorDisabled = __TabControl.BorderColorDisabled;
			__TabPage.ForeColor = __TabControl.ForeColor;
			__TabPage.ForeColorDisabled = __TabControl.ForeColorDisabled;
			__TabPage.MaximumWidth = __TabControl.TabMaximumWidth;
			__TabPage.MinimumWidth = __TabControl.TabMinimumWidth;
			__TabPage.PadLeft = __TabControl.TabPadLeft;
			__TabPage.PadRight = __TabControl.TabPadRight;
			__TabPage.CloseButtonVisible = __TabControl.TabCloseButtonVisible;
			__TabPage.CloseButtonImage = __TabControl.TabCloseButtonImage;
			__TabPage.CloseButtonImageHot = __TabControl.TabCloseButtonImageHot;
			__TabPage.CloseButtonImageDisabled = __TabControl.TabCloseButtonImageDisabled;
			__TabPage.CloseButtonSize = __TabControl.TabCloseButtonSize;
			__TabPage.CloseButtonBackHighColor = __TabControl.TabCloseButtonBackHighColor;
			__TabPage.CloseButtonBackLowColor = __TabControl.TabCloseButtonBackLowColor;
			__TabPage.CloseButtonBorderColor = __TabControl.TabCloseButtonBorderColor;
			__TabPage.CloseButtonForeColor = __TabControl.TabCloseButtonForeColor;
			__TabPage.CloseButtonBackHighColorDisabled = __TabControl.TabCloseButtonBackHighColorDisabled;
			__TabPage.CloseButtonBackLowColorDisabled = __TabControl.TabCloseButtonBackLowColorDisabled;
			__TabPage.CloseButtonBorderColorDisabled = __TabControl.TabCloseButtonBorderColorDisabled;
			__TabPage.CloseButtonForeColorDisabled = __TabControl.TabCloseButtonForeColorDisabled;
			__TabPage.CloseButtonBackHighColorHot = __TabControl.TabCloseButtonBackHighColorHot;
			__TabPage.CloseButtonBackLowColorHot = __TabControl.TabCloseButtonBackLowColorHot;
			__TabPage.CloseButtonBorderColorHot = __TabControl.TabCloseButtonBorderColorHot;
			__TabPage.CloseButtonForeColorHot = __TabControl.TabCloseButtonForeColorHot;
			__TabPage.HotTrack = __TabControl.HotTrack;
			__TabPage.Font = __TabControl.Font;
			__TabPage.FontBoldOnSelect = __TabControl.FontBoldOnSelect;
			__TabPage.IconSize = __TabControl.TabIconSize;
			__TabPage.SmoothingMode = __TabControl.SmoothingMode;
			__TabPage.Alignment = __TabControl.Alignment;
			__TabPage.GlassGradient = __TabControl.TabGlassGradient;
			__TabPage.BorderEnhanced = __TabControl.__TabBorderEnhanced;
			__TabPage.RenderMode = __TabControl.RenderMode;
			__TabPage.BorderEnhanceWeight = __TabControl.TabBorderEnhanceWeight;
			__TabPage.Top = 0;
			__TabPage.Left = __TabControl.__LeftOffset;
			__TabPage.Height = __TabControl.TabHeight;
			__TabPage.Click += __TabPage_Clicked;
			__TabPage.Close += __TabPage_Closed;
			__TabPage.GetTabRegion += __TabPage_GetTabRegion;
			__TabPage.TabPaintBackground += __TabPage_TabPaint__Background;
			__TabPage.TabPaintBorder += __TabPage_TabPaintBorder;
			__TabPage.SizeChanged += __TabPage_SizeChanged;
			__TabPage.Draging += __TabPage_Draging;
			base.List.Add(__TabPage);
			__TabControl.ResumeLayout();
			__TabPage.ResumeLayout();
			OnVisibleChanged?.Invoke(this, b: true);
			return __TabPage;
		}

		[Description("Removes a __TabPage from the collection.")]
		public void Remove(TabPageExt __TabPage)
		{
			try
			{
				__TabControl.__IsDelete = true;
				if (__TabControl.pnlBottom.Controls.Count > 1)
				{
					__TabControl.pnlBottom.Controls[1].Dock = DockStyle.Fill;
					__TabControl.pnlBottom.Controls[1].Visible = true;
				}
				OnVisibleChanged?.Invoke(this, base.List.Count > 1);
				base.List.Remove(__TabPage);
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			base.OnInsertComplete(index, RuntimeHelpers.GetObjectValue(value));
			if (!__IsReorder)
			{
				__TabControl.pnlBottom.Controls.Add(((TabPageExt)value).Form);
				__TabControl.pnlTabs.Controls.Add((TabPageExt)value);
				((TabPageExt)value).Select();
				__TabControl.__AddingPage = false;
				__TabControl.Arrange__Items();
				__TabControl.__Background.Visible = false;
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			base.OnRemoveComplete(index, RuntimeHelpers.GetObjectValue(value));
			if (!__IsReorder)
			{
				if (base.List.Count == 0)
				{
					__TabControl.__Background.Visible = true;
				}
				__TabControl.Arrange__Items();
				__TabControl.pnlBottom.Controls.Remove(((TabPageExt)value).Form);
				((TabPageExt)value).Form.Dispose();
				__TabControl.pnlTabs.Controls.Remove((TabPageExt)value);
				((TabPageExt)value).Dispose();
				__TabControl.SelectItem(-1);
			}
		}

		protected override void OnClear()
		{
			base.OnClear();
			__TabControl.__Background.Visible = true;
		}

		protected override void OnClearComplete()
		{
			base.OnClearComplete();
			__TabControl.pnlBottom.Controls.Clear();
			__TabControl.pnlTabs.Controls.Clear();
		}

		[Description("Returns the selected __TabPage.")]
		public TabPageExt SelectedTab()
		{
			foreach (TabPageExt item in base.List)
			{
				if (item.IsSelected)
				{
					return item;
				}
			}
			return null;
		}

		[Description("Returns the index of the selected __TabPage.")]
		public int SelectedIndex()
		{
			int result = default(int);
			foreach (TabPageExt item in base.List)
			{
				if (item.IsSelected)
				{
					result = base.List.IndexOf(item);
					return result;
				}
			}
			return result;
		}

		private void __TabPage_Clicked(object sender, EventArgs e)
		{
			TabControlExt _TabControl = __TabControl;
			object[] obj = new object[1] { sender };
			object[] array = obj;
			bool[] obj2 = new bool[1] { true };
			bool[] array2 = obj2;
			NewLateBinding.LateCall(_TabControl, null, "SelectItem", obj, null, null, obj2, IgnoreReturn: true);
			if (array2[0])
			{
				sender = RuntimeHelpers.GetObjectValue(array[0]);
			}
		}

		private void __TabPage_Closed(object sender, EventArgs e)
		{
			Remove((TabPageExt)sender);
		}

		private void __TabPage_GetTabRegion(object sender, GetTabRegionEventArgs e)
		{
			GetTabRegion?.Invoke(RuntimeHelpers.GetObjectValue(sender), e);
		}

		private void __TabPage_TabPaint__Background(object sender, TabPaintEventArgs e)
		{
			TabPaint__Background?.Invoke(RuntimeHelpers.GetObjectValue(sender), e);
		}

		private void __TabPage_TabPaintBorder(object sender, TabPaintEventArgs e)
		{
			TabPaintBorder?.Invoke(RuntimeHelpers.GetObjectValue(sender), e);
		}

		private void __TabPage_SizeChanged(object sender, EventArgs e)
		{
			__TabControl.Arrange__Items();
		}

		private void __TabPage_Draging(object sender, MouseEventArgs e)
		{
			if (__TabControl.AllowTabReorder && e.Button == MouseButtons.Left)
			{
				TabPageExt tabPageExt = Get__TabPage((TabPageExt)sender, e.X, e.Y);
				if (tabPageExt != null)
				{
					this.set_IndexOf(tabPageExt, this.get_IndexOf((TabPageExt)sender));
				}
			}
		}

		private TabPageExt Get__TabPage(TabPageExt __TabPage, int x, int y)
		{
			checked
			{
				int num = base.List.Count - 1;
				int num2 = 0;
				while (true)
				{
					if (num2 <= num)
					{
						if ((TabPageExt)base.List[num2] != __TabPage && ((TabPageExt)base.List[num2]).TabVisible && ((TabPageExt)base.List[num2]).RectangleToScreen(((TabPageExt)base.List[num2]).ClientRectangle).Contains(__TabPage.PointToScreen(new Point(x, y))))
						{
							break;
						}
						num2++;
						continue;
					}
					return null;
				}
				return (TabPageExt)base.List[num2];
			}
		}
	}

	[Description("Gets or sets the specified alignment for the control.")]
	public enum TabAlignment : byte
	{
		Top,
		Bottom
	}

	[Description("Gets or sets the specified direction for the control.")]
	public enum FlowDirection : byte
	{
		LeftToRight = 0,
		RightToLeft = 2
	}

	public enum Weight : byte
	{
		Soft = 2,
		Medium,
		Strong,
		Strongest
	}

	public delegate void GetTabRegionEventHandler(object sender, GetTabRegionEventArgs e);

	public delegate void TabPaintBackgroundEventHandler(object sender, TabPaintEventArgs e);

	public delegate void TabPaintBorderEventHandler(object sender, TabPaintEventArgs e);

	public delegate void TabSelectedFormEventHandler(object sender, object e);

	private IContainer components;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("pnlTop")]
	[CompilerGenerated]
	private Panel _pnlTop;

	[AccessedThroughProperty("DropButton")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ControlButton _DropButton;

	[CompilerGenerated]
	[AccessedThroughProperty("CloseButton")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ControlButton _CloseButton;

	private bool __AddingPage;

	private int __LeftOffset;

	private bool __IsDelete;

	private Panel __Background;

	[AccessedThroughProperty("__Items")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private __TabPageCollection ___Items;

	private FlowDirection __TabsDirection;

	private int __TabMaximumWidth;

	private int __TabMinimumWidth;

	private Color __BackLowColor;

	private Color __BackHighColor;

	private Color __BorderColor;

	private Color __TabBackHighColor;

	private Color __TabBackLowColor;

	private Color __TabBackHighColorDisabled;

	private Color __TabBackLowColorDisabled;

	private Color __BorderColorDisabled;

	private Color __ForeColorDisabled;

	private bool __TopSeparator;

	private int __TabTop;

	private int __TabHeight;

	private int __TabOffset;

	private int __TabPadLeft;

	private int __TabPadRight;

	private object __TabSmoothingMode;

	private Size __TabIconSize;

	private TabAlignment __Alignment;

	private bool __FontBoldOnSelect;

	private bool __HotTrack;

	private Size __TabCloseButtonSize;

	private bool __TabCloseButtonVisible;

	private Image __TabCloseButtonImage;

	private Image __TabCloseButtonImageHot;

	private Image __TabCloseButtonImageDisabled;

	private Color __TabCloseButtonBackHighColor;

	private Color __TabCloseButtonBackLowColor;

	private Color __TabCloseButtonBorderColor;

	private Color __TabCloseButtonForeColor;

	private Color __TabCloseButtonBackHighColorDisabled;

	private Color __TabCloseButtonBackLowColorDisabled;

	private Color __TabCloseButtonBorderColorDisabled;

	private Color __TabCloseButtonForeColorDisabled;

	private Color __TabCloseButtonBackHighColorHot;

	private Color __TabCloseButtonBackLowColorHot;

	private Color __TabCloseButtonBorderColorHot;

	private Color __TabCloseButtonForeColorHot;

	private bool __AllowTabReorder;

	private bool __TabGlassGradient;

	private bool __TabBorderEnhanced;

	private ToolStripRenderMode __RenderMode;

	private ToolStripRenderer __ContextMenuRenderer;

	private Weight __TabBorderEnhanceWeight;

	public readonly Padding defaultPadding;

	public readonly Color defaultBackLowColor;

	public readonly Color defaultBackHighColor;

	public readonly Color defaultBorderColor;

	public readonly Color defaultTabBackHighColor;

	public readonly Color defaultTabBackLowColor;

	public readonly Color defaultTabBackHighColorDisabled;

	public readonly Color defaultTabBackLowColorDisabled;

	public readonly Color defaultBorderColorDisabled;

	public readonly Color defaultForeColorDisabled;

	public readonly Color defaultControlButtonBackHighColor;

	public readonly Color defaultControlButtonBackLowColor;

	public readonly Color defaultControlButtonBorderColor;

	public readonly Color defaultControlButtonForeColor;

	public readonly Size defaultTabCloseButtonSize;

	public readonly Size defaultTabIconSize;

	public readonly Color defaultTabCloseButtonBackHighColor;

	public readonly Color defaultTabCloseButtonBackHighColorDisabled;

	public readonly Color defaultTabCloseButtonBackHighColorHot;

	public readonly Color defaultTabCloseButtonBackLowColor;

	public readonly Color defaultTabCloseButtonBackLowColorDisabled;

	public readonly Color defaultTabCloseButtonBackLowColorHot;

	public readonly Color defaultTabCloseButtonBorderColor;

	public readonly Color defaultTabCloseButtonBorderColorDisabled;

	public readonly Color defaultTabCloseButtonBorderColorHot;

	public readonly Color defaultTabCloseButtonForeColor;

	public readonly Color defaultTabCloseButtonForeColorDisabled;

	public readonly Color defaultTabCloseButtonForeColorHot;

	public readonly ToolStripRenderMode defaultRenderMode;

	internal virtual Panel pnlTop
	{
		[CompilerGenerated]
		get
		{
			return _pnlTop;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = pnlTop_SizeChanged;
			PaintEventHandler value3 = pnlTop_Paint;
			Panel panel = _pnlTop;
			if (panel != null)
			{
				panel.SizeChanged -= value2;
				panel.Paint -= value3;
			}
			_pnlTop = value;
			panel = _pnlTop;
			if (panel != null)
			{
				panel.SizeChanged += value2;
				panel.Paint += value3;
			}
		}
	}

	[field: AccessedThroughProperty("pnlTabs")]
	internal virtual Panel pnlTabs
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlBottom")]
	internal virtual Panel pnlBottom
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("WinMenu")]
	internal virtual ContextMenuStrip WinMenu
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ControlButton DropButton
	{
		[CompilerGenerated]
		get
		{
			return _DropButton;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			MouseEventHandler value2 = DropButton_MouseDown;
			ControlButton dropButton = _DropButton;
			if (dropButton != null)
			{
				dropButton.MouseDown -= value2;
			}
			_DropButton = value;
			dropButton = _DropButton;
			if (dropButton != null)
			{
				dropButton.MouseDown += value2;
			}
		}
	}

	[field: AccessedThroughProperty("TabToolTip")]
	internal virtual ToolTip TabToolTip
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ControlButton CloseButton
	{
		[CompilerGenerated]
		get
		{
			return _CloseButton;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			MouseEventHandler value2 = CloseButton_MouseDown;
			ControlButton closeButton = _CloseButton;
			if (closeButton != null)
			{
				closeButton.MouseDown -= value2;
			}
			_CloseButton = value;
			closeButton = _CloseButton;
			if (closeButton != null)
			{
				closeButton.MouseDown += value2;
			}
		}
	}

	[field: AccessedThroughProperty("pnlControls")]
	internal virtual Panel pnlControls
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	private virtual __TabPageCollection __Items
	{
		[CompilerGenerated]
		get
		{
			return ___Items;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			__TabPageCollection.GetTabRegionEventHandler value2 = __ItemsGetTabRegion;
			__TabPageCollection.TabPaint__BackgroundEventHandler value3 = __ItemsTabPaint__Background;
			__TabPageCollection.TabPaintBorderEventHandler value4 = __ItemsTabPaintBorder;
			__TabPageCollection _TabPageCollection = ___Items;
			if (_TabPageCollection != null)
			{
				_TabPageCollection.GetTabRegion -= value2;
				_TabPageCollection.TabPaint__Background -= value3;
				_TabPageCollection.TabPaintBorder -= value4;
			}
			___Items = value;
			_TabPageCollection = ___Items;
			if (_TabPageCollection != null)
			{
				_TabPageCollection.GetTabRegion += value2;
				_TabPageCollection.TabPaint__Background += value3;
				_TabPageCollection.TabPaintBorder += value4;
			}
		}
	}

	public Form SelectedFormIndex { get; set; }

	[Browsable(false)]
	public object SelectedForm
	{
		get
		{
			if (pnlBottom.Controls.Count > 0)
			{
				return pnlBottom.Controls[0];
			}
			return null;
		}
	}

	[Description("Gets or sets the the direction which the tabs are drawn.")]
	[Category("Layout")]
	[DefaultValue(0)]
	[Browsable(true)]
	public FlowDirection TabsDirection
	{
		get
		{
			return __TabsDirection;
		}
		set
		{
			__TabsDirection = value;
			SelectItem(-1);
		}
	}

	[Description("Gets or sets if the tab __Background will paint with glass style.")]
	[DefaultValue(false)]
	[Category("Appearance")]
	[Browsable(true)]
	public bool TabGlassGradient
	{
		get
		{
			return __TabGlassGradient;
		}
		set
		{
			__TabGlassGradient = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.GlassGradient = value;
			}
		}
	}

	[Browsable(true)]
	[Description("Gets or sets if the tab border will paint with enhanced style.")]
	[DefaultValue(false)]
	[Category("Appearance")]
	public bool TabBorderEnhanced
	{
		get
		{
			return __TabBorderEnhanced;
		}
		set
		{
			__TabBorderEnhanced = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.BorderEnhanced = value;
			}
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the starting color of the __Background linear gradient for the tab close button.")]
	[Browsable(true)]
	[Category("Appearance")]
	public Color TabCloseButtonBackHighColor
	{
		get
		{
			return __TabCloseButtonBackHighColor;
		}
		set
		{
			__TabCloseButtonBackHighColor = value;
		}
	}

	[Browsable(true)]
	[Description("Gets or sets the System.Drawing.Color structure that represents the ending color of the __Background linear gradient for the tab close button.")]
	[Category("Appearance")]
	public Color TabCloseButtonBackLowColor
	{
		get
		{
			return __TabCloseButtonBackLowColor;
		}
		set
		{
			__TabCloseButtonBackLowColor = value;
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the border color for the tab close button.")]
	[Browsable(true)]
	[Category("Appearance")]
	public Color TabCloseButtonBorderColor
	{
		get
		{
			return __TabCloseButtonBorderColor;
		}
		set
		{
			__TabCloseButtonBorderColor = value;
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the fore color for the tab close button.")]
	public Color TabCloseButtonForeColor
	{
		get
		{
			return __TabCloseButtonForeColor;
		}
		set
		{
			__TabCloseButtonForeColor = value;
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the starting color of the __Background linear gradient for the disabled tab close button.")]
	[Category("Appearance")]
	[Browsable(true)]
	public Color TabCloseButtonBackHighColorDisabled
	{
		get
		{
			return __TabCloseButtonBackHighColorDisabled;
		}
		set
		{
			__TabCloseButtonBackHighColorDisabled = value;
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the ending color of the __Background linear gradient for the disabled tab close button.")]
	[Category("Appearance")]
	[Browsable(true)]
	public Color TabCloseButtonBackLowColorDisabled
	{
		get
		{
			return __TabCloseButtonBackLowColorDisabled;
		}
		set
		{
			__TabCloseButtonBackLowColorDisabled = value;
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the border color for the disabled tab close button.")]
	[Category("Appearance")]
	[Browsable(true)]
	public Color TabCloseButtonBorderColorDisabled
	{
		get
		{
			return __TabCloseButtonBorderColorDisabled;
		}
		set
		{
			__TabCloseButtonBorderColorDisabled = value;
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the disabled fore color for the tab close button.")]
	public Color TabCloseButtonForeColorDisabled
	{
		get
		{
			return __TabCloseButtonForeColorDisabled;
		}
		set
		{
			__TabCloseButtonForeColorDisabled = value;
		}
	}

	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the starting color of the __Background linear gradient for the Hot tab close button.")]
	[Browsable(true)]
	public Color TabCloseButtonBackHighColorHot
	{
		get
		{
			return __TabCloseButtonBackHighColorHot;
		}
		set
		{
			__TabCloseButtonBackHighColorHot = value;
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the ending color of the __Background linear gradient for the Hot tab close button.")]
	public Color TabCloseButtonBackLowColorHot
	{
		get
		{
			return __TabCloseButtonBackLowColorHot;
		}
		set
		{
			__TabCloseButtonBackLowColorHot = value;
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the border color for the Hot tab close button.")]
	[Browsable(true)]
	[Category("Appearance")]
	public Color TabCloseButtonBorderColorHot
	{
		get
		{
			return __TabCloseButtonBorderColorHot;
		}
		set
		{
			__TabCloseButtonBorderColorHot = value;
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the Hot fore color for the tab close button.")]
	public Color TabCloseButtonForeColorHot
	{
		get
		{
			return __TabCloseButtonForeColorHot;
		}
		set
		{
			__TabCloseButtonForeColorHot = value;
		}
	}

	[Browsable(true)]
	[Description("Gets or sets the tab close button image.")]
	[Category("Appearance")]
	public Image TabCloseButtonImage
	{
		get
		{
			return __TabCloseButtonImage;
		}
		set
		{
			__TabCloseButtonImage = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.CloseButtonImage = value;
			}
		}
	}

	[Description("Gets or sets the tab close button image in hot state.")]
	[Category("Appearance")]
	[Browsable(true)]
	public Image TabCloseButtonImageHot
	{
		get
		{
			return __TabCloseButtonImageHot;
		}
		set
		{
			__TabCloseButtonImageHot = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.CloseButtonImageHot = value;
			}
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the tab close button image in disabled state.")]
	public Image TabCloseButtonImageDisabled
	{
		get
		{
			return __TabCloseButtonImageDisabled;
		}
		set
		{
			__TabCloseButtonImageDisabled = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.CloseButtonImageDisabled = value;
			}
		}
	}

	[Description("Gets or sets whether the tab close button is visble or not.")]
	[DefaultValue(true)]
	[Category("Layout")]
	[Browsable(true)]
	public bool TabCloseButtonVisible
	{
		get
		{
			return __TabCloseButtonVisible;
		}
		set
		{
			__TabCloseButtonVisible = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.CloseButtonVisible = value;
			}
		}
	}

	[Category("Appearance")]
	[Description("Gets or sets the size of the icon displayed at the tab.")]
	[Browsable(true)]
	public Size TabIconSize
	{
		get
		{
			return __TabIconSize;
		}
		set
		{
			__TabIconSize = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.IconSize = value;
			}
		}
	}

	[Category("Appearance")]
	[Description("Gets or sets the size of the close button displayed at the tab.")]
	[Browsable(true)]
	public Size TabCloseButtonSize
	{
		get
		{
			return __TabCloseButtonSize;
		}
		set
		{
			__TabCloseButtonSize = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.CloseButtonSize = value;
			}
		}
	}

	[Category("Appearance")]
	[DefaultValue(3)]
	[Description("Specifies whether smoothing (antialiasing) is applied to lines and curves and the edges of filled areas.")]
	[Browsable(true)]
	public SmoothingMode SmoothingMode
	{
		get
		{
			return (SmoothingMode)Conversions.ToInteger(__TabSmoothingMode);
		}
		set
		{
			__TabSmoothingMode = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.SmoothingMode = value;
			}
		}
	}

	[Category("Layout")]
	[DefaultValue(5)]
	[Browsable(true)]
	[Description("Gets or sets the amount of space on the right side of the tab.")]
	public int TabPadRight
	{
		get
		{
			return __TabPadRight;
		}
		set
		{
			__TabPadRight = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.PadRight = value;
			}
		}
	}

	[DefaultValue(5)]
	[Category("Layout")]
	[Browsable(true)]
	[Description("Gets or sets the amount of space on the left side of the tab.")]
	public int TabPadLeft
	{
		get
		{
			return __TabPadLeft;
		}
		set
		{
			__TabPadLeft = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.PadLeft = value;
			}
		}
	}

	[Browsable(true)]
	[Description("Gets or sets the amount of space between the tabs.")]
	[DefaultValue(3)]
	[Category("Layout")]
	public int TabOffset
	{
		get
		{
			return __TabOffset;
		}
		set
		{
			__TabOffset = value;
			Arrange__Items();
		}
	}

	[Category("Layout")]
	[DefaultValue(28)]
	[Description("Gets or sets the height of the tab.")]
	[Browsable(true)]
	public int TabHeight
	{
		get
		{
			return __TabHeight;
		}
		set
		{
			if (__TabHeight == value)
			{
				return;
			}
			__TabHeight = value;
			pnlTabs.Height = __TabHeight;
			pnlTabs.Top = checked(pnlTop.Height - pnlTabs.Height);
			AdjustHeight();
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.Height = value;
			}
		}
	}

	[Description("Gets or sets the distance between the top of the control and the top of the tab.")]
	[Browsable(true)]
	[Category("Layout")]
	[DefaultValue(3)]
	public int TabTop
	{
		get
		{
			return __TabTop;
		}
		set
		{
			__TabTop = value;
			AdjustHeight();
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the starting color of the __Background linear gradient.")]
	public Color TabBackHighColor
	{
		get
		{
			return __TabBackHighColor;
		}
		set
		{
			__TabBackHighColor = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.BackHighColor = value;
			}
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the ending color of the __Background linear gradient.")]
	public Color TabBackLowColor
	{
		get
		{
			return __TabBackLowColor;
		}
		set
		{
			__TabBackLowColor = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.BackLowColor = value;
			}
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the starting color of the __Background linear gradient for a non selected tab.")]
	public Color TabBackHighColorDisabled
	{
		get
		{
			return __TabBackHighColorDisabled;
		}
		set
		{
			__TabBackHighColorDisabled = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.BackHighColorDisabled = value;
			}
		}
	}

	[Category("Appearance")]
	[Browsable(true)]
	[Description("Gets or sets the System.Drawing.Color structure that represents the ending color of the __Background linear gradient for a non selected tab.")]
	public Color TabBackLowColorDisabled
	{
		get
		{
			return __TabBackLowColorDisabled;
		}
		set
		{
			__TabBackLowColorDisabled = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.BackLowColorDisabled = value;
			}
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the border color of the tab when not selected.")]
	public Color BorderColorDisabled
	{
		get
		{
			return __BorderColorDisabled;
		}
		set
		{
			__BorderColorDisabled = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.BorderColorDisabled = value;
			}
		}
	}

	[Category("Appearance")]
	[Browsable(true)]
	[Description("Gets or sets the System.Drawing.Color structure that represents the fore color of the tab when not selected.")]
	public Color ForeColorDisabled
	{
		get
		{
			return __ForeColorDisabled;
		}
		set
		{
			__ForeColorDisabled = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.ForeColorDisabled = value;
			}
		}
	}

	[Description("Gets or sets the minimum width for the tab.")]
	[Browsable(true)]
	[DefaultValue(100)]
	[Category("Layout")]
	public int TabMinimumWidth
	{
		get
		{
			return __TabMinimumWidth;
		}
		set
		{
			__TabMinimumWidth = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.MinimumWidth = value;
			}
		}
	}

	[DefaultValue(200)]
	[Description("Gets or sets the maximum width for the tab.")]
	[Browsable(true)]
	[Category("Layout")]
	public int TabMaximumWidth
	{
		get
		{
			return __TabMaximumWidth;
		}
		set
		{
			__TabMaximumWidth = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.MaximumWidth = value;
			}
		}
	}

	[Description("Gets or sets whether the font on the selected tab is displayed in bold.")]
	[Browsable(true)]
	[DefaultValue(true)]
	[Category("Appearance")]
	public bool FontBoldOnSelect
	{
		get
		{
			return __FontBoldOnSelect;
		}
		set
		{
			__FontBoldOnSelect = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.FontBoldOnSelect = value;
			}
		}
	}

	[Browsable(true)]
	[Category("Behavior")]
	[DefaultValue(true)]
	[Description("Gets or sets a value indicating whether the control's tabs change in appearance when the mouse passes over them.")]
	public bool HotTrack
	{
		get
		{
			return __HotTrack;
		}
		set
		{
			__HotTrack = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.HotTrack = value;
			}
		}
	}

	[DefaultValue(true)]
	[Description("Gets or sets a value indicating whether the user can reorder tabs draging.")]
	[Browsable(true)]
	[Category("Behavior")]
	public bool AllowTabReorder
	{
		get
		{
			return __AllowTabReorder;
		}
		set
		{
			__AllowTabReorder = value;
		}
	}

	[DefaultValue(false)]
	[Browsable(true)]
	[Description("Gets or sets a value indicating whether the close button is displayed or not.")]
	[Category("Layout")]
	public bool CloseButtonVisible
	{
		get
		{
			return CloseButton.Visible;
		}
		set
		{
			if (CloseButton.Visible != value)
			{
				CloseButton.Visible = value;
				SetControlsSizeLocation();
			}
		}
	}

	[Browsable(true)]
	[Description("Gets or sets a value indicating whether the drop button is displayed or not.")]
	[DefaultValue(true)]
	[Category("Layout")]
	public bool DropButtonVisible
	{
		get
		{
			return DropButton.Visible;
		}
		set
		{
			if (DropButton.Visible != value)
			{
				DropButton.Visible = value;
				SetControlsSizeLocation();
			}
		}
	}

	[Description("Gets or sets a value indicating whether a double line separator is displayed at the top of the control.")]
	[Browsable(true)]
	[DefaultValue(true)]
	[Category("Appearance")]
	public bool TopSeparator
	{
		get
		{
			return __TopSeparator;
		}
		set
		{
			__TopSeparator = value;
			AdjustHeight();
		}
	}

	[DefaultValue(0)]
	[Description("Gets or sets the area of the control (for example, along the top) where the tabs are aligned.")]
	[Browsable(true)]
	[Category("Behavior")]
	public TabAlignment Alignment
	{
		get
		{
			return __Alignment;
		}
		set
		{
			__Alignment = value;
			AdjustHeight();
			PositionButtons();
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.Alignment = value;
			}
		}
	}

	[Browsable(true)]
	[Description("Gets or sets the amount of space around the form on the control's tab pages.")]
	[Category("Layout")]
	public new Padding Padding
	{
		get
		{
			return pnlBottom.Padding;
		}
		set
		{
			pnlBottom.Padding = value;
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the starting color of the __Background linear gradient for the control button.")]
	public Color ControlButtonBackHighColor
	{
		get
		{
			return DropButton.BackHighColor;
		}
		set
		{
			DropButton.BackHighColor = value;
			CloseButton.BackHighColor = value;
		}
	}

	[Browsable(true)]
	[Description("Gets or sets the System.Drawing.Color structure that represents the ending color of the __Background linear gradient for the control button.")]
	[Category("Appearance")]
	public Color ControlButtonBackLowColor
	{
		get
		{
			return DropButton.BackLowColor;
		}
		set
		{
			DropButton.BackLowColor = value;
			CloseButton.BackLowColor = value;
		}
	}

	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the border color for the control button.")]
	[Browsable(true)]
	public Color ControlButtonBorderColor
	{
		get
		{
			return DropButton.BorderColor;
		}
		set
		{
			DropButton.BorderColor = value;
			CloseButton.BorderColor = value;
		}
	}

	[Category("Appearance")]
	[Browsable(true)]
	[Description("Gets or sets the System.Drawing.Color structure that represents the ForeColor for the control button.")]
	public Color ControlButtonForeColor
	{
		get
		{
			return DropButton.ForeColor;
		}
		set
		{
			DropButton.ForeColor = value;
			CloseButton.ForeColor = value;
		}
	}

	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the ending color of the __Background linear gradient for the tabs region.")]
	[Browsable(true)]
	public Color BackLowColor
	{
		get
		{
			return __BackLowColor;
		}
		set
		{
			__BackLowColor = value;
			Invalidate();
		}
	}

	[Browsable(true)]
	[Description("Gets or sets the System.Drawing.Color structure that represents the starting color of the __Background linear gradient for the tabs region.")]
	[Category("Appearance")]
	public Color BackHighColor
	{
		get
		{
			return __BackHighColor;
		}
		set
		{
			__BackHighColor = value;
			Invalidate();
		}
	}

	[Browsable(true)]
	[Category("Appearance")]
	[Description("Gets or sets the System.Drawing.Color structure that represents the border color.")]
	public Color BorderColor
	{
		get
		{
			return __BorderColor;
		}
		set
		{
			__BorderColor = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.BorderColor = value;
			}
			pnlTabs.Invalidate();
			pnlTop.Invalidate();
		}
	}

	[Description("Gets the collection of tab pages in this tab control.")]
	[Browsable(false)]
	public __TabPageCollection TabPages => __Items;

	[Category("Appearance")]
	[Description("The painting style applied to the control.")]
	[Browsable(true)]
	public ToolStripRenderMode RenderMode
	{
		get
		{
			return __RenderMode;
		}
		set
		{
			__RenderMode = value;
			DropButton.RenderMode = value;
			CloseButton.RenderMode = value;
			WinMenu.RenderMode = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.RenderMode = value;
			}
		}
	}

	[Browsable(false)]
	public ToolStripRenderer MenuRenderer
	{
		get
		{
			return __ContextMenuRenderer;
		}
		set
		{
			__ContextMenuRenderer = value;
			WinMenu.Renderer = __ContextMenuRenderer;
		}
	}

	[Category("Appearance")]
	[Browsable(true)]
	[Description("The weight of the border.")]
	[DefaultValue(3)]
	public Weight TabBorderEnhanceWeight
	{
		get
		{
			return __TabBorderEnhanceWeight;
		}
		set
		{
			__TabBorderEnhanceWeight = value;
			foreach (TabPageExt tabPage in TabPages)
			{
				tabPage.BorderEnhanceWeight = value;
			}
		}
	}

	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[Browsable(false)]
	[Category("Appearance")]
	public new BorderStyle BorderStyle
	{
		get
		{
			BorderStyle result = default(BorderStyle);
			return result;
		}
		set
		{
		}
	}

	[Description("Occurs when the Tab Page requests the tab region.")]
	public event GetTabRegionEventHandler GetTabRegion;

	[Description("Occurs when the Tab __Background has been painted.")]
	public event TabPaintBackgroundEventHandler TabPaintBackground;

	[Description("Occurs when the Tab Border has been painted.")]
	public event TabPaintBorderEventHandler TabPaintBorder;

	public event TabSelectedFormEventHandler TabSelectedForm;

	public TabControlExt()
	{
		base.FontChanged += __TabControl_FontChanged;
		base.ForeColorChanged += __TabControl_ForeColorChanged;
		base.Paint += __TabControl_Paint;
		base.Resize += __TabControl_Resize;
		__LeftOffset = 3;
		__IsDelete = false;
		__Background = new Panel();
		__Items = new __TabPageCollection(this);
		__TabsDirection = FlowDirection.LeftToRight;
		__TabMaximumWidth = 200;
		__TabMinimumWidth = 100;
		__TopSeparator = true;
		__TabTop = 3;
		__TabHeight = 28;
		__TabOffset = 3;
		__TabPadLeft = 5;
		__TabPadRight = 5;
		__TabSmoothingMode = SmoothingMode.None;
		__TabIconSize = new Size(16, 16);
		__Alignment = TabAlignment.Top;
		__FontBoldOnSelect = true;
		__HotTrack = true;
		__TabCloseButtonSize = new Size(17, 17);
		__TabCloseButtonVisible = true;
		__AllowTabReorder = true;
		__TabGlassGradient = false;
		__TabBorderEnhanced = false;
		__TabBorderEnhanceWeight = Weight.Medium;
		defaultPadding = new Padding(0, 0, 0, 0);
		defaultBackLowColor = SystemColors.ControlLightLight;
		defaultBackHighColor = SystemColors.Control;
		defaultBorderColor = SystemColors.ControlDarkDark;
		defaultTabBackHighColor = SystemColors.Window;
		defaultTabBackLowColor = SystemColors.Control;
		defaultTabBackHighColorDisabled = SystemColors.Control;
		defaultTabBackLowColorDisabled = SystemColors.ControlDark;
		defaultBorderColorDisabled = SystemColors.ControlDark;
		defaultForeColorDisabled = SystemColors.ControlText;
		defaultControlButtonBackHighColor = SystemColors.GradientInactiveCaption;
		defaultControlButtonBackLowColor = SystemColors.GradientInactiveCaption;
		defaultControlButtonBorderColor = SystemColors.HotTrack;
		defaultControlButtonForeColor = SystemColors.ControlText;
		defaultTabCloseButtonSize = new Size(17, 17);
		defaultTabIconSize = new Size(16, 16);
		defaultTabCloseButtonBackHighColor = Color.IndianRed;
		defaultTabCloseButtonBackHighColorDisabled = Color.LightGray;
		defaultTabCloseButtonBackHighColorHot = Color.LightCoral;
		defaultTabCloseButtonBackLowColor = Color.Firebrick;
		defaultTabCloseButtonBackLowColorDisabled = Color.DarkGray;
		defaultTabCloseButtonBackLowColorHot = Color.IndianRed;
		defaultTabCloseButtonBorderColor = Color.DarkRed;
		defaultTabCloseButtonBorderColorDisabled = Color.Gray;
		defaultTabCloseButtonBorderColorHot = Color.Firebrick;
		defaultTabCloseButtonForeColor = Color.White;
		defaultTabCloseButtonForeColorDisabled = Color.White;
		defaultTabCloseButtonForeColorHot = Color.White;
		defaultRenderMode = ToolStripRenderMode.ManagerRenderMode;
		InitializeComponent();
		SuspendLayout();
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		__Background.BackColor = SystemColors.AppWorkspace;
		__Background.BorderStyle = BorderStyle.Fixed3D;
		__Background.Dock = DockStyle.Fill;
		base.Controls.Add(__Background);
		__Background.BringToFront();
		ResetBackLowColor();
		ResetBackHighColor();
		ResetBorderColor();
		ResetTabBackHighColor();
		ResetTabBackLowColor();
		ResetTabBackHighColorDisabled();
		ResetTabBackLowColorDisabled();
		ResetBorderColorDisabled();
		ResetForeColorDisabled();
		ResetControlButtonBackHighColor();
		ResetControlButtonBackLowColor();
		ResetControlButtonBorderColor();
		ResetControlButtonForeColor();
		ResetTabCloseButtonBackHighColor();
		ResetTabCloseButtonBackLowColor();
		ResetTabCloseButtonBorderColor();
		ResetTabCloseButtonForeColor();
		ResetTabCloseButtonBackHighColorDisabled();
		ResetTabCloseButtonBackLowColorDisabled();
		ResetTabCloseButtonBorderColorDisabled();
		ResetTabCloseButtonForeColorDisabled();
		ResetTabCloseButtonBackHighColorHot();
		ResetTabCloseButtonBackLowColorHot();
		ResetTabCloseButtonBorderColorHot();
		ResetTabCloseButtonForeColorHot();
		ResetPadding();
		ResetTabCloseButtonSize();
		ResetTabIconSize();
		ResetRenderMode();
		AdjustHeight();
		DropButton.RenderMode = RenderMode;
		CloseButton.RenderMode = RenderMode;
		ResumeLayout();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		this.pnlTop = new System.Windows.Forms.Panel();
		this.pnlControls = new System.Windows.Forms.Panel();
		this.DropButton = new ControlButton();
		this.CloseButton = new ControlButton();
		this.pnlTabs = new System.Windows.Forms.Panel();
		this.pnlBottom = new System.Windows.Forms.Panel();
		this.WinMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
		this.TabToolTip = new System.Windows.Forms.ToolTip(this.components);
		this.pnlTop.SuspendLayout();
		this.pnlControls.SuspendLayout();
		base.SuspendLayout();
		this.pnlTop.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.pnlTop.BackColor = System.Drawing.Color.Transparent;
		this.pnlTop.Controls.Add(this.pnlControls);
		this.pnlTop.Controls.Add(this.pnlTabs);
		this.pnlTop.Location = new System.Drawing.Point(0, 0);
		this.pnlTop.Name = "pnlTop";
		this.pnlTop.Size = new System.Drawing.Size(200, 31);
		this.pnlTop.TabIndex = 6;
		this.pnlControls.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.pnlControls.Controls.Add(this.DropButton);
		this.pnlControls.Controls.Add(this.CloseButton);
		this.pnlControls.Location = new System.Drawing.Point(175, 0);
		this.pnlControls.Name = "pnlControls";
		this.pnlControls.Size = new System.Drawing.Size(25, 30);
		this.pnlControls.TabIndex = 1;
		this.DropButton.BackColor = System.Drawing.Color.Transparent;
		this.DropButton.Location = new System.Drawing.Point(4, 8);
		this.DropButton.Name = "DropButton";
		this.DropButton.Size = new System.Drawing.Size(17, 15);
		this.DropButton.Style = ControlButton.ButtonStyle.Drop;
		this.DropButton.TabIndex = 0;
		this.CloseButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.CloseButton.BackColor = System.Drawing.Color.Transparent;
		this.CloseButton.Location = new System.Drawing.Point(4, 8);
		this.CloseButton.Name = "CloseButton";
		this.CloseButton.Size = new System.Drawing.Size(17, 15);
		this.CloseButton.Style = ControlButton.ButtonStyle.Close;
		this.CloseButton.TabIndex = 0;
		this.CloseButton.Visible = false;
		this.pnlTabs.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.pnlTabs.BackColor = System.Drawing.Color.Transparent;
		this.pnlTabs.Location = new System.Drawing.Point(0, 3);
		this.pnlTabs.Name = "pnlTabs";
		this.pnlTabs.Size = new System.Drawing.Size(200, 28);
		this.pnlTabs.TabIndex = 0;
		this.pnlBottom.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.pnlBottom.Location = new System.Drawing.Point(0, 31);
		this.pnlBottom.Name = "pnlBottom";
		this.pnlBottom.Size = new System.Drawing.Size(200, 99);
		this.pnlBottom.TabIndex = 7;
		this.WinMenu.Name = "WinMenu";
		this.WinMenu.Size = new System.Drawing.Size(153, 26);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
		base.Controls.Add(this.pnlTop);
		base.Controls.Add(this.pnlBottom);
		base.Name = "TabControl";
		base.Size = new System.Drawing.Size(200, 130);
		this.pnlTop.ResumeLayout(false);
		this.pnlControls.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	public Panel GetBackground()
	{
		return __Background;
	}

	public bool ShouldSerializeTabCloseButtonBackHighColor()
	{
		return __TabCloseButtonBackHighColor != defaultTabCloseButtonBackHighColor;
	}

	public void ResetTabCloseButtonBackHighColor()
	{
		__TabCloseButtonBackHighColor = defaultTabCloseButtonBackHighColor;
	}

	public bool ShouldSerializeTabCloseButtonBackLowColor()
	{
		return __TabCloseButtonBackLowColor != defaultTabCloseButtonBackLowColor;
	}

	public void ResetTabCloseButtonBackLowColor()
	{
		__TabCloseButtonBackLowColor = defaultTabCloseButtonBackLowColor;
	}

	public bool ShouldSerializeTabCloseButtonBorderColor()
	{
		return __TabCloseButtonBorderColor != defaultTabCloseButtonBorderColor;
	}

	public void ResetTabCloseButtonBorderColor()
	{
		__TabCloseButtonBorderColor = defaultTabCloseButtonBorderColor;
	}

	public bool ShouldSerializeTabCloseButtonForeColor()
	{
		return __TabCloseButtonForeColor != defaultTabCloseButtonForeColor;
	}

	public void ResetTabCloseButtonForeColor()
	{
		__TabCloseButtonForeColor = defaultTabCloseButtonForeColor;
	}

	public bool ShouldSerializeTabCloseButtonBackHighColorDisabled()
	{
		return __TabCloseButtonBackHighColorDisabled != defaultTabCloseButtonBackHighColorDisabled;
	}

	public void ResetTabCloseButtonBackHighColorDisabled()
	{
		__TabCloseButtonBackHighColorDisabled = defaultTabCloseButtonBackHighColorDisabled;
	}

	public bool ShouldSerializeTabCloseButtonBackLowColorDisabled()
	{
		return __TabCloseButtonBackLowColorDisabled != defaultTabCloseButtonBackLowColorDisabled;
	}

	public void ResetTabCloseButtonBackLowColorDisabled()
	{
		__TabCloseButtonBackLowColorDisabled = defaultTabCloseButtonBackLowColorDisabled;
	}

	public bool ShouldSerializeTabCloseButtonBorderColorDisabled()
	{
		return __TabCloseButtonBorderColorDisabled != defaultTabCloseButtonBorderColorDisabled;
	}

	public void ResetTabCloseButtonBorderColorDisabled()
	{
		__TabCloseButtonBorderColorDisabled = defaultTabCloseButtonBorderColorDisabled;
	}

	public bool ShouldSerializeTabCloseButtonForeColorDisabled()
	{
		return __TabCloseButtonForeColorDisabled != defaultTabCloseButtonForeColorDisabled;
	}

	public void ResetTabCloseButtonForeColorDisabled()
	{
		__TabCloseButtonForeColorDisabled = defaultTabCloseButtonForeColorDisabled;
	}

	public bool ShouldSerializeTabCloseButtonBackHighColorHot()
	{
		return __TabCloseButtonBackHighColorHot != defaultTabCloseButtonBackHighColorHot;
	}

	public void ResetTabCloseButtonBackHighColorHot()
	{
		__TabCloseButtonBackHighColorHot = defaultTabCloseButtonBackHighColorHot;
	}

	public bool ShouldSerializeTabCloseButtonBackLowColorHot()
	{
		return __TabCloseButtonBackLowColorHot != defaultTabCloseButtonBackLowColorHot;
	}

	public void ResetTabCloseButtonBackLowColorHot()
	{
		__TabCloseButtonBackLowColorHot = defaultTabCloseButtonBackLowColorHot;
	}

	public bool ShouldSerializeTabCloseButtonBorderColorHot()
	{
		return __TabCloseButtonBorderColorHot != defaultTabCloseButtonBorderColorHot;
	}

	public void ResetTabCloseButtonBorderColorHot()
	{
		__TabCloseButtonBorderColorHot = defaultTabCloseButtonBorderColorHot;
	}

	public bool ShouldSerializeTabCloseButtonForeColorHot()
	{
		return __TabCloseButtonForeColorHot != defaultTabCloseButtonForeColorHot;
	}

	public void ResetTabCloseButtonForeColorHot()
	{
		__TabCloseButtonForeColorHot = defaultTabCloseButtonForeColorHot;
	}

	public bool ShouldSerializeTabIconSize()
	{
		return __TabIconSize != defaultTabIconSize;
	}

	public void ResetTabIconSize()
	{
		__TabIconSize = defaultTabIconSize;
	}

	public bool ShouldSerializeTabCloseButtonSize()
	{
		return __TabCloseButtonSize != defaultTabCloseButtonSize;
	}

	public void ResetTabCloseButtonSize()
	{
		__TabCloseButtonSize = defaultTabCloseButtonSize;
	}

	public bool ShouldSerializeTabBackHighColor()
	{
		return __TabBackHighColor != defaultTabBackHighColor;
	}

	public void ResetTabBackHighColor()
	{
		__TabBackHighColor = defaultTabBackHighColor;
	}

	public bool ShouldSerializeTabBackLowColor()
	{
		return __TabBackLowColor != defaultTabBackLowColor;
	}

	public void ResetTabBackLowColor()
	{
		__TabBackLowColor = defaultTabBackLowColor;
	}

	public bool ShouldSerializeTabBackHighColorDisabled()
	{
		return __TabBackHighColorDisabled != defaultTabBackHighColorDisabled;
	}

	public void ResetTabBackHighColorDisabled()
	{
		__TabBackHighColorDisabled = defaultTabBackHighColorDisabled;
	}

	public bool ShouldSerializeTabBackLowColorDisabled()
	{
		return __TabBackLowColorDisabled != defaultTabBackLowColorDisabled;
	}

	public void ResetTabBackLowColorDisabled()
	{
		__TabBackLowColorDisabled = defaultTabBackLowColorDisabled;
	}

	public bool ShouldSerializeBorderColorDisabled()
	{
		return __BorderColorDisabled != defaultBorderColorDisabled;
	}

	public void ResetBorderColorDisabled()
	{
		__BorderColorDisabled = defaultBorderColorDisabled;
	}

	public bool ShouldSerializeForeColorDisabled()
	{
		return __ForeColorDisabled != defaultForeColorDisabled;
	}

	public void ResetForeColorDisabled()
	{
		__ForeColorDisabled = defaultForeColorDisabled;
	}

	public bool ShouldSerializePadding()
	{
		return pnlBottom.Padding != defaultPadding;
	}

	public void ResetPadding()
	{
		pnlBottom.Padding = defaultPadding;
	}

	public bool ShouldSerializeControlButtonBackHighColor()
	{
		return DropButton.BackHighColor != defaultControlButtonBackHighColor;
	}

	public void ResetControlButtonBackHighColor()
	{
		DropButton.BackHighColor = defaultControlButtonBackHighColor;
		CloseButton.BackHighColor = defaultControlButtonBackHighColor;
	}

	public bool ShouldSerializeControlButtonBackLowColor()
	{
		return DropButton.BackLowColor != defaultControlButtonBackLowColor;
	}

	public void ResetControlButtonBackLowColor()
	{
		DropButton.BackLowColor = defaultControlButtonBackLowColor;
		CloseButton.BackLowColor = defaultControlButtonBackLowColor;
	}

	public bool ShouldSerializeControlButtonBorderColor()
	{
		return DropButton.BorderColor != defaultControlButtonBorderColor;
	}

	public void ResetControlButtonBorderColor()
	{
		DropButton.BorderColor = defaultControlButtonBorderColor;
		CloseButton.BorderColor = defaultControlButtonBorderColor;
	}

	public bool ShouldSerializeControlButtonForeColor()
	{
		return DropButton.ForeColor != defaultControlButtonForeColor;
	}

	public void ResetControlButtonForeColor()
	{
		DropButton.ForeColor = defaultControlButtonForeColor;
		CloseButton.ForeColor = defaultControlButtonForeColor;
	}

	public bool ShouldSerializeBackLowColor()
	{
		return __BackLowColor != defaultBackLowColor;
	}

	public void ResetBackLowColor()
	{
		__BackLowColor = defaultBackLowColor;
	}

	public bool ShouldSerializeBackHighColor()
	{
		return __BackHighColor != defaultBackHighColor;
	}

	public void ResetBackHighColor()
	{
		__BackHighColor = defaultBackHighColor;
	}

	public bool ShouldSerializeBorderColor()
	{
		return __BorderColor != defaultBorderColor;
	}

	public void ResetBorderColor()
	{
		__BorderColor = defaultBorderColor;
	}

	public bool ShouldSerializeRenderMode()
	{
		return __RenderMode != defaultRenderMode;
	}

	public void ResetRenderMode()
	{
		__RenderMode = defaultRenderMode;
	}

	private void SetControlsSizeLocation()
	{
		if (DropButton.Visible & CloseButton.Visible)
		{
			pnlControls.Width = 43;
		}
		else if (DropButton.Visible | CloseButton.Visible)
		{
			pnlControls.Width = 25;
		}
		else
		{
			pnlControls.Width = 3;
		}
		pnlControls.Left = checked(base.Width - pnlControls.Width);
		CheckVisibility();
	}

	private void AdjustHeight()
	{
		checked
		{
			if (Alignment == TabAlignment.Top)
			{
				pnlTop.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
				pnlTop.Height = pnlTabs.Height + __TabTop;
				pnlTop.Top = Conversions.ToInteger(Interaction.IIf(__TopSeparator, 2, 0));
				pnlTabs.Top = __TabTop;
				pnlBottom.Height = Conversions.ToInteger(Operators.SubtractObject(base.Height, Operators.AddObject(pnlTop.Height, Interaction.IIf(__TopSeparator, 2, 0))));
				pnlBottom.Top = base.Height - pnlBottom.Height;
			}
			else
			{
				pnlTop.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
				pnlTop.Height = pnlTabs.Height + __TabTop;
				pnlTop.Top = base.Height - pnlTop.Height;
				pnlTabs.Top = 0;
				pnlBottom.Height = Conversions.ToInteger(Operators.SubtractObject(base.Height, Operators.AddObject(pnlTop.Height, Interaction.IIf(__TopSeparator, 2, 0))));
				pnlBottom.Top = Conversions.ToInteger(Interaction.IIf(__TopSeparator, 2, 0));
			}
			pnlTop.Invalidate();
		}
	}

	private void Arrange__Items()
	{
		pnlTabs.SuspendLayout();
		if (__Items.Count == 0)
		{
			return;
		}
		int num = __LeftOffset;
		checked
		{
			int num2 = __Items.Count - 1;
			int num3 = 0;
			while (true)
			{
				if (num3 <= num2)
				{
					__Items[num3].TabVisible = num + __Items[num3].Width < pnlControls.Left;
					if (__Items[num3].IsSelected & !__Items[num3].TabVisible)
					{
						break;
					}
					__Items[num3].TabLeft = num;
					num += __Items[num3].Width + __TabOffset - 1;
					num3++;
					continue;
				}
				if (!__AddingPage)
				{
					if (__IsDelete)
					{
						int num4 = __Items.Count - 1;
						for (int i = num4; i >= 0; i += -1)
						{
							ShowTab(i);
						}
						__IsDelete = false;
					}
					else
					{
						int num5 = __Items.Count - 1;
						for (int j = 0; j <= num5; j++)
						{
							ShowTab(j);
						}
					}
				}
				pnlTabs.ResumeLayout();
				return;
			}
			SelectItem(__Items[num3]);
		}
	}

	private void CheckVisibility()
	{
		if (__Items == null)
		{
			return;
		}
		int num = __LeftOffset;
		checked
		{
			int num2 = __Items.Count - 1;
			for (int i = 0; i <= num2; i++)
			{
				if (__Items[i].TabVisible != num + __Items[i].Width < pnlControls.Left)
				{
					if (__Items[i].TabVisible)
					{
						__Items[i].TabVisible = false;
						if (__Items[i].IsSelected)
						{
							SelectItem(__Items[i]);
						}
						else
						{
							ShowTab(i);
						}
						break;
					}
					__Items[i].TabVisible = true;
					__Items[i].TabLeft = num;
					ShowTab(i);
				}
				else if (!__Items[i].TabVisible)
				{
					break;
				}
				num += __Items[i].Width + __TabOffset - 1;
				if (num > pnlControls.Left)
				{
					break;
				}
			}
		}
	}

	private void ShowTab(int i)
	{
		__Items[i].Visible = __Items[i].TabVisible;
		if (__Items[0].Width != 1)
		{
			__Items[i].Left = __Items[i].TabLeft;
		}
	}

	public int SelectedIndex()
	{
		checked
		{
			int num = TabPages.Count - 1;
			int num2 = 0;
			while (true)
			{
				if (num2 <= num)
				{
					if (TabPages[num2].IsSelected)
					{
						break;
					}
					num2++;
					continue;
				}
				return -1;
			}
			return num2;
		}
	}

	public void SelectItem(int index)
	{
		if (index < 0)
		{
			index = 0;
		}
		SelectItem(TabPages[index]);
	}

	public void SelectItem(TabPageExt __TabPage)
	{
		Globals.LockWindowUpdate(pnlControls.Handle);
		foreach (TabPageExt tabPage in TabPages)
		{
			tabPage.IsSelected = false;
		}
		if (__TabPage != null)
		{
			foreach (TabPageExt tabPage2 in TabPages)
			{
				if (__TabsDirection == FlowDirection.LeftToRight)
				{
					tabPage2.SendToBack();
				}
				else
				{
					tabPage2.BringToFront();
				}
			}
			__TabPage.Form.Dock = DockStyle.Fill;
			__TabPage.Form.Visible = true;
			__TabPage.BringToFront();
			__TabPage.Form.BringToFront();
			__TabPage.Form.Focus();
			if (pnlBottom.Controls.Count > 1)
			{
				pnlBottom.Controls[1].Visible = false;
				pnlBottom.Controls[1].Dock = DockStyle.None;
			}
			__TabPage.IsSelected = true;
			if (!__TabPage.TabVisible & (TabPages.get_IndexOf(__TabPage) != 0))
			{
				TabPages.set_IndexOf(__TabPage, 0);
			}
			SelectedFormIndex = __TabPage.Form;
			SelectedFormIndex.Tag = __TabPage;
			TabSelectedForm?.Invoke(this, SelectedFormIndex);
		}
		else if (pnlTabs.Controls.Count > 0)
		{
			foreach (TabPageExt _Item in __Items)
			{
				if (_Item.Form.Equals(pnlBottom.Controls[0]))
				{
					_Item.Select();
					break;
				}
			}
		}
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	private void __TabControl_FontChanged(object sender, EventArgs e)
	{
		foreach (TabPageExt tabPage in TabPages)
		{
			tabPage.Font = Font;
		}
	}

	private void __TabControl_ForeColorChanged(object sender, EventArgs e)
	{
		foreach (TabPageExt tabPage in TabPages)
		{
			tabPage.ForeColor = ForeColor;
		}
	}

	private void __TabControl_Paint(object sender, PaintEventArgs e)
	{
		if (__TopSeparator)
		{
			ControlPaint.DrawBorder3D(e.Graphics, new Rectangle(-2, 0, checked(base.Width + 4), -2));
		}
	}

	private void __TabControl_Resize(object sender, EventArgs e)
	{
		CheckVisibility();
	}

	private void pnlTop_SizeChanged(object sender, EventArgs e)
	{
		PositionButtons();
	}

	private void PositionButtons()
	{
		DropButton.Top = Conversions.ToInteger(Operators.AddObject(Math.Ceiling((double)checked(pnlTop.Height - DropButton.Height) / 2.0), Interaction.IIf((Alignment == TabAlignment.Top) & TopSeparator, -1, 0)));
		CloseButton.Top = DropButton.Top;
	}

	private void pnlTop_Paint(object sender, PaintEventArgs e)
	{
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush(new Point(0, 0), new Point(0, pnlTop.Height), Helper.RenderColors.BackHighColor(__RenderMode, BackHighColor), Helper.RenderColors.BackLowColor(__RenderMode, BackLowColor));
		e.Graphics.FillRectangle(linearGradientBrush, new Rectangle(0, 0, pnlTop.Width, pnlTop.Height));
		Pen pen = new Pen(Helper.RenderColors.BorderColor(__RenderMode, BorderColor));
		if (Alignment == TabAlignment.Top)
		{
			Graphics graphics = e.Graphics;
			object[] obj = new object[5]
			{
				pen,
				0,
				Operators.SubtractObject(NewLateBinding.LateGet(sender, null, "Height", new object[0], null, null, null), 1),
				Operators.AddObject(NewLateBinding.LateGet(sender, null, "Width", new object[0], null, null, null), 1),
				Operators.SubtractObject(NewLateBinding.LateGet(sender, null, "Height", new object[0], null, null, null), 1)
			};
			object[] array = obj;
			bool[] obj2 = new bool[5] { true, false, false, false, false };
			bool[] array2 = obj2;
			NewLateBinding.LateCall(graphics, null, "DrawLine", obj, null, null, obj2, IgnoreReturn: true);
			if (array2[0])
			{
				pen = (Pen)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[0]), typeof(Pen));
			}
		}
		else
		{
			Graphics graphics2 = e.Graphics;
			object[] obj3 = new object[5]
			{
				pen,
				0,
				0,
				Operators.AddObject(NewLateBinding.LateGet(sender, null, "Width", new object[0], null, null, null), 1),
				0
			};
			object[] array = obj3;
			bool[] obj4 = new bool[5] { true, false, false, false, false };
			bool[] array2 = obj4;
			NewLateBinding.LateCall(graphics2, null, "DrawLine", obj3, null, null, obj4, IgnoreReturn: true);
			if (array2[0])
			{
				pen = (Pen)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[0]), typeof(Pen));
			}
		}
		pen.Dispose();
		linearGradientBrush.Dispose();
	}

	private void DropButton_MouseDown(object sender, MouseEventArgs e)
	{
		WinMenu.Items.Clear();
		checked
		{
			int num = __Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				WinMenu.Items.Add(__Items[i].MenuItem);
				__Items[i].MenuItem.Click += MenuClick;
			}
			WinMenu.ShowImageMargin = false;
			WinMenu.Show(pnlTop, pnlTop.Width - WinMenu.Width, pnlTop.Height - 1);
		}
	}

	private void MenuClick(object sender, EventArgs e)
	{
		NewLateBinding.LateCall(NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null), null, "Select", new object[0], null, null, null, IgnoreReturn: true);
	}

	private void CloseButton_MouseDown(object sender, MouseEventArgs e)
	{
		__Items.SelectedTab().Form.Close();
	}

	private void __ItemsGetTabRegion(object sender, GetTabRegionEventArgs e)
	{
		GetTabRegion?.Invoke(RuntimeHelpers.GetObjectValue(sender), e);
	}

	private void __ItemsTabPaint__Background(object sender, TabPaintEventArgs e)
	{
		TabPaintBackground?.Invoke(RuntimeHelpers.GetObjectValue(sender), e);
	}

	private void __ItemsTabPaintBorder(object sender, TabPaintEventArgs e)
	{
		TabPaintBorder?.Invoke(RuntimeHelpers.GetObjectValue(sender), e);
	}

	public void SetColors(ProfessionalColorTable ColorTable)
	{
		BackHighColor = ColorTable.ToolStripGradientEnd;
		BackLowColor = ColorTable.ToolStripGradientBegin;
		BorderColor = ColorTable.GripDark;
		BorderColorDisabled = ColorTable.SeparatorDark;
		ControlButtonBackHighColor = ColorTable.ButtonSelectedGradientBegin;
		ControlButtonBackLowColor = ColorTable.ButtonSelectedGradientEnd;
		ControlButtonBorderColor = ColorTable.ButtonPressedBorder;
		TabBackHighColor = ColorTable.MenuItemPressedGradientBegin;
		TabBackLowColor = ColorTable.MenuItemPressedGradientEnd;
		TabBackHighColorDisabled = ColorTable.ToolStripDropDownBackground;
		TabBackLowColorDisabled = ColorTable.ToolStripGradientMiddle;
		TabCloseButtonBackHighColor = Color.Transparent;
		TabCloseButtonBackHighColorDisabled = Color.Transparent;
		TabCloseButtonBackHighColorHot = Color.WhiteSmoke;
		TabCloseButtonBackLowColor = Color.Transparent;
		TabCloseButtonBackLowColorDisabled = Color.Transparent;
		TabCloseButtonBackLowColorHot = Color.LightGray;
		TabCloseButtonBorderColor = Color.Transparent;
		TabCloseButtonBorderColorDisabled = Color.Transparent;
		TabCloseButtonBorderColorHot = Color.Gray;
		TabCloseButtonForeColor = Color.Gray;
		TabCloseButtonForeColorDisabled = Color.Gray;
		TabCloseButtonForeColorHot = Color.Firebrick;
	}
}
