public class RegExpResult
{
	private int int_0;

	private string string_0;

	public int Index
	{
		get
		{
			return int_0;
		}
		set
		{
			int_0 = value;
		}
	}

	public string Value
	{
		get
		{
			return string_0;
		}
		set
		{
			string_0 = value;
		}
	}
}
