using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
public class HttpLog : Form
{
	private IContainer icontainer_0;

	private ToolStripButton toolStripButton_0;

	private Panel panel_0;

	private DataGridView dataGridView_0;

	public HttpLog(ToolStripButton t, Panel b, DataGridView g)
	{
		base.Closing += HttpLog_Closing;
		InitializeComponent();
		toolStripButton_0 = t;
		panel_0 = b;
		dataGridView_0 = g;
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		base.SuspendLayout();
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(863, 395);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
		base.Name = "HttpLog";
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
		this.Text = "HTTP Debugger";
		base.ResumeLayout(false);
	}

	private void HttpLog_Closing(object sender, CancelEventArgs e)
	{
		Globals.LockWindowUpdate(Globals.GMain.Handle);
		toolStripButton_0.Checked = false;
		panel_0.Visible = false;
		toolStripButton_0.Visible = true;
		panel_0.Controls.Add(dataGridView_0);
		Globals.LockWindowUpdate(IntPtr.Zero);
	}
}
