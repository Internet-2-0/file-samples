using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

public class DataGP
{
	public MemoryStream _MemoryStream;

	private ImageList imageList_0;

	public DataGP(MemoryStream ms, ImageList img = null)
	{
		_MemoryStream = ms;
		if (img == null)
		{
			img = Globals.GMain.imgData;
		}
		imageList_0 = img;
	}

	public DataGP(string FileLocation, ImageList oImagelist = null)
	{
		if (File.Exists(FileLocation))
		{
			FileStream fileStream = new FileStream(FileLocation, FileMode.Open, FileAccess.Read);
			_MemoryStream = new MemoryStream();
			byte[] array = new byte[257];
			while (fileStream.Read(array, 0, array.Length) != 0)
			{
				_MemoryStream.Write(array, 0, array.Length);
			}
			fileStream.Close();
		}
		imageList_0 = oImagelist;
	}

	public static List<string> EnumerateCountry()
	{
		List<string> list = new List<string>();
		checked
		{
			int num = Globals.CountryName.Length - 1;
			for (int i = 0; i <= num; i++)
			{
				list.Add("[" + Globals.CountryCode[i] + "] " + Globals.CountryName[i]);
			}
			return list;
		}
	}

	public void Lookup(string sIP, ref string sCountry, [Optional][DefaultParameterValue(null)] ref Image oImage, [Optional][DefaultParameterValue("")] ref string sCountryCode, bool bUnionContryCode = false)
	{
		try
		{
			sCountryCode = LookupCountryCode(sIP);
			if (bUnionContryCode)
			{
				sCountry = "[" + sCountryCode + "] " + LookupCountryName(sIP);
			}
			else
			{
				sCountry = LookupCountryName(sIP);
			}
			oImage = GetFlag(sCountryCode);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	public string LookupCountry(string sIP)
	{
		return "[" + LookupCountryCode(sIP) + "] " + LookupCountryName(sIP);
	}

	public Image GetFlag(string sContryCode)
	{
		if (method_2(sContryCode))
		{
			return imageList_0.Images[LookupCountryCode(sContryCode).ToLower() + ".png"];
		}
		return imageList_0.Images[sContryCode.ToLower() + ".png"];
	}

	private long method_0(IPAddress ipaddress_0)
	{
		string[] array = Strings.Split(ipaddress_0.ToString(), ".");
		if (Information.UBound(array) == 3)
		{
			return checked((long)Math.Round(16777216.0 * Conversions.ToDouble(array[0]) + 65536.0 * Conversions.ToDouble(array[1]) + 256.0 * Conversions.ToDouble(array[2]) + Conversions.ToDouble(array[3])));
		}
		return 0L;
	}

	private string method_1(long long_0)
	{
		string text = Conversions.ToString(Conversion.Int((double)long_0 / 16777216.0) % 256.0);
		string text2 = Conversions.ToString(Conversion.Int((double)long_0 / 65536.0) % 256.0);
		string text3 = Conversions.ToString(Conversion.Int((double)long_0 / 256.0) % 256.0);
		string text4 = Conversions.ToString(Conversion.Int(long_0) % 256);
		return text + "." + text2 + "." + text3 + "." + text4;
	}

	private bool method_2(string string_0)
	{
		string pattern = "\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b";
		Regex regex = new Regex(pattern, RegexOptions.None);
		Match match = regex.Match(string_0);
		return match.Success;
	}

	public static MemoryStream FileToMemory(string FileLocation)
	{
		FileStream fileStream = new FileStream(FileLocation, FileMode.Open, FileAccess.Read);
		MemoryStream memoryStream = new MemoryStream();
		byte[] array = new byte[257];
		while (fileStream.Read(array, 0, array.Length) != 0)
		{
			memoryStream.Write(array, 0, array.Length);
		}
		fileStream.Close();
		return memoryStream;
	}

	public string LookupCountryCode(IPAddress _IPAddress)
	{
		return Globals.CountryCode[checked((int)method_5(0L, method_0(_IPAddress), 31))];
	}

	public bool CountryCodeExist(string sCode)
	{
		string[] countryCode = Globals.CountryCode;
		foreach (string text in countryCode)
		{
			if (text.ToLower().Equals(sCode.ToLower()))
			{
				return true;
			}
		}
		bool result = default(bool);
		return result;
	}

	public string CountryNameByCode(string sCode)
	{
		checked
		{
			int num = Globals.CountryCode.Length - 1;
			int num2 = 0;
			while (true)
			{
				if (num2 <= num)
				{
					if (Globals.CountryCode[num2].ToLower().Equals(sCode.ToLower()))
					{
						break;
					}
					num2++;
					continue;
				}
				return "";
			}
			return "[" + Globals.CountryCode[num2] + "] " + Globals.CountryName[num2];
		}
	}

	public string LookupCountryCode(string _IPAddress)
	{
		string result;
		try
		{
			if (!method_2(_IPAddress))
			{
				result = "--";
			}
			else
			{
				IPAddress iPAddress = IPAddress.Parse(_IPAddress);
				result = LookupCountryCode(iPAddress);
			}
		}
		catch (FormatException projectError)
		{
			ProjectData.SetProjectError(projectError);
			result = "--";
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public string LookupCountryName(IPAddress addr)
	{
		return Globals.CountryName[checked((int)method_5(0L, method_0(addr), 31))];
	}

	public string LookupCountryName(string _IPAddress)
	{
		IPAddress addr;
		string result;
		try
		{
			addr = IPAddress.Parse(_IPAddress);
		}
		catch (FormatException projectError)
		{
			ProjectData.SetProjectError(projectError);
			result = "N/A";
			ProjectData.ClearProjectError();
			goto IL_0026;
		}
		result = LookupCountryName(addr);
		goto IL_0026;
		IL_0026:
		return result;
	}

	private long method_3(long long_0, int int_0)
	{
		long num = long_0;
		checked
		{
			for (int i = 1; i <= int_0; i++)
			{
				num *= 2;
			}
			return num;
		}
	}

	private long method_4(long long_0, int int_0)
	{
		long num = long_0;
		for (int i = 1; i <= int_0; i = checked(i + 1))
		{
			num /= 2;
		}
		return num;
	}

	private long method_5(long long_0, long long_1, int int_0)
	{
		//IL_00aa: Expected I8, but got I4
		if (_MemoryStream == null)
		{
			return 0L;
		}
		byte[] array = new byte[7];
		long[] array2 = new long[3];
		if (int_0 != 0)
		{
		}
		checked
		{
			try
			{
				_MemoryStream.Seek(6 * long_0, SeekOrigin.Begin);
				_MemoryStream.Read(array, 0, 6);
			}
			catch (IOException projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
			int num = 0;
			array2[num] = 0L;
			int num2 = 0;
			do
			{
				int num3 = array[num * 3 + num2];
				if (num3 < 0)
				{
					num3 += 256;
				}
				array2[num] += method_3(num3, num2 * 8);
				num2++;
			}
			while (num2 <= 2);
			num++;
			return 0L;
		}
	}
}
