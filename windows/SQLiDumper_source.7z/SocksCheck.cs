using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Chilkat;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class SocksCheck : Form
{
	private delegate void Delegate53(int iValue);

	private delegate void Delegate54(string sMessage);

	private sealed class Class53
	{
		internal int int_0;

		internal Thread thread_0;

		internal string string_0;

		public Class53(int int_1)
		{
			int_1 = int_1;
		}
	}

	private IContainer icontainer_0;

	[AccessedThroughProperty("btnStart")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripButton _btnStart;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnPause")]
	private ToolStripButton _btnPause;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnStop")]
	private ToolStripButton _btnStop;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("bckWorker")]
	[CompilerGenerated]
	private BackgroundWorker backgroundWorker_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnOK")]
	private ToolStripButton _btnOK;

	internal ArrayList arrayList_0;

	internal ArrayList arrayList_1;

	internal ArrayList arrayList_2;

	private ArrayList arrayList_3;

	private bool bool_0;

	private ThreadPool threadPool_0;

	private bool bool_1;

	private int int_0;

	private int int_1;

	private string string_0;

	private string string_1;

	[field: AccessedThroughProperty("ToolStrip1")]
	internal virtual ToolStrip ToolStrip1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnStart
	{
		[CompilerGenerated]
		get
		{
			return _btnStart;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_2;
			ToolStripButton toolStripButton = _btnStart;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnStart = value;
			toolStripButton = _btnStart;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator2")]
	internal virtual ToolStripSeparator ToolStripSeparator2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnPause
	{
		[CompilerGenerated]
		get
		{
			return _btnPause;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_3;
			ToolStripButton toolStripButton = _btnPause;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnPause = value;
			toolStripButton = _btnPause;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator3")]
	internal virtual ToolStripSeparator ToolStripSeparator3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnStop
	{
		[CompilerGenerated]
		get
		{
			return _btnStop;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_4;
			ToolStripButton toolStripButton = _btnStop;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnStop = value;
			toolStripButton = _btnStop;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("numTimeout")]
	internal virtual NumericUpDown numTimeout
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label2")]
	internal virtual Label Label2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numThreads")]
	internal virtual NumericUpDown numThreads
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label3")]
	internal virtual Label Label3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("stsMain")]
	internal virtual StatusStrip stsMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblStatus")]
	internal virtual ToolStripStatusLabel lblStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pgbChecker")]
	internal virtual ProgressBar pgbChecker
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public virtual BackgroundWorker bckWorker
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler value2 = method_5;
			RunWorkerCompletedEventHandler value3 = method_6;
			BackgroundWorker backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork -= value2;
				backgroundWorker.RunWorkerCompleted -= value3;
			}
			backgroundWorker_0 = value;
			backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork += value2;
				backgroundWorker.RunWorkerCompleted += value3;
			}
		}
	}

	internal virtual ToolStripButton btnOK
	{
		[CompilerGenerated]
		get
		{
			return _btnOK;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_8;
			ToolStripButton toolStripButton = _btnOK;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnOK = value;
			toolStripButton = _btnOK;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	public SocksCheck()
	{
		base.FormClosing += SocksCheck_FormClosing;
		base.Load += SocksCheck_Load;
		arrayList_0 = new ArrayList();
		string_0 = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtUserAgent));
		string_1 = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtAccept));
		InitializeComponent();
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
		this.btnStart = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
		this.btnPause = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
		this.btnStop = new System.Windows.Forms.ToolStripButton();
		this.btnOK = new System.Windows.Forms.ToolStripButton();
		this.Label2 = new System.Windows.Forms.Label();
		this.Label3 = new System.Windows.Forms.Label();
		this.stsMain = new System.Windows.Forms.StatusStrip();
		this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
		this.pgbChecker = new System.Windows.Forms.ProgressBar();
		this.bckWorker = new System.ComponentModel.BackgroundWorker();
		this.numTimeout = new System.Windows.Forms.NumericUpDown();
		this.numThreads = new System.Windows.Forms.NumericUpDown();
		this.ToolStrip1.SuspendLayout();
		this.stsMain.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numTimeout).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numThreads).BeginInit();
		base.SuspendLayout();
		this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.ToolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.btnStart, this.ToolStripSeparator2, this.btnPause, this.ToolStripSeparator3, this.btnStop, this.btnOK });
		this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
		this.ToolStrip1.Name = "ToolStrip1";
		this.ToolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.ToolStrip1.Size = new System.Drawing.Size(390, 32);
		this.ToolStrip1.TabIndex = 0;
		this.ToolStrip1.Text = "ToolStrip1";
		this.btnStart.Image = ns0.Class6.Run_16x_24;
		this.btnStart.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnStart.Name = "btnStart";
		this.btnStart.Size = new System.Drawing.Size(76, 29);
		this.btnStart.Text = "&Start";
		this.ToolStripSeparator2.Name = "ToolStripSeparator2";
		this.ToolStripSeparator2.Size = new System.Drawing.Size(6, 32);
		this.btnPause.CheckOnClick = true;
		this.btnPause.Enabled = false;
		this.btnPause.Image = ns0.Class6.Pause_16x_24;
		this.btnPause.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnPause.Name = "btnPause";
		this.btnPause.Size = new System.Drawing.Size(85, 29);
		this.btnPause.Text = "&Pause";
		this.btnPause.Visible = false;
		this.ToolStripSeparator3.Name = "ToolStripSeparator3";
		this.ToolStripSeparator3.Size = new System.Drawing.Size(6, 32);
		this.ToolStripSeparator3.Visible = false;
		this.btnStop.Enabled = false;
		this.btnStop.Image = ns0.Class6.Stop_16x_24;
		this.btnStop.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnStop.Name = "btnStop";
		this.btnStop.Size = new System.Drawing.Size(77, 29);
		this.btnStop.Text = "&Stop";
		this.btnOK.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnOK.Enabled = false;
		this.btnOK.Image = ns0.Class6.AddAgent_16x_24;
		this.btnOK.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnOK.Name = "btnOK";
		this.btnOK.Size = new System.Drawing.Size(64, 29);
		this.btnOK.Text = "&OK";
		this.Label2.Location = new System.Drawing.Point(196, 43);
		this.Label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label2.Name = "Label2";
		this.Label2.Size = new System.Drawing.Size(93, 26);
		this.Label2.TabIndex = 14;
		this.Label2.Text = "Timeout";
		this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.Label3.Location = new System.Drawing.Point(6, 43);
		this.Label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label3.Name = "Label3";
		this.Label3.Size = new System.Drawing.Size(93, 26);
		this.Label3.TabIndex = 12;
		this.Label3.Text = "Threads";
		this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.stsMain.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.stsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.lblStatus });
		this.stsMain.Location = new System.Drawing.Point(0, 132);
		this.stsMain.Name = "stsMain";
		this.stsMain.Padding = new System.Windows.Forms.Padding(2, 0, 21, 0);
		this.stsMain.Size = new System.Drawing.Size(390, 30);
		this.stsMain.SizingGrip = false;
		this.stsMain.TabIndex = 16;
		this.stsMain.Text = "Ready.";
		this.lblStatus.Name = "lblStatus";
		this.lblStatus.Size = new System.Drawing.Size(367, 25);
		this.lblStatus.Spring = true;
		this.lblStatus.Text = "Socks Checker";
		this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.pgbChecker.Location = new System.Drawing.Point(10, 83);
		this.pgbChecker.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pgbChecker.Name = "pgbChecker";
		this.pgbChecker.Size = new System.Drawing.Size(366, 35);
		this.pgbChecker.TabIndex = 5;
		this.bckWorker.WorkerSupportsCancellation = true;
		this.numTimeout.Increment = new decimal(new int[4] { 5, 0, 0, 0 });
		this.numTimeout.Location = new System.Drawing.Point(298, 43);
		this.numTimeout.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.numTimeout.Maximum = new decimal(new int[4] { 30, 0, 0, 0 });
		this.numTimeout.Minimum = new decimal(new int[4] { 5, 0, 0, 0 });
		this.numTimeout.Name = "numTimeout";
		this.numTimeout.Size = new System.Drawing.Size(78, 26);
		this.numTimeout.TabIndex = 1;
		this.numTimeout.Value = new decimal(new int[4] { 20, 0, 0, 0 });
		this.numThreads.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
		this.numThreads.Location = new System.Drawing.Point(108, 43);
		this.numThreads.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.numThreads.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numThreads.Name = "numThreads";
		this.numThreads.Size = new System.Drawing.Size(78, 26);
		this.numThreads.TabIndex = 2;
		this.numThreads.Value = new decimal(new int[4] { 30, 0, 0, 0 });
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(390, 162);
		base.Controls.Add(this.pgbChecker);
		base.Controls.Add(this.stsMain);
		base.Controls.Add(this.numTimeout);
		base.Controls.Add(this.Label2);
		base.Controls.Add(this.numThreads);
		base.Controls.Add(this.Label3);
		base.Controls.Add(this.ToolStrip1);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "SocksCheck";
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Socks Check";
		this.ToolStrip1.ResumeLayout(false);
		this.ToolStrip1.PerformLayout();
		this.stsMain.ResumeLayout(false);
		this.stsMain.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.numTimeout).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numThreads).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void method_0(string string_2)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 123:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0019;
						case 5:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 4:
						case 6:
						case 7:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					if (!stsMain.InvokeRequired)
					{
						break;
					}
					goto IL_0019;
					IL_0019:
					num = 3;
					stsMain.Invoke(new Delegate54(method_0), string_2);
					goto end_IL_0001_3;
					end_IL_0001_2:
					break;
				}
				num = 5;
				lblStatus.Text = string_2;
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 123;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_1(int int_2)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 128:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0019;
						case 5:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 4:
						case 6:
						case 7:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					if (!stsMain.InvokeRequired)
					{
						break;
					}
					goto IL_0019;
					IL_0019:
					num = 3;
					stsMain.Invoke(new Delegate53(method_1), int_2);
					goto end_IL_0001_3;
					end_IL_0001_2:
					break;
				}
				num = 5;
				pgbChecker.Value = int_2;
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 128;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_2(object sender, EventArgs e)
	{
		if (bool_1)
		{
			return;
		}
		btnStart.Enabled = false;
		btnPause.Enabled = true;
		btnStop.Enabled = true;
		btnOK.Enabled = false;
		numThreads.Enabled = false;
		numTimeout.Enabled = false;
		int_0 = Convert.ToInt32(numThreads.Value);
		int_1 = Convert.ToInt32(numTimeout.Value);
		arrayList_3 = new ArrayList();
		arrayList_1 = new ArrayList();
		arrayList_2 = new ArrayList();
		foreach (object item in arrayList_0)
		{
			string value = Conversions.ToString(item);
			arrayList_3.Add(value);
		}
		bckWorker.RunWorkerAsync();
	}

	private void method_3(object sender, EventArgs e)
	{
		bool_0 = !bool_0;
		btnStop.Enabled = !bool_0;
	}

	private void method_4(object sender, EventArgs e)
	{
		if (!bckWorker.CancellationPending)
		{
			bckWorker.CancelAsync();
		}
		btnPause.Enabled = false;
		btnStop.Enabled = false;
	}

	private void method_5(object sender, DoWorkEventArgs e)
	{
		checked
		{
			try
			{
				int num = 1;
				int count = arrayList_3.Count;
				bool_1 = true;
				int maxThreadCount = ((int_0 <= count) ? int_0 : count);
				threadPool_0 = new ThreadPool(maxThreadCount);
				foreach (object item in arrayList_3)
				{
					string text = Conversions.ToString(item);
					if (!bckWorker.CancellationPending)
					{
						if (threadPool_0.Status != ThreadPool.ThreadStatus.Stopped)
						{
							threadPool_0.Paused = true;
							while (bool_0)
							{
								Thread.Sleep(500);
							}
							threadPool_0.Paused = false;
							lock (this)
							{
								int int_ = (int)Math.Round(Math.Round((double)(100 * num) / (double)count));
								method_0("[" + Conversions.ToString(num) + "/" + Conversions.ToString(count) + "] Checking, checked: " + Conversions.ToString(arrayList_1.Count));
								method_1(int_);
							}
							Thread thread = new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
							{
								method_7((Class53)object_0);
							});
							thread.Name = "Pos : " + num;
							Class53 @class = new Class53(num);
							@class.thread_0 = thread;
							@class.string_0 = text;
							thread.Start(@class);
							threadPool_0.Open(thread);
							threadPool_0.WaitForThreads();
							num++;
							continue;
						}
						break;
					}
					threadPool_0.AbortThreads();
					break;
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message);
				ProjectData.ClearProjectError();
			}
			finally
			{
				threadPool_0.AllJobsPushed();
				do
				{
					method_0("[" + Conversions.ToString(threadPool_0.ThreadCount) + "] Finishing, checked: " + Conversions.ToString(arrayList_1.Count));
					if (bckWorker.CancellationPending)
					{
						threadPool_0.AbortThreads();
						break;
					}
				}
				while (!threadPool_0.Finished);
			}
		}
	}

	private void method_6(object sender, RunWorkerCompletedEventArgs e)
	{
		try
		{
			btnStart.Enabled = true;
			btnPause.Enabled = false;
			btnStop.Enabled = false;
			btnOK.Enabled = true;
			numThreads.Enabled = true;
			numTimeout.Enabled = true;
			pgbChecker.Value = 0;
			bool_1 = false;
			method_0("Done, Checked: " + Conversions.ToString(arrayList_1.Count));
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_7(Class53 class53_0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected O, but got Unknown
		bool flag = default(bool);
		try
		{
			Http val = new Http();
			try
			{
				val.UserAgent = string_0;
				val.Accept = string_1;
				string[] array = class53_0.string_0.Split('|');
				if (array.Length <= 1)
				{
					return;
				}
				int num = Conversions.ToInteger(array[2]);
				if (num == 0)
				{
					val.ProxyDomain = array[0];
					val.ProxyPort = Conversions.ToInteger(array[1]);
					if (array.Length == 5)
					{
						val.ProxyLogin = array[3];
						val.ProxyPassword = array[4];
					}
				}
				else
				{
					val.SocksVersion = num;
					val.SocksHostname = array[0];
					val.SocksPort = Conversions.ToInteger(array[1]);
					if (array.Length == 5)
					{
						val.SocksUsername = array[3];
						val.SocksPassword = array[4];
					}
				}
				val.ConnectTimeout = int_1;
				val.ReadTimeout = int_1;
				string text = val.QuickGetStr("http://www.google.com/");
				if (!string.IsNullOrEmpty(text) && text.Length > 10)
				{
					flag = val.LastStatus == 200;
				}
			}
			finally
			{
				((IDisposable)val)?.Dispose();
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			if (ex2 is ThreadAbortException)
			{
			}
			ProjectData.ClearProjectError();
		}
		finally
		{
			try
			{
				if (flag)
				{
					arrayList_1.Add(class53_0.string_0);
				}
				else
				{
					arrayList_2.Add(class53_0.string_0);
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
			try
			{
				threadPool_0.Close(class53_0.thread_0);
			}
			catch (Exception projectError2)
			{
				ProjectData.SetProjectError(projectError2);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_8(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.OK;
		Close();
	}

	private void SocksCheck_FormClosing(object sender, FormClosingEventArgs e)
	{
		if (bool_1)
		{
			e.Cancel = true;
			Interaction.Beep();
		}
		else
		{
			Class50.smethod_3(this);
		}
	}

	private void SocksCheck_Load(object sender, EventArgs e)
	{
		numThreads.Maximum = new decimal(arrayList_0.Count);
		if (decimal.Compare(numThreads.Maximum, 300m) > 0)
		{
			numThreads.Maximum = 300m;
		}
		numTimeout.Focus();
		Class50.smethod_2(this);
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_9(object object_0)
	{
		method_7((Class53)object_0);
	}
}
