using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
public class ImpBox : Form
{
	private IContainer icontainer_0;

	[AccessedThroughProperty("OK_Button")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _OK_Button;

	[AccessedThroughProperty("Cancel_Button")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _Cancel_Button;

	[AccessedThroughProperty("txtValue")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtValue;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int int_0;

	internal virtual Button OK_Button
	{
		[CompilerGenerated]
		get
		{
			return _OK_Button;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_0;
			Button oK_Button = _OK_Button;
			if (oK_Button != null)
			{
				oK_Button.Click -= value2;
			}
			_OK_Button = value;
			oK_Button = _OK_Button;
			if (oK_Button != null)
			{
				oK_Button.Click += value2;
			}
		}
	}

	internal virtual Button Cancel_Button
	{
		[CompilerGenerated]
		get
		{
			return _Cancel_Button;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_1;
			Button cancel_Button = _Cancel_Button;
			if (cancel_Button != null)
			{
				cancel_Button.Click -= value2;
			}
			_Cancel_Button = value;
			cancel_Button = _Cancel_Button;
			if (cancel_Button != null)
			{
				cancel_Button.Click += value2;
			}
		}
	}

	internal virtual TextBox txtValue
	{
		[CompilerGenerated]
		get
		{
			return _txtValue;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_2;
			TextBox textBox = _txtValue;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtValue = value;
			textBox = _txtValue;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	public int MinLengh
	{
		[CompilerGenerated]
		get
		{
			return int_0;
		}
		[CompilerGenerated]
		set
		{
			int_0 = value;
		}
	}

	public ImpBox()
	{
		base.Load += ImpBox_Load;
		MinLengh = 1;
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.OK_Button = new System.Windows.Forms.Button();
		this.Cancel_Button = new System.Windows.Forms.Button();
		this.txtValue = new System.Windows.Forms.TextBox();
		base.SuspendLayout();
		this.OK_Button.Enabled = false;
		this.OK_Button.Location = new System.Drawing.Point(241, 48);
		this.OK_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.OK_Button.Name = "OK_Button";
		this.OK_Button.Size = new System.Drawing.Size(132, 30);
		this.OK_Button.TabIndex = 1;
		this.OK_Button.Text = "OK";
		this.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.Cancel_Button.Location = new System.Drawing.Point(10, 48);
		this.Cancel_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.Cancel_Button.Name = "Cancel_Button";
		this.Cancel_Button.Size = new System.Drawing.Size(132, 30);
		this.Cancel_Button.TabIndex = 2;
		this.Cancel_Button.Text = "Cancel";
		this.txtValue.Location = new System.Drawing.Point(9, 9);
		this.txtValue.Name = "txtValue";
		this.txtValue.Size = new System.Drawing.Size(361, 26);
		this.txtValue.TabIndex = 0;
		base.AcceptButton = this.OK_Button;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.CancelButton = this.Cancel_Button;
		base.ClientSize = new System.Drawing.Size(382, 89);
		base.Controls.Add(this.OK_Button);
		base.Controls.Add(this.Cancel_Button);
		base.Controls.Add(this.txtValue);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "ImpBox";
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Add Value";
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void method_0(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.OK;
		Close();
	}

	private void method_1(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.Cancel;
		Close();
	}

	private void method_2(object sender, EventArgs e)
	{
		txtValue.Text = txtValue.Text.Replace(" ", "");
		OK_Button.Enabled = !string.IsNullOrEmpty(txtValue.Text) & (txtValue.Text.Length >= MinLengh);
	}

	private void ImpBox_Load(object sender, EventArgs e)
	{
		Globals.AddMouseMoveForm(this);
		Cancel_Button.Text = Globals.translate_0.GetStr("PathAdd", "Cancel_Button", "Cancel");
		OK_Button.Text = Globals.translate_0.GetStr("PathAdd", "OK_Button", "OK");
	}
}
