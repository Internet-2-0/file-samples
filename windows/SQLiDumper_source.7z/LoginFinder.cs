using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class LoginFinder : Form
{
	private delegate void Delegate16(int iValue);

	private delegate void Delegate17(string sMessage);

	private delegate void Delegate18(string url);

	private delegate bool Delegate19();

	private sealed class Class43
	{
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private Thread thread_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string string_1;

		public Thread Thread
		{
			[CompilerGenerated]
			get
			{
				return thread_0;
			}
			[CompilerGenerated]
			set
			{
				thread_0 = value;
			}
		}

		public string Page
		{
			[CompilerGenerated]
			get
			{
				return string_0;
			}
			[CompilerGenerated]
			set
			{
				string_0 = value;
			}
		}

		public string Url
		{
			[CompilerGenerated]
			get
			{
				return string_1;
			}
			[CompilerGenerated]
			set
			{
				string_1 = value;
			}
		}
	}

	private IContainer icontainer_0;

	[CompilerGenerated]
	[AccessedThroughProperty("btnPasteURL")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnPasteURL;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnWorkerStart")]
	[CompilerGenerated]
	private ToolStripButton _btnWorkerStart;

	[CompilerGenerated]
	[AccessedThroughProperty("btnWorkerPause")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnWorkerPause;

	[AccessedThroughProperty("btnWorkerStop")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnWorkerStop;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnLoadDefautSettings")]
	private ToolStripButton _btnLoadDefautSettings;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnDictPath")]
	private Button _btnDictPath;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("bckWorker")]
	[CompilerGenerated]
	private BackgroundWorker backgroundWorker_0;

	[AccessedThroughProperty("chkWebApps")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private CheckBox _chkWebApps;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuResult")]
	private ContextMenuStrip _mnuResult;

	[AccessedThroughProperty("mnuShell")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuShell;

	[AccessedThroughProperty("mnuClipboard")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuClipboard;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("txtURL")]
	private ToolStripSpringTextBox toolStripSpringTextBox_0;

	private ThreadPool threadPool_0;

	private int int_0;

	private int int_1;

	private Globals.WebServer webServer_0;

	private static string string_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int int_2;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool bool_0;

	[SpecialName]
	private DateTime _0024STATIC_0024CheckRequestDelay_00242001_0024LastTick;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024CheckRequestDelay_00242001_0024LastTick_0024Init;

	[field: AccessedThroughProperty("tlsMenu")]
	internal virtual ToolStrip tlsMenu
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnPasteURL
	{
		[CompilerGenerated]
		get
		{
			return _btnPasteURL;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_21;
			ToolStripButton toolStripButton = _btnPasteURL;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnPasteURL = value;
			toolStripButton = _btnPasteURL;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("toolStripSeparator18")]
	internal virtual ToolStripSeparator toolStripSeparator18
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsMain")]
	internal virtual ToolStrip tsMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnWorkerStart
	{
		[CompilerGenerated]
		get
		{
			return _btnWorkerStart;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_6;
			ToolStripButton toolStripButton = _btnWorkerStart;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnWorkerStart = value;
			toolStripButton = _btnWorkerStart;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnWorkerPause
	{
		[CompilerGenerated]
		get
		{
			return _btnWorkerPause;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_7;
			ToolStripButton toolStripButton = _btnWorkerPause;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnWorkerPause = value;
			toolStripButton = _btnWorkerPause;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("btnSearchColumnSP")]
	internal virtual ToolStripSeparator btnSearchColumnSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnWorkerStop
	{
		[CompilerGenerated]
		get
		{
			return _btnWorkerStop;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_8;
			ToolStripButton toolStripButton = _btnWorkerStop;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnWorkerStop = value;
			toolStripButton = _btnWorkerStop;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("prbWorker")]
	internal virtual ToolStripProgressBar prbWorker
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblStatus")]
	internal virtual ToolStripLabel lblStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlSetupDump")]
	internal virtual Panel pnlSetupDump
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlSetupDump2")]
	internal virtual Panel pnlSetupDump2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsBottom")]
	internal virtual ToolStrip tsBottom
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnLoadDefautSettings
	{
		[CompilerGenerated]
		get
		{
			return _btnLoadDefautSettings;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_2;
			ToolStripButton toolStripButton = _btnLoadDefautSettings;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnLoadDefautSettings = value;
			toolStripButton = _btnLoadDefautSettings;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("grbSetup_5")]
	internal virtual GroupBox grbSetup_5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label14")]
	internal virtual Label Label14
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtAddHeaderValue")]
	internal virtual TextBox txtAddHeaderValue
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label8")]
	internal virtual Label Label8
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtAddHeaderName")]
	internal virtual TextBox txtAddHeaderName
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtCookies")]
	internal virtual TextBox txtCookies
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label12")]
	internal virtual Label Label12
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkAddHearder")]
	internal virtual CheckBox chkAddHearder
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbSetup_4")]
	internal virtual GroupBox grbSetup_4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtUserName")]
	internal virtual TextBox txtUserName
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtPassword")]
	internal virtual TextBox txtPassword
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label9")]
	internal virtual Label Label9
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label10")]
	internal virtual Label Label10
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbSetup_3")]
	internal virtual GroupBox grbSetup_3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbCharCasing")]
	internal virtual ComboBox cmbCharCasing
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbSetup_1")]
	internal virtual GroupBox grbSetup_1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkHttpRedirect")]
	internal virtual CheckBox chkHttpRedirect
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numDelay")]
	internal virtual NumericUpDown numDelay
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkThreads")]
	internal virtual CheckBox chkThreads
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numThreads")]
	internal virtual NumericUpDown numThreads
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numTimeOut")]
	internal virtual NumericUpDown numTimeOut
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label16")]
	internal virtual Label Label16
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label2")]
	internal virtual Label Label2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbSetup_2")]
	internal virtual GroupBox grbSetup_2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnDictPath
	{
		[CompilerGenerated]
		get
		{
			return _btnDictPath;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_3;
			Button button = _btnDictPath;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnDictPath = value;
			button = _btnDictPath;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("txtDictPath")]
	internal virtual TextBox txtDictPath
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label1")]
	internal virtual Label Label1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtWebApps")]
	internal virtual TextBox txtWebApps
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label4")]
	internal virtual Label Label4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public virtual BackgroundWorker bckWorker
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler value2 = method_9;
			ProgressChangedEventHandler value3 = method_10;
			RunWorkerCompletedEventHandler value4 = method_11;
			BackgroundWorker backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork -= value2;
				backgroundWorker.ProgressChanged -= value3;
				backgroundWorker.RunWorkerCompleted -= value4;
			}
			backgroundWorker_0 = value;
			backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork += value2;
				backgroundWorker.ProgressChanged += value3;
				backgroundWorker.RunWorkerCompleted += value4;
			}
		}
	}

	internal virtual CheckBox chkWebApps
	{
		[CompilerGenerated]
		get
		{
			return _chkWebApps;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_17;
			CheckBox checkBox = _chkWebApps;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkWebApps = value;
			checkBox = _chkWebApps;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lstResult")]
	internal virtual ListBox lstResult
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ContextMenuStrip mnuResult
	{
		[CompilerGenerated]
		get
		{
			return _mnuResult;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_18;
			ContextMenuStrip contextMenuStrip = _mnuResult;
			if (contextMenuStrip != null)
			{
				contextMenuStrip.Opening -= value2;
			}
			_mnuResult = value;
			contextMenuStrip = _mnuResult;
			if (contextMenuStrip != null)
			{
				contextMenuStrip.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuShell
	{
		[CompilerGenerated]
		get
		{
			return _mnuShell;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_20;
			ToolStripMenuItem toolStripMenuItem = _mnuShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuShell = value;
			toolStripMenuItem = _mnuShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuClipboard
	{
		[CompilerGenerated]
		get
		{
			return _mnuClipboard;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_19;
			ToolStripMenuItem toolStripMenuItem = _mnuClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuClipboard = value;
			toolStripMenuItem = _mnuClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("chkStopWhenDetects")]
	internal virtual CheckBox chkStopWhenDetects
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripSpringTextBox txtURL
	{
		[CompilerGenerated]
		get
		{
			return toolStripSpringTextBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_16;
			ToolStripSpringTextBox toolStripSpringTextBox = toolStripSpringTextBox_0;
			if (toolStripSpringTextBox != null)
			{
				toolStripSpringTextBox.TextChanged -= value2;
			}
			toolStripSpringTextBox_0 = value;
			toolStripSpringTextBox = toolStripSpringTextBox_0;
			if (toolStripSpringTextBox != null)
			{
				toolStripSpringTextBox.TextChanged += value2;
			}
		}
	}

	internal int RunningProgress
	{
		[CompilerGenerated]
		get
		{
			return int_2;
		}
		[CompilerGenerated]
		set
		{
			int_2 = value;
		}
	}

	internal bool RunningWorker
	{
		[CompilerGenerated]
		get
		{
			return bool_0;
		}
		[CompilerGenerated]
		set
		{
			bool_0 = value;
		}
	}

	internal int Int32_0
	{
		get
		{
			if (threadPool_0 == null)
			{
				return 0;
			}
			return threadPool_0.ThreadCount;
		}
	}

	public LoginFinder()
	{
		base.Load += LoginFinder_Load;
		InitializeComponent();
		txtURL = new ToolStripSpringTextBox();
		tlsMenu.Items.Insert(2, txtURL);
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new System.ComponentModel.Container();
		this.tlsMenu = new System.Windows.Forms.ToolStrip();
		this.btnPasteURL = new System.Windows.Forms.ToolStripButton();
		this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
		this.tsMain = new System.Windows.Forms.ToolStrip();
		this.btnWorkerStart = new System.Windows.Forms.ToolStripButton();
		this.btnWorkerPause = new System.Windows.Forms.ToolStripButton();
		this.btnSearchColumnSP = new System.Windows.Forms.ToolStripSeparator();
		this.btnWorkerStop = new System.Windows.Forms.ToolStripButton();
		this.prbWorker = new System.Windows.Forms.ToolStripProgressBar();
		this.lblStatus = new System.Windows.Forms.ToolStripLabel();
		this.pnlSetupDump = new System.Windows.Forms.Panel();
		this.pnlSetupDump2 = new System.Windows.Forms.Panel();
		this.tsBottom = new System.Windows.Forms.ToolStrip();
		this.btnLoadDefautSettings = new System.Windows.Forms.ToolStripButton();
		this.grbSetup_5 = new System.Windows.Forms.GroupBox();
		this.Label14 = new System.Windows.Forms.Label();
		this.txtAddHeaderValue = new System.Windows.Forms.TextBox();
		this.Label8 = new System.Windows.Forms.Label();
		this.txtAddHeaderName = new System.Windows.Forms.TextBox();
		this.txtCookies = new System.Windows.Forms.TextBox();
		this.Label12 = new System.Windows.Forms.Label();
		this.chkAddHearder = new System.Windows.Forms.CheckBox();
		this.grbSetup_4 = new System.Windows.Forms.GroupBox();
		this.txtUserName = new System.Windows.Forms.TextBox();
		this.txtPassword = new System.Windows.Forms.TextBox();
		this.Label9 = new System.Windows.Forms.Label();
		this.Label10 = new System.Windows.Forms.Label();
		this.grbSetup_3 = new System.Windows.Forms.GroupBox();
		this.cmbCharCasing = new System.Windows.Forms.ComboBox();
		this.grbSetup_2 = new System.Windows.Forms.GroupBox();
		this.chkStopWhenDetects = new System.Windows.Forms.CheckBox();
		this.chkWebApps = new System.Windows.Forms.CheckBox();
		this.btnDictPath = new System.Windows.Forms.Button();
		this.txtDictPath = new System.Windows.Forms.TextBox();
		this.Label1 = new System.Windows.Forms.Label();
		this.txtWebApps = new System.Windows.Forms.TextBox();
		this.Label4 = new System.Windows.Forms.Label();
		this.grbSetup_1 = new System.Windows.Forms.GroupBox();
		this.chkHttpRedirect = new System.Windows.Forms.CheckBox();
		this.numDelay = new System.Windows.Forms.NumericUpDown();
		this.chkThreads = new System.Windows.Forms.CheckBox();
		this.numThreads = new System.Windows.Forms.NumericUpDown();
		this.numTimeOut = new System.Windows.Forms.NumericUpDown();
		this.Label16 = new System.Windows.Forms.Label();
		this.Label2 = new System.Windows.Forms.Label();
		this.bckWorker = new System.ComponentModel.BackgroundWorker();
		this.mnuResult = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuClipboard = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuShell = new System.Windows.Forms.ToolStripMenuItem();
		this.lstResult = new System.Windows.Forms.ListBox();
		this.tlsMenu.SuspendLayout();
		this.tsMain.SuspendLayout();
		this.pnlSetupDump.SuspendLayout();
		this.pnlSetupDump2.SuspendLayout();
		this.tsBottom.SuspendLayout();
		this.grbSetup_5.SuspendLayout();
		this.grbSetup_4.SuspendLayout();
		this.grbSetup_3.SuspendLayout();
		this.grbSetup_2.SuspendLayout();
		this.grbSetup_1.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numDelay).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numThreads).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numTimeOut).BeginInit();
		this.mnuResult.SuspendLayout();
		base.SuspendLayout();
		this.tlsMenu.AutoSize = false;
		this.tlsMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tlsMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.btnPasteURL, this.toolStripSeparator18 });
		this.tlsMenu.Location = new System.Drawing.Point(0, 0);
		this.tlsMenu.Name = "tlsMenu";
		this.tlsMenu.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
		this.tlsMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tlsMenu.Size = new System.Drawing.Size(750, 31);
		this.tlsMenu.Stretch = true;
		this.tlsMenu.TabIndex = 21;
		this.tlsMenu.Text = "ToolStrip2";
		this.btnPasteURL.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnPasteURL.Image = ns0.Class6.URLInputBox_16x_24;
		this.btnPasteURL.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnPasteURL.Name = "btnPasteURL";
		this.btnPasteURL.Size = new System.Drawing.Size(23, 28);
		this.btnPasteURL.Text = "&Paste URL";
		this.toolStripSeparator18.Name = "toolStripSeparator18";
		this.toolStripSeparator18.Size = new System.Drawing.Size(6, 31);
		this.tsMain.AutoSize = false;
		this.tsMain.Dock = System.Windows.Forms.DockStyle.Bottom;
		this.tsMain.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.btnWorkerStart, this.btnWorkerPause, this.btnSearchColumnSP, this.btnWorkerStop, this.prbWorker, this.lblStatus });
		this.tsMain.Location = new System.Drawing.Point(0, 536);
		this.tsMain.Name = "tsMain";
		this.tsMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsMain.Size = new System.Drawing.Size(750, 31);
		this.tsMain.TabIndex = 38;
		this.btnWorkerStart.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnWorkerStart.Enabled = false;
		this.btnWorkerStart.Image = ns0.Class6.Run_16x_24;
		this.btnWorkerStart.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnWorkerStart.Name = "btnWorkerStart";
		this.btnWorkerStart.Size = new System.Drawing.Size(51, 28);
		this.btnWorkerStart.Text = "&Start";
		this.btnWorkerStart.ToolTipText = "Start Checker";
		this.btnWorkerPause.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnWorkerPause.CheckOnClick = true;
		this.btnWorkerPause.Image = ns0.Class6.Pause_16x_24;
		this.btnWorkerPause.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnWorkerPause.Name = "btnWorkerPause";
		this.btnWorkerPause.Size = new System.Drawing.Size(58, 28);
		this.btnWorkerPause.Text = "&Pause";
		this.btnWorkerPause.ToolTipText = "Pause Worker";
		this.btnWorkerPause.Visible = false;
		this.btnSearchColumnSP.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnSearchColumnSP.Name = "btnSearchColumnSP";
		this.btnSearchColumnSP.Size = new System.Drawing.Size(6, 31);
		this.btnSearchColumnSP.Visible = false;
		this.btnWorkerStop.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnWorkerStop.Image = ns0.Class6.Stop_16x_24;
		this.btnWorkerStop.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnWorkerStop.Name = "btnWorkerStop";
		this.btnWorkerStop.Size = new System.Drawing.Size(51, 28);
		this.btnWorkerStop.Text = "&Stop";
		this.btnWorkerStop.ToolTipText = "Stop Worker";
		this.btnWorkerStop.Visible = false;
		this.prbWorker.AutoSize = false;
		this.prbWorker.Name = "prbWorker";
		this.prbWorker.Size = new System.Drawing.Size(89, 9);
		this.prbWorker.Visible = false;
		this.lblStatus.Name = "lblStatus";
		this.lblStatus.Size = new System.Drawing.Size(52, 28);
		this.lblStatus.Text = "lblStatus";
		this.pnlSetupDump.Controls.Add(this.pnlSetupDump2);
		this.pnlSetupDump.Dock = System.Windows.Forms.DockStyle.Right;
		this.pnlSetupDump.Location = new System.Drawing.Point(508, 31);
		this.pnlSetupDump.Name = "pnlSetupDump";
		this.pnlSetupDump.Size = new System.Drawing.Size(242, 505);
		this.pnlSetupDump.TabIndex = 39;
		this.pnlSetupDump2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.pnlSetupDump2.AutoScroll = true;
		this.pnlSetupDump2.Controls.Add(this.tsBottom);
		this.pnlSetupDump2.Controls.Add(this.grbSetup_5);
		this.pnlSetupDump2.Controls.Add(this.grbSetup_4);
		this.pnlSetupDump2.Controls.Add(this.grbSetup_3);
		this.pnlSetupDump2.Controls.Add(this.grbSetup_2);
		this.pnlSetupDump2.Controls.Add(this.grbSetup_1);
		this.pnlSetupDump2.Location = new System.Drawing.Point(6, 3);
		this.pnlSetupDump2.Name = "pnlSetupDump2";
		this.pnlSetupDump2.Size = new System.Drawing.Size(230, 499);
		this.pnlSetupDump2.TabIndex = 45;
		this.tsBottom.AutoSize = false;
		this.tsBottom.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsBottom.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.btnLoadDefautSettings });
		this.tsBottom.Location = new System.Drawing.Point(0, 452);
		this.tsBottom.Name = "tsBottom";
		this.tsBottom.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
		this.tsBottom.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsBottom.Size = new System.Drawing.Size(230, 31);
		this.tsBottom.Stretch = true;
		this.tsBottom.TabIndex = 48;
		this.tsBottom.Text = "ToolStrip2";
		this.btnLoadDefautSettings.Image = ns0.Class6.delete;
		this.btnLoadDefautSettings.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnLoadDefautSettings.Name = "btnLoadDefautSettings";
		this.btnLoadDefautSettings.Size = new System.Drawing.Size(85, 28);
		this.btnLoadDefautSettings.Text = "&Clear Form";
		this.grbSetup_5.Controls.Add(this.Label14);
		this.grbSetup_5.Controls.Add(this.txtAddHeaderValue);
		this.grbSetup_5.Controls.Add(this.Label8);
		this.grbSetup_5.Controls.Add(this.txtAddHeaderName);
		this.grbSetup_5.Controls.Add(this.txtCookies);
		this.grbSetup_5.Controls.Add(this.Label12);
		this.grbSetup_5.Controls.Add(this.chkAddHearder);
		this.grbSetup_5.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbSetup_5.Location = new System.Drawing.Point(0, 336);
		this.grbSetup_5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.grbSetup_5.Name = "grbSetup_5";
		this.grbSetup_5.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.grbSetup_5.Size = new System.Drawing.Size(230, 116);
		this.grbSetup_5.TabIndex = 46;
		this.grbSetup_5.TabStop = false;
		this.Label14.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.Label14.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label14.Location = new System.Drawing.Point(10, 89);
		this.Label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.Label14.Name = "Label14";
		this.Label14.Size = new System.Drawing.Size(73, 19);
		this.Label14.TabIndex = 26;
		this.Label14.Text = "&Value";
		this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtAddHeaderValue.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.txtAddHeaderValue.Enabled = false;
		this.txtAddHeaderValue.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtAddHeaderValue.Location = new System.Drawing.Point(87, 90);
		this.txtAddHeaderValue.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.txtAddHeaderValue.Name = "txtAddHeaderValue";
		this.txtAddHeaderValue.Size = new System.Drawing.Size(122, 20);
		this.txtAddHeaderValue.TabIndex = 25;
		this.Label8.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.Label8.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label8.Location = new System.Drawing.Point(10, 70);
		this.Label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.Label8.Name = "Label8";
		this.Label8.Size = new System.Drawing.Size(73, 19);
		this.Label8.TabIndex = 24;
		this.Label8.Text = "&Name";
		this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtAddHeaderName.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.txtAddHeaderName.Enabled = false;
		this.txtAddHeaderName.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtAddHeaderName.Location = new System.Drawing.Point(87, 67);
		this.txtAddHeaderName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.txtAddHeaderName.Name = "txtAddHeaderName";
		this.txtAddHeaderName.Size = new System.Drawing.Size(122, 20);
		this.txtAddHeaderName.TabIndex = 23;
		this.txtCookies.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtCookies.Location = new System.Drawing.Point(9, 32);
		this.txtCookies.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.txtCookies.Name = "txtCookies";
		this.txtCookies.Size = new System.Drawing.Size(199, 20);
		this.txtCookies.TabIndex = 3;
		this.Label12.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label12.Location = new System.Drawing.Point(9, 14);
		this.Label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.Label12.Name = "Label12";
		this.Label12.Size = new System.Drawing.Size(97, 19);
		this.Label12.TabIndex = 19;
		this.Label12.Text = "Coo&kies";
		this.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.chkAddHearder.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.chkAddHearder.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkAddHearder.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkAddHearder.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkAddHearder.Location = new System.Drawing.Point(100, 51);
		this.chkAddHearder.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.chkAddHearder.Name = "chkAddHearder";
		this.chkAddHearder.Size = new System.Drawing.Size(107, 16);
		this.chkAddHearder.TabIndex = 27;
		this.chkAddHearder.Text = "&Add Header";
		this.chkAddHearder.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkAddHearder.UseVisualStyleBackColor = true;
		this.grbSetup_4.Controls.Add(this.txtUserName);
		this.grbSetup_4.Controls.Add(this.txtPassword);
		this.grbSetup_4.Controls.Add(this.Label9);
		this.grbSetup_4.Controls.Add(this.Label10);
		this.grbSetup_4.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbSetup_4.Location = new System.Drawing.Point(0, 271);
		this.grbSetup_4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.grbSetup_4.Name = "grbSetup_4";
		this.grbSetup_4.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.grbSetup_4.Size = new System.Drawing.Size(230, 65);
		this.grbSetup_4.TabIndex = 45;
		this.grbSetup_4.TabStop = false;
		this.grbSetup_4.Text = "Network Credential (&Login)";
		this.txtUserName.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtUserName.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtUserName.Location = new System.Drawing.Point(87, 16);
		this.txtUserName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.txtUserName.Name = "txtUserName";
		this.txtUserName.Size = new System.Drawing.Size(123, 20);
		this.txtUserName.TabIndex = 16;
		this.txtPassword.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtPassword.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtPassword.Location = new System.Drawing.Point(87, 39);
		this.txtPassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.txtPassword.Name = "txtPassword";
		this.txtPassword.Size = new System.Drawing.Size(123, 20);
		this.txtPassword.TabIndex = 17;
		this.Label9.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label9.Location = new System.Drawing.Point(6, 17);
		this.Label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.Label9.Name = "Label9";
		this.Label9.Size = new System.Drawing.Size(77, 19);
		this.Label9.TabIndex = 3;
		this.Label9.Text = "UserName";
		this.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.Label10.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label10.Location = new System.Drawing.Point(6, 38);
		this.Label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.Label10.Name = "Label10";
		this.Label10.Size = new System.Drawing.Size(77, 19);
		this.Label10.TabIndex = 27;
		this.Label10.Text = "Password";
		this.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.grbSetup_3.Controls.Add(this.cmbCharCasing);
		this.grbSetup_3.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbSetup_3.Location = new System.Drawing.Point(0, 226);
		this.grbSetup_3.Name = "grbSetup_3";
		this.grbSetup_3.Size = new System.Drawing.Size(230, 45);
		this.grbSetup_3.TabIndex = 39;
		this.grbSetup_3.TabStop = false;
		this.grbSetup_3.Text = "Character Casing";
		this.cmbCharCasing.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbCharCasing.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbCharCasing.ForeColor = System.Drawing.SystemColors.ControlText;
		this.cmbCharCasing.FormattingEnabled = true;
		this.cmbCharCasing.Location = new System.Drawing.Point(9, 18);
		this.cmbCharCasing.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.cmbCharCasing.Name = "cmbCharCasing";
		this.cmbCharCasing.Size = new System.Drawing.Size(198, 21);
		this.cmbCharCasing.TabIndex = 34;
		this.grbSetup_2.Controls.Add(this.chkStopWhenDetects);
		this.grbSetup_2.Controls.Add(this.chkWebApps);
		this.grbSetup_2.Controls.Add(this.btnDictPath);
		this.grbSetup_2.Controls.Add(this.txtDictPath);
		this.grbSetup_2.Controls.Add(this.Label1);
		this.grbSetup_2.Controls.Add(this.txtWebApps);
		this.grbSetup_2.Controls.Add(this.Label4);
		this.grbSetup_2.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbSetup_2.Location = new System.Drawing.Point(0, 111);
		this.grbSetup_2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.grbSetup_2.Name = "grbSetup_2";
		this.grbSetup_2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.grbSetup_2.Size = new System.Drawing.Size(230, 115);
		this.grbSetup_2.TabIndex = 49;
		this.grbSetup_2.TabStop = false;
		this.chkStopWhenDetects.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.chkStopWhenDetects.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkStopWhenDetects.Checked = true;
		this.chkStopWhenDetects.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkStopWhenDetects.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkStopWhenDetects.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkStopWhenDetects.Location = new System.Drawing.Point(8, 95);
		this.chkStopWhenDetects.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.chkStopWhenDetects.Name = "chkStopWhenDetects";
		this.chkStopWhenDetects.Size = new System.Drawing.Size(201, 16);
		this.chkStopWhenDetects.TabIndex = 30;
		this.chkStopWhenDetects.Text = "Stop Worker on Found";
		this.chkStopWhenDetects.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkStopWhenDetects.UseVisualStyleBackColor = true;
		this.chkWebApps.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkWebApps.Checked = true;
		this.chkWebApps.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkWebApps.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkWebApps.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkWebApps.Location = new System.Drawing.Point(102, 14);
		this.chkWebApps.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.chkWebApps.Name = "chkWebApps";
		this.chkWebApps.Size = new System.Drawing.Size(107, 16);
		this.chkWebApps.TabIndex = 28;
		this.chkWebApps.Text = "&Auto Detect";
		this.chkWebApps.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkWebApps.UseVisualStyleBackColor = true;
		this.btnDictPath.Location = new System.Drawing.Point(173, 73);
		this.btnDictPath.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.btnDictPath.Name = "btnDictPath";
		this.btnDictPath.Size = new System.Drawing.Size(35, 17);
		this.btnDictPath.TabIndex = 22;
		this.btnDictPath.Text = "---";
		this.btnDictPath.UseVisualStyleBackColor = true;
		this.txtDictPath.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtDictPath.Location = new System.Drawing.Point(8, 73);
		this.txtDictPath.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.txtDictPath.Name = "txtDictPath";
		this.txtDictPath.Size = new System.Drawing.Size(163, 20);
		this.txtDictPath.TabIndex = 20;
		this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label1.Location = new System.Drawing.Point(8, 54);
		this.Label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.Label1.Name = "Label1";
		this.Label1.Size = new System.Drawing.Size(201, 19);
		this.Label1.TabIndex = 21;
		this.Label1.Text = "Dictionary Path";
		this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.txtWebApps.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtWebApps.Location = new System.Drawing.Point(9, 32);
		this.txtWebApps.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.txtWebApps.Name = "txtWebApps";
		this.txtWebApps.ReadOnly = true;
		this.txtWebApps.Size = new System.Drawing.Size(199, 20);
		this.txtWebApps.TabIndex = 3;
		this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label4.Location = new System.Drawing.Point(9, 14);
		this.Label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.Label4.Name = "Label4";
		this.Label4.Size = new System.Drawing.Size(97, 19);
		this.Label4.TabIndex = 19;
		this.Label4.Text = "Web Apps";
		this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.grbSetup_1.Controls.Add(this.chkHttpRedirect);
		this.grbSetup_1.Controls.Add(this.numDelay);
		this.grbSetup_1.Controls.Add(this.chkThreads);
		this.grbSetup_1.Controls.Add(this.numThreads);
		this.grbSetup_1.Controls.Add(this.numTimeOut);
		this.grbSetup_1.Controls.Add(this.Label16);
		this.grbSetup_1.Controls.Add(this.Label2);
		this.grbSetup_1.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbSetup_1.Location = new System.Drawing.Point(0, 0);
		this.grbSetup_1.Name = "grbSetup_1";
		this.grbSetup_1.Size = new System.Drawing.Size(230, 111);
		this.grbSetup_1.TabIndex = 42;
		this.grbSetup_1.TabStop = false;
		this.chkHttpRedirect.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.chkHttpRedirect.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkHttpRedirect.Checked = true;
		this.chkHttpRedirect.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkHttpRedirect.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.chkHttpRedirect.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkHttpRedirect.Location = new System.Drawing.Point(7, 87);
		this.chkHttpRedirect.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.chkHttpRedirect.Name = "chkHttpRedirect";
		this.chkHttpRedirect.Size = new System.Drawing.Size(202, 16);
		this.chkHttpRedirect.TabIndex = 29;
		this.chkHttpRedirect.Text = "HTTP Follow Redirect";
		this.chkHttpRedirect.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkHttpRedirect.UseVisualStyleBackColor = true;
		this.numDelay.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numDelay.Increment = new decimal(new int[4] { 50, 0, 0, 0 });
		this.numDelay.Location = new System.Drawing.Point(139, 66);
		this.numDelay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.numDelay.Maximum = new decimal(new int[4] { 20000, 0, 0, 0 });
		this.numDelay.Name = "numDelay";
		this.numDelay.Size = new System.Drawing.Size(70, 20);
		this.numDelay.TabIndex = 11;
		this.numDelay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numDelay.Value = new decimal(new int[4] { 200, 0, 0, 0 });
		this.chkThreads.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkThreads.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkThreads.Location = new System.Drawing.Point(18, 20);
		this.chkThreads.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.chkThreads.Name = "chkThreads";
		this.chkThreads.Size = new System.Drawing.Size(116, 16);
		this.chkThreads.TabIndex = 23;
		this.chkThreads.Text = "Multi-Thread";
		this.chkThreads.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkThreads.UseVisualStyleBackColor = true;
		this.numThreads.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numThreads.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
		this.numThreads.Location = new System.Drawing.Point(139, 19);
		this.numThreads.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.numThreads.Minimum = new decimal(new int[4] { 2, 0, 0, 0 });
		this.numThreads.Name = "numThreads";
		this.numThreads.Size = new System.Drawing.Size(70, 20);
		this.numThreads.TabIndex = 24;
		this.numThreads.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numThreads.Value = new decimal(new int[4] { 10, 0, 0, 0 });
		this.numTimeOut.ForeColor = System.Drawing.SystemColors.ControlText;
		this.numTimeOut.Increment = new decimal(new int[4] { 5, 0, 0, 0 });
		this.numTimeOut.Location = new System.Drawing.Point(139, 42);
		this.numTimeOut.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.numTimeOut.Maximum = new decimal(new int[4] { 60, 0, 0, 0 });
		this.numTimeOut.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numTimeOut.Name = "numTimeOut";
		this.numTimeOut.Size = new System.Drawing.Size(70, 20);
		this.numTimeOut.TabIndex = 10;
		this.numTimeOut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numTimeOut.Value = new decimal(new int[4] { 10, 0, 0, 0 });
		this.Label16.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label16.Location = new System.Drawing.Point(4, 68);
		this.Label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.Label16.Name = "Label16";
		this.Label16.Size = new System.Drawing.Size(130, 19);
		this.Label16.TabIndex = 4;
		this.Label16.Text = "Request Delay  (ms)";
		this.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.Label2.ForeColor = System.Drawing.SystemColors.ControlText;
		this.Label2.Location = new System.Drawing.Point(4, 42);
		this.Label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.Label2.Name = "Label2";
		this.Label2.Size = new System.Drawing.Size(130, 19);
		this.Label2.TabIndex = 0;
		this.Label2.Text = "&TimeOut (sec)";
		this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.bckWorker.WorkerReportsProgress = true;
		this.bckWorker.WorkerSupportsCancellation = true;
		this.mnuResult.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.mnuClipboard, this.mnuShell });
		this.mnuResult.Name = "mnuResult";
		this.mnuResult.ShowImageMargin = false;
		this.mnuResult.Size = new System.Drawing.Size(102, 48);
		this.mnuClipboard.Name = "mnuClipboard";
		this.mnuClipboard.Size = new System.Drawing.Size(101, 22);
		this.mnuClipboard.Text = "Clipboard";
		this.mnuShell.Name = "mnuShell";
		this.mnuShell.Size = new System.Drawing.Size(101, 22);
		this.mnuShell.Text = "Shell";
		this.lstResult.ContextMenuStrip = this.mnuResult;
		this.lstResult.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lstResult.Location = new System.Drawing.Point(0, 31);
		this.lstResult.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		this.lstResult.Name = "lstResult";
		this.lstResult.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
		this.lstResult.Size = new System.Drawing.Size(508, 505);
		this.lstResult.TabIndex = 40;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(750, 567);
		base.Controls.Add(this.lstResult);
		base.Controls.Add(this.pnlSetupDump);
		base.Controls.Add(this.tsMain);
		base.Controls.Add(this.tlsMenu);
		base.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
		base.Name = "LoginFinder";
		this.Text = "AdminLoginFinder";
		this.tlsMenu.ResumeLayout(false);
		this.tlsMenu.PerformLayout();
		this.tsMain.ResumeLayout(false);
		this.tsMain.PerformLayout();
		this.pnlSetupDump.ResumeLayout(false);
		this.pnlSetupDump2.ResumeLayout(false);
		this.tsBottom.ResumeLayout(false);
		this.tsBottom.PerformLayout();
		this.grbSetup_5.ResumeLayout(false);
		this.grbSetup_5.PerformLayout();
		this.grbSetup_4.ResumeLayout(false);
		this.grbSetup_4.PerformLayout();
		this.grbSetup_3.ResumeLayout(false);
		this.grbSetup_2.ResumeLayout(false);
		this.grbSetup_2.PerformLayout();
		this.grbSetup_1.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.numDelay).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numThreads).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numTimeOut).EndInit();
		this.mnuResult.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	public void LoadingOnCancel()
	{
		if (RunningWorker)
		{
			bckWorker.CancelAsync();
		}
	}

	public void SaveSettings()
	{
		Class50.smethod_4(base.Name, txtURL.Name, txtURL.Text);
		Class50.smethod_3(this);
	}

	public void LoadSettings()
	{
		txtURL.Text = Class50.smethod_5(base.Name, txtURL.Name, "");
		Class50.smethod_2(this);
	}

	private void method_0(string string_1)
	{
		if (tsMain.InvokeRequired)
		{
			tsMain.Invoke(new Delegate17(method_0), string_1);
		}
		else
		{
			lblStatus.Text = string_1;
		}
	}

	private void method_1(string string_1)
	{
		if (lstResult.InvokeRequired)
		{
			lstResult.Invoke(new Delegate18(method_1), string_1);
		}
		else
		{
			lstResult.Items.Add(string_1);
		}
	}

	private void method_2(object sender, EventArgs e)
	{
		Globals.GMain.pnlLoginFinder.SuspendLayout();
		Globals.LockWindowUpdateForced(bState: false);
		Globals.GMain.method_62(bool_5: false);
		Globals.GMain.method_59(bool_5: false);
		Globals.LockWindowUpdateForced(bState: true);
		Globals.GMain.pnlLoginFinder.ResumeLayout();
		Globals.GMain.pnlLoginFinder.Refresh();
	}

	private void LoginFinder_Load(object sender, EventArgs e)
	{
		lblStatus.Text = "";
		cmbCharCasing.Items.AddRange(new string[3]
		{
			"Normal",
			"lower".ToLower(),
			"upper".ToUpper()
		});
		cmbCharCasing.SelectedIndex = 0;
		txtWebApps.Text = "php;asp;html";
		grbSetup_5.Visible = false;
		mnuClipboard.Text = Globals.GMain.mnuLWClipboard.Text;
		mnuShell.Text = Globals.GMain.mnuLWShell.Text;
		if (!File.Exists(txtDictPath.Text))
		{
			txtDictPath.Text = Globals.DIC_LOGIN_FINDER;
		}
		if (!File.Exists(Globals.DIC_LOGIN_FINDER))
		{
			File.WriteAllText(Globals.DIC_LOGIN_FINDER, Class6.dic_login_finder);
		}
	}

	private void method_3(object sender, EventArgs e)
	{
		string text = "";
		try
		{
			text = txtDictPath.Text;
			if (!string.IsNullOrEmpty(text))
			{
				Globals.ShellUrl(text);
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_4(bool bool_1)
	{
		btnWorkerStart.Visible = bool_1;
		btnWorkerPause.Visible = !bool_1;
		btnWorkerStop.Visible = !bool_1;
		btnWorkerStop.Enabled = !bool_1;
		btnWorkerPause.Enabled = !bool_1;
		chkThreads.Enabled = bool_1;
		numThreads.Enabled = bool_1;
		grbSetup_2.Enabled = bool_1;
		grbSetup_4.Enabled = bool_1;
		grbSetup_5.Enabled = bool_1;
		prbWorker.Visible = !bool_1;
		lblStatus.Text = "";
		btnLoadDefautSettings.Enabled = bool_1;
		method_16(null, null);
	}

	private bool method_5()
	{
		if (base.InvokeRequired)
		{
			return Conversions.ToBoolean(Invoke(new Delegate19(method_5)));
		}
		if (btnWorkerPause.Checked)
		{
			threadPool_0.Paused = true;
			while (btnWorkerPause.Checked)
			{
				Thread.Sleep(500);
				Application.DoEvents();
				if (bckWorker.CancellationPending)
				{
					break;
				}
			}
			threadPool_0.Paused = false;
		}
		return bckWorker.CancellationPending;
	}

	private void method_6(object sender, EventArgs e)
	{
		try
		{
			method_4(bool_1: false);
			List<string> list = new List<string>();
			string[] array = File.ReadAllLines(txtDictPath.Text);
			for (int i = 0; i < array.Length; i = checked(i + 1))
			{
				string text = array[i];
				if (!string.IsNullOrEmpty(text))
				{
					text = text.Trim();
					if (!list.Contains(text))
					{
						list.Add(text);
					}
				}
			}
			if (chkThreads.Checked)
			{
				int_0 = Convert.ToInt32(numThreads.Value);
			}
			else
			{
				int_0 = 1;
			}
			if (list.Count != 0)
			{
				lstResult.Items.Clear();
				int_1 = 0;
				bckWorker.RunWorkerAsync(list);
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_7(object sender, EventArgs e)
	{
	}

	private void method_8(object sender, EventArgs e)
	{
		btnWorkerStop.Enabled = false;
		btnWorkerPause.Checked = false;
		btnWorkerPause.Enabled = false;
		LoadingOnCancel();
	}

	private void method_9(object sender, DoWorkEventArgs e)
	{
		checked
		{
			try
			{
				RunningWorker = true;
				List<string> list = (List<string>)e.Argument;
				int num = 1;
				int count = list.Count;
				int num2 = ((int_0 <= count) ? int_0 : count);
				threadPool_0 = new ThreadPool(num2);
				method_12();
				foreach (string item in list)
				{
					if (!method_5())
					{
						int percentProgress = (int)Math.Round(Math.Round((double)(100 * num) / (double)count));
						if (num2 > 1)
						{
							method_0("[" + Conversions.ToString(num) + "/" + Conversions.ToString(count) + "] " + Globals.translate_0.GetStr(Globals.GMain, 18) + Conversions.ToString(int_1));
						}
						else
						{
							method_0("[" + Conversions.ToString(num) + "/" + Conversions.ToString(count) + "] " + Globals.translate_0.GetStr(Globals.GMain, 20) + item.Replace(".%EXT%", "") + ", " + Globals.translate_0.GetStr(Globals.GMain, 24) + Conversions.ToString(int_1));
						}
						bckWorker.ReportProgress(percentProgress);
						Thread thread = new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
						{
							method_13((Class43)object_0);
						});
						thread.Name = "Pos : " + num;
						Class43 @class = new Class43();
						@class.Thread = thread;
						@class.Page = item;
						@class.Url = Conversions.ToString(Globals.GetObjectValue(txtURL));
						thread.Start(@class);
						threadPool_0.Open(thread);
						threadPool_0.WaitForThreads();
						num++;
						continue;
					}
					threadPool_0.AbortThreads();
					if (int_1 != 1)
					{
						e.Result = Globals.translate_0.GetStr(Globals.GMain, 25);
					}
					break;
				}
				threadPool_0.AllJobsPushed();
				do
				{
					method_0("[" + Conversions.ToString(threadPool_0.ThreadCount) + "] " + Globals.translate_0.GetStr(Globals.GMain, 23) + Globals.translate_0.GetStr(Globals.GMain, 24) + Globals.FormatNumbers(int_1));
					if (bckWorker.CancellationPending)
					{
						threadPool_0.AbortThreads();
						break;
					}
				}
				while (!threadPool_0.Finished);
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				e.Result = Globals.translate_0.GetStr(Globals.GMain, 27) + ex2.Message;
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_10(object sender, ProgressChangedEventArgs e)
	{
		prbWorker.Value = e.ProgressPercentage;
		RunningProgress = e.ProgressPercentage;
	}

	private void method_11(object sender, RunWorkerCompletedEventArgs e)
	{
		RunningWorker = false;
		method_4(bool_1: true);
		if (e.Result == null)
		{
			method_0(Globals.translate_0.GetStr(Globals.GMain, 25) + " " + Globals.translate_0.GetStr(Globals.GMain, 24) + Conversions.ToString(int_1));
		}
		else
		{
			method_0(e.Result.ToString() + " " + Globals.translate_0.GetStr(Globals.GMain, 24) + Conversions.ToString(int_1));
		}
	}

	private void method_12()
	{
		if (Conversions.ToBoolean(Globals.GetObjectValue(chkWebApps)))
		{
			string text = Conversions.ToString(Globals.GetObjectValue(txtURL));
			string[] array = Strings.Split(text, "//");
			if (array.Length == 2)
			{
				int num = array[1].IndexOf("/");
				if (num > 3)
				{
					array[1] = array[1].Substring(0, num);
				}
				text = array[0] + "//" + array[1];
			}
			HTTP http_ = new HTTP();
			method_14(text, ref http_);
			string string_ = default(string);
			webServer_0 = Class23.smethod_0(text, string_, http_);
			http_.Dispose();
		}
		else
		{
			webServer_0 = Globals.WebServer.UNKNOW;
		}
	}

	private void method_13(Class43 class43_0)
	{
		checked
		{
			try
			{
				string text = Conversions.ToString(Globals.GetObjectValue(txtWebApps));
				HTTP http_ = new HTTP();
				object objectValue = Globals.GetObjectValue(cmbCharCasing);
				if (!Operators.ConditionalCompareObjectEqual(objectValue, 0, TextCompare: false))
				{
					if (Operators.ConditionalCompareObjectEqual(objectValue, 1, TextCompare: false))
					{
						class43_0.Page = class43_0.Page.ToLower();
					}
					else if (Operators.ConditionalCompareObjectEqual(objectValue, 2, TextCompare: false))
					{
						class43_0.Page = class43_0.Page.ToUpper();
					}
				}
				switch (webServer_0)
				{
				case Globals.WebServer.LINUX:
					text = "php;html";
					break;
				case Globals.WebServer.WINDOWS:
					text = "asp;html";
					break;
				}
				string string_ = default(string);
				if (class43_0.Page.Contains("%EXT%"))
				{
					string[] array = text.Split(';');
					foreach (string newValue in array)
					{
						string_ = class43_0.Url + class43_0.Page.Replace("%EXT%", newValue);
						method_14(string_, ref http_);
						if (http_.o.LastStatus == 200)
						{
							break;
						}
					}
				}
				else
				{
					string_ = class43_0.Url + class43_0.Page;
					method_14(string_, ref http_);
				}
				if (!method_5() && http_.o.LastStatus == 200)
				{
					lock (this)
					{
						if (Conversions.ToBoolean(Operators.AndObject(int_1 > 0, Globals.GetObjectValue(chkStopWhenDetects))))
						{
							LoadingOnCancel();
						}
						else
						{
							method_1(string_);
							int_1++;
						}
					}
				}
				http_.Dispose();
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				if (ex2 is ThreadAbortException)
				{
				}
				ProjectData.ClearProjectError();
			}
			finally
			{
				try
				{
					threadPool_0.Close(class43_0.Thread);
				}
				catch (Exception projectError)
				{
					ProjectData.SetProjectError(projectError);
					ProjectData.ClearProjectError();
				}
			}
		}
	}

	private string method_14(string string_1, ref HTTP http_0)
	{
		string text = "";
		http_0.o.FollowRedirects = Conversions.ToBoolean(Globals.GetObjectValue(chkHttpRedirect));
		http_0.o.ConnectTimeout = Conversions.ToInteger(Globals.GetObjectValue(numTimeOut));
		http_0.o.ReadTimeout = http_0.o.ConnectTimeout;
		int num = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPRetry));
		for (int i = 0; i <= num; i = checked(i + 1))
		{
			method_15();
			text = http_0.QuickGet(string_1);
			if (!string.IsNullOrEmpty(text) || http_0.Status > 0 || method_5())
			{
				break;
			}
		}
		return text;
	}

	private void method_15()
	{
		if (_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick_0024Init == null)
		{
			Interlocked.CompareExchange(ref _0024STATIC_0024CheckRequestDelay_00242001_0024LastTick_0024Init, new StaticLocalInitFlag(), null);
		}
		bool lockTaken = false;
		try
		{
			Monitor.Enter(_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick_0024Init, ref lockTaken);
			if (_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick_0024Init.State == 0)
			{
				_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick_0024Init.State = 2;
				_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick = DateAndTime.Now.AddHours(-1.0);
			}
			else if (_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick_0024Init.State == 2)
			{
				throw new IncompleteInitialization();
			}
		}
		finally
		{
			_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick_0024Init.State = 1;
			if (lockTaken)
			{
				Monitor.Exit(_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick_0024Init);
			}
		}
		while (!Operators.ConditionalCompareObjectGreater(DateAndTime.Now.Subtract(_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick).TotalMilliseconds, Globals.GetObjectValue(numDelay), TextCompare: false) && !method_5())
		{
			Thread.Sleep(100);
		}
		_0024STATIC_0024CheckRequestDelay_00242001_0024LastTick = DateAndTime.Now;
	}

	private void method_16(object sender, EventArgs e)
	{
		btnWorkerStart.Enabled = Class23.smethod_13(txtURL.Text, bool_0: false) && txtURL.Text.EndsWith("/") && !RunningWorker;
	}

	private void method_17(object sender, EventArgs e)
	{
		txtWebApps.ReadOnly = chkWebApps.Checked;
	}

	private void method_18(object sender, CancelEventArgs e)
	{
		e.Cancel = lstResult.SelectedItems.Count == 0;
		mnuShell.Visible = lstResult.SelectedItems.Count == 1;
	}

	private void method_19(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				int num = lstResult.SelectedItems.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (i > 0)
					{
						stringBuilder.AppendLine();
					}
					stringBuilder.Append(RuntimeHelpers.GetObjectValue(lstResult.SelectedItems[i]));
				}
				Clipboard.SetText(stringBuilder.ToString());
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				Interaction.MsgBox(ex2.Message);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_20(object sender, EventArgs e)
	{
		try
		{
			Globals.ShellUrl(Conversions.ToString(lstResult.SelectedItems[0]));
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_21(object sender, EventArgs e)
	{
		try
		{
			if (!Clipboard.ContainsText())
			{
				return;
			}
			string text = Clipboard.GetText();
			if (!Class23.smethod_13(text, bool_0: false))
			{
				return;
			}
			if (!text.EndsWith("/"))
			{
				int num = text.LastIndexOf("/");
				if (num > 0)
				{
					text = text.Substring(0, checked(num + 1));
				}
			}
			txtURL.Text = text;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_22(object object_0)
	{
		method_13((Class43)object_0);
	}
}
