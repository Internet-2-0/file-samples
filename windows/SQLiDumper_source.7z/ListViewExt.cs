using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class ListViewExt : ListView
{
	private struct Struct1
	{
		public uint uint_0;

		public int int_0;

		public IntPtr intptr_0;

		public IntPtr intptr_1;

		public int int_1;

		public int int_2;

		public IntPtr intptr_2;

		public int int_3;

		public int int_4;

		public uint uint_1;

		public IntPtr intptr_3;
	}

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	private struct Struct2
	{
		public int int_0;

		public int int_1;

		public int int_2;

		public int int_3;

		public int int_4;

		[MarshalAs(UnmanagedType.LPTStr)]
		public string string_0;

		public int int_5;

		public int int_6;

		public IntPtr intptr_0;

		public int int_7;

		public int int_8;

		public int int_9;

		public IntPtr intptr_1;
	}

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	private struct Struct3
	{
		public int int_0;

		public IntPtr intptr_0;

		[MarshalAs(UnmanagedType.LPTStr)]
		public string string_0;

		public int int_1;

		public int int_2;

		public int int_3;
	}

	public enum ListViewGroupMask
	{
		None = 0,
		Header = 1,
		Footer = 2,
		State = 4,
		Align = 8,
		GroupId = 0x10,
		SubTitle = 0x100,
		Task = 0x200,
		DescriptionTop = 0x400,
		DescriptionBottom = 0x800,
		TitleImage = 0x1000,
		ExtendedImage = 0x2000,
		Items = 0x4000,
		Subset = 0x8000,
		SubsetItems = 0x10000
	}

	public enum ListViewGroupState
	{
		Normal = 0,
		Collapsed = 1,
		Hidden = 2,
		NoHeader = 4,
		Collapsible = 8,
		Focused = 0x10,
		Selected = 0x20,
		SubSeted = 0x40,
		SubSetLinkFocused = 0x80
	}

	private delegate ListViewItem Delegate8(string sURL);

	private delegate ListViewItem Delegate9(string sURL);

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
	[Description("LVGROUP StructureUsed to set and retrieve groups.")]
	public class LVGROUP
	{
		[Description("Size of this structure, in bytes.")]
		public int CbSize;

		[Description("Mask that specifies which members of the structure are valid input. One or more of the following values:LVGF_NONE No other items are valid.")]
		public ListViewGroupMask Mask;

		[MarshalAs(UnmanagedType.LPWStr)]
		[Description("Pointer to a null-terminated string that contains the header text when item information is being set. If group information is being retrieved, this member specifies the address of the buffer that receives the header text.")]
		public string PszHeader;

		[Description("Size in TCHARs of the buffer pointed to by the pszHeader member. If the structure is not receiving information about a group, this member is ignored.")]
		public int CchHeader;

		[MarshalAs(UnmanagedType.LPWStr)]
		[Description("Pointer to a null-terminated string that contains the footer text when item information is being set. If group information is being retrieved, this member specifies the address of the buffer that receives the footer text.")]
		public string PszFooter;

		[Description("Size in TCHARs of the buffer pointed to by the pszFooter member. If the structure is not receiving information about a group, this member is ignored.")]
		public int CchFooter;

		[Description("ID of the group.")]
		public int IGroupId;

		[Description("Mask used with LVM_GETGROUPINFO (Microsoft Windows XP and Windows Vista) and LVM_SETGROUPINFO (Windows Vista only) to specify which flags in the state value are being retrieved or set.")]
		public int StateMask;

		[Description("Flag that can have one of the following values:LVGS_NORMAL Groups are expanded, the group name is displayed, and all items in the group are displayed.")]
		public ListViewGroupState State;

		[Description("Indicates the alignment of the header or footer text for the group. It can have one or more of the following values. Use one of the header flags. Footer flags are optional. Windows XP: Footer flags are reserved.LVGA_FOOTER_CENTERReserved.")]
		public uint UAlign;

		[Description("Windows Vista. Pointer to a null-terminated string that contains the subtitle text when item information is being set. If group information is being retrieved, this member specifies the address of the buffer that receives the subtitle text. This element is drawn under the header text.")]
		public IntPtr PszSubtitle;

		[Description("Windows Vista. Size, in TCHARs, of the buffer pointed to by the pszSubtitle member. If the structure is not receiving information about a group, this member is ignored.")]
		public uint CchSubtitle;

		[MarshalAs(UnmanagedType.LPWStr)]
		[Description("Windows Vista. Pointer to a null-terminated string that contains the text for a task link when item information is being set. If group information is being retrieved, this member specifies the address of the buffer that receives the task text. This item is drawn right-aligned opposite the header text. When clicked by the user, the task link generates an LVN_LINKCLICK notification.")]
		public string PszTask;

		[Description("Windows Vista. Size in TCHARs of the buffer pointed to by the pszTask member. If the structure is not receiving information about a group, this member is ignored.")]
		public uint CchTask;

		[MarshalAs(UnmanagedType.LPWStr)]
		[Description("Windows Vista. Pointer to a null-terminated string that contains the top description text when item information is being set. If group information is being retrieved, this member specifies the address of the buffer that receives the top description text. This item is drawn opposite the title image when there is a title image, no extended image, and uAlign==LVGA_HEADER_CENTER.")]
		public string PszDescriptionTop;

		[Description("Windows Vista. Size in TCHARs of the buffer pointed to by the pszDescriptionTop member. If the structure is not receiving information about a group, this member is ignored.")]
		public uint CchDescriptionTop;

		[MarshalAs(UnmanagedType.LPWStr)]
		[Description("Windows Vista. Pointer to a null-terminated string that contains the bottom description text when item information is being set. If group information is being retrieved, this member specifies the address of the buffer that receives the bottom description text. This item is drawn under the top description text when there is a title image, no extended image, and uAlign==LVGA_HEADER_CENTER.")]
		public string PszDescriptionBottom;

		[Description("Windows Vista. Size in TCHARs of the buffer pointed to by the pszDescriptionBottom member. If the structure is not receiving information about a group, this member is ignored.")]
		public uint CchDescriptionBottom;

		[Description("Windows Vista. Index of the title image in the control imagelist.")]
		public int ITitleImage;

		[Description("Windows Vista. Index of the extended image in the control imagelist.")]
		public int IExtendedImage;

		[Description("Windows Vista. Read-only.")]
		public int IFirstItem;

		[Description("Windows Vista. Read-only in non-owner data mode.")]
		public IntPtr CItems;

		[Description("Windows Vista. NULL if group is not a subset. Pointer to a null-terminated string that contains the subset title text when item information is being set. If group information is being retrieved, this member specifies the address of the buffer that receives the subset title text.")]
		public IntPtr PszSubsetTitle;

		[Description("Windows Vista. Size in TCHARs of the buffer pointed to by the pszSubsetTitle member. If the structure is not receiving information about a group, this member is ignored.")]
		public IntPtr CchSubsetTitle;

		public LVGROUP()
		{
			CbSize = Marshal.SizeOf(typeof(LVGROUP));
		}

		public override string ToString()
		{
			return "LVGROUP: header = " + PszHeader.ToString() + ", iGroupId = " + IGroupId.ToString(CultureInfo.InvariantCulture);
		}
	}

	public class ListViewHelper
	{
		public delegate void CallSetLVGroups(ListViewExt lstvw, ListViewGroupState state);

		internal static int smethod_0(ListViewGroup listViewGroup_0)
		{
			int result = 0;
			Type type = listViewGroup_0.GetType();
			if ((object)type != null)
			{
				PropertyInfo property = type.GetProperty("ID", BindingFlags.Instance | BindingFlags.NonPublic);
				if ((object)property != null)
				{
					object objectValue = RuntimeHelpers.GetObjectValue(property.GetValue(listViewGroup_0, null));
					if (objectValue != null)
					{
						result = Conversions.ToInteger(objectValue);
					}
				}
			}
			return result;
		}

		internal static void smethod_1(ListViewExt listViewExt_0, ListViewGroupState listViewGroupState_0)
		{
			int num = 4096;
			checked
			{
				int int_ = num + 147;
				if (Environment.OSVersion.Version.Major < 6)
				{
					return;
				}
				if (listViewExt_0.InvokeRequired)
				{
					listViewExt_0.Invoke(new CallSetLVGroups(smethod_1), listViewExt_0, listViewGroupState_0);
				}
				else
				{
					if (listViewExt_0 == null)
					{
						return;
					}
					for (int i = 0; i < listViewExt_0.Groups.Count; i++)
					{
						int num2 = smethod_0(listViewExt_0.Groups[i]);
						LVGROUP lVGROUP = new LVGROUP();
						lVGROUP.State = listViewGroupState_0;
						lVGROUP.Mask = ListViewGroupMask.State;
						if (num2 > 0)
						{
							lVGROUP.IGroupId = num2;
							SendMessage(listViewExt_0.Handle, int_, num2, lVGROUP);
						}
						else
						{
							lVGROUP.IGroupId = i;
							SendMessage(listViewExt_0.Handle, int_, i, lVGROUP);
						}
					}
				}
			}
		}
	}

	internal sealed class Class34 : IComparer
	{
		private int int_0;

		private SortOrder sortOrder_0;

		private CaseInsensitiveComparer caseInsensitiveComparer_0;

		public int Int32_0
		{
			get
			{
				return int_0;
			}
			set
			{
				int_0 = value;
			}
		}

		public SortOrder SortOrder_0
		{
			get
			{
				return sortOrder_0;
			}
			set
			{
				sortOrder_0 = value;
			}
		}

		public Class34()
		{
			int_0 = 0;
			sortOrder_0 = SortOrder.None;
			caseInsensitiveComparer_0 = new CaseInsensitiveComparer();
		}

		public int Compare(object x, object y)
		{
			ListViewItem listViewItem = (ListViewItem)x;
			ListViewItem listViewItem2 = (ListViewItem)y;
			if (listViewItem2 == null || listViewItem2 == null)
			{
				return 0;
			}
			int num = caseInsensitiveComparer_0.Compare(listViewItem.SubItems[int_0].Text, listViewItem2.SubItems[int_0].Text);
			if (sortOrder_0 == SortOrder.Ascending)
			{
				return num;
			}
			if (sortOrder_0 == SortOrder.Descending)
			{
				return checked(-num);
			}
			return 0;
		}
	}

	private static int int_0;

	private static int int_1;

	private static int int_2;

	private static int int_3;

	private static int int_4;

	private static int int_5;

	private static int int_6;

	private static int int_7;

	private static int int_8;

	private static int int_9;

	private static int int_10;

	private static int int_11;

	private static int int_12;

	private Class34 class34_0;

	private int int_13;

	private Image image_0;

	private static int int_14;

	private static int int_15;

	public bool IsSelectedSomeItem => base.SelectedItems.Count > 0;

	public ListViewExt()
	{
		base.ColumnClick += ListViewExt_ColumnClick;
		class34_0 = new Class34();
		int_13 = -1;
		base.ListViewItemSorter = class34_0;
		base.View = View.Details;
		base.DoubleBuffered = true;
		base.FullRowSelect = true;
		base.HideSelection = false;
		SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		base.Refresh();
	}

	public ListViewGroup GetGroupByHeader(string name)
	{
		foreach (ListViewGroup group in base.Groups)
		{
			if (group.Header.Equals(name))
			{
				return group;
			}
		}
		return null;
	}

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern int SendMessage(IntPtr intptr_0, int int_16, int int_17, LVGROUP lvgroup_0);

	[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "SendMessage")]
	private static extern IntPtr SendMessage_1(IntPtr intptr_0, uint uint_0, IntPtr intptr_1, IntPtr intptr_2);

	[DllImport("user32.dll", EntryPoint = "SendMessage")]
	private static extern IntPtr SendMessage_2(IntPtr intptr_0, int int_16, IntPtr intptr_1, ref Struct1 struct1_0);

	[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "SendMessage")]
	private static extern IntPtr SendMessage_3(IntPtr intptr_0, int int_16, int int_17, ref Struct2 struct2_0);

	[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "SendMessage")]
	private static extern IntPtr SendMessage_4(IntPtr intptr_0, int int_16, int int_17, ref Struct3 struct3_0);

	protected override void OnPaint(PaintEventArgs e)
	{
		if (GetStyle(ControlStyles.UserPaint))
		{
			Message m = default(Message);
			m.HWnd = base.Handle;
			m.Msg = 792;
			m.WParam = e.Graphics.GetHdc();
			m.LParam = (IntPtr)4;
			DefWndProc(ref m);
			e.Graphics.ReleaseHdc(m.WParam);
		}
		base.OnPaint(e);
	}

	private void method_0(int int_16, int int_17)
	{
		IntPtr intptr_ = SendMessage_1(base.Handle, 4127u, IntPtr.Zero, IntPtr.Zero);
		IntPtr intptr_2 = new IntPtr(int_17);
		IntPtr intptr_3 = new IntPtr(int_16);
		Struct1 struct1_ = default(Struct1);
		struct1_.uint_0 = 4u;
		SendMessage_2(intptr_, 4619, intptr_3, ref struct1_);
		struct1_.int_2 = struct1_.int_2 & -513 & -1025;
		SendMessage_2(intptr_, 4620, intptr_3, ref struct1_);
		struct1_ = default(Struct1);
		struct1_.uint_0 = 4u;
		SendMessage_2(intptr_, 4619, intptr_2, ref struct1_);
		if (class34_0.SortOrder_0 == SortOrder.Ascending)
		{
			struct1_.int_2 |= 1024;
		}
		else
		{
			struct1_.int_2 |= 512;
		}
		SendMessage_2(intptr_, 4620, intptr_2, ref struct1_);
		int_16 = int_17;
	}

	private void method_1(ListViewExt listViewExt_0, int int_16, int int_17, int int_18)
	{
		Struct2 struct2_ = default(Struct2);
		struct2_.int_4 = int_17;
		struct2_.int_3 = int_18;
		SendMessage_3(listViewExt_0.Handle, 4139, int_16, ref struct2_);
	}

	private bool method_2()
	{
		Struct3 struct3_ = default(Struct3);
		if (!(image_0 is Bitmap bitmap))
		{
			struct3_.int_0 = 0;
		}
		else
		{
			struct3_.intptr_0 = bitmap.GetHbitmap();
			struct3_.int_0 = 268435456;
		}
		Application.OleRequired();
		IntPtr intPtr = SendMessage_4(base.Handle, 4234, 0, ref struct3_);
		return intPtr != IntPtr.Zero;
	}

	private void ListViewExt_ColumnClick(object sender, ColumnClickEventArgs e)
	{
		if (e.Column == class34_0.Int32_0)
		{
			if (class34_0.SortOrder_0 == SortOrder.Ascending)
			{
				class34_0.SortOrder_0 = SortOrder.Descending;
			}
			else
			{
				class34_0.SortOrder_0 = SortOrder.Ascending;
			}
		}
		else
		{
			class34_0.Int32_0 = e.Column;
			class34_0.SortOrder_0 = SortOrder.Ascending;
		}
		Sort();
		method_0(int_13, e.Column);
		SetSelectedColumn(base.Columns[e.Column]);
		int_13 = e.Column;
	}

	public void ShowCollapseGroupVisible()
	{
		if (base.ShowGroups)
		{
			ListViewHelper.smethod_1(this, ListViewGroupState.Collapsible);
		}
	}

	public ListViewItem GetSelectedItem()
	{
		if (base.SelectedItems.Count > 0)
		{
			return base.SelectedItems[0];
		}
		return null;
	}

	public bool ContainsItemCD(string sText)
	{
		if (base.InvokeRequired)
		{
			return Conversions.ToBoolean(Invoke(new Delegate8(GetItem), sText));
		}
		foreach (ListViewItem item in base.Items)
		{
			if (item.Text.Equals(sText))
			{
				return true;
			}
		}
		return false;
	}

	public ListViewItem GetItem(string sURL)
	{
		if (base.InvokeRequired)
		{
			return (ListViewItem)Invoke(new Delegate9(GetItem), sURL);
		}
		foreach (ListViewItem item in base.Items)
		{
			if (item.Text.Equals(sURL))
			{
				return item;
			}
		}
		ListViewItem listViewItem2 = new ListViewItem();
		listViewItem2.SubItems.Add("");
		return listViewItem2;
	}

	public void DeselectAllItems()
	{
		method_1(this, -1, 2, 0);
	}

	public void SelectAllItems()
	{
		method_1(this, -1, 2, 2);
	}

	public void SetSelectedColumn(ColumnHeader value)
	{
		SendMessage_1(base.Handle, 4236u, (IntPtr)(value?.Index ?? (-1)), (IntPtr)0);
	}

	public ListViewItem SelectedItem()
	{
		if (IsSelectedSomeItem)
		{
			return base.SelectedItems[0];
		}
		return null;
	}

	public bool Scroll(int dx, int dy)
	{
		return SendMessage_1(base.Handle, 4116u, (IntPtr)dx, (IntPtr)dy) != IntPtr.Zero;
	}
}
