using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class ProxyType : Form
{
	private IContainer icontainer_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("cmbProxy")]
	private ComboBox _cmbProxy;

	[AccessedThroughProperty("btnOK")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnOK;

	internal virtual ComboBox cmbProxy
	{
		[CompilerGenerated]
		get
		{
			return _cmbProxy;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_0;
			ComboBox comboBox = _cmbProxy;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged -= value2;
			}
			_cmbProxy = value;
			comboBox = _cmbProxy;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual Button btnOK
	{
		[CompilerGenerated]
		get
		{
			return _btnOK;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_1;
			Button button = _btnOK;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnOK = value;
			button = _btnOK;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	public ProxyType()
	{
		base.FormClosing += ProxyType_FormClosing;
		base.Load += ProxyType_Load;
		InitializeComponent();
		cmbProxy.Items.AddRange(new string[3] { "WEB PROXY", "SOCKS 4", "SOCKS 5" });
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.cmbProxy = new System.Windows.Forms.ComboBox();
		this.btnOK = new System.Windows.Forms.Button();
		base.SuspendLayout();
		this.cmbProxy.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.cmbProxy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbProxy.FormattingEnabled = true;
		this.cmbProxy.Location = new System.Drawing.Point(12, 9);
		this.cmbProxy.Name = "cmbProxy";
		this.cmbProxy.Size = new System.Drawing.Size(175, 28);
		this.cmbProxy.TabIndex = 0;
		this.btnOK.Enabled = false;
		this.btnOK.Location = new System.Drawing.Point(12, 43);
		this.btnOK.Name = "btnOK";
		this.btnOK.Size = new System.Drawing.Size(175, 30);
		this.btnOK.TabIndex = 46;
		this.btnOK.Text = "&OK";
		this.btnOK.UseVisualStyleBackColor = true;
		base.AcceptButton = this.btnOK;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(199, 83);
		base.Controls.Add(this.btnOK);
		base.Controls.Add(this.cmbProxy);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.MaximizeBox = false;
		base.Name = "ProxyType";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Proxy Type";
		base.ResumeLayout(false);
	}

	private void ProxyType_FormClosing(object sender, FormClosingEventArgs e)
	{
		Class50.smethod_3(this);
	}

	private void ProxyType_Load(object sender, EventArgs e)
	{
		Class50.smethod_2(this);
	}

	private void method_0(object sender, EventArgs e)
	{
		btnOK.Enabled = !Information.IsNothing(RuntimeHelpers.GetObjectValue(cmbProxy.SelectedItem));
	}

	private void method_1(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.OK;
		Close();
	}
}
