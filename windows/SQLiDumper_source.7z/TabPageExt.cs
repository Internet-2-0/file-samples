using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
[DesignTimeVisible(false)]
[Description("Represents a single tab page in a MdiTabControl.TabControl.")]
public class TabPageExt : Control
{
	public delegate void ClickEventHandler(object sender, EventArgs e);

	internal delegate void CloseEventHandler(object sender, EventArgs e);

	internal delegate void GetTabRegionEventHandler(object sender, TabControlExt.GetTabRegionEventArgs e);

	internal delegate void TabPaintBackgroundEventHandler(object sender, TabControlExt.TabPaintEventArgs e);

	internal delegate void TabPaintBorderEventHandler(object sender, TabControlExt.TabPaintEventArgs e);

	internal delegate void DragingEventHandler(object sender, MouseEventArgs e);

	private IContainer components;

	[CompilerGenerated]
	[AccessedThroughProperty("tmrAnimate")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private System.Windows.Forms.Timer _tmrAnimate;

	private Color __BackHighColor;

	private Color __BackHighColorDisabled;

	private Color __BackLowColor;

	private Color __BackLowColorDisabled;

	private Color __BorderColor;

	private Color __BorderColorDisabled;

	private Color __ForeColorDisabled;

	private bool __Selected;

	private bool __Hot;

	private int __MaximumWidth;

	private int __MinimumWidth;

	private int __PadLeft;

	private int __PadRight;

	private bool __CloseButtonVisible;

	private Image __CloseButton;

	private Image __CloseButtonImageHot;

	private Image __CloseButtonImageDisabled;

	private Color __CloseButtonBackHighColor;

	private Color __CloseButtonBackLowColor;

	private Color __CloseButtonBorderColor;

	private Color __CloseButtonForeColor;

	private Color __CloseButtonBackHighColorDisabled;

	private Color __CloseButtonBackLowColorDisabled;

	private Color __CloseButtonBorderColorDisabled;

	private Color __CloseButtonForeColorDisabled;

	private Color __CloseButtonBackHighColorHot;

	private Color __CloseButtonBackLowColorHot;

	private Color __CloseButtonBorderColorHot;

	private Color __CloseButtonForeColorHot;

	private bool __HotTrack;

	private Size __CloseButtonSize;

	private bool __FontBoldOnSelect;

	private Size __IconSize;

	private SmoothingMode __SmoothingMode;

	private TabControlExt.TabAlignment __Alignment;

	private bool __GlassGradient;

	private bool __BorderEnhanced;

	private ToolStripRenderMode __RenderMode;

	private TabControlExt.Weight __BorderEnhanceWeight;

	private bool __IconVisible;

	private bool __ConfirmeClose;

	private int __Index;

	private Icon __Icon;

	[AccessedThroughProperty("__Form")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Form ___Form;

	internal bool TabVisible;

	internal int TabLeft;

	internal ToolStripMenuItem MenuItem;

	private bool __MouseOverCloseButton;

	private Icon[] __Icons;

	[SpecialName]
	private bool _0024STATIC_0024Tab_MouseMove_002420211C128381_0024State;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024Tab_MouseMove_002420211C128381_0024State_0024Init;

	[SpecialName]
	private int _0024STATIC_0024tmrAnimate_Tick_002420211C12819D_0024iTick;

	[field: AccessedThroughProperty("imgAnimate")]
	internal virtual ImageList imgAnimate
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual System.Windows.Forms.Timer tmrAnimate
	{
		[CompilerGenerated]
		get
		{
			return _tmrAnimate;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = tmrAnimate_Tick;
			System.Windows.Forms.Timer timer = _tmrAnimate;
			if (timer != null)
			{
				timer.Tick -= value2;
			}
			_tmrAnimate = value;
			timer = _tmrAnimate;
			if (timer != null)
			{
				timer.Tick += value2;
			}
		}
	}

	internal virtual Form __Form
	{
		[CompilerGenerated]
		get
		{
			return ___Form;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			FormClosedEventHandler value2 = TabContent_FormClosed;
			EventHandler value3 = TabContent_TextChanged;
			Form form = ___Form;
			if (form != null)
			{
				form.FormClosed -= value2;
				form.TextChanged -= value3;
			}
			___Form = value;
			form = ___Form;
			if (form != null)
			{
				form.FormClosed += value2;
				form.TextChanged += value3;
			}
		}
	}

	[Description("Gets the form associated with the tab page")]
	public Form Form => __Form;

	[Description("Gets or sets the System.Drawing.Color structure that represents the starting color of the Background linear gradient for the tab.")]
	public Color BackHighColor
	{
		get
		{
			return __BackHighColor;
		}
		set
		{
			__BackHighColor = value;
			Invalidate();
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the ending color of the Background linear gradient for the tab.")]
	public Color BackLowColor
	{
		get
		{
			return __BackLowColor;
		}
		set
		{
			__BackLowColor = value;
			Invalidate();
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the border color.")]
	internal Color BorderColor
	{
		get
		{
			return __BorderColor;
		}
		set
		{
			__BorderColor = value;
			Invalidate();
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the starting color of the Background linear gradient for a non selected tab.")]
	public Color BackHighColorDisabled
	{
		get
		{
			return __BackHighColorDisabled;
		}
		set
		{
			__BackHighColorDisabled = value;
			Invalidate();
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the ending color of the Background linear gradient for a non selected tab.")]
	public Color BackLowColorDisabled
	{
		get
		{
			return __BackLowColorDisabled;
		}
		set
		{
			__BackLowColorDisabled = value;
			Invalidate();
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the border color of the tab when not selected.")]
	public Color BorderColorDisabled
	{
		get
		{
			return __BorderColorDisabled;
		}
		set
		{
			__BorderColorDisabled = value;
			Invalidate();
		}
	}

	[Description("Gets or sets the System.Drawing.Color structure that represents the fore color of the tab when not selected.")]
	public Color ForeColorDisabled
	{
		get
		{
			return __ForeColorDisabled;
		}
		set
		{
			__ForeColorDisabled = value;
			Invalidate();
		}
	}

	internal bool IsSelected
	{
		get
		{
			return __Selected;
		}
		set
		{
			if (__Selected != value)
			{
				__Selected = value;
				if (__Selected)
				{
					__Hot = false;
				}
				Invalidate();
			}
		}
	}

	[Description("Returns whether the tab is selected or not.")]
	public bool Selected => IsSelected;

	internal int MaximumWidth
	{
		get
		{
			return __MaximumWidth;
		}
		set
		{
			__MaximumWidth = value;
			CalculateWidth();
			Invalidate();
		}
	}

	internal int MinimumWidth
	{
		get
		{
			return __MinimumWidth;
		}
		set
		{
			__MinimumWidth = value;
			CalculateWidth();
			Invalidate();
		}
	}

	internal int PadLeft
	{
		get
		{
			return __PadLeft;
		}
		set
		{
			__PadLeft = value;
			CalculateWidth();
			Invalidate();
		}
	}

	internal int PadRight
	{
		get
		{
			return __PadRight;
		}
		set
		{
			__PadRight = value;
			CalculateWidth();
			Invalidate();
		}
	}

	[Description("Gets or sets whether the tab close button is visble or not.")]
	public bool CloseButtonVisible
	{
		get
		{
			return __CloseButtonVisible;
		}
		set
		{
			value = false;
			if (__CloseButtonVisible != value)
			{
				__CloseButtonVisible = value;
				CalculateWidth();
				Invalidate();
			}
		}
	}

	public Image CloseButtonImage
	{
		get
		{
			return __CloseButton;
		}
		set
		{
			__CloseButton = value;
			Invalidate();
		}
	}

	public Image CloseButtonImageHot
	{
		get
		{
			return __CloseButtonImageHot;
		}
		set
		{
			__CloseButtonImageHot = value;
			Invalidate();
		}
	}

	public Image CloseButtonImageDisabled
	{
		get
		{
			return __CloseButtonImageDisabled;
		}
		set
		{
			__CloseButtonImageDisabled = value;
			Invalidate();
		}
	}

	public Color CloseButtonBackHighColor
	{
		get
		{
			return __CloseButtonBackHighColor;
		}
		set
		{
			__CloseButtonBackHighColor = value;
		}
	}

	public Color CloseButtonBackLowColor
	{
		get
		{
			return __CloseButtonBackLowColor;
		}
		set
		{
			__CloseButtonBackLowColor = value;
		}
	}

	public Color CloseButtonBorderColor
	{
		get
		{
			return __CloseButtonBorderColor;
		}
		set
		{
			__CloseButtonBorderColor = value;
		}
	}

	public Color CloseButtonForeColor
	{
		get
		{
			return __CloseButtonForeColor;
		}
		set
		{
			__CloseButtonForeColor = value;
		}
	}

	public Color CloseButtonBackHighColorDisabled
	{
		get
		{
			return __CloseButtonBackHighColorDisabled;
		}
		set
		{
			__CloseButtonBackHighColorDisabled = value;
		}
	}

	public Color CloseButtonBackLowColorDisabled
	{
		get
		{
			return __CloseButtonBackLowColorDisabled;
		}
		set
		{
			__CloseButtonBackLowColorDisabled = value;
		}
	}

	public Color CloseButtonBorderColorDisabled
	{
		get
		{
			return __CloseButtonBorderColorDisabled;
		}
		set
		{
			__CloseButtonBorderColorDisabled = value;
		}
	}

	public Color CloseButtonForeColorDisabled
	{
		get
		{
			return __CloseButtonForeColorDisabled;
		}
		set
		{
			__CloseButtonForeColorDisabled = value;
		}
	}

	public Color CloseButtonBackHighColorHot
	{
		get
		{
			return __CloseButtonBackHighColorHot;
		}
		set
		{
			__CloseButtonBackHighColorHot = value;
		}
	}

	public Color CloseButtonBackLowColorHot
	{
		get
		{
			return __CloseButtonBackLowColorHot;
		}
		set
		{
			__CloseButtonBackLowColorHot = value;
		}
	}

	public Color CloseButtonBorderColorHot
	{
		get
		{
			return __CloseButtonBorderColorHot;
		}
		set
		{
			__CloseButtonBorderColorHot = value;
		}
	}

	public Color CloseButtonForeColorHot
	{
		get
		{
			return __CloseButtonForeColorHot;
		}
		set
		{
			__CloseButtonForeColorHot = value;
		}
	}

	internal bool HotTrack
	{
		get
		{
			return __HotTrack;
		}
		set
		{
			__HotTrack = value;
			Invalidate();
		}
	}

	internal Size CloseButtonSize
	{
		get
		{
			return __CloseButtonSize;
		}
		set
		{
			__CloseButtonSize = value;
			CalculateWidth();
			Invalidate();
		}
	}

	internal bool FontBoldOnSelect
	{
		get
		{
			return __FontBoldOnSelect;
		}
		set
		{
			__FontBoldOnSelect = value;
			CalculateWidth();
			Invalidate();
		}
	}

	internal Size IconSize
	{
		get
		{
			return __IconSize;
		}
		set
		{
			__IconSize = value;
			CalculateWidth();
			Invalidate();
		}
	}

	internal SmoothingMode SmoothingMode
	{
		get
		{
			return __SmoothingMode;
		}
		set
		{
			__SmoothingMode = value;
			Invalidate();
		}
	}

	internal TabControlExt.TabAlignment Alignment
	{
		get
		{
			return __Alignment;
		}
		set
		{
			__Alignment = value;
			Invalidate();
		}
	}

	internal bool GlassGradient
	{
		get
		{
			return __GlassGradient;
		}
		set
		{
			__GlassGradient = value;
		}
	}

	internal bool BorderEnhanced
	{
		get
		{
			return __BorderEnhanced;
		}
		set
		{
			__BorderEnhanced = value;
		}
	}

	internal ToolStripRenderMode RenderMode
	{
		get
		{
			return __RenderMode;
		}
		set
		{
			__RenderMode = value;
			Invalidate();
		}
	}

	internal TabControlExt.Weight BorderEnhanceWeight
	{
		get
		{
			return __BorderEnhanceWeight;
		}
		set
		{
			__BorderEnhanceWeight = value;
		}
	}

	public Icon Icon
	{
		get
		{
			return __Form.Icon;
		}
		set
		{
			if (value != null)
			{
				__Form.Icon = value;
				if (IconVisible)
				{
					Region region = new Region(new Rectangle(PadLeft, checked((int)Math.Round((double)base.Height / 2.0 - (double)__IconSize.Height / 2.0)), __IconSize.Width, __IconSize.Height));
					Invalidate(region);
					region.Dispose();
					region = null;
					MenuItem.Image = value.ToBitmap();
				}
			}
			else
			{
				MenuItem.Image = null;
				__Form.Icon = null;
			}
		}
	}

	public bool IconVisible
	{
		get
		{
			return __IconVisible;
		}
		set
		{
			__IconVisible = value;
			if (!value)
			{
				using Icon icon = new Icon(__Form.Icon, __IconSize);
				DestroyIcon(icon.Handle);
			}
			Icon = __Form.Icon;
			Invalidate();
		}
	}

	public bool ConfirmeClose
	{
		get
		{
			return __ConfirmeClose;
		}
		set
		{
			__ConfirmeClose = value;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public override Size MinimumSize
	{
		get
		{
			Size result = default(Size);
			return result;
		}
		set
		{
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public override Size MaximumSize
	{
		get
		{
			Size result = default(Size);
			return result;
		}
		set
		{
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public new Padding Padding
	{
		get
		{
			Padding result = default(Padding);
			return result;
		}
		set
		{
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public override Color BackColor
	{
		get
		{
			Color result = default(Color);
			return result;
		}
		set
		{
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public override DockStyle Dock
	{
		get
		{
			DockStyle result = default(DockStyle);
			return result;
		}
		set
		{
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public override AnchorStyles Anchor
	{
		get
		{
			AnchorStyles result = default(AnchorStyles);
			return result;
		}
		set
		{
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public override string Text
	{
		get
		{
			return __Form.Text;
		}
		set
		{
			__Form.Text = value;
		}
	}

	[Description("Occurs when the user clicks the Tab Control.")]
	public new event ClickEventHandler Click;

	internal event CloseEventHandler Close;

	internal event GetTabRegionEventHandler GetTabRegion;

	internal event TabPaintBackgroundEventHandler TabPaintBackground;

	internal event TabPaintBorderEventHandler TabPaintBorder;

	internal event DragingEventHandler Draging;

	public TabPageExt(object o, string sText = "", Bitmap icon = null)
	{
		base.MouseDown += Tab_MouseDown;
		base.MouseEnter += Tab_MouseEnter;
		base.MouseLeave += Tab_MouseLeave;
		base.MouseMove += Tab_MouseMove;
		__Selected = false;
		__Hot = false;
		MenuItem = new ToolStripMenuItem();
		__MouseOverCloseButton = false;
		InitializeComponent();
		SuspendLayout();
		SetStyle(ControlStyles.DoubleBuffer, value: true);
		SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
		SetStyle(ControlStyles.UserPaint, value: true);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		base.BackColor = Color.Transparent;
		base.Visible = false;
		base.Size = new Size(1, 1);
		Form form;
		if (o is Form)
		{
			form = (Form)o;
		}
		else
		{
			if (!(o is Panel))
			{
				throw new Exception("Tab Add Form Error: " + Versioned.TypeName(RuntimeHelpers.GetObjectValue(o)));
			}
			form = new Form
			{
				Name = Conversions.ToString(NewLateBinding.LateGet(o, null, "Name", new object[0], null, null, null)),
				Text = sText
			};
			if (icon != null)
			{
				__Icon = IconFromImage(icon);
			}
			form.Icon = __Icon;
			Panel panel = new Panel
			{
				Height = 2
			};
			form.Controls.Add(panel);
			form.Controls.Add((Control)o);
			NewLateBinding.LateSet(o, null, "Dock", new object[1] { DockStyle.Fill }, null, null);
			NewLateBinding.LateSet(o, null, "Visible", new object[1] { true }, null, null);
			panel.Dock = DockStyle.Top;
			panel.SendToBack();
		}
		form.TopLevel = false;
		form.MdiParent = null;
		form.FormBorderStyle = FormBorderStyle.None;
		form.Dock = DockStyle.Fill;
		form.Show();
		__Form = form;
		MenuItem.Text = form.Text;
		MenuItem.Image = form.Icon.ToBitmap();
		MenuItem.Tag = this;
		MenuItem.Image = null;
		ResumeLayout(performLayout: false);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TabPageExt));
		this.imgAnimate = new System.Windows.Forms.ImageList(this.components);
		this.tmrAnimate = new System.Windows.Forms.Timer(this.components);
		base.SuspendLayout();
		this.imgAnimate.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imgAnimate.ImageStream");
		this.imgAnimate.TransparentColor = System.Drawing.Color.Transparent;
		this.imgAnimate.Images.SetKeyName(0, "1.ico");
		this.imgAnimate.Images.SetKeyName(1, "2.ico");
		this.imgAnimate.Images.SetKeyName(2, "3.ico");
		this.imgAnimate.Images.SetKeyName(3, "4.ico");
		this.imgAnimate.Images.SetKeyName(4, "5.ico");
		this.imgAnimate.Images.SetKeyName(5, "6.ico");
		this.imgAnimate.Images.SetKeyName(6, "7.ico");
		this.imgAnimate.Images.SetKeyName(7, "8.ico");
		this.tmrAnimate.Interval = 500;
		base.ResumeLayout(false);
	}

	public Icon IconFromImage(Image img)
	{
		MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write((short)0);
		binaryWriter.Write((short)1);
		binaryWriter.Write((short)1);
		int num = img.Width;
		if (num >= 256)
		{
			num = 0;
		}
		checked
		{
			binaryWriter.Write((byte)num);
			int num2 = img.Height;
			if (num2 >= 256)
			{
				num2 = 0;
			}
			binaryWriter.Write((byte)num2);
			binaryWriter.Write((byte)0);
			binaryWriter.Write((byte)0);
			binaryWriter.Write((short)0);
			binaryWriter.Write((short)0);
			long position = memoryStream.Position;
			binaryWriter.Write(0);
			int num3 = (int)memoryStream.Position + 4;
			binaryWriter.Write(num3);
			img.Save(memoryStream, ImageFormat.Png);
			int value = (int)memoryStream.Position - num3;
			memoryStream.Seek(position, SeekOrigin.Begin);
			binaryWriter.Write(value);
			memoryStream.Seek(0L, SeekOrigin.Begin);
			return new Icon(memoryStream);
		}
	}

	[Description("Selects the TabPage.")]
	public new void Select()
	{
		if (!IsSelected)
		{
			Click?.Invoke(this, new EventArgs());
		}
	}

	private LinearGradientBrush CreateGradientBrush(Rectangle Rectangle, Color Color1, Color Color2)
	{
		if (__GlassGradient)
		{
			return Helper.CreateGlassGradientBrush(Rectangle, Color1, Color2);
		}
		return new LinearGradientBrush(Rectangle, Color1, Color2, LinearGradientMode.Vertical);
	}

	private void TabContent_FormClosed(object sender, FormClosedEventArgs e)
	{
		Close?.Invoke(this, new EventArgs());
	}

	private void TabContent_TextChanged(object sender, EventArgs e)
	{
		CalculateWidth();
		Invalidate();
		MenuItem.Text = __Form.Text;
	}

	private void Tab_MouseDown(object sender, MouseEventArgs e)
	{
		if (!(__Selected & !(__MouseOverCloseButton & __CloseButtonVisible)) && e.Button == MouseButtons.Left)
		{
			if (__MouseOverCloseButton & __CloseButtonVisible)
			{
				__Form.Close();
			}
			else
			{
				Select();
			}
		}
	}

	private void Tab_MouseEnter(object sender, EventArgs e)
	{
		if (!__Selected)
		{
			if (__HotTrack)
			{
				__Hot = true;
			}
			Invalidate();
		}
	}

	private void Tab_MouseLeave(object sender, EventArgs e)
	{
		__MouseOverCloseButton = false;
		__Hot = false;
		Invalidate();
	}

	private void Tab_MouseMove(object sender, MouseEventArgs e)
	{
		if (_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State_0024Init == null)
		{
			Interlocked.CompareExchange(ref _0024STATIC_0024Tab_MouseMove_002420211C128381_0024State_0024Init, new StaticLocalInitFlag(), null);
		}
		bool lockTaken = false;
		try
		{
			Monitor.Enter(_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State_0024Init, ref lockTaken);
			if (_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State_0024Init.State == 0)
			{
				_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State_0024Init.State = 2;
				_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State = false;
			}
			else if (_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State_0024Init.State == 2)
			{
				throw new IncompleteInitialization();
			}
		}
		finally
		{
			_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State_0024Init.State = 1;
			if (lockTaken)
			{
				Monitor.Exit(_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State_0024Init);
			}
		}
		checked
		{
			if (__CloseButtonVisible)
			{
				int num = base.Width - PadRight - __CloseButtonSize.Width - 2;
				int num2 = (int)Math.Round((double)base.Height / 2.0 - (double)__CloseButtonSize.Height / 2.0);
				__MouseOverCloseButton = (e.X >= num) & (e.X <= num + __CloseButtonSize.Width - 1) & (e.Y >= num2) & (e.Y <= num2 + __CloseButtonSize.Height - 1);
				if ((_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State != __MouseOverCloseButton) & __CloseButtonVisible)
				{
					_0024STATIC_0024Tab_MouseMove_002420211C128381_0024State = __MouseOverCloseButton;
					Region region = new Region(new Rectangle(num, num2, __CloseButtonSize.Width, __CloseButtonSize.Height));
					Invalidate(region);
					region.Dispose();
					region = null;
				}
			}
			if (RectangleToScreen(base.ClientRectangle).Contains(PointToScreen(new Point(e.X, e.Y))))
			{
				Cursor = Cursors.Default;
			}
			else
			{
				Draging?.Invoke(this, e);
			}
		}
	}

	private void DrawText(Graphics g)
	{
		Font font = new Font(Font, (FontStyle)Conversions.ToInteger(Interaction.IIf(__Selected & __FontBoldOnSelect, FontStyle.Bold, FontStyle.Regular)));
		object obj = Interaction.IIf(__Selected | __Hot, ForeColor, __ForeColorDisabled);
		Brush brush = new SolidBrush((obj != null) ? ((Color)obj) : default(Color));
		RectangleF layoutRectangle = new RectangleF(Conversions.ToSingle(Operators.AddObject(Operators.AddObject(PadLeft, Interaction.IIf(__Form.Icon == null, 0, __IconSize.Width)), 2)), 1f, Conversions.ToSingle(Operators.SubtractObject(Operators.SubtractObject(Operators.SubtractObject(Operators.SubtractObject(checked(base.Width - PadLeft), Interaction.IIf(__Form.Icon == null, 0, __IconSize.Height)), 5), Interaction.IIf(__CloseButtonVisible, __CloseButtonSize.Width, 0)), PadRight)), DisplayRectangle.Height);
		StringFormat stringFormat = new StringFormat();
		stringFormat.FormatFlags = StringFormatFlags.NoWrap;
		stringFormat.LineAlignment = StringAlignment.Center;
		stringFormat.Trimming = StringTrimming.EllipsisCharacter;
		g.DrawString(__Form.Text, font, brush, layoutRectangle, stringFormat);
		stringFormat.Dispose();
		brush.Dispose();
		font.Dispose();
		stringFormat = null;
		brush = null;
		font = null;
	}

	private void DrawIcon(Graphics g)
	{
		try
		{
			if (__IconVisible && __Form.Icon != null)
			{
				Rectangle targetRect = new Rectangle(PadLeft, checked((int)Math.Round((double)base.Height / 2.0 - (double)__IconSize.Height / 2.0)), __IconSize.Width, __IconSize.Height);
				Icon icon = new Icon(__Form.Icon, __IconSize);
				g.DrawIcon(icon, targetRect);
				DestroyIcon(icon.Handle);
				icon.Dispose();
				icon = null;
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	[DllImport("user32.dll")]
	private static extern bool DestroyIcon(IntPtr handle);

	private void DrawCloseButton(Graphics g)
	{
		checked
		{
			try
			{
				int num = base.Width - (__CloseButtonSize.Width + PadRight + 2);
				int num2 = (int)Math.Round((double)base.Height / 2.0 - (double)__CloseButtonSize.Height / 2.0);
				Bitmap bitmap = (__MouseOverCloseButton ? ((Bitmap)__CloseButtonImageHot) : ((!__Selected) ? ((Bitmap)__CloseButtonImageDisabled) : ((Bitmap)__CloseButton)));
				bool flag = false;
				if (bitmap == null)
				{
					bitmap = GetButton();
					flag = true;
				}
				Icon icon = Icon.FromHandle(bitmap.GetHicon());
				Rectangle targetRect = new Rectangle(num, num2, __CloseButtonSize.Width, __CloseButtonSize.Height);
				g.DrawIcon(icon, targetRect);
				if (flag)
				{
					bitmap.Dispose();
					bitmap = null;
				}
				DestroyIcon(icon.Handle);
				icon.Dispose();
				icon = null;
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
	}

	private Bitmap GetButton()
	{
		Point[] points = new Point[14]
		{
			new Point(1, 0),
			new Point(3, 0),
			new Point(5, 2),
			new Point(7, 0),
			new Point(9, 0),
			new Point(6, 3),
			new Point(6, 4),
			new Point(9, 7),
			new Point(7, 7),
			new Point(5, 5),
			new Point(3, 7),
			new Point(1, 7),
			new Point(4, 4),
			new Point(4, 3)
		};
		GraphicsPath graphicsPath = new GraphicsPath();
		Matrix matrix = new Matrix();
		Point[] points2 = new Point[8]
		{
			new Point(0, 1),
			new Point(1, 0),
			new Point(15, 0),
			new Point(16, 1),
			new Point(16, 14),
			new Point(15, 15),
			new Point(1, 15),
			new Point(0, 14)
		};
		Color color;
		Color color2;
		Color color3;
		Color color4;
		if (__MouseOverCloseButton)
		{
			color = Helper.RenderColors.TabCloseButtonBackHighColorHot(__RenderMode, CloseButtonBackHighColorHot);
			color2 = Helper.RenderColors.TabCloseButtonBackLowColorHot(__RenderMode, CloseButtonBackLowColorHot);
			color3 = Helper.RenderColors.TabCloseButtonBorderColorHot(__RenderMode, CloseButtonBorderColorHot);
			color4 = Helper.RenderColors.TabCloseButtonForeColorHot(__RenderMode, CloseButtonForeColorHot);
		}
		else if (__Selected)
		{
			color = Helper.RenderColors.TabCloseButtonBackHighColor(__RenderMode, CloseButtonBackHighColor);
			color2 = Helper.RenderColors.TabCloseButtonBackLowColor(__RenderMode, CloseButtonBackLowColor);
			color3 = Helper.RenderColors.TabCloseButtonBorderColor(__RenderMode, CloseButtonBorderColor);
			color4 = Helper.RenderColors.TabCloseButtonForeColor(__RenderMode, CloseButtonForeColor);
		}
		else
		{
			color = Helper.RenderColors.TabCloseButtonBackHighColorDisabled(__RenderMode, CloseButtonBackHighColorDisabled);
			color2 = Helper.RenderColors.TabCloseButtonBackLowColorDisabled(__RenderMode, CloseButtonBackLowColorDisabled);
			color3 = Helper.RenderColors.TabCloseButtonBorderColorDisabled(__RenderMode, CloseButtonBorderColorDisabled);
			color4 = Helper.RenderColors.TabCloseButtonForeColorDisabled(__RenderMode, CloseButtonForeColorDisabled);
		}
		Bitmap bitmap = new Bitmap(17, 17);
		bitmap.MakeTransparent();
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		LinearGradientBrush brush = new LinearGradientBrush(new Point(0, 0), new Point(0, 15), color, color2);
		graphics.FillPolygon(brush, points2);
		Pen pen = new Pen(color3);
		graphics.DrawPolygon(pen, points2);
		graphics.SmoothingMode = SmoothingMode.Default;
		graphicsPath.AddPolygon(points);
		matrix.Translate(3f, 4f);
		graphicsPath.Transform(matrix);
		pen.Dispose();
		pen = new Pen(color4);
		graphics.DrawPolygon(pen, graphicsPath.PathPoints);
		SolidBrush solidBrush = new SolidBrush(color4);
		graphics.FillPolygon(solidBrush, graphicsPath.PathPoints);
		solidBrush.Dispose();
		pen.Dispose();
		graphicsPath.Dispose();
		graphics.Dispose();
		matrix.Dispose();
		return bitmap;
	}

	private void CalculateWidth()
	{
		Graphics graphics = CreateGraphics();
		int num = 0;
		int num2 = 0;
		int num3 = base.Width;
		if (__Form.Icon != null)
		{
			num = __IconSize.Width;
		}
		if (__CloseButtonVisible)
		{
			num2 = __CloseButtonSize.Width;
		}
		Font font = new Font(Font, (FontStyle)Conversions.ToInteger(Interaction.IIf(__FontBoldOnSelect, FontStyle.Bold, FontStyle.Regular)));
		checked
		{
			num3 = (int)Math.Round((float)(PadLeft + num + 3) + graphics.MeasureString(__Form.Text, font).Width + 3f + (float)num2 + (float)__PadRight + 2f);
			font.Dispose();
			if (num3 < __MinimumWidth + 1)
			{
				num3 = __MinimumWidth + 1;
			}
			else if (num3 > __MaximumWidth + 1)
			{
				num3 = __MaximumWidth + 1;
			}
			if (num3 != base.Width)
			{
				base.Width = num3;
			}
			graphics.Dispose();
		}
	}

	private Point[] GetRegion(int int_0, int int_1, int H1)
	{
		checked
		{
			Point[] points = new Point[6]
			{
				new Point(0, int_1),
				new Point(0, 2),
				new Point(2, 0),
				new Point(int_0 - 3, 0),
				new Point(int_0 - 1, 2),
				new Point(int_0 - 1, int_1)
			};
			TabControlExt.GetTabRegionEventArgs getTabRegionEventArgs = new TabControlExt.GetTabRegionEventArgs(points, int_0, int_1, IsSelected);
			GetTabRegion?.Invoke(this, getTabRegionEventArgs);
			Point[] array = getTabRegionEventArgs.Points;
			Array.Resize(ref array, getTabRegionEventArgs.Points.Length + 2);
			getTabRegionEventArgs.Points = array;
			Array.Copy(getTabRegionEventArgs.Points, 0, getTabRegionEventArgs.Points, 1, getTabRegionEventArgs.Points.Length - 1);
			getTabRegionEventArgs.Points[0] = new Point(getTabRegionEventArgs.Points[1].X, H1);
			getTabRegionEventArgs.Points[getTabRegionEventArgs.Points.Length - 1] = new Point(getTabRegionEventArgs.Points[getTabRegionEventArgs.Points.Length - 2].X, H1);
			return getTabRegionEventArgs.Points;
		}
	}

	private void MirrorPath(GraphicsPath GraphicPath)
	{
		Matrix matrix = new Matrix();
		matrix.Translate(0f, checked(base.Height - 1));
		matrix.Scale(1f, -1f);
		GraphicPath.Transform(matrix);
		matrix.Dispose();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		if (false)
		{
			return;
		}
		_ = 1;
		SuspendLayout();
		GraphicsPath graphicsPath = new GraphicsPath();
		int num = base.Width;
		CalculateWidth();
		if (num != base.Width)
		{
			graphicsPath.Dispose();
			return;
		}
		Color color;
		Color color2;
		Color color3;
		Color color4;
		if (__Selected)
		{
			color = Helper.RenderColors.BorderColor(__RenderMode, BorderColor);
			color2 = Helper.RenderColors.TabBackHighColor(__RenderMode, BackHighColor);
			color3 = Helper.RenderColors.TabBackLowColor(__RenderMode, BackLowColor);
			color4 = Helper.RenderColors.TabBackLowColor(__RenderMode, BackLowColor);
		}
		else if (__Hot)
		{
			color = Helper.RenderColors.BorderColor(__RenderMode, BorderColor);
			color2 = Helper.RenderColors.TabBackHighColor(__RenderMode, BackHighColor);
			color3 = Helper.RenderColors.TabBackLowColor(__RenderMode, BackLowColor);
			color4 = Helper.RenderColors.BorderColor(__RenderMode, BorderColor);
		}
		else
		{
			color = Helper.RenderColors.BorderColorDisabled(__RenderMode, BorderColorDisabled);
			color2 = Helper.RenderColors.TabBackHighColorDisabled(__RenderMode, BackHighColorDisabled);
			color3 = Helper.RenderColors.TabBackLowColorDisabled(__RenderMode, BackLowColorDisabled);
			color4 = Helper.RenderColors.BorderColor(__RenderMode, BorderColor);
		}
		e.Graphics.SmoothingMode = __SmoothingMode;
		checked
		{
			graphicsPath.AddPolygon(GetRegion(base.Width - 1, base.Height - 1, Conversions.ToInteger(Interaction.IIf(IsSelected, base.Height, base.Height - 1))));
			if (__Alignment == TabControlExt.TabAlignment.Bottom)
			{
				MirrorPath(graphicsPath);
				Color color5 = color2;
				color2 = color3;
				color3 = color5;
			}
			Region region = new Region(graphicsPath);
			Region region2 = new Region(graphicsPath);
			Region region3 = new Region(graphicsPath);
			Region region4 = new Region(graphicsPath);
			Matrix matrix = new Matrix();
			Matrix matrix2 = new Matrix();
			Matrix matrix3 = new Matrix();
			matrix.Translate(0f, -0.5f);
			matrix2.Translate(0f, 0.5f);
			matrix3.Translate(1f, 0f);
			region2.Transform(matrix);
			region3.Transform(matrix2);
			region4.Transform(matrix3);
			region.Union(region2);
			region.Union(region3);
			region.Union(region4);
			base.Region = region;
			RectangleF bounds = region.GetBounds(e.Graphics);
			Rectangle clipRect = new Rectangle(0, 0, (int)Math.Round(bounds.Width), (int)Math.Round(bounds.Height));
			TabControlExt.TabPaintEventArgs tabPaintEventArgs = new TabControlExt.TabPaintEventArgs(e.Graphics, clipRect, __Selected, __Hot, graphicsPath, base.Width, base.Height);
			TabPaintBackground?.Invoke(this, tabPaintEventArgs);
			LinearGradientBrush linearGradientBrush = CreateGradientBrush(new Rectangle(0, 0, base.Width, base.Height), color2, color3);
			if (!tabPaintEventArgs.Handled)
			{
				e.Graphics.FillPath(linearGradientBrush, graphicsPath);
			}
			linearGradientBrush.Dispose();
			tabPaintEventArgs.Dispose();
			tabPaintEventArgs = new TabControlExt.TabPaintEventArgs(e.Graphics, clipRect, __Selected, __Hot, graphicsPath, base.Width, base.Height);
			TabPaintBorder?.Invoke(this, tabPaintEventArgs);
			if (!tabPaintEventArgs.Handled)
			{
				if (__BorderEnhanced)
				{
					object obj = Interaction.IIf(__Alignment == TabControlExt.TabAlignment.Bottom, color3, color2);
					Color color6 = ((obj != null) ? ((Color)obj) : default(Color));
					Pen pen = new Pen(color6, unchecked((int)__BorderEnhanceWeight));
					e.Graphics.DrawLines(pen, graphicsPath.PathPoints);
					pen.Dispose();
				}
				Pen pen2 = new Pen(color);
				e.Graphics.DrawLines(pen2, graphicsPath.PathPoints);
				pen2.Dispose();
			}
			tabPaintEventArgs.Dispose();
			e.Graphics.SmoothingMode = SmoothingMode.None;
			e.Graphics.DrawLine(new Pen(color4), graphicsPath.PathPoints[0], graphicsPath.PathPoints[graphicsPath.PointCount - 1]);
			e.Graphics.SmoothingMode = __SmoothingMode;
			DrawIcon(e.Graphics);
			DrawText(e.Graphics);
			if (__CloseButtonVisible)
			{
				DrawCloseButton(e.Graphics);
			}
			ResumeLayout();
			graphicsPath.Dispose();
			matrix.Dispose();
			matrix2.Dispose();
			matrix3.Dispose();
			region2.Dispose();
			region3.Dispose();
			region4.Dispose();
			region.Dispose();
			tabPaintEventArgs.Dispose();
			_ = 0;
		}
	}

	public void Animate(bool b)
	{
		checked
		{
			if (b)
			{
				if (tmrAnimate.Enabled)
				{
					return;
				}
				if (__Icons == null)
				{
					int num = imgAnimate.Images.Count - 1;
					__Icons = new Icon[num + 1];
					int num2 = num;
					for (int i = 0; i <= num2; i++)
					{
						using Bitmap bitmap = (Bitmap)imgAnimate.Images[i];
						__Icons[i] = Icon.FromHandle(bitmap.GetHicon());
					}
				}
				Icon = __Icons[0];
				IconVisible = true;
				tmrAnimate.Start();
			}
			else if (tmrAnimate.Enabled)
			{
				tmrAnimate.Stop();
				Icon = __Icon;
				IconVisible = true;
			}
		}
	}

	private void tmrAnimate_Tick(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				if (_0024STATIC_0024tmrAnimate_Tick_002420211C12819D_0024iTick < __Icons.Length)
				{
					Icon = __Icons[_0024STATIC_0024tmrAnimate_Tick_002420211C12819D_0024iTick];
				}
				if (_0024STATIC_0024tmrAnimate_Tick_002420211C12819D_0024iTick < __Icons.Length)
				{
					_0024STATIC_0024tmrAnimate_Tick_002420211C12819D_0024iTick++;
				}
				else
				{
					_0024STATIC_0024tmrAnimate_Tick_002420211C12819D_0024iTick = 0;
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				tmrAnimate.Stop();
				ProjectData.ClearProjectError();
			}
		}
	}
}
