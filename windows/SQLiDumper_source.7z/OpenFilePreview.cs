using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
public class OpenFilePreview : Form
{
	private IContainer icontainer_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnOK")]
	[CompilerGenerated]
	private Button _btnOK;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnCancel")]
	[CompilerGenerated]
	private Button _btnCancel;

	internal virtual Button btnOK
	{
		[CompilerGenerated]
		get
		{
			return _btnOK;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_1;
			Button button = _btnOK;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnOK = value;
			button = _btnOK;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual Button btnCancel
	{
		[CompilerGenerated]
		get
		{
			return _btnCancel;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_0;
			Button button = _btnCancel;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnCancel = value;
			button = _btnCancel;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("txtPreview")]
	internal virtual TextBox txtPreview
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label1")]
	internal virtual Label Label1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numLineIndex")]
	internal virtual NumericUpDown numLineIndex
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public OpenFilePreview()
	{
		InitializeComponent();
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.btnOK = new System.Windows.Forms.Button();
		this.btnCancel = new System.Windows.Forms.Button();
		this.txtPreview = new System.Windows.Forms.TextBox();
		this.Label1 = new System.Windows.Forms.Label();
		this.numLineIndex = new System.Windows.Forms.NumericUpDown();
		((System.ComponentModel.ISupportInitialize)this.numLineIndex).BeginInit();
		base.SuspendLayout();
		this.btnOK.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.btnOK.Location = new System.Drawing.Point(395, 413);
		this.btnOK.Margin = new System.Windows.Forms.Padding(4);
		this.btnOK.Name = "btnOK";
		this.btnOK.Size = new System.Drawing.Size(111, 30);
		this.btnOK.TabIndex = 3;
		this.btnOK.Text = "Start Worker";
		this.btnOK.UseVisualStyleBackColor = true;
		this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.btnCancel.Location = new System.Drawing.Point(281, 413);
		this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
		this.btnCancel.Name = "btnCancel";
		this.btnCancel.Size = new System.Drawing.Size(111, 30);
		this.btnCancel.TabIndex = 4;
		this.btnCancel.Text = "Cancel";
		this.btnCancel.UseVisualStyleBackColor = true;
		this.txtPreview.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtPreview.Location = new System.Drawing.Point(4, 4);
		this.txtPreview.Multiline = true;
		this.txtPreview.Name = "txtPreview";
		this.txtPreview.ReadOnly = true;
		this.txtPreview.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.txtPreview.Size = new System.Drawing.Size(502, 405);
		this.txtPreview.TabIndex = 5;
		this.txtPreview.WordWrap = false;
		this.Label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.Label1.Location = new System.Drawing.Point(131, 418);
		this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label1.Name = "Label1";
		this.Label1.Size = new System.Drawing.Size(142, 26);
		this.Label1.TabIndex = 6;
		this.Label1.Text = "Start Line Index";
		this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.numLineIndex.Location = new System.Drawing.Point(4, 419);
		this.numLineIndex.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numLineIndex.Name = "numLineIndex";
		this.numLineIndex.Size = new System.Drawing.Size(120, 26);
		this.numLineIndex.TabIndex = 7;
		this.numLineIndex.Value = new decimal(new int[4] { 1, 0, 0, 0 });
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.CancelButton = this.btnCancel;
		base.ClientSize = new System.Drawing.Size(511, 449);
		base.Controls.Add(this.numLineIndex);
		base.Controls.Add(this.Label1);
		base.Controls.Add(this.txtPreview);
		base.Controls.Add(this.btnOK);
		base.Controls.Add(this.btnCancel);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "OpenFilePreview";
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "OpenFilePreview";
		((System.ComponentModel.ISupportInitialize)this.numLineIndex).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void method_0(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.Cancel;
		Close();
	}

	private void method_1(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.OK;
		Close();
	}
}
