using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.VisualBasic.CompilerServices;

internal sealed class ThreadPool
{
	public enum ThreadStatus
	{
		Started,
		Stopped,
		Paused
	}

	private object __CountLock;

	private object __PushLock;

	private bool __AllPushed;

	private int __MaxThreadCount;

	private ThreadStatus __Status;

	private List<Thread> __ActiveThreads;

	public int ThreadCount
	{
		get
		{
			int try0001_dispatch = -1;
			int num2 = default(int);
			int num = default(int);
			int num3 = default(int);
			Thread current = default(Thread);
			List<Thread>.Enumerator enumerator = default(List<Thread>.Enumerator);
			int count = default(int);
			while (true)
			{
				try
				{
					/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
					switch (try0001_dispatch)
					{
					default:
						goto IL_003e;
					case 166:
						{
							num2 = num;
							switch ((num3 <= -2) ? 1 : num3)
							{
							case 1:
								break;
							default:
								goto end_IL_0001;
							}
							int num4 = num2 + 1;
							num2 = 0;
							switch (num4)
							{
							case 2:
								break;
							case 3:
								goto IL_0023;
							case 6:
							case 7:
								goto IL_0031;
							case 4:
								goto IL_0035;
							case 1:
							case 5:
								goto IL_003e;
							case 8:
								goto IL_0048;
							case 9:
								goto end_IL_0001_2;
							default:
								goto end_IL_0001;
							case 10:
								goto end_IL_0001_3;
							}
							goto IL_0004;
						}
						IL_0023:
						num = 3;
						if (current.ThreadState != ThreadState.Stopped)
						{
							goto IL_0031;
						}
						goto IL_0035;
						IL_0031:
						num = 7;
						goto IL_0012;
						IL_0048:
						num = 8;
						((IDisposable)enumerator).Dispose();
						break;
						IL_0035:
						num = 4;
						Close(current);
						goto IL_003e;
						IL_003e:
						ProjectData.ClearProjectError();
						num3 = -2;
						goto IL_0004;
						IL_0004:
						num = 2;
						enumerator = __ActiveThreads.GetEnumerator();
						goto IL_0012;
						IL_0012:
						if (enumerator.MoveNext())
						{
							current = enumerator.Current;
							goto IL_0023;
						}
						goto IL_0048;
						end_IL_0001_2:
						break;
					}
					num = 9;
					count = __ActiveThreads.Count;
					break;
					end_IL_0001:;
				}
				catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
				{
					ProjectData.SetProjectError((Exception)obj);
					try0001_dispatch = 166;
					continue;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				continue;
				end_IL_0001_3:
				break;
			}
			if (num2 != 0)
			{
				ProjectData.ClearProjectError();
			}
			return count;
		}
	}

	public int MaxThreadCount
	{
		get
		{
			return __MaxThreadCount;
		}
		set
		{
			__MaxThreadCount = value;
		}
	}

	public bool Finished => AllPushed && ThreadCount <= 0;

	public ThreadStatus Status
	{
		get
		{
			return __Status;
		}
		set
		{
			__Status = value;
		}
	}

	private bool AllPushed
	{
		get
		{
			object _PushLock = __PushLock;
			ObjectFlowControl.CheckForSyncLockOnValueType(_PushLock);
			bool lockTaken = false;
			try
			{
				Monitor.Enter(_PushLock, ref lockTaken);
				return __AllPushed | (Status == ThreadStatus.Stopped);
			}
			finally
			{
				if (lockTaken)
				{
					Monitor.Exit(_PushLock);
				}
			}
		}
	}

	public bool Paused
	{
		get
		{
			if (!Finished)
			{
				return __Status == ThreadStatus.Paused;
			}
			return false;
		}
		set
		{
			if (!Finished)
			{
				if (value)
				{
					__Status = ThreadStatus.Paused;
				}
				else
				{
					__Status = ThreadStatus.Started;
				}
			}
		}
	}

	public ThreadPool(int maxThreadCount)
	{
		__CountLock = RuntimeHelpers.GetObjectValue(new object());
		__PushLock = RuntimeHelpers.GetObjectValue(new object());
		MaxThreadCount = maxThreadCount;
		__ActiveThreads = new List<Thread>(MaxThreadCount);
	}

	public void Open(Thread thread = null)
	{
		if (thread != null)
		{
			__ActiveThreads.Add(thread);
		}
	}

	public void AllJobsPushed()
	{
		object _PushLock = __PushLock;
		ObjectFlowControl.CheckForSyncLockOnValueType(_PushLock);
		bool lockTaken = false;
		try
		{
			Monitor.Enter(_PushLock, ref lockTaken);
			__AllPushed = true;
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(_PushLock);
			}
		}
	}

	public void Close(Thread thread = null)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 90:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_001a;
						case 4:
						case 5:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 6:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					if (!__ActiveThreads.Contains(thread))
					{
						break;
					}
					goto IL_001a;
					IL_001a:
					num = 3;
					__ActiveThreads.Remove(thread);
					break;
					end_IL_0001_2:
					break;
				}
				num = 5;
				thread = null;
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 90;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	public void WaitForThreads()
	{
		while ((ThreadCount >= MaxThreadCount || Status == ThreadStatus.Paused) && Status != ThreadStatus.Stopped)
		{
			Thread.Sleep(200);
		}
	}

	public void AbortThreads()
	{
		object _PushLock = __PushLock;
		ObjectFlowControl.CheckForSyncLockOnValueType(_PushLock);
		bool lockTaken = false;
		try
		{
			Monitor.Enter(_PushLock, ref lockTaken);
			__AllPushed = true;
			Status = ThreadStatus.Stopped;
			__ActiveThreads.Clear();
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(_PushLock);
			}
		}
	}
}
