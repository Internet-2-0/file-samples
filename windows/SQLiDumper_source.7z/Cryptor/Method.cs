namespace Cryptor;

public enum Method : byte
{
	RijnDael,
	RC4,
	MD5,
	const_3
}
