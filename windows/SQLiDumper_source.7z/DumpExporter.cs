using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Web;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class DumpExporter : Form
{
	public enum enFileTytpe
	{
		const_0,
		HTML,
		const_2
	}

	private delegate DataGridViewRow Delegate35(int Index);

	private delegate int Delegate36();

	private IContainer icontainer_0;

	[AccessedThroughProperty("OK_Button")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _OK_Button;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("Cancel_Button")]
	[CompilerGenerated]
	private Button _Cancel_Button;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("rdbOpt1")]
	[CompilerGenerated]
	private RadioButton _rdbOpt1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("bwSave")]
	[CompilerGenerated]
	private BackgroundWorker backgroundWorker_0;

	[AccessedThroughProperty("lsColumns")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private CheckedListBox _lsColumns;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuColumns")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ContextMenuStrip _mnuColumns;

	[AccessedThroughProperty("mmnCheck")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mmnCheck;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mmnUnCheck")]
	[CompilerGenerated]
	private ToolStripMenuItem _mmnUnCheck;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("chkReplaceLines")]
	private CheckBox _chkReplaceLines;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuMoveUP")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuMoveUP;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuMoveDown")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuMoveDown;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("rdpType_2")]
	[CompilerGenerated]
	private RadioButton _rdpType_2;

	[AccessedThroughProperty("rdpType_1")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private RadioButton _rdpType_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("rdpType_3")]
	[CompilerGenerated]
	private RadioButton _rdpType_3;

	private DataGridView dataGridView_0;

	private string string_0;

	private string string_1;

	private static string string_2;

	private static string string_3;

	private static int int_0;

	private string string_4;

	private bool bool_0;

	private Dictionary<string, int> dictionary_0;

	private bool bool_1;

	private string string_5;

	private string string_6;

	private enFileTytpe enFileTytpe_0;

	private Dumper dumper_0;

	internal virtual Button OK_Button
	{
		[CompilerGenerated]
		get
		{
			return _OK_Button;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_6;
			Button oK_Button = _OK_Button;
			if (oK_Button != null)
			{
				oK_Button.Click -= value2;
			}
			_OK_Button = value;
			oK_Button = _OK_Button;
			if (oK_Button != null)
			{
				oK_Button.Click += value2;
			}
		}
	}

	internal virtual Button Cancel_Button
	{
		[CompilerGenerated]
		get
		{
			return _Cancel_Button;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_7;
			Button cancel_Button = _Cancel_Button;
			if (cancel_Button != null)
			{
				cancel_Button.Click -= value2;
			}
			_Cancel_Button = value;
			cancel_Button = _Cancel_Button;
			if (cancel_Button != null)
			{
				cancel_Button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("grbDelimiter")]
	internal virtual GroupBox grbDelimiter
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual RadioButton rdbOpt1
	{
		[CompilerGenerated]
		get
		{
			return _rdbOpt1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_8;
			EventHandler value3 = method_8;
			RadioButton radioButton = _rdbOpt1;
			if (radioButton != null)
			{
				radioButton.CheckedChanged -= value2;
				radioButton.CheckedChanged -= value3;
			}
			_rdbOpt1 = value;
			radioButton = _rdbOpt1;
			if (radioButton != null)
			{
				radioButton.CheckedChanged += value2;
				radioButton.CheckedChanged += value3;
			}
		}
	}

	[field: AccessedThroughProperty("rdbOpt2")]
	internal virtual RadioButton rdbOpt2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtDeli")]
	internal virtual TextBox txtDeli
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("stsMain")]
	internal virtual StatusStrip stsMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblStatus")]
	internal virtual ToolStripStatusLabel lblStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("prbStatus")]
	internal virtual ProgressBar prbStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual BackgroundWorker bwSave
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler value2 = method_2;
			ProgressChangedEventHandler value3 = method_3;
			RunWorkerCompletedEventHandler value4 = method_4;
			BackgroundWorker backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork -= value2;
				backgroundWorker.ProgressChanged -= value3;
				backgroundWorker.RunWorkerCompleted -= value4;
			}
			backgroundWorker_0 = value;
			backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork += value2;
				backgroundWorker.ProgressChanged += value3;
				backgroundWorker.RunWorkerCompleted += value4;
			}
		}
	}

	[field: AccessedThroughProperty("grbColumns")]
	internal virtual GroupBox grbColumns
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckedListBox lsColumns
	{
		[CompilerGenerated]
		get
		{
			return _lsColumns;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			ItemCheckEventHandler value2 = method_14;
			CheckedListBox checkedListBox = _lsColumns;
			if (checkedListBox != null)
			{
				checkedListBox.ItemCheck -= value2;
			}
			_lsColumns = value;
			checkedListBox = _lsColumns;
			if (checkedListBox != null)
			{
				checkedListBox.ItemCheck += value2;
			}
		}
	}

	internal virtual ContextMenuStrip mnuColumns
	{
		[CompilerGenerated]
		get
		{
			return _mnuColumns;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_11;
			ContextMenuStrip contextMenuStrip = _mnuColumns;
			if (contextMenuStrip != null)
			{
				contextMenuStrip.Opening -= value2;
			}
			_mnuColumns = value;
			contextMenuStrip = _mnuColumns;
			if (contextMenuStrip != null)
			{
				contextMenuStrip.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mmnCheck
	{
		[CompilerGenerated]
		get
		{
			return _mmnCheck;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_9;
			ToolStripMenuItem toolStripMenuItem = _mmnCheck;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mmnCheck = value;
			toolStripMenuItem = _mmnCheck;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mmnUnCheck
	{
		[CompilerGenerated]
		get
		{
			return _mmnUnCheck;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_9;
			ToolStripMenuItem toolStripMenuItem = _mmnUnCheck;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mmnUnCheck = value;
			toolStripMenuItem = _mmnUnCheck;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("txtReplaceLine")]
	internal virtual TextBox txtReplaceLine
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckBox chkReplaceLines
	{
		[CompilerGenerated]
		get
		{
			return _chkReplaceLines;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_10;
			CheckBox checkBox = _chkReplaceLines;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkReplaceLines = value;
			checkBox = _chkReplaceLines;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuMoveUP
	{
		[CompilerGenerated]
		get
		{
			return _mnuMoveUP;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_12;
			ToolStripMenuItem toolStripMenuItem = _mnuMoveUP;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuMoveUP = value;
			toolStripMenuItem = _mnuMoveUP;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuMoveDown
	{
		[CompilerGenerated]
		get
		{
			return _mnuMoveDown;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_12;
			ToolStripMenuItem toolStripMenuItem = _mnuMoveDown;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuMoveDown = value;
			toolStripMenuItem = _mnuMoveDown;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator1")]
	internal virtual ToolStripSeparator ToolStripSeparator1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbType")]
	internal virtual GroupBox grbType
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual RadioButton rdpType_2
	{
		[CompilerGenerated]
		get
		{
			return _rdpType_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_13;
			RadioButton radioButton = _rdpType_2;
			if (radioButton != null)
			{
				radioButton.CheckedChanged -= value2;
			}
			_rdpType_2 = value;
			radioButton = _rdpType_2;
			if (radioButton != null)
			{
				radioButton.CheckedChanged += value2;
			}
		}
	}

	internal virtual RadioButton rdpType_1
	{
		[CompilerGenerated]
		get
		{
			return _rdpType_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_13;
			RadioButton radioButton = _rdpType_1;
			if (radioButton != null)
			{
				radioButton.CheckedChanged -= value2;
			}
			_rdpType_1 = value;
			radioButton = _rdpType_1;
			if (radioButton != null)
			{
				radioButton.CheckedChanged += value2;
			}
		}
	}

	internal virtual RadioButton rdpType_3
	{
		[CompilerGenerated]
		get
		{
			return _rdpType_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_13;
			RadioButton radioButton = _rdpType_3;
			if (radioButton != null)
			{
				radioButton.CheckedChanged -= value2;
			}
			_rdpType_3 = value;
			radioButton = _rdpType_3;
			if (radioButton != null)
			{
				radioButton.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("Panel1")]
	internal virtual Panel Panel1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public DumpExporter(DataGridView g, string dFileName, string sURL, Dumper o)
	{
		base.FormClosing += DumpExporter_FormClosing;
		base.Load += DumpExporter_Load;
		InitializeComponent();
		dataGridView_0 = g;
		string_0 = dFileName;
		string_1 = sURL;
		dumper_0 = o;
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new System.ComponentModel.Container();
		this.OK_Button = new System.Windows.Forms.Button();
		this.Cancel_Button = new System.Windows.Forms.Button();
		this.grbDelimiter = new System.Windows.Forms.GroupBox();
		this.chkReplaceLines = new System.Windows.Forms.CheckBox();
		this.txtDeli = new System.Windows.Forms.TextBox();
		this.txtReplaceLine = new System.Windows.Forms.TextBox();
		this.rdbOpt2 = new System.Windows.Forms.RadioButton();
		this.rdbOpt1 = new System.Windows.Forms.RadioButton();
		this.stsMain = new System.Windows.Forms.StatusStrip();
		this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
		this.bwSave = new System.ComponentModel.BackgroundWorker();
		this.grbColumns = new System.Windows.Forms.GroupBox();
		this.lsColumns = new System.Windows.Forms.CheckedListBox();
		this.mnuColumns = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuMoveUP = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuMoveDown = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
		this.mmnCheck = new System.Windows.Forms.ToolStripMenuItem();
		this.mmnUnCheck = new System.Windows.Forms.ToolStripMenuItem();
		this.grbType = new System.Windows.Forms.GroupBox();
		this.rdpType_3 = new System.Windows.Forms.RadioButton();
		this.rdpType_2 = new System.Windows.Forms.RadioButton();
		this.rdpType_1 = new System.Windows.Forms.RadioButton();
		this.Panel1 = new System.Windows.Forms.Panel();
		this.prbStatus = new System.Windows.Forms.ProgressBar();
		this.grbDelimiter.SuspendLayout();
		this.stsMain.SuspendLayout();
		this.grbColumns.SuspendLayout();
		this.mnuColumns.SuspendLayout();
		this.grbType.SuspendLayout();
		this.Panel1.SuspendLayout();
		base.SuspendLayout();
		this.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.OK_Button.Location = new System.Drawing.Point(203, 9);
		this.OK_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.OK_Button.Name = "OK_Button";
		this.OK_Button.Size = new System.Drawing.Size(100, 30);
		this.OK_Button.TabIndex = 3;
		this.OK_Button.Text = "OK";
		this.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.Cancel_Button.Location = new System.Drawing.Point(203, 45);
		this.Cancel_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.Cancel_Button.Name = "Cancel_Button";
		this.Cancel_Button.Size = new System.Drawing.Size(100, 30);
		this.Cancel_Button.TabIndex = 4;
		this.Cancel_Button.Text = "Exit";
		this.grbDelimiter.Controls.Add(this.chkReplaceLines);
		this.grbDelimiter.Controls.Add(this.txtDeli);
		this.grbDelimiter.Controls.Add(this.txtReplaceLine);
		this.grbDelimiter.Controls.Add(this.rdbOpt2);
		this.grbDelimiter.Controls.Add(this.rdbOpt1);
		this.grbDelimiter.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbDelimiter.Location = new System.Drawing.Point(0, 66);
		this.grbDelimiter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbDelimiter.Name = "grbDelimiter";
		this.grbDelimiter.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbDelimiter.Size = new System.Drawing.Size(309, 140);
		this.grbDelimiter.TabIndex = 0;
		this.grbDelimiter.TabStop = false;
		this.grbDelimiter.Text = "Delimiter";
		this.chkReplaceLines.AutoSize = true;
		this.chkReplaceLines.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkReplaceLines.Checked = true;
		this.chkReplaceLines.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkReplaceLines.Location = new System.Drawing.Point(9, 105);
		this.chkReplaceLines.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkReplaceLines.Name = "chkReplaceLines";
		this.chkReplaceLines.Size = new System.Drawing.Size(136, 24);
		this.chkReplaceLines.TabIndex = 3;
		this.chkReplaceLines.Text = "Replace Lines";
		this.chkReplaceLines.UseVisualStyleBackColor = true;
		this.txtDeli.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtDeli.Enabled = false;
		this.txtDeli.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.txtDeli.Location = new System.Drawing.Point(159, 60);
		this.txtDeli.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtDeli.Name = "txtDeli";
		this.txtDeli.Size = new System.Drawing.Size(146, 26);
		this.txtDeli.TabIndex = 2;
		this.txtDeli.Text = ":";
		this.txtReplaceLine.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtReplaceLine.Enabled = false;
		this.txtReplaceLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.txtReplaceLine.Location = new System.Drawing.Point(159, 100);
		this.txtReplaceLine.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtReplaceLine.Name = "txtReplaceLine";
		this.txtReplaceLine.Size = new System.Drawing.Size(144, 26);
		this.txtReplaceLine.TabIndex = 2;
		this.txtReplaceLine.Text = "{NewLine}";
		this.rdbOpt2.AutoSize = true;
		this.rdbOpt2.Location = new System.Drawing.Point(9, 65);
		this.rdbOpt2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdbOpt2.Name = "rdbOpt2";
		this.rdbOpt2.Size = new System.Drawing.Size(89, 24);
		this.rdbOpt2.TabIndex = 1;
		this.rdbOpt2.Text = "Custom";
		this.rdbOpt2.UseVisualStyleBackColor = true;
		this.rdbOpt1.AutoSize = true;
		this.rdbOpt1.Checked = true;
		this.rdbOpt1.Location = new System.Drawing.Point(9, 29);
		this.rdbOpt1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdbOpt1.Name = "rdbOpt1";
		this.rdbOpt1.Size = new System.Drawing.Size(99, 24);
		this.rdbOpt1.TabIndex = 0;
		this.rdbOpt1.TabStop = true;
		this.rdbOpt1.Text = "Char Tab";
		this.rdbOpt1.UseVisualStyleBackColor = true;
		this.stsMain.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.stsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.lblStatus });
		this.stsMain.Location = new System.Drawing.Point(0, 477);
		this.stsMain.Name = "stsMain";
		this.stsMain.Padding = new System.Windows.Forms.Padding(2, 0, 21, 0);
		this.stsMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
		this.stsMain.Size = new System.Drawing.Size(309, 30);
		this.stsMain.TabIndex = 3;
		this.stsMain.Text = "StatusStrip1";
		this.lblStatus.AutoToolTip = true;
		this.lblStatus.Name = "lblStatus";
		this.lblStatus.Size = new System.Drawing.Size(286, 25);
		this.lblStatus.Spring = true;
		this.lblStatus.Text = "Ready";
		this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.bwSave.WorkerReportsProgress = true;
		this.bwSave.WorkerSupportsCancellation = true;
		this.grbColumns.Controls.Add(this.lsColumns);
		this.grbColumns.Dock = System.Windows.Forms.DockStyle.Fill;
		this.grbColumns.Location = new System.Drawing.Point(0, 206);
		this.grbColumns.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbColumns.Name = "grbColumns";
		this.grbColumns.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbColumns.Size = new System.Drawing.Size(309, 188);
		this.grbColumns.TabIndex = 1;
		this.grbColumns.TabStop = false;
		this.grbColumns.Text = "Columns";
		this.lsColumns.ContextMenuStrip = this.mnuColumns;
		this.lsColumns.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lsColumns.FormattingEnabled = true;
		this.lsColumns.Location = new System.Drawing.Point(4, 24);
		this.lsColumns.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.lsColumns.Name = "lsColumns";
		this.lsColumns.Size = new System.Drawing.Size(301, 159);
		this.lsColumns.TabIndex = 0;
		this.mnuColumns.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuColumns.Items.AddRange(new System.Windows.Forms.ToolStripItem[5] { this.mnuMoveUP, this.mnuMoveDown, this.ToolStripSeparator1, this.mmnCheck, this.mmnUnCheck });
		this.mnuColumns.Name = "mnuColumns";
		this.mnuColumns.ShowImageMargin = false;
		this.mnuColumns.Size = new System.Drawing.Size(157, 130);
		this.mnuMoveUP.Name = "mnuMoveUP";
		this.mnuMoveUP.Size = new System.Drawing.Size(156, 30);
		this.mnuMoveUP.Text = "Move UP";
		this.mnuMoveDown.Name = "mnuMoveDown";
		this.mnuMoveDown.Size = new System.Drawing.Size(156, 30);
		this.mnuMoveDown.Text = "Move Down";
		this.ToolStripSeparator1.Name = "ToolStripSeparator1";
		this.ToolStripSeparator1.Size = new System.Drawing.Size(153, 6);
		this.mmnCheck.Name = "mmnCheck";
		this.mmnCheck.Size = new System.Drawing.Size(156, 30);
		this.mmnCheck.Text = "Check All";
		this.mmnUnCheck.Name = "mmnUnCheck";
		this.mmnUnCheck.Size = new System.Drawing.Size(156, 30);
		this.mmnUnCheck.Text = "UnCheck All";
		this.grbType.Controls.Add(this.rdpType_3);
		this.grbType.Controls.Add(this.rdpType_2);
		this.grbType.Controls.Add(this.rdpType_1);
		this.grbType.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbType.Location = new System.Drawing.Point(0, 0);
		this.grbType.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbType.Name = "grbType";
		this.grbType.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbType.Size = new System.Drawing.Size(309, 66);
		this.grbType.TabIndex = 6;
		this.grbType.TabStop = false;
		this.grbType.Text = "File Type";
		this.rdpType_3.AutoSize = true;
		this.rdpType_3.Location = new System.Drawing.Point(220, 29);
		this.rdpType_3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdpType_3.Name = "rdpType_3";
		this.rdpType_3.Size = new System.Drawing.Size(67, 24);
		this.rdpType_3.TabIndex = 2;
		this.rdpType_3.Text = "XML";
		this.rdpType_3.UseVisualStyleBackColor = true;
		this.rdpType_2.AutoSize = true;
		this.rdpType_2.Location = new System.Drawing.Point(125, 29);
		this.rdpType_2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdpType_2.Name = "rdpType_2";
		this.rdpType_2.Size = new System.Drawing.Size(77, 24);
		this.rdpType_2.TabIndex = 1;
		this.rdpType_2.Text = "HTML";
		this.rdpType_2.UseVisualStyleBackColor = true;
		this.rdpType_1.AutoSize = true;
		this.rdpType_1.Checked = true;
		this.rdpType_1.Location = new System.Drawing.Point(9, 29);
		this.rdpType_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdpType_1.Name = "rdpType_1";
		this.rdpType_1.Size = new System.Drawing.Size(98, 24);
		this.rdpType_1.TabIndex = 0;
		this.rdpType_1.TabStop = true;
		this.rdpType_1.Text = "PlainText";
		this.rdpType_1.UseVisualStyleBackColor = true;
		this.Panel1.Controls.Add(this.prbStatus);
		this.Panel1.Controls.Add(this.OK_Button);
		this.Panel1.Controls.Add(this.Cancel_Button);
		this.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
		this.Panel1.Location = new System.Drawing.Point(0, 394);
		this.Panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.Panel1.Name = "Panel1";
		this.Panel1.Size = new System.Drawing.Size(309, 83);
		this.Panel1.TabIndex = 7;
		this.prbStatus.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.prbStatus.Location = new System.Drawing.Point(4, 9);
		this.prbStatus.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.prbStatus.Name = "prbStatus";
		this.prbStatus.Size = new System.Drawing.Size(191, 66);
		this.prbStatus.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
		this.prbStatus.TabIndex = 4;
		this.prbStatus.Visible = false;
		base.AcceptButton = this.OK_Button;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.CancelButton = this.Cancel_Button;
		base.ClientSize = new System.Drawing.Size(309, 507);
		base.ControlBox = false;
		base.Controls.Add(this.grbColumns);
		base.Controls.Add(this.Panel1);
		base.Controls.Add(this.stsMain);
		base.Controls.Add(this.grbDelimiter);
		base.Controls.Add(this.grbType);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
		base.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		this.MinimumSize = new System.Drawing.Size(300, 478);
		base.Name = "DumpExporter";
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Data Exporter";
		this.grbDelimiter.ResumeLayout(false);
		this.grbDelimiter.PerformLayout();
		this.stsMain.ResumeLayout(false);
		this.stsMain.PerformLayout();
		this.grbColumns.ResumeLayout(false);
		this.mnuColumns.ResumeLayout(false);
		this.grbType.ResumeLayout(false);
		this.grbType.PerformLayout();
		this.Panel1.ResumeLayout(false);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private DataGridViewRow method_0(int int_1)
	{
		if (dataGridView_0.InvokeRequired)
		{
			return (DataGridViewRow)dataGridView_0.Invoke(new Delegate35(method_0), int_1);
		}
		return dataGridView_0.Rows[int_1];
	}

	private int method_1()
	{
		if (dataGridView_0.InvokeRequired)
		{
			return Conversions.ToInteger(dataGridView_0.Invoke(new Delegate36(method_1)));
		}
		return dataGridView_0.RowCount;
	}

	private void method_2(object sender, DoWorkEventArgs e)
	{
		StreamWriter streamWriter = null;
		checked
		{
			try
			{
				bool_0 = true;
				streamWriter = new StreamWriter(string_0, append: false, Encoding.Unicode);
				bool flag = default(bool);
				foreach (KeyValuePair<string, int> item in dictionary_0)
				{
					switch (enFileTytpe_0)
					{
					case enFileTytpe.const_0:
						if (flag)
						{
							streamWriter.Write(string_6 + item.Key);
							break;
						}
						streamWriter.Write(DateAndTime.Now.ToString());
						streamWriter.WriteLine();
						streamWriter.Write(Globals.APP_VERSION);
						streamWriter.WriteLine();
						streamWriter.Write(string_1);
						streamWriter.WriteLine();
						streamWriter.WriteLine();
						streamWriter.Write(item.Key);
						break;
					case enFileTytpe.HTML:
						if (!flag)
						{
							streamWriter.WriteLine("<html>");
							streamWriter.WriteLine("<title>" + HttpUtility.HtmlEncode(string_1) + "</title>");
							streamWriter.WriteLine("<body>");
							streamWriter.WriteLine("<table border>");
							streamWriter.WriteLine("<tr>");
						}
						streamWriter.WriteLine("<td>" + HttpUtility.HtmlEncode(item.Key) + "</td>");
						break;
					case enFileTytpe.const_2:
						if (!flag)
						{
							streamWriter.WriteLine("<DocumentElement>");
							streamWriter.WriteLine("<URL>" + HttpUtility.HtmlEncode(string_1) + "</URL>");
						}
						break;
					}
					flag = true;
				}
				switch (enFileTytpe_0)
				{
				case enFileTytpe.const_0:
					streamWriter.WriteLine();
					break;
				case enFileTytpe.HTML:
					streamWriter.WriteLine("</tr>");
					break;
				}
				int num = default(int);
				while (true)
				{
					int percentProgress = (int)Math.Round(Math.Round((double)((num + 1) * 100) / (double)method_1()));
					bwSave.ReportProgress(percentProgress, "Rows " + Strings.FormatNumber(num, 0) + " of " + Strings.FormatNumber(method_1(), 0));
					if (bwSave.CancellationPending)
					{
						break;
					}
					DataGridViewRow dataGridViewRow = method_0(num);
					flag = false;
					foreach (KeyValuePair<string, int> item2 in dictionary_0)
					{
						string text = Conversions.ToString(dataGridViewRow.Cells[item2.Value].Value);
						if (enFileTytpe_0 == enFileTytpe.const_0 && bool_1)
						{
							if (text.IndexOf("\n") > 0)
							{
								text = text.Replace("\n", string_5);
							}
							if (text.IndexOf("\v\n") > 0)
							{
								text = text.Replace("\v\n", string_5);
							}
							if (text.IndexOf("\r") > 0)
							{
								text = text.Replace("\r", string_5);
							}
							if (text.IndexOf("\r\n") > 0)
							{
								text = text.Replace("\r\n", string_5);
							}
						}
						switch (enFileTytpe_0)
						{
						case enFileTytpe.const_0:
							if (flag)
							{
								streamWriter.Write(string_6 + text);
							}
							else
							{
								streamWriter.Write(text);
							}
							break;
						case enFileTytpe.HTML:
							if (!flag)
							{
								streamWriter.WriteLine("<tr>");
							}
							streamWriter.WriteLine("<td>" + HttpUtility.HtmlEncode(text) + "</td>");
							break;
						case enFileTytpe.const_2:
						{
							if (!flag)
							{
								streamWriter.WriteLine("<item>");
							}
							string text2 = HttpUtility.HtmlEncode(item2.Key);
							streamWriter.WriteLine("<" + text2 + ">" + HttpUtility.HtmlEncode(text) + "</" + text2 + ">");
							break;
						}
						}
						flag = true;
					}
					switch (enFileTytpe_0)
					{
					case enFileTytpe.const_0:
						streamWriter.WriteLine();
						break;
					case enFileTytpe.HTML:
						streamWriter.WriteLine("</tr>");
						break;
					case enFileTytpe.const_2:
						streamWriter.WriteLine("</item>");
						break;
					}
					num++;
					if (dumper_0.Boolean_0)
					{
						if (num >= method_1() - 1)
						{
							do
							{
								bwSave.ReportProgress(percentProgress, "Waiting.. Rows " + Strings.FormatNumber(num, 0) + " of " + Strings.FormatNumber(method_1(), 0));
								Thread.Sleep(200);
							}
							while (dumper_0.Boolean_0 && method_1() - 1 - num <= 20 && !bwSave.CancellationPending);
						}
					}
					else if (num >= method_1() - 1)
					{
						break;
					}
				}
				switch (enFileTytpe_0)
				{
				case enFileTytpe.HTML:
					streamWriter.WriteLine("</body>");
					streamWriter.WriteLine("</html>");
					break;
				case enFileTytpe.const_2:
					streamWriter.WriteLine("</DocumentElement>");
					break;
				}
				if (num == method_1() - 1)
				{
					e.Result = "Saved " + Strings.FormatNumber(method_1(), 0) + " rows.";
					return;
				}
				e.Result = "Saved " + Strings.FormatNumber(method_1(), 0) + " rows, missed " + Conversions.ToString(method_1() - 1 - num) + ".";
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				ProjectData.ClearProjectError();
			}
			finally
			{
				if (bwSave.CancellationPending)
				{
					e.Result = "Canceled by user";
				}
				streamWriter?.Close();
			}
		}
	}

	private void method_3(object sender, ProgressChangedEventArgs e)
	{
		if (e.ProgressPercentage < 100)
		{
			prbStatus.Value = e.ProgressPercentage;
		}
		lblStatus.Text = e.UserState.ToString();
	}

	private void method_4(object sender, RunWorkerCompletedEventArgs e)
	{
		prbStatus.Value = 0;
		prbStatus.Visible = false;
		if (e.Result == null)
		{
			lblStatus.Text = "Ready.";
		}
		else
		{
			lblStatus.Text = e.Result.ToString();
		}
		OK_Button.Enabled = true;
		OK_Button.Text = "&Start..";
		Cancel_Button.Enabled = true;
		grbDelimiter.Enabled = true;
		grbColumns.Enabled = true;
		method_13(null, null);
		bool_0 = false;
	}

	private int method_5(string string_7)
	{
		checked
		{
			int num = dataGridView_0.ColumnCount - 1;
			int num2 = 1;
			while (true)
			{
				if (num2 <= num)
				{
					if (string_7.Equals(dataGridView_0.Columns[num2].HeaderText))
					{
						break;
					}
					num2++;
					continue;
				}
				return -1;
			}
			return num2;
		}
	}

	private void method_6(object sender, EventArgs e)
	{
		checked
		{
			if (OK_Button.Text.Equals("&Start.."))
			{
				dictionary_0 = new Dictionary<string, int>();
				int num = lsColumns.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					string text = Conversions.ToString(lsColumns.Items[i]);
					if (lsColumns.GetItemChecked(i))
					{
						dictionary_0.Add(text, method_5(text));
					}
				}
				if (dictionary_0.Count != 0)
				{
					if (rdbOpt1.Checked)
					{
						string_6 = "\t";
					}
					else
					{
						string_6 = txtDeli.Text;
					}
					bool_1 = chkReplaceLines.Checked;
					string_5 = txtReplaceLine.Text;
					using SaveFileDialog saveFileDialog = new SaveFileDialog();
					saveFileDialog.Title = "Save as..";
					saveFileDialog.FileName = string_0.Replace("/", "-");
					saveFileDialog.InitialDirectory = string_4;
					bool flag;
					if ((flag = true) == rdpType_1.Checked)
					{
						enFileTytpe_0 = enFileTytpe.const_0;
						saveFileDialog.Filter = "Text File|*.txt";
						saveFileDialog.FileName = Path.ChangeExtension(saveFileDialog.FileName, "txt");
					}
					else if (flag == rdpType_2.Checked)
					{
						enFileTytpe_0 = enFileTytpe.HTML;
						saveFileDialog.Filter = "HTML File|*.html";
						saveFileDialog.FileName = Path.ChangeExtension(saveFileDialog.FileName, "html");
					}
					else if (flag == rdpType_3.Checked)
					{
						enFileTytpe_0 = enFileTytpe.const_2;
						saveFileDialog.Filter = "XML File|*.xml";
						saveFileDialog.FileName = Path.ChangeExtension(saveFileDialog.FileName, "xml");
					}
					if (saveFileDialog.ShowDialog() == DialogResult.OK)
					{
						string_0 = saveFileDialog.FileName;
						saveFileDialog.InitialDirectory = string_4;
						bwSave.RunWorkerAsync();
						OK_Button.Text = "&Cancel..";
						prbStatus.Visible = true;
						Cancel_Button.Enabled = false;
						grbDelimiter.Enabled = false;
						grbColumns.Enabled = false;
					}
					return;
				}
				Interaction.Beep();
				lblStatus.Text = "Selected the column(s).";
			}
			else
			{
				OK_Button.Enabled = false;
				bwSave.CancelAsync();
			}
		}
	}

	private void method_7(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.Cancel;
		Close();
	}

	private void method_8(object sender, EventArgs e)
	{
		txtDeli.Enabled = rdbOpt2.Checked;
	}

	private void DumpExporter_FormClosing(object sender, FormClosingEventArgs e)
	{
		try
		{
			Class50.smethod_4(base.Name, "LastPath", string_4);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void DumpExporter_Load(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				OK_Button.Text = "&Start..";
				int num = dataGridView_0.ColumnCount - 1;
				for (int i = 1; i <= num; i++)
				{
					lsColumns.Items.Add(dataGridView_0.Columns[i].HeaderText);
					lsColumns.SetItemChecked(i - 1, value: true);
				}
				Globals.AddMouseMoveForm(this);
				Class50.smethod_2(this);
				string_4 = Class50.smethod_5(base.Name, "LastPath", "");
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_9(object sender, EventArgs e)
	{
		checked
		{
			int num = lsColumns.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				bool flag;
				if ((flag = true) == (sender == mmnCheck))
				{
					lsColumns.SetItemChecked(i, value: true);
				}
				else if (flag == (sender == mmnUnCheck))
				{
					lsColumns.SetItemChecked(i, value: false);
				}
			}
		}
	}

	private void method_10(object sender, EventArgs e)
	{
		txtReplaceLine.Enabled = chkReplaceLines.Checked;
	}

	private void method_11(object sender, CancelEventArgs e)
	{
		e.Cancel = bool_0;
		if (lsColumns.SelectedIndex < 0)
		{
			mnuMoveUP.Enabled = false;
			mnuMoveDown.Enabled = false;
		}
		else
		{
			mnuMoveUP.Enabled = lsColumns.SelectedIndex > 0;
			mnuMoveDown.Enabled = lsColumns.SelectedIndex < checked(lsColumns.Items.Count - 1);
		}
	}

	private void method_12(object sender, EventArgs e)
	{
		bool itemChecked = lsColumns.GetItemChecked(lsColumns.SelectedIndex);
		checked
		{
			if (sender == mnuMoveUP)
			{
				if (lsColumns.SelectedIndex > 0)
				{
					int num = lsColumns.SelectedIndex - 1;
					lsColumns.Items.Insert(num, RuntimeHelpers.GetObjectValue(lsColumns.SelectedItem));
					lsColumns.Items.RemoveAt(lsColumns.SelectedIndex);
					lsColumns.SelectedIndex = num;
				}
			}
			else if (lsColumns.SelectedIndex < lsColumns.Items.Count - 1)
			{
				int num2 = lsColumns.SelectedIndex + 2;
				lsColumns.Items.Insert(num2, RuntimeHelpers.GetObjectValue(lsColumns.SelectedItem));
				lsColumns.Items.RemoveAt(lsColumns.SelectedIndex);
				lsColumns.SelectedIndex = num2 - 1;
			}
			lsColumns.SetItemChecked(lsColumns.SelectedIndex, itemChecked);
		}
	}

	private void method_13(object sender, EventArgs e)
	{
		Globals.LockWindowUpdate(base.Handle);
		chkReplaceLines.Enabled = rdpType_1.Checked;
		txtReplaceLine.Enabled = rdpType_1.Checked;
		grbDelimiter.Visible = rdpType_1.Checked;
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	private void method_14(object sender, ItemCheckEventArgs e)
	{
		_ = 0;
	}
}
