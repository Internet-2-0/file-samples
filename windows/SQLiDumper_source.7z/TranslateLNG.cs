using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class TranslateLNG : Form
{
	private IContainer icontainer_0;

	private Class51 class51_0;

	[field: AccessedThroughProperty("tsChecked")]
	internal virtual ToolStrip tsChecked
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbFileInclusaoSearch")]
	internal virtual ToolStripTextBox cmbFileInclusaoSearch
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnSave")]
	internal virtual ToolStripButton btnSave
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("stMain")]
	internal virtual StatusStrip stMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblMainStatus")]
	internal virtual ToolStripStatusLabel lblMainStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlControls")]
	internal virtual Panel pnlControls
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public TranslateLNG()
	{
		base.Load += TranslateLNG_Load;
		class51_0 = new Class51(Globals.LNG_PATH + "\\Russian.xml");
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.tsChecked = new System.Windows.Forms.ToolStrip();
		this.cmbFileInclusaoSearch = new System.Windows.Forms.ToolStripTextBox();
		this.btnSave = new System.Windows.Forms.ToolStripButton();
		this.stMain = new System.Windows.Forms.StatusStrip();
		this.lblMainStatus = new System.Windows.Forms.ToolStripStatusLabel();
		this.pnlControls = new System.Windows.Forms.Panel();
		this.tsChecked.SuspendLayout();
		this.stMain.SuspendLayout();
		base.SuspendLayout();
		this.tsChecked.AutoSize = false;
		this.tsChecked.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsChecked.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.cmbFileInclusaoSearch, this.btnSave });
		this.tsChecked.Location = new System.Drawing.Point(0, 0);
		this.tsChecked.Name = "tsChecked";
		this.tsChecked.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsChecked.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsChecked.Size = new System.Drawing.Size(913, 48);
		this.tsChecked.TabIndex = 4;
		this.tsChecked.Text = "ToolStrip2";
		this.cmbFileInclusaoSearch.Name = "cmbFileInclusaoSearch";
		this.cmbFileInclusaoSearch.Size = new System.Drawing.Size(180, 48);
		this.btnSave.Image = ns0.Class6.SaveFileDialogControl_16x_24;
		this.btnSave.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSave.Name = "btnSave";
		this.btnSave.Size = new System.Drawing.Size(77, 45);
		this.btnSave.Text = "Save";
		this.stMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.lblMainStatus });
		this.stMain.Location = new System.Drawing.Point(0, 623);
		this.stMain.Name = "stMain";
		this.stMain.Padding = new System.Windows.Forms.Padding(2, 0, 21, 0);
		this.stMain.Size = new System.Drawing.Size(913, 30);
		this.stMain.Stretch = false;
		this.stMain.TabIndex = 12;
		this.stMain.Text = "StatusStrip1";
		this.lblMainStatus.Name = "lblMainStatus";
		this.lblMainStatus.Size = new System.Drawing.Size(890, 25);
		this.lblMainStatus.Spring = true;
		this.lblMainStatus.Text = "Ready";
		this.lblMainStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.pnlControls.AutoScroll = true;
		this.pnlControls.Dock = System.Windows.Forms.DockStyle.Fill;
		this.pnlControls.Location = new System.Drawing.Point(0, 48);
		this.pnlControls.Name = "pnlControls";
		this.pnlControls.Size = new System.Drawing.Size(913, 575);
		this.pnlControls.TabIndex = 13;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(913, 653);
		base.Controls.Add(this.pnlControls);
		base.Controls.Add(this.stMain);
		base.Controls.Add(this.tsChecked);
		base.Name = "TranslateLNG";
		this.Text = "TranslateLNG";
		this.tsChecked.ResumeLayout(false);
		this.tsChecked.PerformLayout();
		this.stMain.ResumeLayout(false);
		this.stMain.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void TranslateLNG_Load(object sender, EventArgs e)
	{
		SuspendLayout();
		List<ucLNG> list = new List<ucLNG>();
		int num = 1;
		foreach (object key in class51_0.method_1().Keys)
		{
			string string_ = Conversions.ToString(key);
			foreach (Class52 value in class51_0.method_2(string_).Values)
			{
				ucLNG ucLNG2 = new ucLNG(num, value.String_2, value.String_0, value.String_1);
				ucLNG2.Dock = DockStyle.Top;
				list.Add(ucLNG2);
				num = checked(num + 1);
			}
		}
		pnlControls.Controls.AddRange(list.ToArray());
		ResumeLayout();
		Invalidate();
		Refresh();
	}
}
