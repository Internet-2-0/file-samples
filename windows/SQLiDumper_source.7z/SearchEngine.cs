using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Threading;
using Chilkat;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

public class SearchEngine
{
	public enum Worker
	{
		Ide,
		Working,
		Paused
	}

	private Globals.SearchHost __Host;

	private Worker __State;

	private string __Dork;

	private Dictionary<string, Stopwatch> __DelayControl;

	private int __Delay;

	private List<Class24> __NextSearchPOST;

	private HTTP __HTTP;

	private string __ProxyIP;

	private int __TotalCalls;

	private string Domain { get; set; }

	public bool IPS_BLACK_LISTED { get; set; }

	public int LinksLoaded { get; set; }

	public int LinksLoadedLastTime { get; set; }

	public int DorkIndex { get; set; }

	public int Percentage { get; set; }

	public List<string> BlackListProxy { get; set; }

	public int MaxPages { get; set; }

	public string Host => __Host.ToString();

	public int HostInt => (int)__Host;

	public bool Canceled { get; set; }

	public SearchEngine(byte host, List<string> rBlackListProxy = null)
	{
		__Delay = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numScanningDelay));
		__ProxyIP = "MyIP";
		Domain = "com";
		MaxPages = 10;
		__Host = (Globals.SearchHost)host;
		__DelayControl = new Dictionary<string, Stopwatch>();
		BlackListProxy = rBlackListProxy;
		if (BlackListProxy == null)
		{
			ClearBlackList();
		}
		__HTTP = new HTTP();
	}

	public void ClearBlackList()
	{
		BlackListProxy = new List<string>();
		IPS_BLACK_LISTED = false;
	}

	public void Dispose()
	{
		if (__HTTP != null)
		{
			__HTTP.Dispose();
			__HTTP = null;
		}
	}

	public void StopScanning()
	{
		__State = Worker.Ide;
	}

	public void StartScanning(string dork)
	{
		__NextSearchPOST = new List<Class24>();
		__Dork = dork;
		Worker_Scanner();
	}

	public void PauseScanning(bool state)
	{
		if (__State != 0)
		{
			if (state)
			{
				__State = Worker.Paused;
			}
			else
			{
				__State = Worker.Working;
			}
		}
	}

	public bool IsComplete()
	{
		return __State == Worker.Ide;
	}

	private void Worker_Delay()
	{
		if (__DelayControl.ContainsKey(__ProxyIP))
		{
			Stopwatch stopwatch = __DelayControl[__ProxyIP];
			do
			{
				Thread.Sleep(100);
			}
			while (!Worker_PausedOrStoped() && __Delay > stopwatch.ElapsedMilliseconds);
		}
		else
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			__DelayControl.Add(__ProxyIP, stopwatch);
		}
	}

	private void Worker_Proxy()
	{
		if (Globals.G_SOCKS.method_9() == 0)
		{
			__ProxyIP = "MyIP";
			IPS_BLACK_LISTED = BlackListProxy.Contains("MyIP");
		}
		else
		{
			__HTTP.ProxyChecked = true;
			Class35 g_SOCKS = Globals.G_SOCKS;
			HTTP _HTTP;
			Http http_ = (_HTTP = __HTTP).o;
			bool num = g_SOCKS.method_13(ref http_, ref __ProxyIP, BlackListProxy);
			_HTTP.o = http_;
			IPS_BLACK_LISTED = !num;
			if (string.IsNullOrEmpty(__ProxyIP))
			{
				__ProxyIP = "MyIP";
			}
			else
			{
				__HTTP.Proxy = __ProxyIP;
			}
		}
		if (IPS_BLACK_LISTED)
		{
			StopScanning();
		}
	}

	private bool Worker_PausedOrStoped()
	{
		while (__State != 0 && __State != Worker.Working)
		{
			Thread.Sleep(500);
		}
		return (__State == Worker.Ide) | IPS_BLACK_LISTED;
	}

	private void Worker_Scanner()
	{
		try
		{
			__State = Worker.Working;
			int maxPages = MaxPages;
			for (int i = 0; i <= maxPages; i = checked(i + 1))
			{
				bool bNextPage = false;
				List<string> links = GetLinks(__Dork, i, ref bNextPage);
				if (links.Count > 0 && Globals.GQueue.method_3(links) != 0 && bNextPage && !Worker_PausedOrStoped())
				{
					Thread.Sleep(100);
					continue;
				}
				break;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.ToString());
			ProjectData.ClearProjectError();
		}
		finally
		{
			StopScanning();
		}
	}

	private List<string> GetLinks(string sQuery, int iPage, ref bool bNextPage)
	{
		List<string> list = new List<string>();
		string address = GetAddress(sQuery, iPage);
		if (iPage == 0)
		{
			if (__Host == Globals.SearchHost.DuckDuckGo)
			{
				__NextSearchPOST = new List<Class24>();
				AddNextSearchPOST("q", sQuery);
				AddNextSearchPOST("b", "");
				AddNextSearchPOST("kl", "us-en");
			}
			if (__Host == Globals.SearchHost.StartPage)
			{
				__NextSearchPOST = new List<Class24>();
				AddNextSearchPOST("cmd", "process_search");
				AddNextSearchPOST("language", "english");
				AddNextSearchPOST("enginecount", "1");
				AddNextSearchPOST("query", sQuery.Replace("?", ""));
				AddNextSearchPOST("pg", "0");
			}
		}
		string text = LoadPage(address);
		if (((__Host == Globals.SearchHost.DuckDuckGo) | (__Host == Globals.SearchHost.StartPage)) && IsValidePage(text, ref bNextPage))
		{
			ProcNextSearchPOST(text);
		}
		IsValidePage(text, ref bNextPage);
		list = ParseURLs(text);
		checked
		{
			LinksLoaded += list.Count;
			return list;
		}
	}

	private string LoadPage(string sUrl)
	{
		string text = "";
		int num = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPRetry));
		if (__TotalCalls > 50)
		{
			__HTTP.Dispose();
			__HTTP = new HTTP();
			Globals.ReleaseMemory();
			__TotalCalls = 0;
		}
		switch (__Host)
		{
		case Globals.SearchHost.Google:
		case Globals.SearchHost.DuckDuckGo:
		case Globals.SearchHost.Bing:
		case Globals.SearchHost.StartPage:
			__HTTP.o.AddQuickHeader("Upgrade-Insecure-Requests", "1");
			break;
		}
		int num2 = num;
		checked
		{
			for (int i = 0; i <= num2; i++)
			{
				Worker_Proxy();
				Worker_Delay();
				if (Worker_PausedOrStoped() || BlackListProxy.Contains(__ProxyIP))
				{
					break;
				}
				__HTTP.o.ClearInMemoryCookies();
				__TotalCalls++;
				Globals.SearchHost _Host = __Host;
				text = ((_Host == Globals.SearchHost.DuckDuckGo || _Host == Globals.SearchHost.StartPage) ? __HTTP.QuickPost(sUrl, __NextSearchPOST) : __HTTP.QuickGet(sUrl));
				if (CheckedCaptcha(text))
				{
					_ = 1;
				}
				if (__HTTP.Status != 200)
				{
					if (__HTTP.Status >= 10 && true && !BlackListProxy.Contains(__ProxyIP) && Conversions.ToBoolean(Globals.GetObjectValue(Globals.GMain.chkScanningBlackListProxy)))
					{
						BlackListProxy.Add(__ProxyIP);
					}
					continue;
				}
				__DelayControl[__ProxyIP] = Stopwatch.StartNew();
				break;
			}
			return text;
		}
	}

	private void ProcNextSearchPOST(string sHtml)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected O, but got Unknown
		__NextSearchPOST = new List<Class24>();
		StringBuilder val = new StringBuilder();
		if (__Host == Globals.SearchHost.DuckDuckGo)
		{
			int num = sHtml.IndexOf("value=\"Next\"");
			if (num <= 0)
			{
				return;
			}
			sHtml = sHtml.Substring(num);
			int num2 = sHtml.IndexOf("<input name=");
			if (num2 <= 0)
			{
				return;
			}
			sHtml = sHtml.Substring(0, num2).Trim();
			string[] array = sHtml.Split('\n');
			foreach (string text in array)
			{
				_ = 34;
				if (text.Contains("name=") & text.Contains("value="))
				{
					val.Append(text);
				}
			}
			RegExpNextSearchPOST(val.ToString());
			if (__NextSearchPOST.Count > 0)
			{
				AddNextSearchPOST("kl", "us-en");
			}
		}
		else
		{
			if (__Host != Globals.SearchHost.StartPage)
			{
				return;
			}
			int num3 = sHtml.IndexOf("'Searchpage pagination'>");
			if (num3 <= 0)
			{
				return;
			}
			sHtml = sHtml.Substring(num3);
			int num4 = sHtml.IndexOf("</form>");
			if (num4 <= 0)
			{
				return;
			}
			sHtml = sHtml.Substring(0, num4).Trim();
			string[] array2 = sHtml.Split('\n');
			foreach (string text2 in array2)
			{
				if (text2.StartsWith("<input"))
				{
					val.Append(text2);
				}
			}
			RegExpNextSearchPOST(sHtml);
		}
	}

	public void RegExpNextSearchPOST(string html)
	{
		foreach (Match item in Regex.Matches(html, "<input type=\"hidden\" name=\"([^\"]+)\" value=\"([^\"]+)\" /", RegexOptions.IgnoreCase))
		{
			AddNextSearchPOST(item.Groups[1].Value, Class23.smethod_5(item.Groups[2].Value));
		}
	}

	private void AddNextSearchPOST(string sName, string sValue)
	{
		Class24 @class = new Class24();
		@class.Name = sName;
		@class.Value = sValue;
		__NextSearchPOST.Add(@class);
	}

	private string GetAddress(string sQuery, int iPage)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Expected O, but got Unknown
		StringBuilder val = new StringBuilder();
		checked
		{
			switch (__Host)
			{
			case Globals.SearchHost.Google:
				val.Append("https://www.google." + Domain + "/search?");
				val.Append("newwindow=1");
				val.Append("&site=");
				val.Append("&q=" + Class23.smethod_7(sQuery));
				val.Append("&start=" + Conversions.ToString(iPage * 100));
				val.Append("&num=100");
				break;
			case Globals.SearchHost.DuckDuckGo:
				val.Append("https://duckduckgo." + Domain + "/html/");
				break;
			case Globals.SearchHost.Bing:
				val.Append("http://www.bing." + Domain + "/search?");
				val.Append("q=" + Class23.smethod_7(sQuery));
				if (iPage > 0)
				{
					val.Append("&first=" + Conversions.ToString(iPage * 50));
				}
				val.Append("&count=50");
				break;
			case Globals.SearchHost.Yahoo:
				val.Append("http://search.yahoo." + Domain + "/search?");
				val.Append("&p=" + Class23.smethod_7(sQuery));
				if (iPage > 0)
				{
					val.Append("&b=" + Conversions.ToString(iPage + 10));
				}
				break;
			case Globals.SearchHost.Ask:
				val.Append("http://www.ask." + Domain + "/web?");
				val.Append("q=" + Class23.smethod_7(sQuery));
				if (iPage > 0)
				{
					val.Append("&page=" + Conversions.ToString(iPage + 1));
				}
				break;
			case Globals.SearchHost.AOL:
				val.Append("http://search.aol." + Domain + "/aol/search?");
				val.Append("query=" + Class23.smethod_7(sQuery));
				if (iPage > 0)
				{
					val.Append("&page=" + Conversions.ToString(iPage + 1));
				}
				break;
			case Globals.SearchHost.WOW:
				val.Append("http://search.wow." + Domain + "/search?");
				val.Append("q=" + Class23.smethod_7(sQuery));
				if (iPage > 0)
				{
					val.Append("&page=" + Conversions.ToString(iPage + 1));
				}
				break;
			case Globals.SearchHost.StartPage:
				val.Append("https://s2-eu4.startpage.com/do/search");
				break;
			case Globals.SearchHost.Yandex:
				val.Append("https://www.yandex.com/search/?");
				val.Append("text=" + Class23.smethod_7(sQuery));
				if (iPage > 0)
				{
					val.Append("&p=" + Conversions.ToString(iPage));
				}
				break;
			case Globals.SearchHost.Rambler:
				val.Append("https://nova.rambler.ru/search?");
				val.Append("query=" + Class23.smethod_7(sQuery));
				val.Append("&suggest=false");
				val.Append("&page=" + Conversions.ToString(iPage));
				break;
			case Globals.SearchHost.Search:
				val.Append("https://www.search.com/web?");
				val.Append("q=" + Class23.smethod_7(sQuery));
				if (iPage > 0)
				{
					val.Append("&page=" + Conversions.ToString(iPage + 1));
				}
				break;
			}
			return val.ToString();
		}
	}

	private bool IsValidePage(string sData, ref bool bNextPage)
	{
		switch (__Host)
		{
		case Globals.SearchHost.Google:
			bNextPage = sData.ToLower().Contains("display:block;margin-left:53px".ToLower());
			return sData.ToLower().Contains("resultStats".ToLower());
		case Globals.SearchHost.DuckDuckGo:
			bNextPage = sData.ToLower().Contains("value=\"Next\"".ToLower());
			return sData.ToLower().Contains("id=\"search_button_homepage\"".ToLower());
		case Globals.SearchHost.Bing:
			bNextPage = sData.ToLower().Contains("sb_pagN".ToLower());
			return sData.ToLower().Contains("schemas.live.com/Web/".ToLower());
		case Globals.SearchHost.Yahoo:
			bNextPage = sData.ToLower().Contains("class=\"next".ToLower());
			return sData.ToLower().Contains(".query.yahoo.com".ToLower());
		case Globals.SearchHost.Ask:
			bNextPage = sData.ToLower().Contains("pagination-next".ToLower());
			return sData.ToLower().Contains("ask-search.xml".ToLower());
		case Globals.SearchHost.AOL:
			bNextPage = sData.ToLower().Contains(">Next</".ToLower());
			return sData.ToLower().Contains("compPagination".ToLower());
		case Globals.SearchHost.WOW:
			bNextPage = sData.ToLower().Contains(">Next</".ToLower());
			return sData.ToLower().Contains(".compImageProfile".ToLower());
		case Globals.SearchHost.StartPage:
			bNextPage = sData.ToLower().Contains("pagination__next-prev-button".ToLower());
			return sData.ToLower().Contains("data-component-base".ToLower());
		case Globals.SearchHost.Yandex:
			bNextPage = sData.ToLower().Contains(">next<".ToLower());
			return sData.ToLower().Contains("class=i-ua_js_no".ToLower());
		case Globals.SearchHost.Rambler:
			bNextPage = sData.ToLower().Contains("pager::page_next".ToLower());
			return sData.ToLower().Contains("images.rambler.ru".ToLower());
		case Globals.SearchHost.Search:
			bNextPage = sData.ToLower().Contains("\"show-more-button\"".ToLower());
			return sData.ToLower().Contains("og:description".ToLower());
		default:
		{
			bool result = default(bool);
			return result;
		}
		}
	}

	private bool CheckedCaptcha(string sData)
	{
		if (!string.IsNullOrEmpty(sData))
		{
			switch (__Host)
			{
			case Globals.SearchHost.Google:
				return sData.ToLower().Contains("google.com/websearch/answer/86640".ToLower());
			case Globals.SearchHost.Yandex:
				return sData.ToLower().Contains("action=\"/checkcaptcha".ToLower());
			}
		}
		return false;
	}

	private List<string> ParseURLs(string sData)
	{
		int try0001_dispatch = -1;
		int num = default(int);
		List<string> list = default(List<string>);
		int num2 = default(int);
		int num3 = default(int);
		string text = default(string);
		List<string> list2 = default(List<string>);
		List<string>.Enumerator enumerator = default(List<string>.Enumerator);
		List<string> result = default(List<string>);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				checked
				{
					switch (try0001_dispatch)
					{
					default:
						num = 1;
						list = new List<string>();
						goto IL_000a;
					case 1035:
						{
							num2 = num;
							switch ((num3 <= -2) ? 1 : num3)
							{
							case 1:
								break;
							default:
								goto end_IL_0001;
							}
							int num4 = unchecked(num2 + 1);
							num2 = 0;
							switch (num4)
							{
							case 1:
								break;
							case 2:
								goto IL_000a;
							case 3:
								goto IL_0016;
							case 4:
								goto IL_0023;
							case 6:
								goto IL_002e;
							case 5:
							case 7:
							case 8:
								goto IL_0037;
							case 9:
								goto IL_003f;
							case 10:
								goto IL_005f;
							case 15:
								goto IL_00a2;
							case 17:
								goto IL_00b6;
							case 18:
								goto IL_00c7;
							case 19:
							case 20:
								goto IL_00ea;
							case 21:
								goto IL_00fe;
							case 22:
							case 23:
								goto IL_0119;
							case 26:
								goto IL_012a;
							case 27:
								goto IL_013b;
							case 28:
							case 29:
								goto IL_015e;
							case 30:
								goto IL_0172;
							case 31:
							case 32:
								goto IL_018d;
							case 34:
								goto IL_019e;
							case 35:
								goto IL_01b4;
							case 37:
								goto IL_01cf;
							case 38:
								goto IL_01e0;
							case 39:
							case 40:
								goto IL_0203;
							case 41:
								goto IL_0217;
							case 42:
							case 43:
								goto IL_0232;
							case 46:
								goto IL_0243;
							case 47:
								goto IL_0254;
							case 48:
							case 49:
								goto IL_0277;
							case 50:
								goto IL_028b;
							case 51:
							case 52:
								goto IL_02a6;
							case 55:
								goto IL_02b4;
							case 56:
								goto IL_02c4;
							case 16:
							case 57:
							case 58:
							case 59:
								goto IL_02cf;
							case 11:
							case 12:
							case 13:
							case 14:
							case 24:
							case 25:
							case 33:
							case 36:
							case 44:
							case 45:
							case 53:
							case 54:
								goto IL_02d7;
							case 60:
								goto IL_02e6;
							case 61:
								goto end_IL_0001_2;
							default:
								goto end_IL_0001;
							case 62:
								goto end_IL_0001_3;
							}
							goto default;
						}
						IL_02b4:
						num = 55;
						if (!list.Contains(text))
						{
							goto IL_02c4;
						}
						goto IL_02cf;
						IL_02c4:
						num = 56;
						list.Add(text);
						goto IL_02cf;
						IL_02d7:
						num = 54;
						if (Class23.smethod_13(text))
						{
							goto IL_02b4;
						}
						goto IL_02cf;
						IL_02cf:
						num = 59;
						goto IL_004a;
						IL_000a:
						num = 2;
						sData = Class23.smethod_5(sData);
						goto IL_0016;
						IL_0016:
						num = 3;
						if (__Host == Globals.SearchHost.StartPage)
						{
							goto IL_0023;
						}
						goto IL_002e;
						IL_0023:
						num = 4;
						list2 = Class23.smethod_4(sData);
						goto IL_0037;
						IL_002e:
						num = 6;
						list2 = Class23.smethod_3(sData);
						goto IL_0037;
						IL_0037:
						ProjectData.ClearProjectError();
						num3 = -2;
						goto IL_003f;
						IL_003f:
						num = 9;
						enumerator = list2.GetEnumerator();
						goto IL_004a;
						IL_004a:
						if (enumerator.MoveNext())
						{
							text = enumerator.Current;
							goto IL_005f;
						}
						goto IL_02e6;
						IL_02e6:
						num = 60;
						((IDisposable)enumerator).Dispose();
						break;
						IL_005f:
						num = 10;
						switch (__Host)
						{
						case Globals.SearchHost.Yahoo:
							break;
						case Globals.SearchHost.AOL:
						case Globals.SearchHost.WOW:
							goto IL_012a;
						case Globals.SearchHost.StartPage:
							goto IL_019e;
						case Globals.SearchHost.Yandex:
							goto IL_01cf;
						case Globals.SearchHost.Search:
							goto IL_0243;
						default:
							goto IL_02d7;
						}
						goto IL_00a2;
						IL_0243:
						num = 46;
						if (text.Contains("surl="))
						{
							goto IL_0254;
						}
						goto IL_0277;
						IL_0254:
						num = 47;
						text = text.Substring(text.IndexOf("surl=") + "surl=".Length);
						goto IL_0277;
						IL_0277:
						num = 49;
						if (text.IndexOf("&") > 1)
						{
							goto IL_028b;
						}
						goto IL_02a6;
						IL_028b:
						num = 50;
						text = text.Substring(0, text.IndexOf("&") - 1);
						goto IL_02a6;
						IL_02a6:
						num = 52;
						text = Class23.smethod_8(text);
						goto IL_02d7;
						IL_01cf:
						num = 37;
						if (text.Contains("url="))
						{
							goto IL_01e0;
						}
						goto IL_0203;
						IL_01e0:
						num = 38;
						text = text.Substring(text.IndexOf("url=") + "url=".Length);
						goto IL_0203;
						IL_0203:
						num = 40;
						if (text.IndexOf("&") > 1)
						{
							goto IL_0217;
						}
						goto IL_0232;
						IL_0217:
						num = 41;
						text = text.Substring(0, text.IndexOf("&") - 1);
						goto IL_0232;
						IL_0232:
						num = 43;
						text = Class23.smethod_8(text);
						goto IL_02d7;
						IL_019e:
						num = 34;
						text = text.Replace("href=", "");
						goto IL_01b4;
						IL_01b4:
						num = 35;
						text = text.Replace("\"", "");
						goto IL_02d7;
						IL_012a:
						num = 26;
						if (text.Contains("RU="))
						{
							goto IL_013b;
						}
						goto IL_015e;
						IL_013b:
						num = 27;
						text = text.Substring(text.IndexOf("RU=") + "RU=".Length);
						goto IL_015e;
						IL_015e:
						num = 29;
						if (text.IndexOf("/RK=") > 1)
						{
							goto IL_0172;
						}
						goto IL_018d;
						IL_0172:
						num = 30;
						text = text.Substring(0, text.IndexOf("/RK=") - 1);
						goto IL_018d;
						IL_018d:
						num = 32;
						text = Class23.smethod_8(text);
						goto IL_02d7;
						IL_00a2:
						num = 15;
						if (!text.Contains("srpcache"))
						{
							goto IL_00b6;
						}
						goto IL_02cf;
						IL_00b6:
						num = 17;
						if (text.Contains("RU="))
						{
							goto IL_00c7;
						}
						goto IL_00ea;
						IL_00c7:
						num = 18;
						text = text.Substring(text.IndexOf("RU=") + "RU=".Length);
						goto IL_00ea;
						IL_00ea:
						num = 20;
						if (text.IndexOf("RK=") > 1)
						{
							goto IL_00fe;
						}
						goto IL_0119;
						IL_00fe:
						num = 21;
						text = text.Substring(0, text.IndexOf("RK=") - 1);
						goto IL_0119;
						IL_0119:
						num = 23;
						text = Class23.smethod_8(text);
						goto IL_02d7;
						end_IL_0001_2:
						break;
					}
					num = 61;
					result = list;
					break;
				}
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 1035;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
		return result;
	}
}
