using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Chilkat;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class Analizer : Form
{
	private delegate void Delegate15(string sMessage);

	private IContainer icontainer_0;

	[AccessedThroughProperty("btnPasteURL")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnPasteURL;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("cmbUnionStyle")]
	private ToolStripComboBox _cmbUnionStyle;

	[AccessedThroughProperty("btnNext")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnNext;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnBackward")]
	[CompilerGenerated]
	private ToolStripButton _btnBackward;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("txtUnionStyle")]
	[CompilerGenerated]
	private ToolStripComboBox _txtUnionStyle;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuCount")]
	[CompilerGenerated]
	private ContextMenuStrip _mnuCount;

	[AccessedThroughProperty("bckWorker")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private BackgroundWorker backgroundWorker_0;

	[AccessedThroughProperty("cmbUnionPosition")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripComboBox _cmbUnionPosition;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnWorker")]
	private ToolStripButton _btnWorker;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("chkIE")]
	[CompilerGenerated]
	private ToolStripButton _chkIE;

	[AccessedThroughProperty("btnClearForm")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnClearForm;

	[AccessedThroughProperty("btnGoToDumper")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnGoToDumper;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("ImageList1")]
	[CompilerGenerated]
	private ImageList imageList_0;

	private ToolStripSpringTextBox toolStripSpringTextBox_0;

	private ToolStripSpringTextBox toolStripSpringTextBox_1;

	private ToolStripControl toolStripControl_0;

	private ToolStripSpringTextBox toolStripSpringTextBox_2;

	private bool bool_0;

	[field: AccessedThroughProperty("tslMain_1")]
	internal virtual ToolStrip tslMain_1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnPasteURL
	{
		[CompilerGenerated]
		get
		{
			return _btnPasteURL;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_14;
			ToolStripButton toolStripButton = _btnPasteURL;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnPasteURL = value;
			toolStripButton = _btnPasteURL;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tslMain_4")]
	internal virtual ToolStrip tslMain_4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripComboBox cmbUnionStyle
	{
		[CompilerGenerated]
		get
		{
			return _cmbUnionStyle;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_9;
			ToolStripComboBox toolStripComboBox = _cmbUnionStyle;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged -= value2;
			}
			_cmbUnionStyle = value;
			toolStripComboBox = _cmbUnionStyle;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual ToolStripButton btnNext
	{
		[CompilerGenerated]
		get
		{
			return _btnNext;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_17;
			ToolStripButton toolStripButton = _btnNext;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnNext = value;
			toolStripButton = _btnNext;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnBackward
	{
		[CompilerGenerated]
		get
		{
			return _btnBackward;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_16;
			ToolStripButton toolStripButton = _btnBackward;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnBackward = value;
			toolStripButton = _btnBackward;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tslMain_3")]
	internal virtual ToolStrip tslMain_3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripComboBox txtUnionStyle
	{
		[CompilerGenerated]
		get
		{
			return _txtUnionStyle;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_9;
			ToolStripComboBox toolStripComboBox = _txtUnionStyle;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.TextChanged -= value2;
			}
			_txtUnionStyle = value;
			toolStripComboBox = _txtUnionStyle;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.TextChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator1")]
	internal virtual ToolStripSeparator ToolStripSeparator1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ContextMenuStrip mnuCount
	{
		[CompilerGenerated]
		get
		{
			return _mnuCount;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_11;
			ContextMenuStrip contextMenuStrip = _mnuCount;
			if (contextMenuStrip != null)
			{
				contextMenuStrip.Opening -= value2;
			}
			_mnuCount = value;
			contextMenuStrip = _mnuCount;
			if (contextMenuStrip != null)
			{
				contextMenuStrip.Opening += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripMenuItem1")]
	internal virtual ToolStripMenuItem ToolStripMenuItem1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tbcMain")]
	internal virtual UxTabControl tbcMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tpWB")]
	internal virtual TabPage tpWB
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tpSource")]
	internal virtual TabPage tpSource
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("stsMain")]
	internal virtual StatusStrip stsMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tpSetup")]
	internal virtual TabPage tpSetup
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("wbBrowser")]
	internal virtual WebBrowser wbBrowser
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public virtual BackgroundWorker bckWorker
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler value2 = method_22;
			ProgressChangedEventHandler value3 = method_23;
			RunWorkerCompletedEventHandler value4 = method_24;
			BackgroundWorker backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork -= value2;
				backgroundWorker.ProgressChanged -= value3;
				backgroundWorker.RunWorkerCompleted -= value4;
			}
			backgroundWorker_0 = value;
			backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork += value2;
				backgroundWorker.ProgressChanged += value3;
				backgroundWorker.RunWorkerCompleted += value4;
			}
		}
	}

	[field: AccessedThroughProperty("lblStatus")]
	internal virtual ToolStripStatusLabel lblStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripComboBox cmbUnionPosition
	{
		[CompilerGenerated]
		get
		{
			return _cmbUnionPosition;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_15;
			ToolStripComboBox toolStripComboBox = _cmbUnionPosition;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged -= value2;
			}
			_cmbUnionPosition = value;
			toolStripComboBox = _cmbUnionPosition;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator3")]
	internal virtual ToolStripSeparator ToolStripSeparator3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tpRaw")]
	internal virtual TabPage tpRaw
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator5")]
	internal virtual ToolStripSeparator ToolStripSeparator5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator7")]
	internal virtual ToolStripSeparator ToolStripSeparator7
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("prbStatus")]
	internal virtual ToolStripProgressBar prbStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtSourceCode")]
	internal virtual TextBox txtSourceCode
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtRaw")]
	internal virtual TextBox txtRaw
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbLogin")]
	internal virtual GroupBox grbLogin
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtUserName")]
	internal virtual TextBox txtUserName
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtPassword")]
	internal virtual TextBox txtPassword
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblUser")]
	internal virtual Label lblUser
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblPassword")]
	internal virtual Label lblPassword
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator9")]
	internal virtual ToolStripSeparator ToolStripSeparator9
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tslMain_2")]
	internal virtual ToolStrip tslMain_2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnWorker
	{
		[CompilerGenerated]
		get
		{
			return _btnWorker;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_20;
			ToolStripButton toolStripButton = _btnWorker;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnWorker = value;
			toolStripButton = _btnWorker;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblHttpStatus")]
	internal virtual ToolStripLabel lblHttpStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSp1")]
	internal virtual ToolStripSeparator tsSp1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSp2")]
	internal virtual ToolStripSeparator tsSp2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblIP")]
	internal virtual ToolStripLabel lblIP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSp4")]
	internal virtual ToolStripLabel tsSp4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblCountry")]
	internal virtual ToolStripLabel lblCountry
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSp3")]
	internal virtual ToolStripSeparator tsSp3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator6")]
	internal virtual ToolStripSeparator ToolStripSeparator6
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkWafs")]
	internal virtual ToolStripButton chkWafs
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator2")]
	internal virtual ToolStripSeparator ToolStripSeparator2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton chkIE
	{
		[CompilerGenerated]
		get
		{
			return _chkIE;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_8;
			ToolStripButton toolStripButton = _chkIE;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_chkIE = value;
			toolStripButton = _chkIE;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator4")]
	internal virtual ToolStripSeparator ToolStripSeparator4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkFlowRedirects")]
	internal virtual ToolStripButton chkFlowRedirects
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnClearForm
	{
		[CompilerGenerated]
		get
		{
			return _btnClearForm;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_7;
			ToolStripButton toolStripButton = _btnClearForm;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnClearForm = value;
			toolStripButton = _btnClearForm;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tsSp5")]
	internal virtual ToolStripSeparator tsSp5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnGoToDumper
	{
		[CompilerGenerated]
		get
		{
			return _btnGoToDumper;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_18;
			ToolStripButton toolStripButton = _btnGoToDumper;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnGoToDumper = value;
			toolStripButton = _btnGoToDumper;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("btnGoToDumperSP")]
	internal virtual ToolStripSeparator btnGoToDumperSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbSetup")]
	internal virtual GroupBox grbSetup
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkBypassProxy")]
	internal virtual CheckBox chkBypassProxy
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ImageList ImageList1
	{
		[CompilerGenerated]
		get
		{
			return imageList_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			imageList_0 = value;
		}
	}

	public Analizer()
	{
		base.Load += Analizer_Load;
		toolStripSpringTextBox_0 = new ToolStripSpringTextBox();
		toolStripSpringTextBox_1 = new ToolStripSpringTextBox();
		toolStripControl_0 = new ToolStripControl(new NumericUpDown());
		toolStripSpringTextBox_2 = new ToolStripSpringTextBox(1);
		InitializeComponent();
		Globals.translate_0.Add(this, icontainer_0);
		Globals.AddMouseMoveForm(this);
		cmbUnionStyle.Items.Add(Globals.translate_0.GetStr(base.Name + ".Strings", 0, "Numeric"));
		cmbUnionStyle.Items.Add(Globals.translate_0.GetStr(base.Name + ".Strings", 1, "Hex"));
		cmbUnionStyle.Items.Add(Globals.translate_0.GetStr(base.Name + ".Strings", 2, "Null"));
		cmbUnionStyle.Items.Add(Globals.translate_0.GetStr(base.Name + ".Strings", 3, "Custom"));
		cmbUnionStyle.SelectedIndex = 0;
		toolStripControl_0.Control.AutoSize = false;
		toolStripControl_0.Control.Minimum = 1m;
		toolStripControl_0.Control.Maximum = 100m;
		toolStripControl_0.Value = 1m;
		toolStripControl_0.Alignment = ToolStripItemAlignment.Right;
		checked
		{
			toolStripControl_0.Width += 30;
			toolStripControl_0.Control.ContextMenuStrip = mnuCount;
			cmbUnionPosition.AutoSize = false;
			cmbUnionPosition.Width = 50;
			cmbUnionStyle.AutoSize = false;
			cmbUnionStyle.Width = 75;
			txtUnionStyle.AutoSize = false;
			txtUnionStyle.Width = cmbUnionStyle.Width;
			chkWafs.CheckOnClick = true;
			foreach (object item2 in Globals.GMain.lstAnalizerUnion.Items)
			{
				string item = Conversions.ToString(item2);
				toolStripSpringTextBox_2.Items.Add(item);
			}
			if (!toolStripSpringTextBox_2.Items.Contains("999999.9 union all select [t]--"))
			{
				toolStripSpringTextBox_2.Items.Insert(0, "999999.9 union all select [t]--");
			}
			toolStripSpringTextBox_2.SelectedItem = "999999.9 union all select [t]--";
			tslMain_1.Items.Insert(1, new ToolStripSeparator());
			tslMain_1.Items.Insert(2, toolStripSpringTextBox_0);
			tslMain_3.Items.Insert(3, new ToolStripSeparator());
			tslMain_3.Items.Insert(4, toolStripSpringTextBox_2);
			tslMain_3.Items.Insert(8, toolStripControl_0);
			tslMain_4.Items.Insert(2, toolStripSpringTextBox_1);
			toolStripSpringTextBox_2.Focus();
			tslMain_1.Focus();
			toolStripSpringTextBox_0.Focus();
			toolStripSpringTextBox_1.KeyDown += toolStripSpringTextBox_1_KeyDown;
			toolStripSpringTextBox_1.TextChanged += toolStripSpringTextBox_1_TextChanged;
			toolStripSpringTextBox_0.TextChanged += toolStripSpringTextBox_0_TextChanged;
			toolStripControl_0.ValueChanged += numUnionCount_ValueChanged;
			toolStripSpringTextBox_2.SelectedIndexChanged += numUnionCount_ValueChanged;
			mnuCount.Closing += method_12;
			mnuCount.ShowCheckMargin = true;
			method_2(wbBrowser);
		}
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Analizer));
		this.tslMain_1 = new System.Windows.Forms.ToolStrip();
		this.btnPasteURL = new System.Windows.Forms.ToolStripButton();
		this.cmbUnionPosition = new System.Windows.Forms.ToolStripComboBox();
		this.ToolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
		this.tslMain_4 = new System.Windows.Forms.ToolStrip();
		this.txtUnionStyle = new System.Windows.Forms.ToolStripComboBox();
		this.ToolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
		this.btnGoToDumper = new System.Windows.Forms.ToolStripButton();
		this.btnGoToDumperSP = new System.Windows.Forms.ToolStripSeparator();
		this.cmbUnionStyle = new System.Windows.Forms.ToolStripComboBox();
		this.btnNext = new System.Windows.Forms.ToolStripButton();
		this.btnBackward = new System.Windows.Forms.ToolStripButton();
		this.tslMain_3 = new System.Windows.Forms.ToolStrip();
		this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
		this.ToolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
		this.ToolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuCount = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
		this.tbcMain = new UxTabControl();
		this.tpWB = new System.Windows.Forms.TabPage();
		this.wbBrowser = new System.Windows.Forms.WebBrowser();
		this.tpSource = new System.Windows.Forms.TabPage();
		this.txtSourceCode = new System.Windows.Forms.TextBox();
		this.tpRaw = new System.Windows.Forms.TabPage();
		this.txtRaw = new System.Windows.Forms.TextBox();
		this.tpSetup = new System.Windows.Forms.TabPage();
		this.grbSetup = new System.Windows.Forms.GroupBox();
		this.chkBypassProxy = new System.Windows.Forms.CheckBox();
		this.grbLogin = new System.Windows.Forms.GroupBox();
		this.txtUserName = new System.Windows.Forms.TextBox();
		this.txtPassword = new System.Windows.Forms.TextBox();
		this.lblUser = new System.Windows.Forms.Label();
		this.lblPassword = new System.Windows.Forms.Label();
		this.ImageList1 = new System.Windows.Forms.ImageList(this.icontainer_0);
		this.stsMain = new System.Windows.Forms.StatusStrip();
		this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
		this.prbStatus = new System.Windows.Forms.ToolStripProgressBar();
		this.bckWorker = new System.ComponentModel.BackgroundWorker();
		this.tslMain_2 = new System.Windows.Forms.ToolStrip();
		this.btnWorker = new System.Windows.Forms.ToolStripButton();
		this.btnClearForm = new System.Windows.Forms.ToolStripButton();
		this.tsSp1 = new System.Windows.Forms.ToolStripSeparator();
		this.lblHttpStatus = new System.Windows.Forms.ToolStripLabel();
		this.tsSp2 = new System.Windows.Forms.ToolStripSeparator();
		this.lblIP = new System.Windows.Forms.ToolStripLabel();
		this.tsSp3 = new System.Windows.Forms.ToolStripSeparator();
		this.lblCountry = new System.Windows.Forms.ToolStripLabel();
		this.tsSp5 = new System.Windows.Forms.ToolStripSeparator();
		this.tsSp4 = new System.Windows.Forms.ToolStripLabel();
		this.ToolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
		this.chkWafs = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
		this.chkIE = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
		this.chkFlowRedirects = new System.Windows.Forms.ToolStripButton();
		this.tslMain_1.SuspendLayout();
		this.tslMain_4.SuspendLayout();
		this.tslMain_3.SuspendLayout();
		this.mnuCount.SuspendLayout();
		this.tbcMain.SuspendLayout();
		this.tpWB.SuspendLayout();
		this.tpSource.SuspendLayout();
		this.tpRaw.SuspendLayout();
		this.tpSetup.SuspendLayout();
		this.grbSetup.SuspendLayout();
		this.grbLogin.SuspendLayout();
		this.stsMain.SuspendLayout();
		this.tslMain_2.SuspendLayout();
		base.SuspendLayout();
		this.tslMain_1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tslMain_1.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tslMain_1.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.btnPasteURL, this.cmbUnionPosition, this.ToolStripSeparator3 });
		this.tslMain_1.Location = new System.Drawing.Point(0, 0);
		this.tslMain_1.Name = "tslMain_1";
		this.tslMain_1.Padding = new System.Windows.Forms.Padding(0, 0, 4, 0);
		this.tslMain_1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tslMain_1.Size = new System.Drawing.Size(994, 33);
		this.tslMain_1.Stretch = true;
		this.tslMain_1.TabIndex = 21;
		this.tslMain_1.Text = "ToolStrip2";
		this.btnPasteURL.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnPasteURL.Image = ns0.Class6.URLInputBox_16x_24;
		this.btnPasteURL.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnPasteURL.Name = "btnPasteURL";
		this.btnPasteURL.Size = new System.Drawing.Size(28, 30);
		this.btnPasteURL.Text = "Paste URL";
		this.cmbUnionPosition.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.cmbUnionPosition.AutoSize = false;
		this.cmbUnionPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbUnionPosition.Name = "cmbUnionPosition";
		this.cmbUnionPosition.Size = new System.Drawing.Size(60, 33);
		this.ToolStripSeparator3.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator3.Name = "ToolStripSeparator3";
		this.ToolStripSeparator3.Size = new System.Drawing.Size(6, 33);
		this.tslMain_4.AutoSize = false;
		this.tslMain_4.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tslMain_4.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tslMain_4.Items.AddRange(new System.Windows.Forms.ToolStripItem[4] { this.txtUnionStyle, this.ToolStripSeparator7, this.btnGoToDumper, this.btnGoToDumperSP });
		this.tslMain_4.Location = new System.Drawing.Point(0, 97);
		this.tslMain_4.Name = "tslMain_4";
		this.tslMain_4.Padding = new System.Windows.Forms.Padding(0, 0, 4, 0);
		this.tslMain_4.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tslMain_4.Size = new System.Drawing.Size(994, 32);
		this.tslMain_4.Stretch = true;
		this.tslMain_4.TabIndex = 23;
		this.tslMain_4.Text = "ToolStrip2";
		this.txtUnionStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
		this.txtUnionStyle.Name = "txtUnionStyle";
		this.txtUnionStyle.Size = new System.Drawing.Size(160, 32);
		this.txtUnionStyle.Text = "~SQLI:[t]~";
		this.ToolStripSeparator7.Name = "ToolStripSeparator7";
		this.ToolStripSeparator7.Size = new System.Drawing.Size(6, 32);
		this.btnGoToDumper.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnGoToDumper.Checked = true;
		this.btnGoToDumper.CheckOnClick = true;
		this.btnGoToDumper.CheckState = System.Windows.Forms.CheckState.Checked;
		this.btnGoToDumper.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnGoToDumper.Enabled = false;
		this.btnGoToDumper.Image = ns0.Class6.UpdatePanel_16x_24;
		this.btnGoToDumper.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnGoToDumper.Name = "btnGoToDumper";
		this.btnGoToDumper.Size = new System.Drawing.Size(28, 29);
		this.btnGoToDumper.Text = "Go To Dumper";
		this.btnGoToDumperSP.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnGoToDumperSP.Name = "btnGoToDumperSP";
		this.btnGoToDumperSP.Size = new System.Drawing.Size(6, 32);
		this.cmbUnionStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbUnionStyle.Name = "cmbUnionStyle";
		this.cmbUnionStyle.Size = new System.Drawing.Size(160, 32);
		this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnNext.Enabled = false;
		this.btnNext.Image = ns0.Class6.NextFrameArrow_16x;
		this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnNext.Name = "btnNext";
		this.btnNext.Size = new System.Drawing.Size(28, 29);
		this.btnNext.Text = "Next [F8]";
		this.btnBackward.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnBackward.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnBackward.Enabled = false;
		this.btnBackward.Image = ns0.Class6.PreviousFrame_16x;
		this.btnBackward.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnBackward.Name = "btnBackward";
		this.btnBackward.Size = new System.Drawing.Size(28, 29);
		this.btnBackward.Text = "Backward [F7]";
		this.btnBackward.ToolTipText = "Load";
		this.tslMain_3.AutoSize = false;
		this.tslMain_3.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tslMain_3.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tslMain_3.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.cmbUnionStyle, this.btnNext, this.ToolStripSeparator1, this.btnBackward, this.ToolStripSeparator5, this.ToolStripSeparator9 });
		this.tslMain_3.Location = new System.Drawing.Point(0, 65);
		this.tslMain_3.Name = "tslMain_3";
		this.tslMain_3.Padding = new System.Windows.Forms.Padding(0, 0, 4, 0);
		this.tslMain_3.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tslMain_3.Size = new System.Drawing.Size(994, 32);
		this.tslMain_3.Stretch = true;
		this.tslMain_3.TabIndex = 22;
		this.tslMain_3.Text = "ToolStrip2";
		this.ToolStripSeparator1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator1.Name = "ToolStripSeparator1";
		this.ToolStripSeparator1.Size = new System.Drawing.Size(6, 32);
		this.ToolStripSeparator5.Name = "ToolStripSeparator5";
		this.ToolStripSeparator5.Size = new System.Drawing.Size(6, 32);
		this.ToolStripSeparator9.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator9.Name = "ToolStripSeparator9";
		this.ToolStripSeparator9.Size = new System.Drawing.Size(6, 32);
		this.mnuCount.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuCount.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.ToolStripMenuItem1 });
		this.mnuCount.Name = "mnuCount";
		this.mnuCount.ShowImageMargin = false;
		this.mnuCount.Size = new System.Drawing.Size(220, 34);
		this.ToolStripMenuItem1.Name = "ToolStripMenuItem1";
		this.ToolStripMenuItem1.Size = new System.Drawing.Size(219, 30);
		this.ToolStripMenuItem1.Text = "ToolStripMenuItem1";
		this.tbcMain.Controls.Add(this.tpWB);
		this.tbcMain.Controls.Add(this.tpSource);
		this.tbcMain.Controls.Add(this.tpRaw);
		this.tbcMain.Controls.Add(this.tpSetup);
		this.tbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
		this.tbcMain.ImageList = this.ImageList1;
		this.tbcMain.Location = new System.Drawing.Point(0, 129);
		this.tbcMain.Multiline = true;
		this.tbcMain.Name = "tbcMain";
		this.tbcMain.SelectedIndex = 0;
		this.tbcMain.Size = new System.Drawing.Size(994, 546);
		this.tbcMain.TabIndex = 24;
		this.tpWB.Controls.Add(this.wbBrowser);
		this.tpWB.ImageIndex = 0;
		this.tpWB.Location = new System.Drawing.Point(4, 4);
		this.tpWB.Name = "tpWB";
		this.tpWB.Padding = new System.Windows.Forms.Padding(3);
		this.tpWB.Size = new System.Drawing.Size(986, 513);
		this.tpWB.TabIndex = 0;
		this.tpWB.Text = "Web View";
		this.tpWB.UseVisualStyleBackColor = true;
		this.wbBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
		this.wbBrowser.Location = new System.Drawing.Point(3, 3);
		this.wbBrowser.MinimumSize = new System.Drawing.Size(20, 20);
		this.wbBrowser.Name = "wbBrowser";
		this.wbBrowser.Size = new System.Drawing.Size(980, 507);
		this.wbBrowser.TabIndex = 2;
		this.tpSource.Controls.Add(this.txtSourceCode);
		this.tpSource.ImageIndex = 1;
		this.tpSource.Location = new System.Drawing.Point(4, 4);
		this.tpSource.Name = "tpSource";
		this.tpSource.Padding = new System.Windows.Forms.Padding(3);
		this.tpSource.Size = new System.Drawing.Size(986, 513);
		this.tpSource.TabIndex = 1;
		this.tpSource.Text = "Page Source";
		this.tpSource.UseVisualStyleBackColor = true;
		this.txtSourceCode.BackColor = System.Drawing.SystemColors.Control;
		this.txtSourceCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.txtSourceCode.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtSourceCode.Font = new System.Drawing.Font("Courier New", 9.75f);
		this.txtSourceCode.Location = new System.Drawing.Point(3, 3);
		this.txtSourceCode.Multiline = true;
		this.txtSourceCode.Name = "txtSourceCode";
		this.txtSourceCode.ReadOnly = true;
		this.txtSourceCode.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.txtSourceCode.Size = new System.Drawing.Size(980, 507);
		this.txtSourceCode.TabIndex = 1;
		this.tpRaw.Controls.Add(this.txtRaw);
		this.tpRaw.ImageIndex = 2;
		this.tpRaw.Location = new System.Drawing.Point(4, 4);
		this.tpRaw.Name = "tpRaw";
		this.tpRaw.Padding = new System.Windows.Forms.Padding(3);
		this.tpRaw.Size = new System.Drawing.Size(986, 513);
		this.tpRaw.TabIndex = 3;
		this.tpRaw.Text = "Raw";
		this.tpRaw.UseVisualStyleBackColor = true;
		this.txtRaw.BackColor = System.Drawing.SystemColors.Control;
		this.txtRaw.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.txtRaw.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtRaw.Font = new System.Drawing.Font("Courier New", 9.75f);
		this.txtRaw.Location = new System.Drawing.Point(3, 3);
		this.txtRaw.Multiline = true;
		this.txtRaw.Name = "txtRaw";
		this.txtRaw.ReadOnly = true;
		this.txtRaw.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.txtRaw.Size = new System.Drawing.Size(980, 507);
		this.txtRaw.TabIndex = 2;
		this.tpSetup.Controls.Add(this.grbSetup);
		this.tpSetup.Controls.Add(this.grbLogin);
		this.tpSetup.ImageIndex = 3;
		this.tpSetup.Location = new System.Drawing.Point(4, 4);
		this.tpSetup.Name = "tpSetup";
		this.tpSetup.Padding = new System.Windows.Forms.Padding(3);
		this.tpSetup.Size = new System.Drawing.Size(986, 513);
		this.tpSetup.TabIndex = 2;
		this.tpSetup.Text = "Setup";
		this.tpSetup.UseVisualStyleBackColor = true;
		this.grbSetup.Controls.Add(this.chkBypassProxy);
		this.grbSetup.Location = new System.Drawing.Point(6, 112);
		this.grbSetup.Name = "grbSetup";
		this.grbSetup.Size = new System.Drawing.Size(330, 63);
		this.grbSetup.TabIndex = 47;
		this.grbSetup.TabStop = false;
		this.chkBypassProxy.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkBypassProxy.Location = new System.Drawing.Point(14, 14);
		this.chkBypassProxy.Name = "chkBypassProxy";
		this.chkBypassProxy.Size = new System.Drawing.Size(298, 34);
		this.chkBypassProxy.TabIndex = 0;
		this.chkBypassProxy.Text = "Bypass proxy";
		this.chkBypassProxy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkBypassProxy.UseVisualStyleBackColor = true;
		this.grbLogin.Controls.Add(this.txtUserName);
		this.grbLogin.Controls.Add(this.txtPassword);
		this.grbLogin.Controls.Add(this.lblUser);
		this.grbLogin.Controls.Add(this.lblPassword);
		this.grbLogin.Location = new System.Drawing.Point(6, 6);
		this.grbLogin.Name = "grbLogin";
		this.grbLogin.Size = new System.Drawing.Size(330, 100);
		this.grbLogin.TabIndex = 46;
		this.grbLogin.TabStop = false;
		this.grbLogin.Text = "Network Credential (Login)";
		this.txtUserName.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtUserName.Location = new System.Drawing.Point(130, 25);
		this.txtUserName.Name = "txtUserName";
		this.txtUserName.Size = new System.Drawing.Size(182, 26);
		this.txtUserName.TabIndex = 16;
		this.txtPassword.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtPassword.Location = new System.Drawing.Point(130, 60);
		this.txtPassword.Name = "txtPassword";
		this.txtPassword.Size = new System.Drawing.Size(182, 26);
		this.txtPassword.TabIndex = 17;
		this.lblUser.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblUser.Location = new System.Drawing.Point(9, 26);
		this.lblUser.Name = "lblUser";
		this.lblUser.Size = new System.Drawing.Size(116, 29);
		this.lblUser.TabIndex = 3;
		this.lblUser.Text = "UserName";
		this.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblPassword.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblPassword.Location = new System.Drawing.Point(9, 58);
		this.lblPassword.Name = "lblPassword";
		this.lblPassword.Size = new System.Drawing.Size(116, 29);
		this.lblPassword.TabIndex = 27;
		this.lblPassword.Text = "Password";
		this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.ImageList1.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("ImageList1.ImageStream");
		this.ImageList1.TransparentColor = System.Drawing.Color.Fuchsia;
		this.ImageList1.Images.SetKeyName(0, "VBWebAddNewBrowser_16x_24.bmp");
		this.ImageList1.Images.SetKeyName(1, "BlockSelection_16x_24.bmp");
		this.ImageList1.Images.SetKeyName(2, "HeaderFile_12x_24.bmp");
		this.ImageList1.Images.SetKeyName(3, "ConfigurationEditor_16x_24.bmp");
		this.stsMain.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.stsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.lblStatus, this.prbStatus });
		this.stsMain.Location = new System.Drawing.Point(0, 675);
		this.stsMain.Name = "stsMain";
		this.stsMain.Padding = new System.Windows.Forms.Padding(2, 0, 14, 0);
		this.stsMain.Size = new System.Drawing.Size(994, 30);
		this.stsMain.SizingGrip = false;
		this.stsMain.TabIndex = 25;
		this.stsMain.Text = "StatusStrip1";
		this.lblStatus.Name = "lblStatus";
		this.lblStatus.Size = new System.Drawing.Size(978, 25);
		this.lblStatus.Spring = true;
		this.lblStatus.Text = "lblStatus";
		this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.prbStatus.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.prbStatus.Name = "prbStatus";
		this.prbStatus.Size = new System.Drawing.Size(100, 25);
		this.prbStatus.Visible = false;
		this.bckWorker.WorkerReportsProgress = true;
		this.bckWorker.WorkerSupportsCancellation = true;
		this.tslMain_2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tslMain_2.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tslMain_2.Items.AddRange(new System.Windows.Forms.ToolStripItem[16]
		{
			this.btnWorker, this.btnClearForm, this.tsSp1, this.lblHttpStatus, this.tsSp2, this.lblIP, this.tsSp3, this.lblCountry, this.tsSp5, this.tsSp4,
			this.ToolStripSeparator6, this.chkWafs, this.ToolStripSeparator2, this.chkIE, this.ToolStripSeparator4, this.chkFlowRedirects
		});
		this.tslMain_2.Location = new System.Drawing.Point(0, 33);
		this.tslMain_2.Name = "tslMain_2";
		this.tslMain_2.Padding = new System.Windows.Forms.Padding(0, 0, 4, 0);
		this.tslMain_2.Size = new System.Drawing.Size(994, 32);
		this.tslMain_2.Stretch = true;
		this.tslMain_2.TabIndex = 26;
		this.tslMain_2.Text = "ToolStrip2";
		this.btnWorker.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnWorker.Enabled = false;
		this.btnWorker.Image = ns0.Class6.Run_16x_24;
		this.btnWorker.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnWorker.Name = "btnWorker";
		this.btnWorker.Size = new System.Drawing.Size(113, 29);
		this.btnWorker.Text = "Load [F5]";
		this.btnWorker.ToolTipText = "F5";
		this.btnClearForm.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnClearForm.Image = ns0.Class6.delete;
		this.btnClearForm.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnClearForm.Name = "btnClearForm";
		this.btnClearForm.Size = new System.Drawing.Size(28, 29);
		this.btnClearForm.Text = "Clear Form";
		this.btnClearForm.ToolTipText = "Clear Form";
		this.tsSp1.Name = "tsSp1";
		this.tsSp1.Size = new System.Drawing.Size(6, 32);
		this.lblHttpStatus.Name = "lblHttpStatus";
		this.lblHttpStatus.Size = new System.Drawing.Size(115, 29);
		this.lblHttpStatus.Text = "lblHttpStatus";
		this.tsSp2.Name = "tsSp2";
		this.tsSp2.Size = new System.Drawing.Size(6, 32);
		this.lblIP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.lblIP.Name = "lblIP";
		this.lblIP.Size = new System.Drawing.Size(46, 29);
		this.lblIP.Text = "lblIP";
		this.tsSp3.Name = "tsSp3";
		this.tsSp3.Size = new System.Drawing.Size(6, 32);
		this.lblCountry.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.lblCountry.Name = "lblCountry";
		this.lblCountry.Size = new System.Drawing.Size(94, 29);
		this.lblCountry.Text = "lblCountry";
		this.tsSp5.Name = "tsSp5";
		this.tsSp5.Size = new System.Drawing.Size(6, 32);
		this.tsSp4.Name = "tsSp4";
		this.tsSp4.Size = new System.Drawing.Size(62, 29);
		this.tsSp4.Text = "lblSize";
		this.ToolStripSeparator6.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator6.Name = "ToolStripSeparator6";
		this.ToolStripSeparator6.Size = new System.Drawing.Size(6, 32);
		this.chkWafs.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.chkWafs.Checked = true;
		this.chkWafs.CheckOnClick = true;
		this.chkWafs.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkWafs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.chkWafs.Image = ns0.Class6.AddStyleRule_16x_24;
		this.chkWafs.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkWafs.Name = "chkWafs";
		this.chkWafs.Size = new System.Drawing.Size(28, 29);
		this.chkWafs.Text = "Enable Wafs";
		this.chkWafs.ToolTipText = "Load";
		this.ToolStripSeparator2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator2.Name = "ToolStripSeparator2";
		this.ToolStripSeparator2.Size = new System.Drawing.Size(6, 32);
		this.chkIE.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.chkIE.CheckOnClick = true;
		this.chkIE.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.chkIE.Image = ns0.Class6.DownloadWebSetting_16x;
		this.chkIE.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkIE.Name = "chkIE";
		this.chkIE.Size = new System.Drawing.Size(28, 29);
		this.chkIE.Text = "IE Browser Component";
		this.chkIE.ToolTipText = "IE Browser";
		this.ToolStripSeparator4.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator4.Name = "ToolStripSeparator4";
		this.ToolStripSeparator4.Size = new System.Drawing.Size(6, 32);
		this.chkFlowRedirects.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.chkFlowRedirects.Checked = true;
		this.chkFlowRedirects.CheckOnClick = true;
		this.chkFlowRedirects.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkFlowRedirects.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.chkFlowRedirects.Image = ns0.Class6.PageRedirect_16x;
		this.chkFlowRedirects.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkFlowRedirects.Name = "chkFlowRedirects";
		this.chkFlowRedirects.Size = new System.Drawing.Size(28, 29);
		this.chkFlowRedirects.Text = "Follow HTTP Redirects";
		this.chkFlowRedirects.ToolTipText = "Follow HTTP Redirects";
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(994, 705);
		base.Controls.Add(this.tbcMain);
		base.Controls.Add(this.tslMain_4);
		base.Controls.Add(this.tslMain_3);
		base.Controls.Add(this.stsMain);
		base.Controls.Add(this.tslMain_2);
		base.Controls.Add(this.tslMain_1);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Analizer";
		this.tslMain_1.ResumeLayout(false);
		this.tslMain_1.PerformLayout();
		this.tslMain_4.ResumeLayout(false);
		this.tslMain_4.PerformLayout();
		this.tslMain_3.ResumeLayout(false);
		this.tslMain_3.PerformLayout();
		this.mnuCount.ResumeLayout(false);
		this.tbcMain.ResumeLayout(false);
		this.tpWB.ResumeLayout(false);
		this.tpSource.ResumeLayout(false);
		this.tpSource.PerformLayout();
		this.tpRaw.ResumeLayout(false);
		this.tpRaw.PerformLayout();
		this.tpSetup.ResumeLayout(false);
		this.grbSetup.ResumeLayout(false);
		this.grbLogin.ResumeLayout(false);
		this.grbLogin.PerformLayout();
		this.stsMain.ResumeLayout(false);
		this.stsMain.PerformLayout();
		this.tslMain_2.ResumeLayout(false);
		this.tslMain_2.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void method_0(string string_0)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 123:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0019;
						case 5:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 4:
						case 6:
						case 7:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					if (!stsMain.InvokeRequired)
					{
						break;
					}
					goto IL_0019;
					IL_0019:
					num = 3;
					stsMain.Invoke(new Delegate15(method_0), string_0);
					goto end_IL_0001_3;
					end_IL_0001_2:
					break;
				}
				num = 5;
				lblStatus.Text = string_0;
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 123;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_1(bool bool_1)
	{
		prbStatus.Visible = !bool_1;
		prbStatus.Style = ProgressBarStyle.Marquee;
		prbStatus.Value = 0;
		tslMain_1.Enabled = bool_1;
		tslMain_3.Enabled = bool_1;
		tslMain_4.Enabled = bool_1;
		btnWorker.Enabled = true;
		if (bool_1)
		{
			btnWorker.Image = Class6.Run_16x_24;
			btnWorker.Text = Globals.translate_0.GetStr(base.Name + ".Strings", 4, "Load");
		}
		else
		{
			wbBrowser.DocumentStream = null;
			wbBrowser.DocumentText = "";
			txtSourceCode.Text = "";
			txtRaw.Text = "";
			btnWorker.Image = Class6.Stop_16x_24;
			btnWorker.Text = Globals.translate_0.GetStr(base.Name + ".Strings", 5, "Stop");
			lblHttpStatus.Text = "";
			lblIP.Text = "";
			lblIP.Image = null;
			lblCountry.Text = "";
			tsSp4.Text = "";
		}
		tsSp1.Visible = !string.IsNullOrEmpty(lblIP.Text);
		tsSp2.Visible = !string.IsNullOrEmpty(lblIP.Text);
		tsSp3.Visible = !string.IsNullOrEmpty(lblIP.Text);
		tsSp4.Visible = !string.IsNullOrEmpty(lblIP.Text);
		tsSp5.Visible = !string.IsNullOrEmpty(lblIP.Text);
	}

	public void SaveSettings()
	{
		txtSourceCode.Text = "";
		txtRaw.Text = "";
		Class50.smethod_4(base.Name, "txtURL", toolStripSpringTextBox_0.Text);
		Class50.smethod_4(base.Name, "txtURL_Out", toolStripSpringTextBox_1.Text);
		Class50.smethod_4(base.Name, "numUnionCount", Conversions.ToString(toolStripControl_0.Value));
		Class50.smethod_4(base.Name, "cmbUnion", toolStripSpringTextBox_2.Text);
		Class50.smethod_3(this);
	}

	public void LoadSettings()
	{
		toolStripSpringTextBox_0.Text = Class50.smethod_5(base.Name, "txtURL", "");
		toolStripSpringTextBox_1.Text = Class50.smethod_5(base.Name, "txtURL_Out", "");
		toolStripControl_0.Text = Conversions.ToString(Conversions.ToInteger(Class50.smethod_5(base.Name, "numUnionCount", "1")));
		if (toolStripSpringTextBox_2.Items.Contains(Class50.smethod_5(base.Name, "cmbUnion", "")))
		{
			toolStripSpringTextBox_2.SelectedItem = Class50.smethod_5(base.Name, "cmbUnion", "");
		}
		Class50.smethod_2(this);
	}

	private void Analizer_Load(object sender, EventArgs e)
	{
		method_0("");
		method_1(bool_1: false);
		method_1(bool_1: true);
		base.KeyPreview = true;
	}

	protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
	{
		bool flag = default(bool);
		if (base.Visible)
		{
			switch (keyData)
			{
			case Keys.F5:
				method_20(null, null);
				flag = true;
				break;
			case Keys.F7:
				if (!bool_0)
				{
					method_16(null, null);
					flag = true;
				}
				break;
			case Keys.F8:
				if (!bool_0)
				{
					method_17(null, null);
					flag = true;
				}
				break;
			}
		}
		if (flag)
		{
			return true;
		}
		return base.ProcessCmdKey(ref msg, keyData);
	}

	private void method_2(WebBrowser webBrowser_0)
	{
		webBrowser_0.ScriptErrorsSuppressed = true;
		webBrowser_0.DocumentCompleted += method_5;
		webBrowser_0.StatusTextChanged += method_4;
		webBrowser_0.ProgressChanged += method_3;
	}

	private void method_3(object sender, WebBrowserProgressChangedEventArgs e)
	{
		if (e.CurrentProgress > 0 && !Conversions.ToBoolean(Operators.NotObject(Globals.GetObjectValue(chkIE))) && bool_0 && e.CurrentProgress <= e.MaximumProgress)
		{
			int num = checked((int)Math.Round(Math.Round((double)(100 * e.CurrentProgress) / (double)e.MaximumProgress)));
			if (prbStatus.Style == ProgressBarStyle.Marquee && num > 0 && num < 100)
			{
				prbStatus.Style = ProgressBarStyle.Blocks;
			}
			prbStatus.Value = num;
			if (e.CurrentProgress > 0 && num < 100)
			{
				method_0(Globals.translate_0.GetStr(base.Name + ".Strings", 7, "Downloading") + Conversions.ToString(num) + " %");
			}
			else
			{
				method_0(Globals.translate_0.GetStr(base.Name + ".Strings", 7, "Downloading"));
			}
		}
	}

	private void method_4(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 182:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0021;
						case 4:
							goto IL_0056;
						case 5:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 6:
						case 7:
						case 8:
						case 9:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					if (string.IsNullOrEmpty(wbBrowser.DocumentText))
					{
						goto end_IL_0001_3;
					}
					goto IL_0021;
					IL_0021:
					num = 3;
					if (wbBrowser.DocumentText.StartsWith("<HTML></HTML>") || wbBrowser.DocumentText.Length < 15)
					{
						goto end_IL_0001_3;
					}
					goto IL_0056;
					IL_0056:
					num = 4;
					if (string.IsNullOrEmpty(wbBrowser.StatusText))
					{
						goto end_IL_0001_3;
					}
					break;
					end_IL_0001_2:
					break;
				}
				num = 5;
				method_0(wbBrowser.StatusText);
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 182;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_5(object sender, WebBrowserDocumentCompletedEventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 168:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0031;
						case 4:
							goto IL_0043;
						case 5:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 6:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					txtSourceCode.Text = wbBrowser.DocumentText.Replace("\n", "\r\n");
					goto IL_0031;
					IL_0031:
					num = 3;
					txtRaw.Text = "";
					goto IL_0043;
					IL_0043:
					num = 4;
					tpWB.Text = wbBrowser.DocumentTitle;
					break;
					end_IL_0001_2:
					break;
				}
				num = 5;
				((WebBrowser)sender).Document.Window.Error += method_6;
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 168;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_6(object sender, HtmlElementErrorEventArgs e)
	{
		e.Handled = true;
	}

	private void method_7(object sender, EventArgs e)
	{
		Globals.GMain.pnlAnalizer.SuspendLayout();
		Globals.LockWindowUpdateForced(bState: false);
		Globals.GMain.method_61(bool_5: false);
		Globals.GMain.method_58(bool_5: false);
		Globals.LockWindowUpdateForced(bState: true);
		Globals.GMain.pnlAnalizer.ResumeLayout();
		Globals.GMain.pnlAnalizer.Refresh();
	}

	private void method_8(object sender, EventArgs e)
	{
		grbLogin.Enabled = !chkIE.Checked;
		chkFlowRedirects.Enabled = !chkIE.Checked;
	}

	private void toolStripSpringTextBox_1_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			method_21();
		}
	}

	private void method_9(object sender, EventArgs e)
	{
		txtUnionStyle.Enabled = cmbUnionStyle.SelectedIndex == 3;
		method_15(null, null);
	}

	private void method_10(object sender, EventArgs e)
	{
		chkFlowRedirects.Enabled = !chkIE.Checked;
	}

	private void method_11(object sender, CancelEventArgs e)
	{
		checked
		{
			if (decimal.Compare(toolStripControl_0.Value, 1m) <= 0)
			{
				e.Cancel = true;
			}
			else if (decimal.Compare(toolStripControl_0.Value, new decimal(mnuCount.Items.Count - 2)) != 0)
			{
				mnuCount.Items.Clear();
				mnuCount.ShowCheckMargin = false;
				int num = Convert.ToInt32(toolStripControl_0.Value);
				ToolStripMenuItem toolStripMenuItem = default(ToolStripMenuItem);
				for (int i = 1; i <= num; i++)
				{
					toolStripMenuItem = (ToolStripMenuItem)mnuCount.Items.Add(i.ToString());
					toolStripMenuItem.Click += method_13;
				}
				toolStripMenuItem.Click += method_13;
			}
		}
	}

	private void method_12(object sender, ToolStripDropDownClosingEventArgs e)
	{
	}

	private void method_13(object sender, EventArgs e)
	{
		if (Versioned.IsNumeric(RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null))))
		{
			List<int> list = new List<int>();
			list.Add(Conversions.ToInteger(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null)));
			toolStripSpringTextBox_1.Text = method_19(list);
		}
	}

	private void method_14(object sender, EventArgs e)
	{
		try
		{
			if (Clipboard.ContainsText())
			{
				string string_ = Clipboard.GetText().Trim();
				if (Class23.smethod_13(string_, bool_0: false))
				{
					toolStripSpringTextBox_0.Text = string_;
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void toolStripSpringTextBox_1_TextChanged(object sender, EventArgs e)
	{
		btnGoToDumper.Enabled = toolStripSpringTextBox_1.Text.Contains("[t]");
		btnGoToDumperSP.Enabled = btnGoToDumper.Visible;
	}

	private void toolStripSpringTextBox_0_TextChanged(object sender, EventArgs e)
	{
		try
		{
			string string_ = toolStripSpringTextBox_0.Text;
			cmbUnionPosition.Items.Clear();
			wbBrowser.DocumentStream = null;
			wbBrowser.DocumentText = "";
			txtSourceCode.Text = "";
			txtRaw.Text = "";
			if (Class23.smethod_13(string_, bool_0: false))
			{
				List<string> list = Class23.smethod_17(string_, "[t]", bool_0: false, bool_1: false);
				int count = list.Count;
				for (int i = 1; i <= count; i = checked(i + 1))
				{
					cmbUnionPosition.Items.Add(i);
				}
				cmbUnionPosition.SelectedIndex = 0;
			}
			method_15(null, null);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	public void numUnionCount_ValueChanged(object sender, EventArgs e)
	{
		btnBackward.Enabled = decimal.Compare(toolStripControl_0.Value, 1m) > 0;
		method_15(null, null);
	}

	private void method_15(object sender, EventArgs e)
	{
		try
		{
			toolStripSpringTextBox_1.Text = method_19(new List<int>());
			btnBackward.Enabled = (cmbUnionPosition.Items.Count > 0) & (decimal.Compare(toolStripControl_0.Value, 1m) > 0);
			btnNext.Enabled = cmbUnionPosition.Items.Count > 0;
			btnWorker.Enabled = cmbUnionPosition.Items.Count > 0;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_16(object sender, EventArgs e)
	{
		if (decimal.Compare(toolStripControl_0.Value, 0m) > 0)
		{
			ToolStripControl toolStripControl;
			(toolStripControl = toolStripControl_0).Value = decimal.Subtract(toolStripControl.Value, 1m);
			method_21();
		}
	}

	private void method_17(object sender, EventArgs e)
	{
		if (decimal.Compare(toolStripControl_0.Value, 101m) < 0)
		{
			ToolStripControl toolStripControl;
			(toolStripControl = toolStripControl_0).Value = decimal.Add(toolStripControl.Value, 1m);
			method_21();
		}
	}

	private void method_18(object sender, EventArgs e)
	{
		if (!Globals.GMain.DumperForm.Boolean_0)
		{
			if (Globals.GMain.bool_3)
			{
				Globals.GMain.mdiTabControl.SelectItem(2);
			}
			else
			{
				Globals.GMain.twMain.SelectedNode = Globals.GMain.treeNode_3;
			}
			Globals.GMain.DumperForm.method_76();
			Globals.GMain.DumperForm.txtURL.Text = toolStripSpringTextBox_1.Text;
			if (!toolStripSpringTextBox_1.Text.Contains(".asp"))
			{
				Globals.GMain.DumperForm.cmbSqlType.Text = Conversions.ToString(Globals.GMain.DumperForm.cmbSqlType.Items[0]);
			}
			else
			{
				Globals.GMain.DumperForm.cmbSqlType.Text = Conversions.ToString(Globals.GMain.DumperForm.cmbSqlType.Items[2]);
			}
			Globals.GMain.DumperForm.method_90(null, null);
		}
	}

	private string method_19(List<int> list_0)
	{
		checked
		{
			string result;
			try
			{
				if (cmbUnionPosition.Items.Count > 0)
				{
					string text = "";
					int num = Convert.ToInt32(toolStripControl_0.Value);
					for (int i = 1; i <= num; i++)
					{
						if (!string.IsNullOrEmpty(text))
						{
							text += ",";
						}
						if (list_0.Contains(i))
						{
							text += "[t]";
							continue;
						}
						switch (cmbUnionStyle.SelectedIndex)
						{
						case 0:
							text += Conversions.ToString(i);
							break;
						case 1:
							text += Class23.smethod_20(i.ToString());
							break;
						case 2:
							text += "null";
							break;
						case 3:
							text = ((list_0.Count != 0) ? (text + Conversions.ToString(i)) : (text + Class23.smethod_20(txtUnionStyle.Text.Replace("[t]", Conversions.ToString(i)))));
							break;
						}
					}
					string text2 = "";
					string text3 = toolStripSpringTextBox_2.Text;
					if (text3.EndsWith("--"))
					{
						text2 = "--";
						text3 = text3.Remove(text3.Length - 2);
					}
					text3 = text3.Replace("[t]", text) + text2;
					List<string> list = Class23.smethod_17(toolStripSpringTextBox_0.Text, text3, bool_0: false, bool_1: false);
					result = ((cmbUnionPosition.SelectedIndex + 1 <= list.Count) ? list[cmbUnionPosition.SelectedIndex] : "");
				}
				else
				{
					result = "";
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				result = ex2.Message;
				ProjectData.ClearProjectError();
			}
			return result;
		}
	}

	private void method_20(object sender, EventArgs e)
	{
		if (bool_0)
		{
			bckWorker.CancelAsync();
			btnWorker.Enabled = false;
		}
		else
		{
			method_21();
		}
	}

	private void method_21()
	{
		if (!bool_0)
		{
			if (Class23.smethod_13(toolStripSpringTextBox_0.Text))
			{
				method_1(bool_1: false);
				bckWorker.RunWorkerAsync();
			}
			else
			{
				method_0(Globals.translate_0.GetStr("Dumper.Strings", 61, "Invalid URL"));
			}
		}
	}

	private static MemoryStream smethod_0(string string_0)
	{
		MemoryStream memoryStream = new MemoryStream();
		StreamWriter streamWriter = new StreamWriter(memoryStream);
		streamWriter.Write(string_0);
		streamWriter.Flush();
		memoryStream.Position = 0L;
		return memoryStream;
	}

	private void method_22(object sender, DoWorkEventArgs e)
	{
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Expected O, but got Unknown
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Expected O, but got Unknown
		string string_ = "";
		bool_0 = true;
		method_0(Globals.translate_0.GetStr(base.Name + ".Strings", 6, "Connecting.."));
		string text = default(string);
		Http http_ = default(Http);
		Stopwatch stopwatch = default(Stopwatch);
		long long_ = default(long);
		string text2 = default(string);
		int length = default(int);
		try
		{
			text = Conversions.ToString(Globals.GetObjectValue(toolStripSpringTextBox_1));
			if (Conversions.ToBoolean(Globals.GetObjectValue(chkIE)))
			{
				wbBrowser.Navigate(text);
				do
				{
					Thread.Sleep(100);
					if (!bckWorker.CancellationPending)
					{
						bckWorker.ReportProgress(0);
						continue;
					}
					e.Result = Globals.translate_0.GetStr(base.Name + ".Strings", 8, "Worker Canceled");
					wbBrowser.Stop();
				}
				while (wbBrowser.IsBusy | bckWorker.CancellationPending);
			}
			else
			{
				http_ = new Http();
				e.Result = "";
				stopwatch = Stopwatch.StartNew();
				if (chkWafs.Checked)
				{
					text = Class23.smethod_15(text);
				}
				http_.UserAgent = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtUserAgent));
				http_.Accept = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtAccept));
				http_.ConnectTimeout = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPTimeout));
				http_.ReadTimeout = http_.ConnectTimeout;
				http_.FollowRedirects = Conversions.ToBoolean(Globals.GetObjectValue(chkFlowRedirects));
				http_.AutoAddHostHeader = true;
				http_.AllowGzip = true;
				http_.SendCookies = true;
				http_.SaveCookies = true;
				http_.CookieDir = "memory";
				http_.UseIEProxy = false;
				http_.MaxConnections = 500;
				http_.MaxResponseSize = 5242880u;
				http_.EnableEvents = true;
				http_.KeepEventLog = false;
				http_.Login = Conversions.ToString(Globals.GetObjectValue(txtUserName));
				http_.Password = Conversions.ToString(Globals.GetObjectValue(txtPassword));
				if (Conversions.ToBoolean(Operators.NotObject(Globals.GetObjectValue(chkBypassProxy))))
				{
					Globals.G_SOCKS.method_12(ref http_, ref string_);
				}
				long_ = Globals.GMain.method_207(text, string_);
				Task val = http_.QuickGetObjAsync(text);
				if (http_.LastMethodSuccess)
				{
					if (val.Run())
					{
						do
						{
							val.SleepMs(100);
							if (!bckWorker.CancellationPending)
							{
								bckWorker.ReportProgress(val.PercentDone);
								continue;
							}
							e.Result = Globals.translate_0.GetStr(base.Name + ".Strings", 8, "Worker Canceled");
							val.Cancel();
						}
						while (!(val.Finished | bckWorker.CancellationPending));
						if (val.StatusInt == 7)
						{
							HttpResponse val2 = new HttpResponse();
							if (val2.LoadTaskResult(val))
							{
								StringBuilder stringBuilder = new StringBuilder();
								if (!string.IsNullOrEmpty(http_.LastHeader))
								{
									stringBuilder.Append(http_.LastHeader);
									stringBuilder.AppendLine();
									stringBuilder.Append(new string('-', 50));
									stringBuilder.AppendLine();
								}
								stringBuilder.Append(val2.Header);
								stringBuilder.AppendLine();
								checked
								{
									if (val2.NumCookies > 0)
									{
										stringBuilder.Append(new string('-', 50));
										stringBuilder.AppendLine();
										int num = val2.NumCookies - 1;
										for (int i = 0; i <= num; i++)
										{
											stringBuilder.AppendLine("Name:" + val2.GetCookieName(i));
											stringBuilder.Append(", Value:" + val2.GetCookieValue(i));
											stringBuilder.Append(", Expires:" + val2.GetCookieExpiresStr(i));
										}
									}
									Globals.SetObjectValue(txtRaw, stringBuilder.ToString());
									Globals.SetObjectValue(txtSourceCode, val2.BodyStr);
									Globals.SetObjectValue(wbBrowser, val2.BodyStr);
								}
								if ((val2.StatusCode > 0) & (val2.StatusCode != 999999))
								{
									HttpStatusCode statusCode = default(HttpStatusCode);
									try
									{
										statusCode = (HttpStatusCode)val2.StatusCode;
									}
									catch (Exception projectError)
									{
										ProjectData.SetProjectError(projectError);
										ProjectData.ClearProjectError();
									}
									text2 = ((Operators.CompareString(val2.StatusCode.ToString(), statusCode.ToString(), TextCompare: false) != 0) ? (text2 + " " + statusCode) : text2);
								}
								else
								{
									text2 = "Unknown";
								}
								length = val2.BodyStr.Length;
								string text3 = "";
								string sCountry = "";
								Image oImage = null;
								string text4 = Class23.smethod_12(text);
								if (Globals.G_DataGP.CountryCodeExist(text4))
								{
									sCountry = Globals.G_DataGP.CountryNameByCode(text4);
									oImage = Globals.GMain.imgData.Images[text4 + ".png"];
								}
								else
								{
									text3 = Globals.GMain.method_85(Class23.smethod_11(text)).ToString();
									if (!string.IsNullOrEmpty(text3))
									{
										DataGP g_DataGP = Globals.G_DataGP;
										string sIP = text3;
										string sCountryCode = "";
										g_DataGP.Lookup(sIP, ref sCountry, ref oImage, ref sCountryCode, bUnionContryCode: true);
									}
								}
								Globals.SetObjectValue(lblIP, text3);
								Globals.SetObjectValue(lblHttpStatus, val2.StatusLine);
								Globals.SetObjectValue(lblCountry, sCountry);
								Globals.SetObjectValue(lblCountry, oImage);
								Globals.SetObjectValue(tsSp4, Globals.FormatBytes(val2.BodyStr.Length));
							}
							else
							{
								e.Result = val2.LastErrorText;
							}
						}
						else
						{
							e.Result = val.Status;
						}
					}
					else
					{
						e.Result = val.LastErrorText;
					}
				}
				else
				{
					e.Result = http_.LastErrorText;
				}
			}
			http_.CloseAllConnections();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			e.Result = ex2.ToString();
			ProjectData.ClearProjectError();
		}
		finally
		{
			try
			{
				Globals.SetObjectValue(tpWB, wbBrowser.DocumentTitle);
			}
			catch (Exception projectError2)
			{
				ProjectData.SetProjectError(projectError2);
				ProjectData.ClearProjectError();
			}
			if (Conversions.ToBoolean(Operators.NotObject(Globals.GetObjectValue(chkIE))))
			{
				stopwatch.Stop();
				if (string.IsNullOrEmpty(text2) && !string.IsNullOrEmpty(Conversions.ToString(e.Result)))
				{
					text2 = Conversions.ToString(e.Result);
				}
				Globals.GMain.method_206(long_, text, Globals.FormatBytes(length), Strings.FormatNumber(stopwatch.Elapsed.TotalMilliseconds / 1000.0, 2), text2, "");
				http_.Dispose();
			}
			bool_0 = false;
		}
	}

	private void method_23(object sender, ProgressChangedEventArgs e)
	{
		if ((prbStatus.Style == ProgressBarStyle.Marquee) & ((e.ProgressPercentage > 0) & (e.ProgressPercentage < 100)))
		{
			prbStatus.Style = ProgressBarStyle.Blocks;
		}
		prbStatus.Value = e.ProgressPercentage;
		if ((e.ProgressPercentage > 0) & (e.ProgressPercentage < 100))
		{
			method_0(Globals.translate_0.GetStr(base.Name + ".Strings", 7, "Downloading") + Conversions.ToString(e.ProgressPercentage) + " %");
		}
		else
		{
			method_0(Globals.translate_0.GetStr(base.Name + ".Strings", 7, "Downloading"));
		}
	}

	private void method_24(object sender, RunWorkerCompletedEventArgs e)
	{
		if (!string.IsNullOrEmpty(Conversions.ToString(e.Result)))
		{
			txtSourceCode.Text = Conversions.ToString(e.Result);
		}
		method_1(bool_1: true);
		method_0(Globals.translate_0.GetStr(base.Name + ".Strings", 9, "Done"));
	}
}
