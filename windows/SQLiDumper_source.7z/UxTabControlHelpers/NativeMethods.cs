using System;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.CompilerServices;

namespace UxTabControlHelpers;

[StandardModule]
internal sealed class NativeMethods
{
	public struct Struct5
	{
		public int int_0;

		public int int_1;
	}

	public struct Struct6
	{
		public Struct5 struct5_0;

		public uint uint_0;
	}

	public struct Struct7
	{
		public IntPtr intptr_0;

		public IntPtr intptr_1;

		public int int_0;

		public int int_1;

		public int int_2;

		public int int_3;

		public int int_4;
	}

	public static uint uint_0;

	public static int int_0;

	public static int int_1;

	public static int int_2;

	public static int int_3;

	public static int int_4;

	public static int int_5;

	public static int int_6;

	public static int int_7;

	public static int int_8;

	public static int int_9;

	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern IntPtr CreateCompatibleDC(IntPtr intptr_0);

	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool DeleteDC(IntPtr intptr_0);

	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern IntPtr CreateCompatibleBitmap(IntPtr intptr_0, int int_10, int int_11);

	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern IntPtr SelectObject(IntPtr intptr_0, IntPtr intptr_1);

	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool DeleteObject(IntPtr intptr_0);

	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool StretchBlt(IntPtr intptr_0, int int_10, int int_11, int int_12, int int_13, IntPtr intptr_1, int int_14, int int_15, int int_16, int int_17, uint uint_1);

	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool BitBlt(IntPtr intptr_0, int int_10, int int_11, int int_12, int int_13, IntPtr intptr_1, int int_14, int int_15, uint uint_1);

	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern uint GetPixel(IntPtr intptr_0, int int_10, int int_11);

	[DllImport("gdi32.dll", CallingConvention = CallingConvention.StdCall)]
	public static extern uint SetPixel(IntPtr intptr_0, int int_10, int int_11, uint uint_1);

	[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode)]
	public static extern IntPtr SendMessageW(IntPtr intptr_0, uint uint_1, IntPtr intptr_1, IntPtr intptr_2);

	[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode)]
	public static extern uint RealGetWindowClassW(IntPtr intptr_0, StringBuilder stringBuilder_0, uint uint_1);
}
