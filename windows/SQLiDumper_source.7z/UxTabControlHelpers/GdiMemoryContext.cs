using System;
using System.Drawing;
using Microsoft.VisualBasic;

namespace UxTabControlHelpers;

internal sealed class GdiMemoryContext : IDisposable
{
	private IntPtr intptr_0;

	private IntPtr intptr_1;

	private IntPtr intptr_2;

	private int int_0;

	private int int_1;

	private Graphics graphics_0;

	public Graphics Graphics_0 => graphics_0;

	public int Int32_0 => int_0;

	public int Int32_1 => int_1;

	public GdiMemoryContext(Graphics graphics_1, int int_2, int int_3)
	{
		if (Information.IsNothing(graphics_1) || int_2 <= 0 || int_3 <= 0)
		{
			throw new ArgumentException("Arguments are unacceptable");
		}
		IntPtr hdc = graphics_1.GetHdc();
		bool flag = true;
		intptr_0 = NativeMethods.CreateCompatibleDC(hdc);
		if (!(intptr_0 == IntPtr.Zero))
		{
			intptr_1 = NativeMethods.CreateCompatibleBitmap(hdc, int_2, int_3);
			if (intptr_1 == IntPtr.Zero)
			{
				NativeMethods.DeleteDC(intptr_0);
			}
			else
			{
				intptr_2 = NativeMethods.SelectObject(intptr_0, intptr_1);
				if (intptr_2 == IntPtr.Zero)
				{
					NativeMethods.DeleteObject(intptr_1);
					NativeMethods.DeleteDC(intptr_0);
				}
				else
				{
					flag = false;
				}
				_ = 0;
			}
		}
		graphics_1.ReleaseHdc(hdc);
		if (flag)
		{
			throw new SystemException("GDI error occured while creating context");
		}
		graphics_0 = Graphics.FromHdc(intptr_0);
		int_0 = int_2;
		int_1 = int_3;
	}

	~GdiMemoryContext()
	{
		vmethod_0(bool_0: false);
	}

	protected virtual void vmethod_0(bool bool_0)
	{
		if (bool_0 && !Information.IsNothing(graphics_0))
		{
			graphics_0.Dispose();
		}
		NativeMethods.SelectObject(intptr_0, intptr_2);
		NativeMethods.DeleteDC(intptr_0);
		intptr_0 = (IntPtr)(long)(0 - ((intptr_2 == IntPtr.Zero) ? 1 : 0));
		NativeMethods.DeleteObject(intptr_1);
		intptr_1 = IntPtr.Zero;
	}

	public void Dispose()
	{
		vmethod_0(bool_0: true);
		GC.SuppressFinalize(this);
	}

	public void method_0()
	{
		checked
		{
			if (intptr_0 != IntPtr.Zero)
			{
				NativeMethods.StretchBlt(intptr_0, 0, int_1 - 1, int_0, -int_1, intptr_0, 0, 0, int_0, int_1, 13369376u);
			}
		}
	}

	public uint method_1(int int_2, int int_3)
	{
		if (!(intptr_0 != IntPtr.Zero))
		{
			throw new ObjectDisposedException(null, "GDI context seems to be disposed.");
		}
		return NativeMethods.GetPixel(intptr_0, int_2, int_3);
	}

	public void method_2(int int_2, int int_3, uint uint_0)
	{
		if (!(intptr_0 != IntPtr.Zero))
		{
			throw new ObjectDisposedException(null, "GDI context seems to be disposed.");
		}
		NativeMethods.SetPixel(intptr_0, int_2, int_3, uint_0);
	}

	public void method_3(Graphics graphics_1, Rectangle rectangle_0)
	{
		if (!Information.IsNothing(graphics_1) && !(intptr_0 == IntPtr.Zero))
		{
			IntPtr hdc = graphics_1.GetHdc();
			if (!(hdc == IntPtr.Zero))
			{
				NativeMethods.BitBlt(hdc, rectangle_0.Left, rectangle_0.Top, rectangle_0.Width, rectangle_0.Height, intptr_0, 0, 0, 13369376u);
				graphics_1.ReleaseHdc(hdc);
				_ = 0;
			}
		}
	}
}
