public class Link
{
	private string string_0;

	private string string_1;

	private RegExpResult regExpResult_0;

	public string UrlSite
	{
		get
		{
			return string_0;
		}
		set
		{
			string_0 = value;
		}
	}

	public string Url
	{
		get
		{
			return string_1;
		}
		set
		{
			string_1 = value;
		}
	}

	public RegExpResult Result
	{
		get
		{
			return regExpResult_0;
		}
		set
		{
			regExpResult_0 = value;
		}
	}

	public Link(string sUrlSite, string sUrl, RegExpResult oResult)
	{
		string_0 = sUrlSite;
		string_1 = sUrl;
		regExpResult_0 = oResult;
	}
}
