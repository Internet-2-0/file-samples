using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using UxTabControlHelpers;

public class UxTabControl : TabControl
{
	[SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
	private sealed class Class42 : NativeWindow
	{
		private int int_0;

		private UxTabControl uxTabControl_0;

		public int Int32_0 => int_0;

		public Class42(UxTabControl uxTabControl_1)
		{
			uxTabControl_0 = uxTabControl_1;
		}

		protected override void WndProc(ref Message m)
		{
			if (m.Msg == 2 || m.Msg == 130)
			{
				ReleaseHandle();
			}
			else if (m.Msg == 70)
			{
				object lParam = m.GetLParam(typeof(NativeMethods.Struct7));
				int_0 = ((lParam != null) ? ((NativeMethods.Struct7)lParam) : default(NativeMethods.Struct7)).int_0;
			}
			else if (m.Msg == 512 && uxTabControl_0.int_0 > 0 && uxTabControl_0.int_0 != uxTabControl_0.SelectedIndex)
			{
				using Graphics graphics_ = Graphics.FromHwnd(uxTabControl_0.Handle);
				VisualStyleRenderer visualStyleRenderer = new VisualStyleRenderer(VisualStyleElement.Tab.TabItem.Normal);
				uxTabControl_0.method_2(graphics_, uxTabControl_0.int_0, uxTabControl_0.GetTabRect(uxTabControl_0.int_0), visualStyleRenderer);
				if (checked(uxTabControl_0.int_0 - uxTabControl_0.SelectedIndex) == 1)
				{
					Rectangle tabRect = uxTabControl_0.GetTabRect(uxTabControl_0.SelectedIndex);
					tabRect.Inflate(2, 2);
					visualStyleRenderer.SetParameters(visualStyleRenderer.Class, visualStyleRenderer.Part, 3);
					uxTabControl_0.method_2(graphics_, uxTabControl_0.SelectedIndex, tabRect, visualStyleRenderer);
				}
			}
			else if (m.Msg == 513)
			{
				Rectangle tabRect2 = uxTabControl_0.GetTabRect(uxTabControl_0.SelectedIndex);
				tabRect2.X = 0;
				tabRect2.Width = 2;
				tabRect2.Inflate(0, 2);
				uxTabControl_0.Invalidate(tabRect2);
			}
			base.WndProc(ref m);
		}
	}

	private bool bool_0;

	private IntPtr intptr_0;

	private int int_0;

	private Class42 class42_0;

	[Browsable(true)]
	[DefaultValue(1)]
	public new TabAlignment Alignment
	{
		get
		{
			return base.Alignment;
		}
		set
		{
			if (value <= TabAlignment.Bottom)
			{
				base.Alignment = value;
			}
		}
	}

	[Browsable(true)]
	[DefaultValue(true)]
	public new bool HotTrack
	{
		get
		{
			return base.HotTrack;
		}
		set
		{
			base.HotTrack = value;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public new TabAppearance Appearance
	{
		get
		{
			return base.Appearance;
		}
		set
		{
			if (value == TabAppearance.Normal)
			{
				base.Appearance = value;
			}
		}
	}

	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[Browsable(false)]
	public new TabDrawMode DrawMode
	{
		get
		{
			return base.DrawMode;
		}
		set
		{
			if (value == TabDrawMode.Normal)
			{
				base.DrawMode = value;
			}
		}
	}

	public UxTabControl()
	{
		base.SelectedIndexChanged += UxTabControl_SelectedIndexChanged;
		intptr_0 = IntPtr.Zero;
		int_0 = -1;
		Alignment = TabAlignment.Bottom;
		HotTrack = true;
		class42_0 = new Class42(this);
	}

	protected override void Dispose(bool disposing)
	{
		if (intptr_0 != IntPtr.Zero)
		{
			NativeMethods.DeleteObject(intptr_0);
			intptr_0 = IntPtr.Zero;
		}
		class42_0.ReleaseHandle();
		base.Dispose(disposing);
	}

	private void method_0()
	{
		bool_0 = Application.RenderWithVisualStyles && TabRenderer.IsSupported;
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque, bool_0);
		UpdateStyles();
		if (bool_0)
		{
			if (intptr_0 == IntPtr.Zero)
			{
				intptr_0 = Font.ToHfont();
			}
			NativeMethods.SendMessageW(base.Handle, 48u, intptr_0, (IntPtr)1);
			return;
		}
		NativeMethods.SendMessageW(base.Handle, 48u, Font.ToHfont(), (IntPtr)1);
		if (intptr_0 != IntPtr.Zero)
		{
			NativeMethods.DeleteObject(intptr_0);
			intptr_0 = IntPtr.Zero;
		}
	}

	protected override void OnHandleCreated(EventArgs e)
	{
		base.OnHandleCreated(e);
		method_0();
	}

	protected override void OnFontChanged(EventArgs e)
	{
		base.OnFontChanged(e);
		if (bool_0)
		{
			if (intptr_0 != IntPtr.Zero)
			{
				NativeMethods.DeleteObject(intptr_0);
			}
			intptr_0 = Font.ToHfont();
			NativeMethods.SendMessageW(base.Handle, 48u, intptr_0, (IntPtr)1);
		}
	}

	protected override void WndProc(ref Message m)
	{
		if (m.Msg == 794)
		{
			method_0();
		}
		else if (m.Msg == 528 && (m.WParam.ToInt32() & 0xFFFF) == 1)
		{
			StringBuilder stringBuilder = new StringBuilder(16);
			if ((long)NativeMethods.RealGetWindowClassW(m.LParam, stringBuilder, 16u) > 0L && Operators.CompareString(stringBuilder.ToString(), "msctls_updown32", TextCompare: false) == 0)
			{
				class42_0.ReleaseHandle();
				class42_0.AssignHandle(m.LParam);
			}
		}
		base.WndProc(ref m);
	}

	private void method_1(Graphics graphics_0, Rectangle rectangle_0)
	{
		if (!base.Visible)
		{
			return;
		}
		int num = base.SelectedIndex;
		object obj = Interaction.IIf(num != -1, GetTabRect(num), Rectangle.Empty);
		Rectangle rectangle_ = ((obj != null) ? ((Rectangle)obj) : default(Rectangle));
		Rectangle clientRectangle = base.ClientRectangle;
		VisualStyleRenderer visualStyleRenderer;
		int num3;
		checked
		{
			switch (Alignment)
			{
			case TabAlignment.Bottom:
				clientRectangle.Height -= rectangle_.Height * base.RowCount + 1;
				break;
			case TabAlignment.Top:
			{
				int num2 = rectangle_.Height * base.RowCount + 2;
				clientRectangle.Y += num2;
				clientRectangle.Height -= num2;
				break;
			}
			}
			if (clientRectangle.IntersectsWith(rectangle_0))
			{
				TabRenderer.DrawTabPage(graphics_0, clientRectangle);
			}
			int tabCount = base.TabCount;
			if (tabCount == 0)
			{
				return;
			}
			int_0 = method_4();
			visualStyleRenderer = new VisualStyleRenderer(VisualStyleElement.Tab.TabItem.Normal);
			num3 = tabCount - 1;
		}
		for (int i = 0; i <= num3; i = checked(i + 1))
		{
			if (i != num)
			{
				Rectangle tabRect = GetTabRect(i);
				if (tabRect.Right >= 3 && tabRect.IntersectsWith(rectangle_0))
				{
					TabItemState tabItemState = (TabItemState)Conversions.ToInteger(Interaction.IIf(i == int_0, TabItemState.Hot, TabItemState.Normal));
					visualStyleRenderer.SetParameters(visualStyleRenderer.Class, visualStyleRenderer.Part, (int)tabItemState);
					method_2(graphics_0, i, tabRect, visualStyleRenderer);
				}
			}
		}
		rectangle_.Inflate(2, 2);
		if (num != -1 && rectangle_.IntersectsWith(rectangle_0))
		{
			visualStyleRenderer.SetParameters(visualStyleRenderer.Class, visualStyleRenderer.Part, 3);
			method_2(graphics_0, num, rectangle_, visualStyleRenderer);
		}
	}

	private void method_2(Graphics graphics_0, int int_1, Rectangle rectangle_0, VisualStyleRenderer visualStyleRenderer_0)
	{
		if (class42_0.Int32_0 > 0 && rectangle_0.X >= class42_0.Int32_0)
		{
			return;
		}
		bool flag = visualStyleRenderer_0.State == 3;
		checked
		{
			using GdiMemoryContext gdiMemoryContext = new GdiMemoryContext(graphics_0, rectangle_0.Width, rectangle_0.Height);
			Rectangle bounds = new Rectangle(0, 0, rectangle_0.Width, rectangle_0.Height);
			visualStyleRenderer_0.DrawBackground(gdiMemoryContext.Graphics_0, bounds);
			if (flag && rectangle_0.X == 0)
			{
				int num = gdiMemoryContext.Int32_1 - 1;
				gdiMemoryContext.method_2(0, num, gdiMemoryContext.method_1(0, num - 1));
			}
			if (Alignment == TabAlignment.Bottom)
			{
				gdiMemoryContext.method_0();
			}
			TabPage tabPage = base.TabPages[int_1];
			Image image = method_3(tabPage.ImageIndex, tabPage.ImageKey);
			if (!Information.IsNothing(image))
			{
				Point point = new Point(Conversions.ToInteger(Interaction.IIf(flag, 8, 6)), 2);
				int num2 = point.X + image.Width;
				if (Alignment == TabAlignment.Bottom)
				{
					point.Y = Conversions.ToInteger(Operators.SubtractObject(bounds.Bottom - image.Height, Interaction.IIf(flag, 4, 2)));
				}
				if (RightToLeftLayout)
				{
					point.X = bounds.Right - num2;
				}
				gdiMemoryContext.Graphics_0.DrawImageUnscaled(image, point);
				bounds.X += num2;
				bounds.Width -= num2;
			}
			TextRenderer.DrawText(gdiMemoryContext.Graphics_0, tabPage.Text, Font, bounds, visualStyleRenderer_0.GetColor(ColorProperty.TextColor), TextFormatFlags.HorizontalCenter | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter);
			if (class42_0.Int32_0 > 0 && class42_0.Int32_0 >= rectangle_0.X && class42_0.Int32_0 < rectangle_0.Right)
			{
				rectangle_0.Width -= rectangle_0.Right - class42_0.Int32_0;
			}
			gdiMemoryContext.method_3(graphics_0, rectangle_0);
		}
	}

	private Image method_3(int int_1, string string_0)
	{
		if (Information.IsNothing(base.ImageList))
		{
			return null;
		}
		if (int_1 > -1)
		{
			return base.ImageList.Images[int_1];
		}
		if (string_0.Length > 0)
		{
			return base.ImageList.Images[string_0];
		}
		return null;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Point location = base.Location;
		checked
		{
			e.Graphics.TranslateTransform(-location.X, -location.Y);
			InvokePaintBackground(base.Parent, e);
			e.Graphics.TranslateTransform(location.X, location.Y);
			method_1(e.Graphics, e.ClipRectangle);
		}
	}

	private int method_4()
	{
		NativeMethods.Struct6 @struct = default(NativeMethods.Struct6);
		Point point = PointToClient(Control.MousePosition);
		@struct.struct5_0.int_0 = point.X;
		@struct.struct5_0.int_1 = point.Y;
		GCHandle gCHandle = GCHandle.Alloc(@struct, GCHandleType.Pinned);
		int result = NativeMethods.SendMessageW(base.Handle, 4877u, IntPtr.Zero, gCHandle.AddrOfPinnedObject()).ToInt32();
		gCHandle.Free();
		return result;
	}

	private void UxTabControl_SelectedIndexChanged(object sender, EventArgs e)
	{
		Globals.LockWindowUpdate(base.Handle);
		if (base.SelectedTab.Controls.Count > 0)
		{
			base.SelectedTab.Controls[0].Focus();
		}
		Globals.LockWindowUpdate(IntPtr.Zero);
	}
}
