using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
public class NewSocks : Form
{
	private IContainer icontainer_0;

	[AccessedThroughProperty("txtIP")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private TextBox _txtIP;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("txtUser")]
	private TextBox _txtUser;

	[CompilerGenerated]
	[AccessedThroughProperty("txtPwd")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TextBox _txtPwd;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("btnOK")]
	private Button _btnOK;

	[AccessedThroughProperty("numPort")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private NumericUpDown _numPort;

	internal virtual TextBox txtIP
	{
		[CompilerGenerated]
		get
		{
			return _txtIP;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_1;
			EventHandler value3 = method_2;
			TextBox textBox = _txtIP;
			if (textBox != null)
			{
				textBox.Leave -= value2;
				textBox.TextChanged -= value3;
			}
			_txtIP = value;
			textBox = _txtIP;
			if (textBox != null)
			{
				textBox.Leave += value2;
				textBox.TextChanged += value3;
			}
		}
	}

	[field: AccessedThroughProperty("Label16")]
	internal virtual Label Label16
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("Label1")]
	internal virtual Label Label1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtUser
	{
		[CompilerGenerated]
		get
		{
			return _txtUser;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_1;
			TextBox textBox = _txtUser;
			if (textBox != null)
			{
				textBox.Leave -= value2;
			}
			_txtUser = value;
			textBox = _txtUser;
			if (textBox != null)
			{
				textBox.Leave += value2;
			}
		}
	}

	[field: AccessedThroughProperty("Label2")]
	internal virtual Label Label2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual TextBox txtPwd
	{
		[CompilerGenerated]
		get
		{
			return _txtPwd;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_1;
			TextBox textBox = _txtPwd;
			if (textBox != null)
			{
				textBox.Leave -= value2;
			}
			_txtPwd = value;
			textBox = _txtPwd;
			if (textBox != null)
			{
				textBox.Leave += value2;
			}
		}
	}

	[field: AccessedThroughProperty("Label3")]
	internal virtual Label Label3
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("btnCancel")]
	internal virtual Button btnCancel
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual Button btnOK
	{
		[CompilerGenerated]
		get
		{
			return _btnOK;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_0;
			Button button = _btnOK;
			if (button != null)
			{
				button.Click -= value2;
			}
			_btnOK = value;
			button = _btnOK;
			if (button != null)
			{
				button.Click += value2;
			}
		}
	}

	internal virtual NumericUpDown numPort
	{
		[CompilerGenerated]
		get
		{
			return _numPort;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_2;
			EventHandler value3 = method_2;
			NumericUpDown numericUpDown = _numPort;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged -= value2;
				numericUpDown.TextChanged -= value3;
			}
			_numPort = value;
			numericUpDown = _numPort;
			if (numericUpDown != null)
			{
				numericUpDown.ValueChanged += value2;
				numericUpDown.TextChanged += value3;
			}
		}
	}

	[field: AccessedThroughProperty("Label4")]
	internal virtual Label Label4
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("cmbProxy")]
	internal virtual ComboBox cmbProxy
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public NewSocks()
	{
		base.Load += NewSocks_Load;
		InitializeComponent();
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.txtIP = new System.Windows.Forms.TextBox();
		this.Label16 = new System.Windows.Forms.Label();
		this.Label1 = new System.Windows.Forms.Label();
		this.txtUser = new System.Windows.Forms.TextBox();
		this.Label2 = new System.Windows.Forms.Label();
		this.txtPwd = new System.Windows.Forms.TextBox();
		this.Label3 = new System.Windows.Forms.Label();
		this.btnCancel = new System.Windows.Forms.Button();
		this.btnOK = new System.Windows.Forms.Button();
		this.numPort = new System.Windows.Forms.NumericUpDown();
		this.Label4 = new System.Windows.Forms.Label();
		this.cmbProxy = new System.Windows.Forms.ComboBox();
		((System.ComponentModel.ISupportInitialize)this.numPort).BeginInit();
		base.SuspendLayout();
		this.txtIP.Location = new System.Drawing.Point(105, 10);
		this.txtIP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtIP.Name = "txtIP";
		this.txtIP.Size = new System.Drawing.Size(184, 26);
		this.txtIP.TabIndex = 0;
		this.Label16.Location = new System.Drawing.Point(6, 10);
		this.Label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label16.Name = "Label16";
		this.Label16.Size = new System.Drawing.Size(92, 24);
		this.Label16.TabIndex = 26;
		this.Label16.Text = "IP";
		this.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.Label1.Location = new System.Drawing.Point(6, 43);
		this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label1.Name = "Label1";
		this.Label1.Size = new System.Drawing.Size(92, 24);
		this.Label1.TabIndex = 28;
		this.Label1.Text = "Port";
		this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtUser.Location = new System.Drawing.Point(105, 112);
		this.txtUser.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtUser.Name = "txtUser";
		this.txtUser.Size = new System.Drawing.Size(184, 26);
		this.txtUser.TabIndex = 3;
		this.Label2.Location = new System.Drawing.Point(6, 112);
		this.Label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label2.Name = "Label2";
		this.Label2.Size = new System.Drawing.Size(92, 24);
		this.Label2.TabIndex = 30;
		this.Label2.Text = "Username";
		this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.txtPwd.Location = new System.Drawing.Point(105, 145);
		this.txtPwd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtPwd.Name = "txtPwd";
		this.txtPwd.Size = new System.Drawing.Size(184, 26);
		this.txtPwd.TabIndex = 4;
		this.Label3.Location = new System.Drawing.Point(6, 145);
		this.Label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label3.Name = "Label3";
		this.Label3.Size = new System.Drawing.Size(92, 24);
		this.Label3.TabIndex = 32;
		this.Label3.Text = "Password";
		this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.btnCancel.Location = new System.Drawing.Point(13, 179);
		this.btnCancel.Margin = new System.Windows.Forms.Padding(5);
		this.btnCancel.Name = "btnCancel";
		this.btnCancel.Size = new System.Drawing.Size(132, 30);
		this.btnCancel.TabIndex = 6;
		this.btnCancel.Text = "Close";
		this.btnCancel.UseVisualStyleBackColor = true;
		this.btnOK.Enabled = false;
		this.btnOK.Location = new System.Drawing.Point(157, 179);
		this.btnOK.Margin = new System.Windows.Forms.Padding(5);
		this.btnOK.Name = "btnOK";
		this.btnOK.Size = new System.Drawing.Size(132, 30);
		this.btnOK.TabIndex = 5;
		this.btnOK.Text = "Add";
		this.btnOK.UseVisualStyleBackColor = true;
		this.numPort.Location = new System.Drawing.Point(105, 43);
		this.numPort.Maximum = new decimal(new int[4] { 9999999, 0, 0, 0 });
		this.numPort.Name = "numPort";
		this.numPort.Size = new System.Drawing.Size(184, 26);
		this.numPort.TabIndex = 1;
		this.Label4.Location = new System.Drawing.Point(6, 81);
		this.Label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.Label4.Name = "Label4";
		this.Label4.Size = new System.Drawing.Size(92, 24);
		this.Label4.TabIndex = 33;
		this.Label4.Text = "Type";
		this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.cmbProxy.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.cmbProxy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbProxy.FormattingEnabled = true;
		this.cmbProxy.Location = new System.Drawing.Point(105, 77);
		this.cmbProxy.Name = "cmbProxy";
		this.cmbProxy.Size = new System.Drawing.Size(184, 28);
		this.cmbProxy.TabIndex = 2;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(299, 219);
		base.Controls.Add(this.cmbProxy);
		base.Controls.Add(this.Label4);
		base.Controls.Add(this.numPort);
		base.Controls.Add(this.btnCancel);
		base.Controls.Add(this.btnOK);
		base.Controls.Add(this.txtPwd);
		base.Controls.Add(this.Label3);
		base.Controls.Add(this.txtUser);
		base.Controls.Add(this.Label2);
		base.Controls.Add(this.Label1);
		base.Controls.Add(this.txtIP);
		base.Controls.Add(this.Label16);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "NewSocks";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Add Proxy";
		((System.ComponentModel.ISupportInitialize)this.numPort).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	private void method_0(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.OK;
		int num = default(int);
		switch (cmbProxy.SelectedIndex)
		{
		case 0:
			num = 0;
			break;
		case 1:
			num = 4;
			break;
		case 2:
			num = 5;
			break;
		}
		Globals.G_SOCKS.method_3(txtIP.Text + ":" + Conversions.ToString(numPort.Value) + ":" + Conversions.ToString(num) + ":" + txtUser.Text + ":" + txtPwd.Text);
		txtIP.Clear();
		numPort.Value = 0m;
		txtUser.Clear();
		txtPwd.Clear();
	}

	private void NewSocks_Load(object sender, EventArgs e)
	{
		cmbProxy.Items.AddRange(new string[3] { "WEB PROXY", "SOCKS 4", "SOCKS 5" });
		base.CancelButton = btnCancel;
	}

	private void method_1(object sender, EventArgs e)
	{
		((TextBox)sender).Text = ((TextBox)sender).Text.Replace(" ", "");
	}

	private void method_2(object sender, EventArgs e)
	{
		btnOK.Enabled = (Globals.ValideIP(txtIP.Text) && decimal.Compare(numPort.Value, 0m) > 0) & !Information.IsNothing(RuntimeHelpers.GetObjectValue(cmbProxy.SelectedItem));
	}
}
