using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace ns0;

internal sealed class Class11
{
	public static byte[] smethod_0(byte[] byte_0, string string_0)
	{
		checked
		{
			byte[] array2;
			using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
			{
				rijndaelManaged.KeySize = 256;
				rijndaelManaged.Key = smethod_2(string_0);
				rijndaelManaged.IV = smethod_3(string_0);
				using MemoryStream memoryStream = new MemoryStream(byte_0);
				using (CryptoStream cryptoStream = new CryptoStream(memoryStream, rijndaelManaged.CreateDecryptor(), CryptoStreamMode.Read))
				{
					byte[] array = new byte[byte_0.Length + 1];
					int num = cryptoStream.Read(array, 0, byte_0.Length);
					array2 = new byte[num + 1];
					Array.Copy(array, array2, num);
					cryptoStream.Close();
				}
				memoryStream.Close();
			}
			return array2;
		}
	}

	public static byte[] smethod_1(byte[] byte_0, string string_0)
	{
		byte[] result;
		using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
		{
			rijndaelManaged.KeySize = 256;
			rijndaelManaged.Key = smethod_2(string_0);
			rijndaelManaged.IV = smethod_3(string_0);
			using MemoryStream memoryStream = new MemoryStream();
			using (CryptoStream cryptoStream = new CryptoStream(memoryStream, rijndaelManaged.CreateEncryptor(), CryptoStreamMode.Write))
			{
				cryptoStream.Write(byte_0, 0, byte_0.Length);
				cryptoStream.FlushFinalBlock();
				result = memoryStream.ToArray();
				cryptoStream.Close();
			}
			memoryStream.Close();
		}
		return result;
	}

	private static byte[] smethod_2(string string_0)
	{
		string_0 = "\0" + string_0 + "\0";
		byte[] result;
		using (SHA256Managed sHA256Managed = new SHA256Managed())
		{
			string text = Convert.ToBase64String(sHA256Managed.ComputeHash(Encoding.UTF8.GetBytes(string_0)));
			string s = string_0 + text;
			result = sHA256Managed.ComputeHash(Encoding.UTF8.GetBytes(s));
			sHA256Managed.Clear();
		}
		return result;
	}

	private static byte[] smethod_3(string string_0)
	{
		string_0 = "\0" + string_0 + "\0";
		byte[] result;
		using (MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider())
		{
			string text = Convert.ToBase64String(mD5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(string_0)));
			string s = string_0 + text;
			result = mD5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(s));
			mD5CryptoServiceProvider.Clear();
		}
		return result;
	}
}
