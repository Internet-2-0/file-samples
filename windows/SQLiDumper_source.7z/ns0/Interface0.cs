using System;
using System.Runtime.InteropServices;

namespace ns0;

[ComImport]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("c43dc798-95d1-4bea-9030-bb99e2983a1a")]
internal interface Interface0
{
	[PreserveSig]
	void imethod_0();

	[PreserveSig]
	void imethod_1(IntPtr intptr_0);

	[PreserveSig]
	void imethod_2(IntPtr intptr_0);

	[PreserveSig]
	void imethod_3(IntPtr intptr_0);

	[PreserveSig]
	void imethod_4(IntPtr intptr_0);

	[PreserveSig]
	void imethod_5(IntPtr intptr_0, [MarshalAs(UnmanagedType.Bool)] bool bool_0);

	[PreserveSig]
	void imethod_6(IntPtr intptr_0, ulong ulong_0, ulong ulong_1);

	[PreserveSig]
	void imethod_7(IntPtr intptr_0, Enum3 enum3_0);
}
