using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[DebuggerNonUserCode]
[HideModuleName]
[CompilerGenerated]
[StandardModule]
internal sealed class Class6
{
	private static ResourceManager resourceManager_0;

	private static CultureInfo cultureInfo_0;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager
	{
		get
		{
			if (object.ReferenceEquals(resourceManager_0, null))
			{
				ResourceManager resourceManager = new ResourceManager("Resources", typeof(Class6).Assembly);
				resourceManager_0 = resourceManager;
			}
			return resourceManager_0;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo Culture
	{
		get
		{
			return cultureInfo_0;
		}
		set
		{
			cultureInfo_0 = value;
		}
	}

	internal static Bitmap _Stop
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("_Stop", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap about
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("about", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap add
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("add", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap AddAgent_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("AddAgent_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap AddStyleRule_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("AddStyleRule_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap AddToCollection_ActionGray_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("AddToCollection_ActionGray_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap appwindow_info_annotation_16
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("appwindow_info_annotation_16", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap AutoArrangeShapes_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("AutoArrangeShapes_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap BuilderDialog_delete
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("BuilderDialog_delete", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap CascadeWindows
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("CascadeWindows", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap ChartFilter_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("ChartFilter_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap CheckSpellingHS
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("CheckSpellingHS", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap claspe
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("claspe", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap clipboard
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("clipboard", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap clipboard_16xLG
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("clipboard_16xLG", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap CloseDocumentGroup_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("CloseDocumentGroup_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap CloseGroup_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("CloseGroup_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap CloseSolution_inverse_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("CloseSolution_inverse_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap ConfirmButton_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("ConfirmButton_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Control_PrintPreviewDialog
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Control_PrintPreviewDialog", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap DatabaseSchema_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("DatabaseSchema_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap DataSet_TableView
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("DataSet_TableView", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap delete
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("delete", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap deletered
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("deletered", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap DeleteTable
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("DeleteTable", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static string dic_login_finder => ResourceManager.GetString("dic_login_finder", cultureInfo_0);

	internal static Bitmap downarrowhover
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("downarrowhover", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Download_grey_inverse_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Download_grey_inverse_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap DownloadWebSetting_16x
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("DownloadWebSetting_16x", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap DynamicMenu_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("DynamicMenu_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static string English => ResourceManager.GetString("English", cultureInfo_0);

	internal static Bitmap Entry_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Entry_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap expand
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("expand", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap FillDown
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("FillDown", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap FillUp
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("FillUp", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap find_and_replace
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("find_and_replace", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap formalines
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("formalines", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static string French => ResourceManager.GetString("French", cultureInfo_0);

	internal static string German => ResourceManager.GetString("German", cultureInfo_0);

	internal static Bitmap GetDynamicValuePropertyactivity_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("GetDynamicValuePropertyactivity_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap help
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("help", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap HTMLSubmit
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("HTMLSubmit", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Icon icon
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("icon", cultureInfo_0));
			return (Icon)objectValue;
		}
	}

	internal static Bitmap infohover
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("infohover", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap IPAddressControl_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("IPAddressControl_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap log_about
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("log_about", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap lol
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("lol", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap NewDocument
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("NewDocument", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap NextFrameArrow_16x
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("NextFrameArrow_16x", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Bitmap_0
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("OK", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap open_file
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("open_file", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap OpenTopic_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("OpenTopic_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap PageNumber
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("PageNumber", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap PageRedirect_16x
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("PageRedirect_16x", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Pause
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Pause", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Pause_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Pause_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static string Persian => ResourceManager.GetString("Persian", cultureInfo_0);

	internal static string Portuguese => ResourceManager.GetString("Portuguese", cultureInfo_0);

	internal static Bitmap PreviousFrame_16x
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("PreviousFrame_16x", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap progress_go
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("progress_go", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap progress_stop
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("progress_stop", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap ProjectSystemModelRefresh_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("ProjectSystemModelRefresh_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Refresh
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Refresh", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap reg
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("reg", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Retry
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Retry", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Run
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Run", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Run_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Run_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap RunThread_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("RunThread_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap RunUpdate_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("RunUpdate_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static string Russian => ResourceManager.GetString("Russian", cultureInfo_0);

	internal static Bitmap Save_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Save_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap SaveFileDialogControl_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("SaveFileDialogControl_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap search
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("search", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap SearchContract_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("SearchContract_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap speed_test
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("speed_test", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap StepIntoArrow_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("StepIntoArrow_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Stop_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Stop_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Template_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Template_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Text_align_left
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Text_align_left", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap UpdatePanel_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("UpdatePanel_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Upload_gray_inverse_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Upload_gray_inverse_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap URLInputBox_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("URLInputBox_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap ViewFull_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("ViewFull_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap ViewLandscape_16x_24
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("ViewLandscape_16x_24", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Windows
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Windows", cultureInfo_0));
			return (Bitmap)objectValue;
		}
	}
}
