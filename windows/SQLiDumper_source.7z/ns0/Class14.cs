using Microsoft.VisualBasic;

namespace ns0;

internal sealed class Class14
{
	public static byte[] smethod_0(byte[] byte_0, string string_0)
	{
		return smethod_2(byte_0, string_0);
	}

	public static byte[] smethod_1(byte[] byte_0, string string_0)
	{
		return smethod_2(byte_0, string_0);
	}

	private static byte[] smethod_2(byte[] byte_0, string string_0)
	{
		checked
		{
			byte[] array = new byte[byte_0.Length - 1 + 1];
			string_0 = "\0" + string_0 + "\0";
			int num = byte_0.Length - 1;
			for (int i = 0; i <= num; i++)
			{
				array[i] = (byte)(byte_0[i] ^ Strings.Asc(string_0.Substring(unchecked(i % string_0.Length), 1)));
			}
			return array;
		}
	}
}
