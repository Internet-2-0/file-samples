using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class17
{
	public enum Enum0
	{
		const_0,
		const_1,
		const_2,
		const_3,
		const_4,
		const_5,
		const_6
	}

	private delegate void Delegate1(object arg);

	private delegate void Delegate2(List<ListViewItem> o);

	private delegate void Delegate3(string value, int column, ListViewItem item);

	public sealed class Class18
	{
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool bool_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int int_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string[] string_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private ListViewItem listViewItem_0;

		public bool UseChecked
		{
			[CompilerGenerated]
			get
			{
				return bool_0;
			}
			[CompilerGenerated]
			set
			{
				bool_0 = value;
			}
		}

		public int CountryIndex
		{
			[CompilerGenerated]
			get
			{
				return int_0;
			}
			[CompilerGenerated]
			set
			{
				int_0 = value;
			}
		}

		public string[] Items
		{
			[CompilerGenerated]
			get
			{
				return string_0;
			}
			[CompilerGenerated]
			set
			{
				string_0 = value;
			}
		}

		public ListViewItem ViewItem
		{
			[CompilerGenerated]
			get
			{
				return listViewItem_0;
			}
			[CompilerGenerated]
			set
			{
				listViewItem_0 = value;
			}
		}

		public Class18()
		{
			UseChecked = false;
			CountryIndex = -1;
		}

		public ListViewItem method_0()
		{
			ViewItem = new ListViewItem(Items[0]);
			if (CountryIndex != -1)
			{
				method_2(ViewItem);
			}
			checked
			{
				int num = Items.Length - 1;
				if (UseChecked)
				{
					num--;
				}
				int num2 = num;
				for (int i = 1; i <= num2; i++)
				{
					ViewItem.SubItems.Add(Items[i]);
				}
				ViewItem.Tag = this;
				if (UseChecked)
				{
					ViewItem.Checked = Conversions.ToBoolean(Items[Items.Length - 1]);
				}
				return ViewItem;
			}
		}

		public string method_1()
		{
			StringBuilder stringBuilder = new StringBuilder();
			checked
			{
				int num = Items.Length - 1;
				if (UseChecked)
				{
					num--;
				}
				int num2 = num;
				for (int i = 0; i <= num2; i++)
				{
					if (i > 0)
					{
						stringBuilder.Append("|");
					}
					stringBuilder.Append(Items[i]);
				}
				if (UseChecked)
				{
					stringBuilder.Append(ViewItem.Checked.ToString());
				}
				return stringBuilder.ToString();
			}
		}

		private void method_2(ListViewItem listViewItem_1)
		{
			int try0001_dispatch = -1;
			int num3 = default(int);
			int num2 = default(int);
			int num = default(int);
			string sCountry = default(string);
			string sCountryCode = default(string);
			string text = default(string);
			string text2 = default(string);
			while (true)
			{
				try
				{
					/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
					DataGP g_DataGP;
					string sIP;
					Image oImage;
					switch (try0001_dispatch)
					{
					default:
						ProjectData.ClearProjectError();
						num3 = -2;
						goto IL_000a;
					case 483:
						{
							num2 = num;
							switch ((num3 <= -2) ? 1 : num3)
							{
							case 1:
								break;
							default:
								goto end_IL_0001;
							}
							int num4 = num2 + 1;
							num2 = 0;
							switch (num4)
							{
							case 1:
								break;
							case 2:
								goto IL_000a;
							case 3:
								goto IL_001a;
							case 4:
								goto IL_0025;
							case 5:
								goto IL_0040;
							case 7:
								goto IL_005a;
							case 8:
								goto IL_0064;
							case 9:
								goto IL_0072;
							case 10:
							case 11:
								goto IL_0082;
							case 12:
								goto IL_008d;
							case 13:
								goto IL_00a7;
							case 14:
								goto IL_00b6;
							case 6:
							case 15:
							case 16:
							case 17:
							case 18:
								goto IL_00cf;
							case 19:
								goto IL_00db;
							case 20:
								goto IL_00e5;
							case 21:
							case 22:
								goto IL_00f5;
							case 23:
								goto IL_0106;
							case 24:
								goto IL_0128;
							case 26:
								goto end_IL_0001_2;
							default:
								goto end_IL_0001;
							case 25:
							case 27:
							case 28:
								goto end_IL_0001_3;
							}
							goto default;
						}
						IL_00f5:
						num = 22;
						Items[CountryIndex] = sCountry;
						goto IL_0106;
						IL_0106:
						num = 23;
						if (!sCountryCode.Equals("??") && !sCountryCode.Equals("EU"))
						{
							break;
						}
						goto IL_0128;
						IL_00e5:
						num = 20;
						sCountry = Globals.G_DataGP.CountryNameByCode(sCountryCode);
						goto IL_00f5;
						IL_0128:
						num = 24;
						ViewItem.ImageKey = "--.png";
						goto end_IL_0001_3;
						IL_000a:
						num = 2;
						sCountry = Items[CountryIndex];
						goto IL_001a;
						IL_001a:
						num = 3;
						text = Items[0];
						goto IL_0025;
						IL_0025:
						num = 4;
						if (sCountry.Contains("[") & sCountry.Contains("]"))
						{
							goto IL_0040;
						}
						goto IL_005a;
						IL_0040:
						num = 5;
						sCountryCode = sCountry.Substring(1, checked(sCountry.IndexOf("]") - 1));
						goto IL_00cf;
						IL_005a:
						num = 7;
						sCountryCode = Class23.smethod_12(text);
						goto IL_0064;
						IL_0064:
						num = 8;
						if (!string.IsNullOrEmpty(sCountryCode))
						{
							goto IL_0072;
						}
						goto IL_0082;
						IL_0072:
						num = 9;
						sCountry = Globals.G_DataGP.CountryNameByCode(sCountryCode);
						goto IL_0082;
						IL_0082:
						num = 11;
						if (string.IsNullOrEmpty(sCountry))
						{
							goto IL_008d;
						}
						goto IL_00cf;
						IL_008d:
						num = 12;
						text2 = Globals.GMain.method_85(Class23.smethod_11(text)).ToString();
						goto IL_00a7;
						IL_00a7:
						num = 13;
						if (!string.IsNullOrEmpty(text2))
						{
							goto IL_00b6;
						}
						goto IL_00cf;
						IL_00b6:
						num = 14;
						g_DataGP = Globals.G_DataGP;
						sIP = text2;
						oImage = null;
						g_DataGP.Lookup(sIP, ref sCountry, ref oImage, ref sCountryCode, bUnionContryCode: true);
						goto IL_00cf;
						IL_00cf:
						num = 18;
						if (string.IsNullOrEmpty(sCountryCode))
						{
							goto IL_00db;
						}
						goto IL_00f5;
						IL_00db:
						num = 19;
						sCountryCode = "??";
						goto IL_00e5;
						end_IL_0001_2:
						break;
					}
					num = 26;
					ViewItem.ImageKey = sCountryCode.ToLower() + ".png";
					break;
					end_IL_0001:;
				}
				catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
				{
					ProjectData.SetProjectError((Exception)obj);
					try0001_dispatch = 483;
					continue;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				continue;
				end_IL_0001_3:
				break;
			}
			if (num2 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		public void method_3()
		{
			ViewItem.Text = Items[0];
			checked
			{
				int num = Items.Length - 1;
				for (int i = 1; i <= num; i++)
				{
					ViewItem.SubItems[i].Text = Items[i];
				}
			}
		}
	}

	[CompilerGenerated]
	internal sealed class Class19
	{
		public string string_0;

		[SpecialName]
		internal bool method_0(Class18 class18_0)
		{
			return class18_0.Items[0].Equals(string_0);
		}
	}

	[CompilerGenerated]
	internal sealed class Class20
	{
		public string string_0;

		[SpecialName]
		internal bool method_0(Class18 class18_0)
		{
			return class18_0.Items[0].ToLower().Contains(string_0.ToLower());
		}
	}

	[CompilerGenerated]
	internal sealed class Class21
	{
		public int int_0;

		public string string_0;

		[SpecialName]
		internal bool method_0(Class18 class18_0)
		{
			return class18_0.Items[int_0].ToLower().Contains(string_0.ToLower());
		}
	}

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_0;

	private List<Class18> list_0;

	private ListViewExt listViewExt_0;

	private string string_0;

	private int int_0;

	private int int_1;

	private Enum0 enum0_0;

	private static char char_0;

	public bool AutoScroll
	{
		[CompilerGenerated]
		get
		{
			return bool_0;
		}
		[CompilerGenerated]
		set
		{
			bool_0 = value;
		}
	}

	public Class17(ListView listView_0, string string_1, int int_2 = -1, int int_3 = -1)
	{
		enum0_0 = Enum0.const_0;
		listViewExt_0 = (ListViewExt)listView_0;
		string_0 = string_1;
		int_0 = int_2;
		int_1 = int_3;
		if (int_2 != -1)
		{
			listViewExt_0.SmallImageList = Globals.GMain.imgData;
		}
	}

	public void method_0(Enum0 enum0_1)
	{
		enum0_0 = enum0_1;
	}

	public void method_1(object object_0)
	{
		checked
		{
			if (listViewExt_0.InvokeRequired)
			{
				listViewExt_0.Invoke(new Delegate1(method_1), object_0);
			}
			else if (!method_10(Conversions.ToString(NewLateBinding.LateIndexGet(object_0, new object[1] { 0 }, null))))
			{
				if (listViewExt_0.CheckBoxes)
				{
					object_0 = Utils.CopyArray((Array)object_0, new object[Conversions.ToInteger(NewLateBinding.LateGet(object_0, null, "Length", new object[0], null, null, null)) + 1]);
					NewLateBinding.LateIndexSet(object_0, new object[2]
					{
						Operators.SubtractObject(NewLateBinding.LateGet(object_0, null, "Length", new object[0], null, null, null), 1),
						"False"
					}, null);
				}
				Class18 @class = new Class18();
				@class.CountryIndex = int_0;
				@class.Items = (string[])object_0;
				list_0.Add(@class);
				Globals.LockWindowUpdate(listViewExt_0.Handle);
				listViewExt_0.Items.Add(@class.method_0());
				if (AutoScroll)
				{
					listViewExt_0.EnsureVisible(listViewExt_0.Items.Count - 1);
				}
				Globals.LockWindowUpdate(IntPtr.Zero);
			}
		}
	}

	public void method_2(List<ListViewItem> list_1)
	{
		if (listViewExt_0.InvokeRequired)
		{
			listViewExt_0.Invoke(new Delegate2(method_2), list_1);
			return;
		}
		Globals.LockWindowUpdate(listViewExt_0.Handle);
		while (list_1.Count > 0)
		{
			list_0.Remove((Class18)list_1[0].Tag);
			listViewExt_0.Items.Remove(list_1[0]);
			list_1.RemoveAt(0);
		}
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	public void method_3(string string_1, int int_2, ListViewItem listViewItem_0)
	{
		if (listViewExt_0.InvokeRequired)
		{
			listViewExt_0.Invoke(new Delegate3(method_3), string_1, int_2, listViewItem_0);
			return;
		}
		Class18 @class = (Class18)listViewItem_0.Tag;
		if (list_0.Contains(@class))
		{
			@class.Items[int_2] = string_1;
			@class.method_3();
		}
	}

	public void method_4()
	{
		if (listViewExt_0.SelectedItems.Count == list_0.Count)
		{
			method_8();
			return;
		}
		List<Class18> list = method_21();
		if (list.Count > 0)
		{
			Globals.LockWindowUpdate(listViewExt_0.Handle);
			while (list.Count > 0)
			{
				list_0.Remove(list[0]);
				listViewExt_0.Items.Remove(list[0].ViewItem);
				list.RemoveAt(0);
			}
			Globals.LockWindowUpdate(IntPtr.Zero);
		}
	}

	public int method_5()
	{
		return list_0.Count;
	}

	public int method_6()
	{
		return listViewExt_0.Items.Count;
	}

	public int method_7()
	{
		List<Class18> list = list_0.FindAll([SpecialName] (Class18 class18_0) => class18_0.ViewItem.Checked);
		if (list == null)
		{
			return list.Count;
		}
		return 0;
	}

	public void method_8()
	{
		list_0 = new List<Class18>();
		Globals.LockWindowUpdate(listViewExt_0.Handle);
		listViewExt_0.BeginUpdate();
		listViewExt_0.Items.Clear();
		listViewExt_0.EndUpdate();
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	public void method_9()
	{
		listViewExt_0.SelectAllItems();
	}

	public bool method_10(string string_1)
	{
		Class18 @class = null;
		try
		{
			@class = list_0.Find([SpecialName] (Class18 class18_0) => class18_0.Items[0].Equals(string_1));
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		if (@class == null)
		{
			return false;
		}
		return true;
	}

	public bool method_11(string string_1)
	{
		string string_0 = Class23.smethod_10(string_1);
		Class18 @class = null;
		try
		{
			@class = list_0.Find([SpecialName] (Class18 class18_0) => class18_0.Items[0].ToLower().Contains(string_0.ToLower()));
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		if (@class == null)
		{
			return false;
		}
		return true;
	}

	public bool method_12()
	{
		bool result;
		try
		{
			if (File.Exists(string_0))
			{
				File.Delete(string_0);
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (Class18 item in list_0)
			{
				stringBuilder.Append(item.method_1() + "\r\n");
			}
			if (!string.IsNullOrEmpty(Conversions.ToString(stringBuilder.Length)))
			{
				File.AppendAllText(string_0, stringBuilder.ToString());
			}
			result = true;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			result = false;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public void method_13(bool bool_1)
	{
		method_8();
		method_19();
		if (bool_1)
		{
			method_17();
		}
	}

	public void method_14(string string_1, int int_2 = 0)
	{
		Globals.LockWindowUpdate(listViewExt_0.Handle);
		listViewExt_0.SetSelectedColumn(null);
		listViewExt_0.BeginUpdate();
		listViewExt_0.Items.Clear();
		if (string.IsNullOrEmpty(string_1) & (enum0_0 == Enum0.const_0))
		{
			method_17();
		}
		else
		{
			List<Class18> list = ((!string.IsNullOrEmpty(string_1)) ? list_0.FindAll([SpecialName] (Class18 class18_0) => class18_0.Items[int_2].ToLower().Contains(string_1.ToLower())) : list_0);
			if (list.Count > 0)
			{
				list = list.FindAll(method_15);
				if (list != null)
				{
					listViewExt_0.Items.AddRange(Array.ConvertAll(list.ToArray(), method_22));
				}
			}
		}
		listViewExt_0.EndUpdate();
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	private bool method_15(Class18 class18_0)
	{
		bool result = default(bool);
		try
		{
			if (enum0_0 == Enum0.const_0)
			{
				result = true;
			}
			else if (enum0_0 == Enum0.const_1)
			{
				result = Process.GetCurrentProcess().StartTime.Subtract(DateTime.Parse(class18_0.Items[int_1].ToString(), CultureInfo.InvariantCulture.DateTimeFormat)).TotalMinutes <= 1.0;
			}
			else
			{
				TimeSpan timeSpan = DateAndTime.Now.Subtract(DateTime.Parse(class18_0.Items[int_1].ToString(), CultureInfo.InvariantCulture.DateTimeFormat));
				if (enum0_0 == Enum0.const_2)
				{
					result = timeSpan.TotalDays <= 1.0;
				}
				else if (enum0_0 == Enum0.const_3)
				{
					result = timeSpan.TotalDays <= 7.0;
				}
				else if (enum0_0 == Enum0.const_4)
				{
					result = timeSpan.TotalDays <= 30.0;
				}
				else if (enum0_0 == Enum0.const_5)
				{
					result = timeSpan.TotalDays <= 90.0;
				}
				else if (enum0_0 == Enum0.const_6)
				{
					result = timeSpan.TotalDays >= 90.0;
				}
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			class18_0.Items[int_1] = DateAndTime.Now.ToString(CultureInfo.InvariantCulture.DateTimeFormat);
			result = false;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public void method_16()
	{
		List<Class18> list = method_21();
		if (list.Count > 0)
		{
			Globals.LockWindowUpdate(listViewExt_0.Handle);
			listViewExt_0.Items.Clear();
			listViewExt_0.Items.AddRange(Array.ConvertAll(list.ToArray(), method_22));
			Globals.LockWindowUpdate(IntPtr.Zero);
		}
	}

	private void method_17()
	{
		if (list_0.Count > 0)
		{
			listViewExt_0.Items.AddRange(Array.ConvertAll(list_0.ToArray(), method_22));
		}
	}

	public void method_18(List<Class18> list_1)
	{
		if (listViewExt_0.InvokeRequired)
		{
			listViewExt_0.Invoke((Delegate1)([SpecialName] [DebuggerHidden] (object object_0) =>
			{
				method_18((List<Class18>)object_0);
			}), list_1);
		}
		else
		{
			list_0.AddRange(list_1.ToArray());
			listViewExt_0.Items.AddRange(Array.ConvertAll(list_1.ToArray(), method_22));
		}
	}

	private void method_19()
	{
		List<Class18> list = new List<Class18>();
		foreach (string item in method_20())
		{
			string current = item.Trim();
			if (current.Contains("|"))
			{
				string[] array = Strings.Split(current, "|");
				if (array.Length >= listViewExt_0.Columns.Count)
				{
					Class18 @class = new Class18();
					@class.CountryIndex = int_0;
					@class.Items = array;
					list.Add(@class);
				}
			}
		}
		if (list.Count > 0)
		{
			list_0.AddRange(list);
		}
	}

	private List<string> method_20()
	{
		List<string> list = new List<string>();
		if (File.Exists(string_0))
		{
			list.AddRange(File.ReadAllLines(string_0));
		}
		return list;
	}

	private List<Class18> method_21()
	{
		List<Class18> list = new List<Class18>();
		foreach (ListViewItem selectedItem in listViewExt_0.SelectedItems)
		{
			if (selectedItem.Selected)
			{
				list.Add((Class18)selectedItem.Tag);
			}
		}
		return list;
	}

	private ListViewItem method_22(Class18 class18_0)
	{
		return class18_0.method_0();
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_23(object object_0)
	{
		method_18((List<Class18>)object_0);
	}
}
