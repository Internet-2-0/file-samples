using System;
using System.Net.Sockets;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class22
{
	private static int int_0;

	public static bool smethod_0(string string_0, int int_1, string string_1 = "")
	{
		bool result = default(bool);
		try
		{
			using TcpClient tcpClient = new TcpClient();
			tcpClient.SendTimeout = 5000;
			tcpClient.ReceiveTimeout = 5000;
			IAsyncResult asyncResult = tcpClient.BeginConnect(string_0, int_1, null, null);
			asyncResult.AsyncWaitHandle.WaitOne(5000, exitContext: false);
			if (tcpClient != null && tcpClient.Connected)
			{
				result = true;
				tcpClient.Close();
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			string_1 = ex2.Message;
			ProjectData.ClearProjectError();
		}
		return result;
	}
}
