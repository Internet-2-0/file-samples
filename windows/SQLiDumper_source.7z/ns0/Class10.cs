using System.IO;
using System.IO.Compression;

namespace ns0;

internal sealed class Class10
{
	public static byte[] smethod_0(byte[] byte_0)
	{
		using (MemoryStream memoryStream = new MemoryStream())
		{
			using (GZipStream gZipStream = new GZipStream(memoryStream, CompressionLevel.Optimal))
			{
				gZipStream.Write(byte_0, 0, byte_0.Length);
				gZipStream.Close();
				byte_0 = new byte[checked(memoryStream.ToArray().Length - 1 + 1)];
				byte_0 = memoryStream.ToArray();
			}
			memoryStream.Close();
		}
		return byte_0;
	}

	public static byte[] smethod_1(byte[] byte_0)
	{
		using GZipStream gZipStream = new GZipStream(new MemoryStream(byte_0), CompressionMode.Decompress);
		int num = 4096;
		byte[] array = new byte[checked(num - 1 + 1)];
		using MemoryStream memoryStream = new MemoryStream();
		int num2 = 0;
		do
		{
			num2 = gZipStream.Read(array, 0, num);
			if (num2 > 0)
			{
				memoryStream.Write(array, 0, num2);
			}
		}
		while (num2 > 0);
		return memoryStream.ToArray();
	}
}
