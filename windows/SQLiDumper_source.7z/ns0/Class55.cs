using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ns0;

[CompilerGenerated]
internal sealed class Class55
{
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 19)]
	private struct Struct11
	{
	}

	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 26)]
	private struct Struct12
	{
	}

	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 48)]
	private struct Struct13
	{
	}

	internal static readonly Struct11 struct11_0/* Not supported: data(53 48 C7 C0 01 00 00 00 0F A2 41 89 00 41 89 50 04 5B C3) */;

	internal static readonly Struct13 struct13_0/* Not supported: data(00 04 00 00 00 00 00 00 00 00 10 00 00 00 00 00 00 00 00 40 00 00 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00 00 04 00 00 00 00 00 00 00 00 10) */;

	internal static readonly Struct12 struct12_0/* Not supported: data(55 89 E5 57 8B 7D 10 6A 01 58 53 0F A2 89 07 89 57 04 5B 5F 89 EC 5D C2 10 00) */;

	internal static uint smethod_0(string string_0)
	{
		uint num = 2166136261u;
		if (string_0 != null)
		{
			for (int i = 0; i < string_0.Length; i++)
			{
				num = (string_0[i] ^ num) * 16777619;
			}
		}
		return num;
	}
}
