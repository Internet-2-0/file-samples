using System;
using System.Text;

namespace ns0;

internal sealed class Class15
{
	public static string smethod_0(string string_0)
	{
		ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
		byte[] bytes = aSCIIEncoding.GetBytes(string_0);
		bytes = smethod_2(bytes);
		return aSCIIEncoding.GetString(bytes);
	}

	public static string smethod_1(string string_0)
	{
		ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
		byte[] bytes = aSCIIEncoding.GetBytes(string_0);
		bytes = smethod_3(bytes);
		return aSCIIEncoding.GetString(bytes);
	}

	public static byte[] smethod_2(byte[] byte_0)
	{
		ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
		return aSCIIEncoding.GetBytes(Convert.ToBase64String(byte_0));
	}

	public static byte[] smethod_3(byte[] byte_0)
	{
		ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
		return Convert.FromBase64String(aSCIIEncoding.GetString(byte_0));
	}
}
