using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class29
{
	public enum Enum2
	{
		const_0,
		const_1,
		const_2,
		const_3,
		const_4,
		const_5,
		const_6
	}

	private delegate void Delegate5(object arg);

	private delegate void Delegate6(List<DataGridViewRow> o);

	private delegate void Delegate7(string value, int column, DataGridViewRow item);

	public sealed class Class30
	{
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string[] string_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private DataGridViewRow dataGridViewRow_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private DataGridView dataGridView_0;

		public int CountryIndex
		{
			[CompilerGenerated]
			get
			{
				return int_0;
			}
			[CompilerGenerated]
			set
			{
				int_0 = value;
			}
		}

		public string[] Items
		{
			[CompilerGenerated]
			get
			{
				return string_0;
			}
			[CompilerGenerated]
			set
			{
				string_0 = value;
			}
		}

		public DataGridViewRow Row
		{
			[CompilerGenerated]
			get
			{
				return dataGridViewRow_0;
			}
			[CompilerGenerated]
			set
			{
				dataGridViewRow_0 = value;
			}
		}

		public DataGridView Grid
		{
			[CompilerGenerated]
			get
			{
				return dataGridView_0;
			}
			[CompilerGenerated]
			set
			{
				dataGridView_0 = value;
			}
		}

		public Class30(DataGridView dataGridView_1)
		{
			CountryIndex = -1;
			Grid = dataGridView_1;
		}

		public DataGridViewRow method_0()
		{
			DataGridViewRow row = default(DataGridViewRow);
			try
			{
				Row = new DataGridViewRow();
				Row.CreateCells(Grid);
				if (CountryIndex != -1)
				{
					method_2(Row);
				}
				method_3();
				Row.Tag = this;
				row = Row;
				return row;
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				Interaction.MsgBox(ex2.Message);
				ProjectData.ClearProjectError();
			}
			return row;
		}

		public string method_1()
		{
			StringBuilder stringBuilder = new StringBuilder();
			checked
			{
				int num = Items.Length - 1;
				int num2 = num;
				for (int i = 0; i <= num2; i++)
				{
					if (i > 0)
					{
						stringBuilder.Append("|");
					}
					stringBuilder.Append(Items[i]);
				}
				return stringBuilder.ToString();
			}
		}

		private void method_2(DataGridViewRow dataGridViewRow_1)
		{
			int try0001_dispatch = -1;
			int num3 = default(int);
			int num2 = default(int);
			int num = default(int);
			string sCountry = default(string);
			string sCountryCode = default(string);
			string text = default(string);
			string text2 = default(string);
			while (true)
			{
				try
				{
					/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
					DataGP g_DataGP;
					string sIP;
					Image oImage;
					switch (try0001_dispatch)
					{
					default:
						ProjectData.ClearProjectError();
						num3 = -2;
						goto IL_000a;
					case 525:
						{
							num2 = num;
							switch ((num3 <= -2) ? 1 : num3)
							{
							case 1:
								break;
							default:
								goto end_IL_0001;
							}
							int num4 = num2 + 1;
							num2 = 0;
							switch (num4)
							{
							case 1:
								break;
							case 2:
								goto IL_000a;
							case 3:
								goto IL_001a;
							case 4:
								goto IL_0025;
							case 5:
								goto IL_0040;
							case 7:
								goto IL_005a;
							case 8:
								goto IL_0064;
							case 9:
								goto IL_0072;
							case 10:
							case 11:
								goto IL_0082;
							case 12:
								goto IL_008d;
							case 13:
								goto IL_00a7;
							case 14:
								goto IL_00b6;
							case 6:
							case 15:
							case 16:
							case 17:
							case 18:
								goto IL_00cf;
							case 19:
								goto IL_00db;
							case 20:
								goto IL_00e5;
							case 22:
								goto IL_00f7;
							case 21:
							case 23:
							case 24:
								goto IL_0111;
							case 25:
								goto IL_0122;
							case 27:
								goto end_IL_0001_2;
							default:
								goto end_IL_0001;
							case 26:
							case 28:
							case 29:
								goto end_IL_0001_3;
							}
							goto default;
						}
						IL_00f7:
						num = 22;
						Row.Cells[0].ToolTipText = sCountry;
						goto IL_0111;
						IL_0111:
						num = 24;
						Items[CountryIndex] = sCountry;
						goto IL_0122;
						IL_00e5:
						num = 20;
						sCountry = Globals.G_DataGP.CountryNameByCode(sCountryCode);
						goto IL_0111;
						IL_0122:
						num = 25;
						if (!sCountryCode.Equals("??") && !sCountryCode.Equals("EU"))
						{
							break;
						}
						goto end_IL_0001_3;
						IL_000a:
						num = 2;
						sCountry = Items[CountryIndex];
						goto IL_001a;
						IL_001a:
						num = 3;
						text = Items[0];
						goto IL_0025;
						IL_0025:
						num = 4;
						if (sCountry.Contains("[") & sCountry.Contains("]"))
						{
							goto IL_0040;
						}
						goto IL_005a;
						IL_0040:
						num = 5;
						sCountryCode = sCountry.Substring(1, checked(sCountry.IndexOf("]") - 1));
						goto IL_00cf;
						IL_005a:
						num = 7;
						sCountryCode = Class23.smethod_12(text);
						goto IL_0064;
						IL_0064:
						num = 8;
						if (!string.IsNullOrEmpty(sCountryCode))
						{
							goto IL_0072;
						}
						goto IL_0082;
						IL_0072:
						num = 9;
						sCountry = Globals.G_DataGP.CountryNameByCode(sCountryCode);
						goto IL_0082;
						IL_0082:
						num = 11;
						if (string.IsNullOrEmpty(sCountry))
						{
							goto IL_008d;
						}
						goto IL_00cf;
						IL_008d:
						num = 12;
						text2 = Globals.GMain.method_85(Class23.smethod_11(text)).ToString();
						goto IL_00a7;
						IL_00a7:
						num = 13;
						if (!string.IsNullOrEmpty(text2))
						{
							goto IL_00b6;
						}
						goto IL_00cf;
						IL_00b6:
						num = 14;
						g_DataGP = Globals.G_DataGP;
						sIP = text2;
						oImage = null;
						g_DataGP.Lookup(sIP, ref sCountry, ref oImage, ref sCountryCode, bUnionContryCode: true);
						goto IL_00cf;
						IL_00cf:
						num = 18;
						if (string.IsNullOrEmpty(sCountryCode))
						{
							goto IL_00db;
						}
						goto IL_00f7;
						IL_00db:
						num = 19;
						sCountryCode = "??";
						goto IL_00e5;
						end_IL_0001_2:
						break;
					}
					num = 27;
					Row.Cells[0].Value = Globals.GMain.imgData.Images[sCountryCode.ToLower() + ".png"];
					break;
					end_IL_0001:;
				}
				catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
				{
					ProjectData.SetProjectError((Exception)obj);
					try0001_dispatch = 525;
					continue;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				continue;
				end_IL_0001_3:
				break;
			}
			if (num2 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		public void method_3()
		{
			checked
			{
				if (Row.Cells.Count > Items.Length)
				{
					Items = (string[])Utils.CopyArray(Items, new string[Row.Cells.Count - 2 + 1]);
				}
				int num = Row.Cells.Count - 1;
				for (int i = 1; i <= num; i++)
				{
					if (Items[i - 1] == null)
					{
						Items[i - 1] = "";
					}
					Row.Cells[i].Value = Items[i - 1];
				}
			}
		}
	}

	[CompilerGenerated]
	internal sealed class Class31
	{
		public string string_0;

		[SpecialName]
		internal bool method_0(Class30 class30_0)
		{
			return class30_0.Items[0].Equals(string_0);
		}
	}

	[CompilerGenerated]
	internal sealed class Class32
	{
		public string string_0;

		[SpecialName]
		internal bool method_0(Class30 class30_0)
		{
			return class30_0.Items[0].ToLower().Contains(string_0.ToLower());
		}
	}

	[CompilerGenerated]
	internal sealed class Class33
	{
		public int int_0;

		public string string_0;

		[SpecialName]
		internal bool method_0(Class30 class30_0)
		{
			return class30_0.Items[int_0].ToLower().Contains(string_0.ToLower());
		}
	}

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_0;

	private List<Class30> list_0;

	private DataGridView dataGridView_0;

	private string string_0;

	private int int_0;

	private int int_1;

	private Enum2 enum2_0;

	private static char char_0;

	public bool AutoScroll
	{
		[CompilerGenerated]
		get
		{
			return bool_0;
		}
		[CompilerGenerated]
		set
		{
			bool_0 = value;
		}
	}

	public Class29(DataGridView dataGridView_1, string string_1, int int_2, int int_3)
	{
		enum2_0 = Enum2.const_0;
		dataGridView_0 = dataGridView_1;
		string_0 = string_1;
		int_0 = int_2;
		int_1 = int_3;
		dataGridView_0.Columns[0].DefaultCellStyle.NullValue = null;
	}

	public void method_0(Enum2 enum2_1)
	{
		enum2_0 = enum2_1;
	}

	public void method_1(object object_0)
	{
		if (dataGridView_0.InvokeRequired)
		{
			dataGridView_0.Invoke(new Delegate5(method_1), object_0);
		}
		else if (!method_9(Conversions.ToString(NewLateBinding.LateIndexGet(object_0, new object[1] { 0 }, null))))
		{
			Class30 @class = new Class30(dataGridView_0);
			@class.CountryIndex = int_0;
			@class.Items = (string[])object_0;
			list_0.Add(@class);
			dataGridView_0.Rows.Add(@class.method_0());
			if (AutoScroll)
			{
				dataGridView_0.FirstDisplayedScrollingRowIndex = checked(dataGridView_0.Rows.Count - 1);
			}
		}
	}

	public void method_2(object object_0)
	{
		if (dataGridView_0.InvokeRequired)
		{
			dataGridView_0.Invoke(new Delegate6(method_2), object_0);
			return;
		}
		List<Class30> list = new List<Class30>();
		if (object_0 is List<DataGridViewRow>)
		{
			list.AddRange(Array.ConvertAll(((List<DataGridViewRow>)object_0).ToArray(), method_22));
		}
		else if (object_0 is DataGridViewRow)
		{
			list.Add((Class30)((DataGridViewRow)object_0).Tag);
		}
		else if (object_0 is List<Class30>)
		{
			list.AddRange(((List<Class30>)object_0).ToArray());
		}
		else if (object_0 is Class30)
		{
			list.Add((Class30)object_0);
		}
		if (list.Count > 100)
		{
			List<Class30> list2 = new List<Class30>();
			foreach (DataGridViewRow item2 in (IEnumerable)dataGridView_0.Rows)
			{
				Class30 item = (Class30)item2.Tag;
				if (!list.Contains(item))
				{
					list2.Add(item);
				}
			}
			if (list.Count > 0)
			{
				while (list.Count > 0)
				{
					list_0.Remove(list[0]);
					list.RemoveAt(0);
				}
			}
			Globals.LockWindowUpdate(dataGridView_0.Handle);
			dataGridView_0.Rows.Clear();
			dataGridView_0.ClearSelection();
			if (list2.Count > 0)
			{
				dataGridView_0.Rows.AddRange(Array.ConvertAll(list2.ToArray(), method_21));
			}
			Globals.LockWindowUpdate(IntPtr.Zero);
		}
		else if (list.Count > 0)
		{
			while (list.Count > 0)
			{
				list_0.Remove(list[0]);
				dataGridView_0.Rows.Remove(list[0].Row);
				list.RemoveAt(0);
			}
		}
	}

	public void method_3(string string_1, int int_2, DataGridViewRow dataGridViewRow_0)
	{
		if (dataGridView_0.InvokeRequired)
		{
			dataGridView_0.Invoke(new Delegate7(method_3), string_1, int_2, dataGridViewRow_0);
			return;
		}
		Class30 @class = (Class30)dataGridViewRow_0.Tag;
		if (list_0.Contains(@class))
		{
			@class.Items[int_2] = string_1;
			@class.method_3();
		}
	}

	public void method_4()
	{
		if (dataGridView_0.SelectedRows.Count == list_0.Count)
		{
			method_7();
		}
		else
		{
			method_2(method_20());
		}
	}

	public int method_5()
	{
		return list_0.Count;
	}

	public int method_6()
	{
		return dataGridView_0.Rows.Count;
	}

	public void method_7()
	{
		list_0 = new List<Class30>();
		dataGridView_0.Rows.Clear();
	}

	public void method_8()
	{
		dataGridView_0.SelectAll();
	}

	public bool method_9(string string_1)
	{
		Class30 @class = null;
		try
		{
			@class = list_0.Find([SpecialName] (Class30 class30_0) => class30_0.Items[0].Equals(string_1));
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		if (@class == null)
		{
			return false;
		}
		return true;
	}

	public bool method_10(string string_1)
	{
		string string_0 = Class23.smethod_10(string_1);
		Class30 @class = null;
		try
		{
			@class = list_0.Find([SpecialName] (Class30 class30_0) => class30_0.Items[0].ToLower().Contains(string_0.ToLower()));
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		if (@class == null)
		{
			return false;
		}
		return true;
	}

	public bool method_11()
	{
		bool result;
		try
		{
			if (File.Exists(string_0))
			{
				File.Delete(string_0);
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (Class30 item in list_0)
			{
				stringBuilder.Append(item.method_1() + "\r\n");
			}
			if (!string.IsNullOrEmpty(Conversions.ToString(stringBuilder.Length)))
			{
				File.AppendAllText(string_0, stringBuilder.ToString());
			}
			result = true;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			result = false;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public void method_12(bool bool_1)
	{
		method_7();
		method_18();
		if (bool_1)
		{
			method_16();
		}
	}

	public void method_13(string string_1, int int_2 = 0)
	{
		Globals.LockWindowUpdate(dataGridView_0.Handle);
		dataGridView_0.ClearSelection();
		dataGridView_0.Rows.Clear();
		if (string.IsNullOrEmpty(string_1) & (enum2_0 == Enum2.const_0))
		{
			method_16();
		}
		else
		{
			List<Class30> list = ((!string.IsNullOrEmpty(string_1)) ? list_0.FindAll([SpecialName] (Class30 class30_0) => class30_0.Items[int_2].ToLower().Contains(string_1.ToLower())) : list_0);
			if (list.Count > 0)
			{
				list = list.FindAll(method_14);
				if (list != null)
				{
					dataGridView_0.Rows.AddRange(Array.ConvertAll(list.ToArray(), method_21));
				}
			}
		}
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	private bool method_14(Class30 class30_0)
	{
		bool result = default(bool);
		try
		{
			if (enum2_0 == Enum2.const_0)
			{
				result = true;
			}
			else if (enum2_0 == Enum2.const_1)
			{
				result = Process.GetCurrentProcess().StartTime.Subtract(DateTime.Parse(class30_0.Items[int_1].ToString(), CultureInfo.InvariantCulture.DateTimeFormat)).TotalMinutes <= 1.0;
			}
			else
			{
				TimeSpan timeSpan = DateAndTime.Now.Subtract(DateTime.Parse(class30_0.Items[int_1].ToString(), CultureInfo.InvariantCulture.DateTimeFormat));
				if (enum2_0 == Enum2.const_2)
				{
					result = timeSpan.TotalDays <= 1.0;
				}
				else if (enum2_0 == Enum2.const_3)
				{
					result = timeSpan.TotalDays <= 7.0;
				}
				else if (enum2_0 == Enum2.const_4)
				{
					result = timeSpan.TotalDays <= 30.0;
				}
				else if (enum2_0 == Enum2.const_5)
				{
					result = timeSpan.TotalDays <= 90.0;
				}
				else if (enum2_0 == Enum2.const_6)
				{
					result = timeSpan.TotalDays >= 90.0;
				}
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			class30_0.Items[int_1] = DateAndTime.Now.ToString(CultureInfo.InvariantCulture.DateTimeFormat);
			result = false;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public void method_15()
	{
		List<Class30> list = method_20();
		if (list.Count > 0)
		{
			dataGridView_0.Rows.Clear();
			dataGridView_0.Rows.AddRange(Array.ConvertAll(list.ToArray(), method_21));
		}
	}

	private void method_16()
	{
		if (list_0.Count > 0)
		{
			dataGridView_0.Rows.AddRange(Array.ConvertAll(list_0.ToArray(), method_21));
		}
	}

	public void method_17(List<Class30> list_1)
	{
		if (dataGridView_0.InvokeRequired)
		{
			dataGridView_0.Invoke((Delegate5)([SpecialName] [DebuggerHidden] (object object_0) =>
			{
				method_17((List<Class30>)object_0);
			}), list_1);
		}
		else
		{
			list_0.AddRange(list_1.ToArray());
			dataGridView_0.Rows.AddRange(Array.ConvertAll(list_1.ToArray(), method_21));
		}
	}

	private void method_18()
	{
		List<Class30> list = new List<Class30>();
		foreach (string item in method_19())
		{
			string current = item.Trim();
			if (current.Contains("|"))
			{
				string[] array = Strings.Split(current, "|");
				if (array.Length >= checked(dataGridView_0.Columns.Count - 2))
				{
					Class30 @class = new Class30(dataGridView_0);
					@class.CountryIndex = int_0;
					@class.Items = array;
					list.Add(@class);
				}
			}
		}
		if (list.Count > 0)
		{
			list_0.AddRange(list);
		}
	}

	private List<string> method_19()
	{
		List<string> list = new List<string>();
		if (File.Exists(string_0))
		{
			list.AddRange(File.ReadAllLines(string_0));
		}
		return list;
	}

	private List<Class30> method_20()
	{
		List<Class30> list = new List<Class30>();
		foreach (DataGridViewRow selectedRow in dataGridView_0.SelectedRows)
		{
			if (selectedRow.Selected)
			{
				list.Add((Class30)selectedRow.Tag);
			}
		}
		return list;
	}

	private DataGridViewRow method_21(Class30 class30_0)
	{
		return class30_0.method_0();
	}

	private Class30 method_22(DataGridViewRow dataGridViewRow_0)
	{
		return (Class30)dataGridViewRow_0.Tag;
	}

	[SpecialName]
	[DebuggerHidden]
	[CompilerGenerated]
	private void method_23(object object_0)
	{
		method_17((List<Class30>)object_0);
	}
}
