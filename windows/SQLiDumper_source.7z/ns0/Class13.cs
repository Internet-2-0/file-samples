using System.Security.Cryptography;
using System.Text;

namespace ns0;

internal sealed class Class13
{
	public static byte[] smethod_0(byte[] byte_0, string string_0, CipherMode cipherMode_0 = CipherMode.ECB, PaddingMode paddingMode_0 = PaddingMode.PKCS7)
	{
		MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
		byte[] key = mD5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(string_0));
		mD5CryptoServiceProvider.Clear();
		TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
		tripleDESCryptoServiceProvider.Key = key;
		tripleDESCryptoServiceProvider.Mode = cipherMode_0;
		tripleDESCryptoServiceProvider.Padding = paddingMode_0;
		ICryptoTransform cryptoTransform = tripleDESCryptoServiceProvider.CreateEncryptor();
		byte[] result = cryptoTransform.TransformFinalBlock(byte_0, 0, byte_0.Length);
		tripleDESCryptoServiceProvider.Clear();
		return result;
	}

	public static byte[] smethod_1(byte[] byte_0, string string_0, CipherMode cipherMode_0 = CipherMode.ECB, PaddingMode paddingMode_0 = PaddingMode.PKCS7)
	{
		MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
		byte[] key = mD5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(string_0));
		mD5CryptoServiceProvider.Clear();
		TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
		tripleDESCryptoServiceProvider.Key = key;
		tripleDESCryptoServiceProvider.Mode = cipherMode_0;
		tripleDESCryptoServiceProvider.Padding = paddingMode_0;
		ICryptoTransform cryptoTransform = tripleDESCryptoServiceProvider.CreateDecryptor();
		byte[] result = cryptoTransform.TransformFinalBlock(byte_0, 0, byte_0.Length);
		tripleDESCryptoServiceProvider.Clear();
		return result;
	}
}
