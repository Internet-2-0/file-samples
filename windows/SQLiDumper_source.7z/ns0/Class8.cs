using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class8 : IDisposable
{
	private delegate bool Delegate0(IntPtr hWnd, IntPtr lp);

	private struct Struct0
	{
		public int int_0;

		public int int_1;

		public int int_2;

		public int int_3;
	}

	private int int_0;

	private Form form_0;

	public Class8(Form form_1)
	{
		int_0 = 0;
		form_0 = form_1;
		form_1.BeginInvoke(new MethodInvoker(method_0));
	}

	[DllImport("user32.dll")]
	private static extern bool EnumThreadWindows(int int_1, Delegate0 delegate0_0, IntPtr intptr_0);

	[DllImport("kernel32.dll")]
	private static extern int GetCurrentThreadId();

	[DllImport("user32.dll")]
	private static extern int GetClassName(IntPtr intptr_0, StringBuilder stringBuilder_0, int int_1);

	[DllImport("user32.dll")]
	private static extern bool GetWindowRect(IntPtr intptr_0, ref Struct0 struct0_0);

	[DllImport("user32.dll")]
	private static extern bool MoveWindow(IntPtr intptr_0, int int_1, int int_2, int int_3, int int_4, bool bool_0);

	private void method_0()
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		Delegate0 delegate0_ = default(Delegate0);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 168:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 4:
						case 5:
							goto IL_0017;
						case 6:
							goto IL_0026;
						case 7:
							goto IL_003a;
						case 8:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
						case 9:
						case 10:
						case 11:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_0017:
					num = 5;
					delegate0_ = method_1;
					goto IL_0026;
					IL_0026:
					num = 6;
					if (!EnumThreadWindows(GetCurrentThreadId(), delegate0_, IntPtr.Zero))
					{
						goto end_IL_0001_3;
					}
					goto IL_003a;
					IL_000a:
					num = 2;
					if (int_0 < 0)
					{
						goto end_IL_0001_3;
					}
					goto IL_0017;
					IL_003a:
					num = 7;
					if (Interlocked.Increment(ref int_0) >= 10)
					{
						goto end_IL_0001_3;
					}
					break;
					end_IL_0001_2:
					break;
				}
				num = 8;
				form_0.BeginInvoke(new MethodInvoker(method_0));
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 168;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private bool method_1(IntPtr intptr_0, IntPtr intptr_1)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		Rectangle rectangle = default(Rectangle);
		Struct0 struct0_ = default(Struct0);
		bool result = default(bool);
		StringBuilder stringBuilder = default(StringBuilder);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				checked
				{
					switch (try0001_dispatch)
					{
					default:
						ProjectData.ClearProjectError();
						num3 = -2;
						goto IL_000a;
					case 293:
						{
							num2 = num;
							switch ((num3 <= -2) ? 1 : num3)
							{
							case 1:
								break;
							default:
								goto end_IL_0001;
							}
							int num4 = unchecked(num2 + 1);
							num2 = 0;
							switch (num4)
							{
							case 1:
								break;
							case 2:
								goto IL_000a;
							case 3:
								goto IL_0017;
							case 4:
								goto IL_0027;
							case 5:
								goto IL_003f;
							case 6:
							case 7:
								goto IL_0048;
							case 8:
								goto IL_0067;
							case 9:
								goto IL_0072;
							case 10:
								goto end_IL_0001_2;
							default:
								goto end_IL_0001;
							case 11:
								goto end_IL_0001_3;
							}
							goto default;
						}
						IL_0048:
						num = 7;
						rectangle = new Rectangle(form_0.Location, form_0.Size);
						goto IL_0067;
						IL_0067:
						num = 8;
						GetWindowRect(intptr_0, ref struct0_);
						goto IL_0072;
						IL_003f:
						num = 5;
						result = true;
						goto end_IL_0001_3;
						IL_0072:
						num = 9;
						MoveWindow(intptr_0, rectangle.Left + unchecked(checked(rectangle.Width - struct0_.int_2 + struct0_.int_0) / 2), rectangle.Top + unchecked(checked(rectangle.Height - struct0_.int_3 + struct0_.int_1) / 2), struct0_.int_2 - struct0_.int_0, struct0_.int_3 - struct0_.int_1, bool_0: true);
						break;
						IL_000a:
						num = 2;
						stringBuilder = new StringBuilder(260);
						goto IL_0017;
						IL_0017:
						num = 3;
						GetClassName(intptr_0, stringBuilder, stringBuilder.Capacity);
						goto IL_0027;
						IL_0027:
						num = 4;
						if (Operators.CompareString(stringBuilder.ToString(), "#32770", TextCompare: false) != 0)
						{
							goto IL_003f;
						}
						goto IL_0048;
						end_IL_0001_2:
						break;
					}
					num = 10;
					result = false;
					break;
				}
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 293;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public void Dispose()
	{
		int_0 = -1;
	}
}
