namespace ns0;

internal enum Enum3
{
	const_0 = 0,
	const_1 = 1,
	const_2 = 2,
	const_3 = 4,
	const_4 = 8
}
