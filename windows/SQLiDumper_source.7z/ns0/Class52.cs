namespace ns0;

internal sealed class Class52
{
	private string string_0;

	private string string_1;

	private string string_2;

	internal string String_0
	{
		get
		{
			return string_0;
		}
		set
		{
			string_0 = value;
		}
	}

	internal string String_1
	{
		get
		{
			return string_1;
		}
		set
		{
			string_1 = value;
		}
	}

	internal string String_2
	{
		get
		{
			return string_2;
		}
		set
		{
			string_2 = value;
		}
	}
}
