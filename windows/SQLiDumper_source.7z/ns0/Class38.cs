using System.Runtime.InteropServices;

namespace ns0;

[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("56FDF344-FD6D-11d0-958A-006097C9A090")]
internal sealed class Class38
{
}
