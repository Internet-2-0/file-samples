using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Windows.Forms;
using Chilkat;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class23
{
	public static Globals.WebServer smethod_0(string string_0, string string_1, HTTP http_0)
	{
		Globals.WebServer result = Globals.WebServer.UNKNOW;
		if (http_0.o != null)
		{
			result = ((http_0.o.LastResponseHeader.ToLower().Contains("iis") | http_0.o.LastResponseHeader.ToLower().Contains("microsoft")) ? Globals.WebServer.WINDOWS : (string_0.Contains(".php") ? Globals.WebServer.LINUX : ((!string_0.Contains(".asp")) ? Globals.WebServer.LINUX : Globals.WebServer.WINDOWS)));
		}
		return result;
	}

	public static string smethod_1(string string_0)
	{
		return SecurityElement.Escape(string_0);
	}

	public static string smethod_2(string string_0)
	{
		return SecurityElement.FromString(string_0).Text;
	}

	public static List<string> smethod_3(string string_0)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Expected O, but got Unknown
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Expected O, but got Unknown
		List<string> list = new List<string>();
		StringArray val = new StringArray();
		HtmlUtil val2 = new HtmlUtil();
		val = val2.GetHyperlinkedUrls(string_0);
		checked
		{
			int num = val.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				string @string = val.GetString(i);
				if (!list.Contains(@string))
				{
					list.Add(@string);
				}
			}
			return list;
		}
	}

	public static List<string> smethod_4(string string_0)
	{
		List<string> list = new List<string>();
		try
		{
			string pattern = "href\\s*=\\s*(?:[\"'](?<1>[^\"']*)[\"']|(?<1>\\S+))";
			Match match = Regex.Match(string_0, pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled, TimeSpan.FromSeconds(1.0));
			while (match.Success)
			{
				list.Add(match.Value);
				match = match.NextMatch();
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return list;
	}

	public static string smethod_5(string string_0)
	{
		return HttpUtility.HtmlDecode(string_0);
	}

	public static string smethod_6(string string_0)
	{
		return HttpUtility.HtmlEncode(string_0);
	}

	public static string smethod_7(string string_0)
	{
		if (string.IsNullOrEmpty(string_0))
		{
			return "";
		}
		string_0 = string_0.Replace("  ", " ");
		return HttpUtility.UrlEncode(string_0);
	}

	public static string smethod_8(string string_0)
	{
		return HttpUtility.UrlDecode(string_0);
	}

	public static bool smethod_9(string string_0)
	{
		return string_0.Contains("=") && string_0.Contains("?");
	}

	public static string smethod_10(string string_0)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Expected O, but got Unknown
		Url val = new Url();
		if (val.ParseUrl(string_0))
		{
			return val.Host;
		}
		return "";
	}

	public static string smethod_11(string string_0)
	{
		string result;
		try
		{
			Uri uri = new Uri(string_0);
			result = uri.Host.Replace("www.", "");
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			result = smethod_10(string_0);
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public static string smethod_12(string string_0)
	{
		try
		{
			Uri uri = new Uri(string_0);
			int num = uri.Host.LastIndexOf(".");
			if (num > 0)
			{
				return uri.Host.Substring(checked(num + 1));
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return "";
	}

	public static bool smethod_13(string string_0, bool bool_0 = true)
	{
		try
		{
			string_0 = string_0.ToLower();
			if (bool_0)
			{
				if (string_0.Contains(".qwant."))
				{
					return false;
				}
				if (string_0.Contains(".startpage."))
				{
					return false;
				}
				if (string_0.Contains(".wenglor."))
				{
					return false;
				}
				if (string_0.Contains(".autarcon."))
				{
					return false;
				}
				if (string_0.Contains(".hyperoutlet."))
				{
					return false;
				}
				if (string_0.Contains(".utfkiev."))
				{
					return false;
				}
				if (string_0.Contains(".enermax."))
				{
					return false;
				}
				if (string_0.Contains(".cefetra."))
				{
					return false;
				}
				if (string_0.Contains("adw.sapo"))
				{
					return false;
				}
				if (string_0.Contains("pastebin."))
				{
					return false;
				}
				if (string_0.Contains("webcache."))
				{
					return false;
				}
				if (string_0.Contains("google."))
				{
					return false;
				}
				if (string_0.Contains("opera."))
				{
					return false;
				}
				if (string_0.Contains("mozilla"))
				{
					return false;
				}
				if (string_0.Contains("apple."))
				{
					return false;
				}
				if (string_0.Contains("twitter."))
				{
					return false;
				}
				if (string_0.Contains("paypal."))
				{
					return false;
				}
				if (string_0.Contains("yahoo."))
				{
					return false;
				}
				if (string_0.Contains("microsoft."))
				{
					return false;
				}
				if (string_0.Contains(".microsoft"))
				{
					return false;
				}
				if (string_0.Contains("bing."))
				{
					return false;
				}
				if (string_0.Contains("msn."))
				{
					return false;
				}
				if (string_0.Contains("youtube."))
				{
					return false;
				}
				if (string_0.Contains("ask."))
				{
					return false;
				}
				if (string_0.Contains("aol."))
				{
					return false;
				}
				if (string_0.Contains("nintendo."))
				{
					return false;
				}
				if (string_0.Contains("facebook."))
				{
					return false;
				}
				if (string_0.Contains("instagram."))
				{
					return false;
				}
				if (string_0.Contains("stackoverflow."))
				{
					return false;
				}
				if (string_0.Contains("cnet."))
				{
					return false;
				}
				if (string_0.Contains("ebay."))
				{
					return false;
				}
				if (string_0.Contains("amazon."))
				{
					return false;
				}
				if (string_0.Contains("yandex."))
				{
					return false;
				}
				if (string_0.Contains("exploit."))
				{
					return false;
				}
				if (string_0.Contains("ixquick"))
				{
					return false;
				}
				if (string_0.Contains("twitter."))
				{
					return false;
				}
				if (string_0.Contains("live."))
				{
					return false;
				}
				if (string_0.Contains("oracle."))
				{
					return false;
				}
				if (string_0.Contains("blogger."))
				{
					return false;
				}
				if (string_0.Contains("linkedin."))
				{
					return false;
				}
				if (string_0.Contains("symantec."))
				{
					return false;
				}
				if (string_0.Contains("vmware."))
				{
					return false;
				}
				if (string_0.Contains("github."))
				{
					return false;
				}
				if (string_0.Contains("sourceforge."))
				{
					return false;
				}
				if (string_0.Contains("wikipedia."))
				{
					return false;
				}
				if (string_0.Contains("rambler.ru"))
				{
					return false;
				}
				if (string_0.Contains("yandex"))
				{
					return false;
				}
				foreach (object item in (IEnumerable)Globals.GetObjectValue(Globals.GMain.lstExcludeUrlWords))
				{
					string value = Conversions.ToString(item);
					if (string_0.Contains(value))
					{
						return false;
					}
				}
			}
			if (string_0.Length < 12)
			{
				return false;
			}
			if (string_0.StartsWith("http://") || string_0.StartsWith("https://"))
			{
				return true;
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return false;
	}

	public static string smethod_14(string string_0)
	{
		NameValueCollection nameValueCollection = HttpUtility.ParseQueryString(string_0);
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (nameValueCollection != null)
			{
				int num = nameValueCollection.AllKeys.Count() - 1;
				int num2 = num;
				for (int i = 0; i <= num2; i++)
				{
					string text = nameValueCollection.Keys[i];
					if (!string.IsNullOrEmpty(text))
					{
						stringBuilder.Append(text + "=");
					}
					if (i < num)
					{
						stringBuilder.Append("&");
					}
				}
			}
			nameValueCollection = null;
			if (string.IsNullOrEmpty(stringBuilder.ToString()))
			{
				return string_0;
			}
			return stringBuilder.ToString();
		}
	}

	public static string smethod_15(string string_0)
	{
		NameValueCollection nameValueCollection = HttpUtility.ParseQueryString(string_0);
		checked
		{
			string text3 = default(string);
			if (nameValueCollection != null)
			{
				int num = nameValueCollection.AllKeys.Count() - 1;
				int num2 = num;
				for (int i = 0; i <= num2; i++)
				{
					string text = nameValueCollection.Keys[i];
					if (!string.IsNullOrEmpty(text))
					{
						string text2 = nameValueCollection[text].ToLower();
						if (text2.Contains("select") | text2.Contains("convert") | text2.Contains("cast(") | text2.Contains("into outfile") | text2.Contains("into dumpfile"))
						{
							string string_ = nameValueCollection[text];
							string_ = smethod_7(string_);
							Class54.smethod_1(ref string_);
							text3 = smethod_18(nameValueCollection, i, string_);
							break;
						}
					}
				}
			}
			nameValueCollection = null;
			if (string.IsNullOrEmpty(text3))
			{
				text3 = string_0;
			}
			return text3;
		}
	}

	public static List<string> smethod_16(string string_0, string string_1, bool bool_0)
	{
		NameValueCollection nameValueCollection = HttpUtility.ParseQueryString(string_0);
		List<string> list = new List<string>();
		checked
		{
			if (nameValueCollection != null)
			{
				int num = nameValueCollection.AllKeys.Count() - 1;
				int num2 = num;
				for (int i = 0; i <= num2; i++)
				{
					string text = nameValueCollection.Keys[i];
					if (!string.IsNullOrEmpty(text) && (!bool_0 || !Versioned.IsNumeric(nameValueCollection[text])))
					{
						list.Add(smethod_18(nameValueCollection, i, string_1));
					}
				}
			}
			nameValueCollection = null;
			return list;
		}
	}

	public static List<string> smethod_17(string string_0, string string_1, bool bool_0, bool bool_1)
	{
		NameValueCollection nameValueCollection = HttpUtility.ParseQueryString(string_0);
		List<string> list = new List<string>();
		checked
		{
			if (nameValueCollection != null)
			{
				int num = nameValueCollection.AllKeys.Count() - 1;
				int num2 = num;
				for (int i = 0; i <= num2; i++)
				{
					string text = nameValueCollection.Keys[i];
					if (!string.IsNullOrEmpty(text))
					{
						if (bool_0 && Versioned.IsNumeric(nameValueCollection[text]))
						{
							list.Add(smethod_18(nameValueCollection, i, string_1, bool_1));
						}
						else if (!bool_0)
						{
							list.Add(smethod_18(nameValueCollection, i, string_1, bool_1));
						}
					}
				}
			}
			nameValueCollection = null;
			return list;
		}
	}

	private static string smethod_18(NameValueCollection nameValueCollection_0, int int_0, string string_0, bool bool_0 = false)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			int num = nameValueCollection_0.AllKeys.Count() - 1;
			int num2 = num;
			for (int i = 0; i <= num2; i++)
			{
				string text = nameValueCollection_0.Keys[i];
				if (!string.IsNullOrEmpty(text))
				{
					if (i == int_0)
					{
						if (bool_0)
						{
							stringBuilder.Append(text + "=" + nameValueCollection_0[text] + string_0);
						}
						else
						{
							stringBuilder.Append(text + "=" + string_0);
						}
					}
					else
					{
						stringBuilder.Append(text + "=" + nameValueCollection_0[text]);
					}
				}
				if (i < num)
				{
					stringBuilder.Append("&");
				}
			}
			return stringBuilder.ToString();
		}
	}

	public static string smethod_19(string string_0)
	{
		checked
		{
			string result;
			try
			{
				if (string.IsNullOrEmpty(string_0))
				{
					result = "";
				}
				else
				{
					string text = string_0;
					string text2 = "";
					string text3 = "";
					if (text.StartsWith("0x"))
					{
						text = text.Substring(2);
					}
					for (int i = 0; i < text.Length; i += 2)
					{
						text3 = text.Substring(i, 2);
						text2 += Conversions.ToString(Strings.ChrW((int)uint.Parse(text3, NumberStyles.HexNumber)));
					}
					if (text2.Contains("\u0012"))
					{
						text2 = Conversions.ToString(Conversion.Val("&H" + string_0));
					}
					result = text2;
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				result = string_0;
				ProjectData.ClearProjectError();
			}
			return result;
		}
	}

	public static string smethod_20(string string_0)
	{
		checked
		{
			string result;
			try
			{
				if (string.IsNullOrEmpty(string_0))
				{
					result = "";
				}
				else
				{
					char[] chars = string_0.ToCharArray();
					byte[] bytes = Encoding.ASCII.GetBytes(chars);
					string text = "";
					int num = bytes.Length - 1;
					for (int i = 0; i <= num; i++)
					{
						text += $"{bytes[i]:x2}";
					}
					result = "0x" + text;
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				result = string_0;
				ProjectData.ClearProjectError();
			}
			return result;
		}
	}

	public static string smethod_21(string string_0, bool bool_0, string string_1 = "+", string string_2 = "char")
	{
		checked
		{
			string result;
			try
			{
				if (string.IsNullOrEmpty(string_0))
				{
					result = "";
				}
				else
				{
					char[] chars = string_0.ToCharArray();
					byte[] bytes = Encoding.ASCII.GetBytes(chars);
					string text = "";
					int num = bytes.Length - 1;
					for (int i = 0; i <= num; i++)
					{
						text = ((!bool_0) ? ((i != 0) ? (text + string_1 + string_2 + "(" + Convert.ToString(bytes[i]) + ")") : (text + string_2 + "(" + Convert.ToString(bytes[i]) + ")")) : ((i != 0) ? (text + "," + Convert.ToString(bytes[i])) : (text + string_2 + "(" + Convert.ToString(bytes[i]))));
					}
					if (bool_0)
					{
						text += ")";
					}
					result = text;
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				result = "ERROR: " + ex2.Message;
				ProjectData.ClearProjectError();
			}
			return result;
		}
	}

	public static string smethod_22(string string_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		CharacterCasing characterCasing = CharacterCasing.Normal;
		char[] array = string_0.ToCharArray();
		foreach (char c in array)
		{
			if ("abcdefghijklmnopqrstuvwxyz".Contains(Conversions.ToString(c)))
			{
				switch (characterCasing)
				{
				case CharacterCasing.Normal:
				case CharacterCasing.Upper:
					stringBuilder.Append(char.ToLower(c));
					characterCasing = CharacterCasing.Lower;
					break;
				case CharacterCasing.Lower:
					stringBuilder.Append(char.ToUpper(c));
					characterCasing = CharacterCasing.Upper;
					break;
				}
			}
			else
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.ToString();
	}
}
