using System;
using System.Text;

namespace ns0;

internal sealed class Class12
{
	public static byte[] smethod_0(byte[] byte_0, string string_0)
	{
		return smethod_2(byte_0, smethod_4(string_0));
	}

	public static byte[] smethod_1(byte[] byte_0, string string_0)
	{
		return smethod_2(byte_0, smethod_4(string_0));
	}

	private static byte[] smethod_2(byte[] byte_0, byte[] byte_1)
	{
		int[] int_;
		int num;
		int num2;
		int num3;
		checked
		{
			_ = new byte[byte_0.Length + 1];
			int_ = new int[257];
			num = 0;
			num2 = 0;
			smethod_3(byte_1, ref int_);
			num3 = byte_0.Length - 1;
		}
		for (int i = 0; i <= num3; i = checked(i + 1))
		{
			num = checked(num + 1) % 256;
			num2 = checked(num2 + int_[num]) % 256;
			int num4 = int_[num];
			int_[num] = int_[num2];
			int_[num2] = num4;
			int value = int_[checked(int_[num] + int_[num2]) % 256];
			byte_0[i] ^= Convert.ToByte(value);
		}
		return byte_0;
	}

	protected static void smethod_3(byte[] byte_0, ref int[] int_0)
	{
		int num = byte_0.Length;
		int num2 = 0;
		do
		{
			int_0[num2] = num2;
			num2 = checked(num2 + 1);
		}
		while (num2 <= 255);
		int num3 = 0;
		num2 = 0;
		do
		{
			num3 = checked(num3 + int_0[num2] + byte_0[unchecked(num2 % num)]) % 256;
			int num4 = int_0[num2];
			int_0[num2] = int_0[num3];
			int_0[num3] = num4;
			num2 = checked(num2 + 1);
		}
		while (num2 <= 255);
	}

	private static byte[] smethod_4(string string_0)
	{
		ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
		return aSCIIEncoding.GetBytes("\0" + string_0 + "\0");
	}
}
