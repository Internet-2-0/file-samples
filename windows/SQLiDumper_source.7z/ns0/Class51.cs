using System;
using System.Collections;
using System.IO;
using System.Xml;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class51
{
	private string string_0;

	private string string_1;

	private char char_0;

	private XmlDocument xmlDocument_0;

	public string String_0
	{
		get
		{
			return string_0;
		}
		set
		{
			string_0 = value.Trim();
		}
	}

	public string String_1
	{
		get
		{
			return string_1;
		}
		set
		{
			string_1 = value.Trim();
		}
	}

	public char Char_0
	{
		get
		{
			return char_0;
		}
		set
		{
			char_0 = value;
		}
	}

	public Class51(string string_2, string string_3 = "SQLi_Dumper", char char_1 = ';', int int_0 = 0)
	{
		string_1 = string_3.Trim();
		char_0 = char_1;
		if (int_0 == 0)
		{
			string_0 = string_2;
			method_0();
		}
		else
		{
			xmlDocument_0 = new XmlDocument();
			xmlDocument_0.LoadXml(string_2);
		}
	}

	~Class51()
	{
		xmlDocument_0 = null;
		base.Finalize();
	}

	private void method_0()
	{
		try
		{
			if (File.Exists(string_0) || string_0.ToLower().StartsWith("http"))
			{
				XmlTextReader xmlTextReader = new XmlTextReader(string_0);
				xmlDocument_0 = new XmlDocument();
				xmlDocument_0.Load(xmlTextReader);
				xmlTextReader.Close();
				xmlTextReader = null;
			}
		}
		catch (XmlException projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		if (xmlDocument_0 == null)
		{
			xmlDocument_0 = new XmlDocument();
			xmlDocument_0.LoadXml("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<" + string_1 + ">\r\n</" + string_1 + ">");
		}
	}

	internal Hashtable method_1()
	{
		Hashtable hashtable = new Hashtable();
		XmlNodeList xmlNodeList = xmlDocument_0.SelectNodes("//Section");
		if (xmlNodeList != null)
		{
			foreach (XmlNode item in xmlNodeList)
			{
				hashtable.Add(item.Attributes["Name"].Value, item);
			}
		}
		xmlNodeList = null;
		XmlNode xmlNode = null;
		return hashtable;
	}

	internal Hashtable method_2(string string_2)
	{
		Hashtable hashtable = new Hashtable();
		string[] array = ((Strings.InStr(string_2, Conversions.ToString(char_0)) != 0) ? Strings.Split(string_2, Conversions.ToString(char_0)) : new string[1] { string_2 });
		try
		{
			string[] array2 = array;
			XmlNodeList xmlNodeList;
			foreach (string text in array2)
			{
				XmlNode xmlNode = xmlDocument_0.SelectSingleNode("//Section[@Name='" + text + "']");
				if (xmlNode == null)
				{
					continue;
				}
				xmlNodeList = xmlNode.SelectNodes("descendant::Key");
				if (xmlNodeList == null)
				{
					continue;
				}
				foreach (XmlNode item in xmlNodeList)
				{
					Class52 @class = new Class52();
					@class.String_0 = item.Attributes["Name"].Value;
					@class.String_1 = item.Attributes["Value"].Value;
					@class.String_2 = text;
					hashtable.Add(item.Attributes["Name"].Value, @class);
				}
			}
			xmlNodeList = null;
			XmlNode xmlNode2 = null;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return hashtable;
	}

	internal string method_3(string string_2, string string_3, string string_4)
	{
		string text = method_4(string_2, string_3);
		if (string.IsNullOrEmpty(text))
		{
			return string_4;
		}
		return text;
	}

	internal string method_4(string string_2, string string_3)
	{
		string result = string.Empty;
		XmlNode xmlNode = xmlDocument_0.SelectSingleNode("//Section[@Name='" + string_2 + "']");
		XmlNode xmlNode2;
		if (xmlNode != null)
		{
			xmlNode2 = xmlNode.SelectSingleNode("descendant::Key[@Name='" + string_3 + "']");
			if (xmlNode2 != null)
			{
				result = xmlNode2.Attributes["Value"].Value;
			}
		}
		xmlNode = null;
		xmlNode2 = null;
		return result;
	}

	public string method_5(string string_2, string string_3, string string_4 = "")
	{
		string text = "";
		try
		{
			XmlNodeList elementsByTagName = xmlDocument_0.GetElementsByTagName(string_2);
			if (elementsByTagName.Count > 0)
			{
				text = elementsByTagName[0].Attributes[string_3].Value;
				if (Versioned.IsNumeric(text))
				{
					text = Strings.FormatNumber(Conversions.ToDouble(text), 0).ToString();
				}
			}
			if (string.IsNullOrEmpty(text))
			{
				text = string_4;
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return text;
	}

	internal void method_6(string string_2, string string_3, string string_4)
	{
		if (xmlDocument_0.DocumentElement == null)
		{
			xmlDocument_0.LoadXml("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<" + string_1 + ">\r\n</" + string_1 + ">");
			return;
		}
		XmlNode xmlNode = xmlDocument_0.SelectSingleNode("//Section[@Name='" + string_2 + "']");
		if (xmlNode == null)
		{
			try
			{
				xmlNode = xmlDocument_0.CreateNode(XmlNodeType.Element, "Section", "");
				XmlAttribute xmlAttribute = xmlDocument_0.CreateAttribute("Name");
				xmlAttribute.Value = string_2;
				xmlNode.Attributes.SetNamedItem(xmlAttribute);
				XmlNode documentElement = xmlDocument_0.DocumentElement;
				documentElement.AppendChild(xmlNode);
				documentElement = null;
			}
			catch (XmlException projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
		XmlNode xmlNode2 = xmlNode.SelectSingleNode("descendant::Key[@Name='" + string_3 + "']");
		if (xmlNode2 == null)
		{
			try
			{
				xmlNode2 = xmlDocument_0.CreateNode(XmlNodeType.Element, "Key", "");
				XmlAttribute xmlAttribute = xmlDocument_0.CreateAttribute("Name");
				xmlAttribute.Value = string_3;
				xmlNode2.Attributes.SetNamedItem(xmlAttribute);
				xmlAttribute = xmlDocument_0.CreateAttribute("Value");
				xmlAttribute.Value = string_4;
				xmlNode2.Attributes.SetNamedItem(xmlAttribute);
				xmlNode.AppendChild(xmlNode2);
			}
			catch (XmlException projectError2)
			{
				ProjectData.SetProjectError(projectError2);
				ProjectData.ClearProjectError();
			}
		}
		else
		{
			xmlNode2.Attributes["Value"].Value = string_4;
		}
		xmlNode2 = null;
		xmlNode = null;
	}

	internal void method_7(string string_2, string string_3)
	{
		XmlNode xmlNode = xmlDocument_0.SelectSingleNode("//Section[@Name='" + string_2 + "']");
		XmlNode xmlNode2;
		if (xmlNode != null)
		{
			xmlNode2 = xmlNode.SelectSingleNode("descendant::Key[@Name='" + string_3 + "']");
			if (xmlNode2 == null)
			{
				return;
			}
			xmlNode.RemoveChild(xmlNode2);
		}
		xmlNode2 = null;
		xmlNode = null;
	}

	internal void method_8(string string_2)
	{
		XmlNode xmlNode = xmlDocument_0.SelectSingleNode("//Section[@Name='" + string_2 + "']");
		if (xmlNode != null)
		{
			XmlNode documentElement = xmlDocument_0.DocumentElement;
			documentElement.RemoveChild(xmlNode);
		}
		xmlNode = null;
	}

	internal void method_9(bool bool_0 = true, bool bool_1 = true)
	{
		try
		{
			if (bool_1 && File.Exists(string_0) && bool_0)
			{
				File.Delete(string_0);
			}
			xmlDocument_0.Save(string_0);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			try
			{
				File.Delete(string_0);
			}
			catch (Exception projectError2)
			{
				ProjectData.SetProjectError(projectError2);
				ProjectData.ClearProjectError();
			}
			ProjectData.ClearProjectError();
		}
	}
}
