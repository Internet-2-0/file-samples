using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class26
{
	internal enum Enum1
	{
		const_0,
		const_1,
		const_2,
		const_3,
		const_4,
		const_5,
		const_6,
		const_7
	}

	public delegate void Delegate4(Enum1 k, string desc, object value);

	public sealed class Class27
	{
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object object_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ListViewItem listViewItem_0;

		public string Name
		{
			[CompilerGenerated]
			get
			{
				return string_0;
			}
			[CompilerGenerated]
			set
			{
				string_0 = value;
			}
		}

		public object Value
		{
			[CompilerGenerated]
			get
			{
				return object_0;
			}
			[CompilerGenerated]
			set
			{
				object_0 = RuntimeHelpers.GetObjectValue(value);
			}
		}

		public ListViewItem Item
		{
			[CompilerGenerated]
			get
			{
				return listViewItem_0;
			}
			[CompilerGenerated]
			set
			{
				listViewItem_0 = value;
			}
		}
	}

	[CompilerGenerated]
	internal sealed class Class28
	{
		public string string_0;

		[SpecialName]
		internal bool method_0(Class27 class27_0)
		{
			return class27_0.Name.Equals(string_0);
		}
	}

	private static string string_0;

	private Dictionary<Enum1, ListViewGroup> dictionary_0;

	private Dictionary<Enum1, List<Class27>> dictionary_1;

	public Class26()
	{
		dictionary_0 = new Dictionary<Enum1, ListViewGroup>();
		dictionary_1 = new Dictionary<Enum1, List<Class27>>();
		if (Globals.IS_DUMP_INSTANCE)
		{
			return;
		}
		dictionary_0.Add(Enum1.const_0, new ListViewGroup("Exploiter XSS Vectors"));
		dictionary_0.Add(Enum1.const_1, new ListViewGroup("Exploiter LFi Vectors"));
		dictionary_0.Add(Enum1.const_2, new ListViewGroup("Exploiter SQLi Vectors"));
		dictionary_0.Add(Enum1.const_3, new ListViewGroup("HTTP Status"));
		dictionary_0.Add(Enum1.const_5, new ListViewGroup("Application"));
		dictionary_0.Add(Enum1.const_6, new ListViewGroup("Virtualization"));
		Globals.GMain.lvwStatistics.Groups.AddRange(dictionary_0.Values.ToArray());
		foreach (KeyValuePair<Enum1, ListViewGroup> item in dictionary_0)
		{
			string[] array = Class50.smethod_5("Statistics", Conversions.ToString((int)item.Key), "").Split('|');
			foreach (string text in array)
			{
				string[] array2 = text.Split('§');
				if (array2.Length == 2 && item.Key != Enum1.const_4)
				{
					method_1(item.Key, array2[0], array2[1]);
				}
			}
		}
	}

	public void method_0()
	{
		if (Globals.IS_DUMP_INSTANCE)
		{
			return;
		}
		foreach (KeyValuePair<Enum1, List<Class27>> item in dictionary_1)
		{
			if (item.Key == Enum1.const_5)
			{
				continue;
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (Class27 item2 in item.Value)
			{
				if (!string.IsNullOrEmpty(stringBuilder.ToString()))
				{
					stringBuilder.Append("|");
				}
				stringBuilder.Append(Operators.ConcatenateObject(item2.Name + "§", item2.Value));
			}
			Class50.smethod_4("Statistics", Conversions.ToString((int)item.Key), stringBuilder.ToString());
		}
	}

	public void method_1(Enum1 enum1_0, string string_1, object object_0)
	{
		if (Globals.IS_DUMP_INSTANCE)
		{
			return;
		}
		if (Globals.GMain.lvwStatistics.InvokeRequired)
		{
			Globals.GMain.lvwStatistics.Invoke(new Delegate4(method_1), enum1_0, string_1, object_0);
			return;
		}
		Class27 @class = null;
		List<Class27> list = null;
		if (dictionary_1.ContainsKey(enum1_0))
		{
			list = dictionary_1[enum1_0];
			@class = list.Find([SpecialName] (Class27 class27_0) => class27_0.Name.Equals(string_1));
		}
		if (@class != null)
		{
			switch (enum1_0)
			{
			default:
			{
				Class27 class2;
				(class2 = @class).Value = Operators.AddObject(class2.Value, object_0);
				break;
			}
			case Enum1.const_4:
			case Enum1.const_5:
			case Enum1.const_6:
			case Enum1.const_7:
				@class.Value = RuntimeHelpers.GetObjectValue(object_0);
				break;
			}
			return;
		}
		@class = new Class27();
		@class.Name = string_1;
		@class.Value = RuntimeHelpers.GetObjectValue(object_0);
		@class.Item = new ListViewItem(string_1);
		ListViewItem.ListViewSubItemCollection subItems = @class.Item.SubItems;
		object[] obj = new object[1] { object_0 };
		object[] array = obj;
		bool[] obj2 = new bool[1] { true };
		bool[] array2 = obj2;
		NewLateBinding.LateCall(subItems, null, "Add", obj, null, null, obj2, IgnoreReturn: true);
		if (array2[0])
		{
			object_0 = RuntimeHelpers.GetObjectValue(array[0]);
		}
		@class.Item.Group = dictionary_0[enum1_0];
		if (list == null)
		{
			list = new List<Class27>();
		}
		list.Add(@class);
		Globals.GMain.lvwStatistics.Items.Add(@class.Item);
		if (!dictionary_1.ContainsKey(enum1_0))
		{
			dictionary_1.Add(enum1_0, list);
		}
	}

	public void method_2()
	{
		if (Globals.IS_DUMP_INSTANCE)
		{
			return;
		}
		if (Globals.GMain.lvwStatistics.InvokeRequired)
		{
			Globals.GMain.lvwStatistics.Invoke((EventHandler)([SpecialName] [DebuggerHidden] (object sender, EventArgs e) =>
			{
				method_2();
			}));
			return;
		}
		foreach (KeyValuePair<Enum1, List<Class27>> item in dictionary_1)
		{
			foreach (Class27 item2 in item.Value)
			{
				if ((item.Key == Enum1.const_4) | (item.Key == Enum1.const_5) | (item.Key == Enum1.const_6) | (item.Key == Enum1.const_7))
				{
					if (item2.Name.Equals(Globals.translate_0.GetStr(Globals.GMain, 107)))
					{
						item2.Item.SubItems[1].Text = Globals.FormatBytes(Conversions.ToDouble(item2.Value));
					}
					else
					{
						item2.Item.SubItems[1].Text = Conversions.ToString(item2.Value);
					}
				}
				else
				{
					item2.Item.SubItems[1].Text = Globals.FormatNumbers(Conversions.ToInteger(item2.Value));
				}
			}
		}
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_3(object sender, EventArgs e)
	{
		method_2();
	}
}
