using System;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

[StandardModule]
internal sealed class Class50
{
	private static Class51 class51_0;

	public static Class51 Class51_0 => class51_0;

	public static void smethod_0()
	{
		class51_0 = new Class51(Globals.XML_PATH);
	}

	public static void smethod_1()
	{
		class51_0.method_9();
	}

	public static void smethod_2(Form form_0, Class51 class51_1 = null)
	{
		int try0001_dispatch = -1;
		int num = default(int);
		int num2 = default(int);
		int num3 = default(int);
		object objectValue = default(object);
		Class52 @class = default(Class52);
		bool flag = default(bool);
		Hashtable hashtable = default(Hashtable);
		IEnumerator enumerator = default(IEnumerator);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					num = 1;
					if (class51_1 == null)
					{
						goto IL_000a;
					}
					goto IL_0015;
				case 1033:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0015;
						case 4:
							goto IL_001e;
						case 5:
							goto IL_0026;
						case 6:
							goto IL_0057;
						case 7:
							goto IL_006b;
						case 8:
							goto IL_0081;
						case 9:
							goto IL_008d;
						case 10:
							goto IL_00a1;
						case 12:
							goto IL_00a7;
						case 13:
							goto IL_00ba;
						case 15:
							goto IL_00d5;
						case 16:
							goto IL_00e8;
						case 18:
							goto IL_0103;
						case 19:
							goto IL_0116;
						case 21:
							goto IL_0136;
						case 22:
							goto IL_0149;
						case 24:
							goto IL_0169;
						case 25:
							goto IL_017c;
						case 27:
							goto IL_01a1;
						case 28:
							goto IL_01b4;
						case 30:
							goto IL_01d4;
						case 31:
							goto IL_01e7;
						case 33:
							goto IL_0202;
						case 34:
							goto IL_0215;
						case 36:
							goto IL_0230;
						case 37:
							goto IL_0243;
						case 39:
							goto IL_025e;
						case 40:
							goto IL_0271;
						case 42:
							goto IL_028e;
						case 43:
							goto IL_02a1;
						case 44:
							goto IL_02b2;
						case 47:
							goto IL_02cf;
						case 48:
							goto IL_02e2;
						case 11:
						case 14:
						case 17:
						case 20:
						case 23:
						case 26:
						case 29:
						case 32:
						case 35:
						case 38:
						case 41:
						case 45:
						case 46:
						case 49:
						case 50:
						case 51:
						case 52:
						case 53:
							goto IL_02f8;
						case 54:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 55:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_02b2:
					num = 44;
					((ToolStripButton)objectValue).Checked = Conversions.ToBoolean(@class.String_1);
					goto IL_02f8;
					IL_02cf:
					num = 47;
					if (flag == objectValue is TreeViewExt)
					{
						goto IL_02e2;
					}
					goto IL_02f8;
					IL_02a1:
					num = 43;
					if (((ToolStripButton)objectValue).CheckOnClick)
					{
						goto IL_02b2;
					}
					goto IL_02f8;
					IL_02e2:
					num = 48;
					smethod_9((TreeViewExt)objectValue, @class.String_1);
					goto IL_02f8;
					IL_000a:
					num = 2;
					class51_1 = class51_0;
					goto IL_0015;
					IL_0015:
					num = 3;
					hashtable = smethod_6(form_0);
					goto IL_001e;
					IL_001e:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_0026;
					IL_0026:
					num = 5;
					enumerator = class51_1.method_2(form_0.Name).Values.GetEnumerator();
					goto IL_003f;
					IL_003f:
					if (!enumerator.MoveNext())
					{
						break;
					}
					@class = (Class52)enumerator.Current;
					goto IL_0057;
					IL_02f8:
					num = 53;
					goto IL_003f;
					IL_0057:
					num = 6;
					if (hashtable.Contains(@class.String_0))
					{
						goto IL_006b;
					}
					goto IL_02f8;
					IL_006b:
					num = 7;
					objectValue = RuntimeHelpers.GetObjectValue(hashtable[@class.String_0]);
					goto IL_0081;
					IL_0081:
					num = 8;
					if (objectValue != null)
					{
						goto IL_008d;
					}
					goto IL_02f8;
					IL_008d:
					num = 9;
					if (smethod_10(RuntimeHelpers.GetObjectValue(objectValue)))
					{
						goto IL_00a1;
					}
					goto IL_02f8;
					IL_00a1:
					num = 10;
					flag = true;
					goto IL_00a7;
					IL_00a7:
					num = 12;
					if (flag == objectValue is TextBox)
					{
						goto IL_00ba;
					}
					goto IL_00d5;
					IL_00ba:
					num = 13;
					((TextBox)objectValue).Text = @class.String_1;
					goto IL_02f8;
					IL_00d5:
					num = 15;
					if (flag == objectValue is ComboBox)
					{
						goto IL_00e8;
					}
					goto IL_0103;
					IL_00e8:
					num = 16;
					((ComboBox)objectValue).Text = @class.String_1;
					goto IL_02f8;
					IL_0103:
					num = 18;
					if (flag == objectValue is CheckBox)
					{
						goto IL_0116;
					}
					goto IL_0136;
					IL_0116:
					num = 19;
					((CheckBox)objectValue).Checked = Conversions.ToBoolean(@class.String_1);
					goto IL_02f8;
					IL_0136:
					num = 21;
					if (flag == objectValue is RadioButton)
					{
						goto IL_0149;
					}
					goto IL_0169;
					IL_0149:
					num = 22;
					((RadioButton)objectValue).Checked = Conversions.ToBoolean(@class.String_1);
					goto IL_02f8;
					IL_0169:
					num = 24;
					if (flag == objectValue is NumericUpDown)
					{
						goto IL_017c;
					}
					goto IL_01a1;
					IL_017c:
					num = 25;
					((NumericUpDown)objectValue).Value = new decimal(Conversions.ToInteger(@class.String_1));
					goto IL_02f8;
					IL_01a1:
					num = 27;
					if (flag == objectValue is TrackBar)
					{
						goto IL_01b4;
					}
					goto IL_01d4;
					IL_01b4:
					num = 28;
					((TrackBar)objectValue).Value = Conversions.ToInteger(@class.String_1);
					goto IL_02f8;
					IL_01d4:
					num = 30;
					if (flag == objectValue is ToolStripTextBox)
					{
						goto IL_01e7;
					}
					goto IL_0202;
					IL_01e7:
					num = 31;
					((ToolStripTextBox)objectValue).Text = @class.String_1;
					goto IL_02f8;
					IL_0202:
					num = 33;
					if (flag == objectValue is ToolStripComboBox)
					{
						goto IL_0215;
					}
					goto IL_0230;
					IL_0215:
					num = 34;
					((ToolStripTextBox)objectValue).Text = @class.String_1;
					goto IL_02f8;
					IL_0230:
					num = 36;
					if (flag == objectValue is ToolStripSpringTextBox)
					{
						goto IL_0243;
					}
					goto IL_025e;
					IL_0243:
					num = 37;
					((ToolStripSpringTextBox)objectValue).Text = @class.String_1;
					goto IL_02f8;
					IL_025e:
					num = 39;
					if (flag == objectValue is ToolStripControl)
					{
						goto IL_0271;
					}
					goto IL_028e;
					IL_0271:
					num = 40;
					((ToolStripControl)objectValue).Value = Conversions.ToDecimal(@class.String_1);
					goto IL_02f8;
					IL_028e:
					num = 42;
					if (flag == objectValue is ToolStripButton)
					{
						goto IL_02a1;
					}
					goto IL_02cf;
					end_IL_0001_2:
					break;
				}
				num = 54;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 1033;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	public static void smethod_3(Form form_0, Class51 class51_1 = null)
	{
		int try0001_dispatch = -1;
		int num = default(int);
		int num2 = default(int);
		int num3 = default(int);
		object objectValue = default(object);
		bool flag = default(bool);
		IEnumerator enumerator = default(IEnumerator);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					num = 1;
					if (class51_1 == null)
					{
						goto IL_000a;
					}
					goto IL_0015;
				case 1293:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0015;
						case 4:
							goto IL_001d;
						case 5:
							goto IL_0047;
						case 6:
							goto IL_0052;
						case 7:
							goto IL_0064;
						case 9:
							goto IL_0069;
						case 10:
							goto IL_007b;
						case 12:
							goto IL_00b4;
						case 13:
							goto IL_00c6;
						case 15:
							goto IL_00ff;
						case 16:
							goto IL_0111;
						case 18:
							goto IL_0153;
						case 19:
							goto IL_0165;
						case 21:
							goto IL_01a7;
						case 22:
							goto IL_01b9;
						case 24:
							goto IL_01fb;
						case 25:
							goto IL_020d;
						case 27:
							goto IL_024f;
						case 28:
							goto IL_0261;
						case 30:
							goto IL_029a;
						case 31:
							goto IL_02ac;
						case 33:
							goto IL_02e5;
						case 34:
							goto IL_02f7;
						case 35:
							goto IL_030a;
						case 38:
							goto IL_034c;
						case 39:
							goto IL_035e;
						case 41:
							goto IL_0379;
						case 42:
							goto IL_038b;
						case 44:
							goto IL_03c1;
						case 45:
							goto IL_03d3;
						case 8:
						case 11:
						case 14:
						case 17:
						case 20:
						case 23:
						case 26:
						case 29:
						case 32:
						case 36:
						case 37:
						case 40:
						case 43:
						case 46:
						case 47:
						case 48:
						case 49:
							goto IL_040c;
						case 50:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 51:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_038b:
					num = 42;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((ToolStripSpringTextBox)objectValue).Text);
					goto IL_040c;
					IL_03c1:
					num = 44;
					if (flag == objectValue is ToolStripControl)
					{
						goto IL_03d3;
					}
					goto IL_040c;
					IL_0379:
					num = 41;
					if (flag == objectValue is ToolStripSpringTextBox)
					{
						goto IL_038b;
					}
					goto IL_03c1;
					IL_03d3:
					num = 45;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), Conversions.ToString(((ToolStripControl)objectValue).Value));
					goto IL_040c;
					IL_000a:
					num = 2;
					class51_1 = class51_0;
					goto IL_0015;
					IL_0015:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_001d;
					IL_001d:
					num = 4;
					enumerator = smethod_6(form_0).Values.GetEnumerator();
					goto IL_0030;
					IL_0030:
					if (!enumerator.MoveNext())
					{
						break;
					}
					objectValue = RuntimeHelpers.GetObjectValue(enumerator.Current);
					goto IL_0047;
					IL_040c:
					num = 49;
					goto IL_0030;
					IL_0047:
					num = 5;
					if (objectValue != null)
					{
						goto IL_0052;
					}
					goto IL_040c;
					IL_0052:
					num = 6;
					if (smethod_10(RuntimeHelpers.GetObjectValue(objectValue)))
					{
						goto IL_0064;
					}
					goto IL_040c;
					IL_0064:
					num = 7;
					flag = true;
					goto IL_0069;
					IL_0069:
					num = 9;
					if (flag == objectValue is TextBox)
					{
						goto IL_007b;
					}
					goto IL_00b4;
					IL_007b:
					num = 10;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((TextBox)objectValue).Text);
					goto IL_040c;
					IL_00b4:
					num = 12;
					if (flag == objectValue is ComboBox)
					{
						goto IL_00c6;
					}
					goto IL_00ff;
					IL_00c6:
					num = 13;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((ComboBox)objectValue).Text);
					goto IL_040c;
					IL_00ff:
					num = 15;
					if (flag == objectValue is CheckBox)
					{
						goto IL_0111;
					}
					goto IL_0153;
					IL_0111:
					num = 16;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((CheckBox)objectValue).Checked.ToString());
					goto IL_040c;
					IL_0153:
					num = 18;
					if (flag == objectValue is RadioButton)
					{
						goto IL_0165;
					}
					goto IL_01a7;
					IL_0165:
					num = 19;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((RadioButton)objectValue).Checked.ToString());
					goto IL_040c;
					IL_01a7:
					num = 21;
					if (flag == objectValue is NumericUpDown)
					{
						goto IL_01b9;
					}
					goto IL_01fb;
					IL_01b9:
					num = 22;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((NumericUpDown)objectValue).Value.ToString());
					goto IL_040c;
					IL_01fb:
					num = 24;
					if (flag == objectValue is TrackBar)
					{
						goto IL_020d;
					}
					goto IL_024f;
					IL_020d:
					num = 25;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((TrackBar)objectValue).Value.ToString());
					goto IL_040c;
					IL_024f:
					num = 27;
					if (flag == objectValue is ToolStripTextBox)
					{
						goto IL_0261;
					}
					goto IL_029a;
					IL_0261:
					num = 28;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((ToolStripTextBox)objectValue).Text);
					goto IL_040c;
					IL_029a:
					num = 30;
					if (flag == objectValue is ToolStripComboBox)
					{
						goto IL_02ac;
					}
					goto IL_02e5;
					IL_02ac:
					num = 31;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((ToolStripComboBox)objectValue).Text);
					goto IL_040c;
					IL_02e5:
					num = 33;
					if (flag == objectValue is ToolStripButton)
					{
						goto IL_02f7;
					}
					goto IL_034c;
					IL_02f7:
					num = 34;
					if (((ToolStripButton)objectValue).CheckOnClick)
					{
						goto IL_030a;
					}
					goto IL_040c;
					IL_030a:
					num = 35;
					class51_1.method_6(form_0.Name, Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null)), ((ToolStripButton)objectValue).Checked.ToString());
					goto IL_040c;
					IL_034c:
					num = 38;
					if (flag == objectValue is TreeViewExt)
					{
						goto IL_035e;
					}
					goto IL_0379;
					IL_035e:
					num = 39;
					smethod_8(form_0.Name, (TreeViewExt)objectValue, class51_1);
					goto IL_040c;
					end_IL_0001_2:
					break;
				}
				num = 50;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 1293;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	public static void smethod_4(string string_0, string string_1, string string_2, Class51 class51_1 = null)
	{
		if (class51_1 == null)
		{
			class51_1 = class51_0;
		}
		class51_1.method_6(string_0, string_1, string_2);
	}

	public static string smethod_5(string string_0, string string_1, string string_2, Class51 class51_1 = null)
	{
		if (class51_1 == null)
		{
			class51_1 = class51_0;
		}
		return class51_1.method_3(string_0, string_1, string_2);
	}

	public static Hashtable smethod_6(Form form_0)
	{
		Hashtable hashtable_ = new Hashtable();
		foreach (Control control in form_0.Controls)
		{
			if (control == null || string.IsNullOrEmpty(control.Name))
			{
				continue;
			}
			if (!hashtable_.Contains(control.Name))
			{
				hashtable_.Add(control.Name, control);
			}
			if (control is ToolStrip)
			{
				foreach (ToolStripItem item in ((ToolStrip)control).Items)
				{
					bool flag;
					if ((!hashtable_.Contains(item.Name) & !string.IsNullOrEmpty(item.Name)) && ((flag = true) == item is ToolStripTextBox || flag == item is ToolStripComboBox || flag == item is ToolStripSeparator || flag == item is ToolStripLabel || flag == item is ToolStripButton) && !hashtable_.Contains(item.Name))
					{
						hashtable_.Add(item.Name, item);
					}
				}
			}
			else if (control is SplitContainer)
			{
				if (((SplitContainer)control).Panel1.Controls.Count > 0)
				{
					smethod_7(((SplitContainer)control).Panel1, ref hashtable_);
				}
				if (((SplitContainer)control).Panel2.Controls.Count > 0)
				{
					smethod_7(((SplitContainer)control).Panel2, ref hashtable_);
				}
			}
			else if (control.Controls.Count > 0)
			{
				smethod_7(control, ref hashtable_);
			}
		}
		return hashtable_;
	}

	public static void smethod_7(Control control_0, ref Hashtable hashtable_0)
	{
		foreach (Control control in control_0.Controls)
		{
			if (control == null || string.IsNullOrEmpty(control.Name))
			{
				continue;
			}
			if (!hashtable_0.Contains(control.Name))
			{
				hashtable_0.Add(control.Name, control);
			}
			if (control.Controls.Count > 0)
			{
				if (control is SplitContainer)
				{
					smethod_7(((SplitContainer)control).Panel1, ref hashtable_0);
					smethod_7(((SplitContainer)control).Panel2, ref hashtable_0);
				}
				else
				{
					smethod_7(control, ref hashtable_0);
				}
			}
		}
	}

	public static string smethod_8(string string_0, TreeViewExt treeViewExt_0, Class51 class51_1 = null)
	{
		string result = default(string);
		try
		{
			string text = "";
			foreach (TreeNode node in treeViewExt_0.Nodes)
			{
				if (node.Nodes.Count == 0)
				{
					text = ((Operators.CompareString(text, "", TextCompare: false) != 0) ? (text + "|" + node.FullPath) : node.FullPath);
					continue;
				}
				foreach (TreeNode node2 in node.Nodes)
				{
					if (node2.Nodes.Count == 0)
					{
						text = ((Operators.CompareString(text, "", TextCompare: false) != 0) ? (text + "|" + node2.FullPath) : node2.FullPath);
						continue;
					}
					foreach (TreeNode node3 in node2.Nodes)
					{
						if (node3.Nodes.Count == 0)
						{
							text = ((Operators.CompareString(text, "", TextCompare: false) != 0) ? (text + "|" + node3.FullPath) : node3.FullPath);
						}
						else
						{
							foreach (TreeNode node4 in node3.Nodes)
							{
								text = ((Operators.CompareString(text, "", TextCompare: false) != 0) ? (text + "|" + node4.FullPath) : node4.FullPath);
							}
						}
						text = text + "\\" + node3.Checked;
					}
				}
			}
			class51_1?.method_6(string_0, treeViewExt_0.Name, text);
			result = text;
			return result;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public static void smethod_9(TreeViewExt treeViewExt_0, string string_0)
	{
		try
		{
			string[] array = string_0.Split('|');
			treeViewExt_0.BeginUpdate();
			treeViewExt_0.Nodes.Clear();
			string[] array2 = array;
			foreach (string text in array2)
			{
				string[] array3 = text.Split('\\');
				TreeNode treeNode2;
				TreeNode treeNode;
				switch (array3.Length)
				{
				case 2:
					treeNode = treeViewExt_0.Nodes[array3[0]];
					if (treeNode == null)
					{
						treeNode = treeViewExt_0.Nodes.Add(array3[0], array3[0], 0);
					}
					treeNode2 = treeNode.Nodes[array3[1]];
					if (treeNode2 == null)
					{
						treeNode = treeNode.Nodes.Add(array3[1], array3[1], 1);
						treeNode.SelectedImageIndex = 1;
					}
					continue;
				case 1:
					if (!string.IsNullOrEmpty(array3[0]))
					{
						treeViewExt_0.Nodes.Add(array3[0], array3[0], 0);
					}
					continue;
				}
				treeNode = treeViewExt_0.Nodes[array3[0]];
				if (treeNode == null)
				{
					treeNode = treeViewExt_0.Nodes.Add(array3[0], array3[0], 0);
				}
				treeNode2 = treeNode.Nodes[array3[1]];
				if (treeNode2 == null)
				{
					treeNode = treeNode.Nodes.Add(array3[1], array3[1], 1);
					treeNode.SelectedImageIndex = 1;
				}
				else
				{
					treeNode = treeNode2;
				}
				if (treeNode != null)
				{
					treeNode = treeNode.Nodes.Add(array3[2], array3[2], 2);
					treeNode.SelectedImageIndex = 2;
					if (array3.Length > 3)
					{
						treeNode.Checked = Conversions.ToBoolean(array3[3]);
					}
				}
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		finally
		{
			treeViewExt_0.EndUpdate();
		}
	}

	private static bool smethod_10(object object_0)
	{
		if (object_0 == Globals.GMain.twMain)
		{
			return false;
		}
		return true;
	}
}
