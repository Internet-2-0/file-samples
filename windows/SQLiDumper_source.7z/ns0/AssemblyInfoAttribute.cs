using System;

namespace ns0;

internal class AssemblyInfoAttribute : Attribute
{
	public AssemblyInfoAttribute(string str)
	{
	}
}
