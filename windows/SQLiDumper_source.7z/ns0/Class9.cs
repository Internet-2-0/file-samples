using System;
using System.IO;
using System.Text;
using Cryptor;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class9
{
	public static byte[] smethod_0(string string_0)
	{
		UnicodeEncoding unicodeEncoding = new UnicodeEncoding();
		return unicodeEncoding.GetBytes(string_0);
	}

	public static string smethod_1(byte[] byte_0)
	{
		UnicodeEncoding unicodeEncoding = new UnicodeEncoding();
		return unicodeEncoding.GetString(byte_0);
	}

	public static byte[] smethod_2(string string_0, string string_1, Method method_0 = Method.RC4, bool bool_0 = false)
	{
		UnicodeEncoding unicodeEncoding = new UnicodeEncoding();
		byte[] array = unicodeEncoding.GetBytes(string_0);
		switch (method_0)
		{
		case Method.RijnDael:
			array = Class11.smethod_1(array, string_1);
			break;
		case Method.RC4:
			array = Class12.smethod_0(array, string_1);
			break;
		case Method.MD5:
			array = Class13.smethod_0(array, string_1);
			break;
		case Method.const_3:
			array = Class14.smethod_0(array, string_1);
			break;
		}
		if (bool_0)
		{
			array = Class10.smethod_0(array);
		}
		return array;
	}

	public static string smethod_3(string string_0, string string_1, Method method_0 = Method.RC4, bool bool_0 = false)
	{
		ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
		byte[] array = aSCIIEncoding.GetBytes(string_0);
		switch (method_0)
		{
		case Method.RijnDael:
			array = Class11.smethod_1(array, string_1);
			break;
		case Method.RC4:
			array = Class12.smethod_0(array, string_1);
			break;
		case Method.MD5:
			array = Class13.smethod_0(array, string_1);
			break;
		case Method.const_3:
			array = Class14.smethod_0(array, string_1);
			break;
		}
		if (bool_0)
		{
			array = Class10.smethod_0(array);
		}
		return Convert.ToBase64String(array);
	}

	public static string smethod_4(byte[] byte_0, string string_0, Method method_0 = Method.RC4, bool bool_0 = false)
	{
		UnicodeEncoding unicodeEncoding = new UnicodeEncoding();
		byte[] array = byte_0;
		if (bool_0)
		{
			array = Class10.smethod_1(array);
		}
		switch (method_0)
		{
		case Method.RijnDael:
			array = Class11.smethod_0(array, string_0);
			break;
		case Method.RC4:
			array = Class12.smethod_1(array, string_0);
			break;
		case Method.MD5:
			array = Class13.smethod_1(array, string_0);
			break;
		case Method.const_3:
			array = Class14.smethod_1(array, string_0);
			break;
		}
		return unicodeEncoding.GetString(array);
	}

	public static string smethod_5(string string_0, string string_1, Method method_0 = Method.RC4, bool bool_0 = false)
	{
		ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
		byte[] array = Convert.FromBase64String(string_0);
		if (bool_0)
		{
			array = Class10.smethod_1(array);
		}
		switch (method_0)
		{
		case Method.RijnDael:
			array = Class11.smethod_0(array, string_1);
			break;
		case Method.RC4:
			array = Class12.smethod_1(array, string_1);
			break;
		case Method.MD5:
			array = Class13.smethod_1(array, string_1);
			break;
		case Method.const_3:
			array = Class14.smethod_1(array, string_1);
			break;
		}
		return aSCIIEncoding.GetString(array);
	}

	public static bool smethod_6(string string_0, Method method_0, string string_1)
	{
		if (!File.Exists(string_0))
		{
			return true;
		}
		byte[] array = File.ReadAllBytes(string_0);
		if (array.Length == 0)
		{
			return true;
		}
		switch (method_0)
		{
		case Method.RijnDael:
			array = Class11.smethod_1(array, string_1);
			break;
		case Method.RC4:
			array = Class12.smethod_0(array, string_1);
			break;
		case Method.MD5:
			array = Class13.smethod_0(array, string_1);
			break;
		case Method.const_3:
			array = Class14.smethod_0(array, string_1);
			break;
		}
		array = (byte[])Utils.CopyArray(array, new byte[checked(array.Length - 1 + 1)]);
		array = Class10.smethod_0(array);
		File.Delete(string_0);
		File.WriteAllBytes(string_0, array);
		return true;
	}

	public static bool smethod_7(string string_0, Method method_0, string string_1)
	{
		if (!File.Exists(string_0))
		{
			return true;
		}
		byte[] array = File.ReadAllBytes(string_0);
		if (array.Length == 0)
		{
			return true;
		}
		array = Class10.smethod_1(array);
		switch (method_0)
		{
		case Method.RijnDael:
			array = Class11.smethod_0(array, string_1);
			break;
		case Method.RC4:
			array = Class12.smethod_1(array, string_1);
			break;
		case Method.MD5:
			array = Class13.smethod_1(array, string_1);
			break;
		case Method.const_3:
			array = Class14.smethod_1(array, string_1);
			break;
		}
		File.Delete(string_0);
		File.WriteAllBytes(string_0, array);
		return true;
	}
}
