using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace ns0;

internal sealed class Class40
{
	private List<string> list_0;

	private static int int_0;

	public Class40()
	{
		list_0 = new List<string>();
	}

	public void method_0(string string_0)
	{
		string item = Class23.smethod_14(string_0);
		if (!list_0.Contains(item))
		{
			list_0.Add(item);
		}
	}

	public void method_1(string string_0)
	{
		if (list_0.Contains(string_0))
		{
			list_0.Remove(string_0);
		}
	}

	public bool method_2(string string_0)
	{
		return list_0.Contains(string_0);
	}

	public int method_3()
	{
		return list_0.Count;
	}

	public void method_4()
	{
		list_0.Clear();
		Globals.GMain.dtgTrash.Rows.Clear();
	}

	public void method_5()
	{
		if (File.Exists(Globals.TRASH_PATH))
		{
			string[] collection = File.ReadAllLines(Globals.TRASH_PATH);
			list_0.AddRange(collection);
		}
		method_7();
	}

	public void method_6()
	{
		if (File.Exists(Globals.TRASH_PATH))
		{
			File.Delete(Globals.TRASH_PATH);
		}
		if (list_0.Count > 0)
		{
			File.WriteAllLines(Globals.TRASH_PATH, list_0.ToArray());
		}
	}

	public void method_7()
	{
		checked
		{
			if (Globals.GMain.dtgTrash.InvokeRequired)
			{
				Globals.GMain.dtgTrash.Invoke((EventHandler)([SpecialName] [DebuggerHidden] (object sender, EventArgs e) =>
				{
					method_7();
				}));
			}
			else if (list_0.Count > 0)
			{
				int num = 2000;
				if (num > list_0.Count)
				{
					num = list_0.Count;
				}
				List<string> list = new List<string>();
				int num2 = num - 1;
				for (int i = 0; i <= num2; i++)
				{
					list.Add(list_0[list_0.Count - 1 - i]);
				}
				Globals.LockWindowUpdate(Globals.GMain.dtgTrash.Handle);
				Globals.GMain.dtgTrash.Rows.Clear();
				Globals.GMain.dtgTrash.Rows.AddRange(Array.ConvertAll(list.ToArray(), method_8));
				Globals.LockWindowUpdate(IntPtr.Zero);
			}
		}
	}

	private DataGridViewRow method_8(string string_0)
	{
		DataGridViewRow dataGridViewRow = new DataGridViewRow();
		dataGridViewRow.CreateCells(Globals.GMain.dtgTrash);
		dataGridViewRow.SetValues(string_0);
		return dataGridViewRow;
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_9(object sender, EventArgs e)
	{
		method_7();
	}
}
