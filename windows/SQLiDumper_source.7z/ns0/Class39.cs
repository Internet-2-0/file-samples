using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class39
{
	private static object object_0 = RuntimeHelpers.GetObjectValue(new object());

	private static Interface0 interface0_0;

	internal static Interface0 Interface0_0
	{
		get
		{
			if (interface0_0 == null)
			{
				object obj = object_0;
				ObjectFlowControl.CheckForSyncLockOnValueType(obj);
				bool lockTaken = false;
				try
				{
					Monitor.Enter(obj, ref lockTaken);
					if (interface0_0 == null)
					{
						interface0_0 = (Interface0)(object)new Class38();
						interface0_0.imethod_0();
					}
				}
				finally
				{
					if (lockTaken)
					{
						Monitor.Exit(obj);
					}
				}
			}
			return interface0_0;
		}
	}

	private Class39()
	{
	}
}
