using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Chilkat;
using Microsoft.VisualBasic.CompilerServices;
using SkinSoft.VisualStyler;

namespace ns0;

internal sealed class Class35
{
	public delegate int Delegate10();

	public sealed class Class36 : DataGridViewRow
	{
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int int_1;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string string_1;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string string_2;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_3;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private bool bool_0;

		public string String_0
		{
			[CompilerGenerated]
			get
			{
				return string_0;
			}
		}

		public int Port
		{
			[CompilerGenerated]
			get
			{
				return int_0;
			}
		}

		public int Version
		{
			[CompilerGenerated]
			get
			{
				return int_1;
			}
		}

		public string Username
		{
			[CompilerGenerated]
			get
			{
				return string_1;
			}
		}

		public string Password
		{
			[CompilerGenerated]
			get
			{
				return string_2;
			}
		}

		public string Country
		{
			[CompilerGenerated]
			get
			{
				return string_3;
			}
		}

		public bool Checked
		{
			[CompilerGenerated]
			get
			{
				return bool_0;
			}
			[CompilerGenerated]
			set
			{
				bool_0 = value;
			}
		}

		public Class36(string string_4, int int_2, int int_3, string string_5, string string_6, bool bool_1 = false)
		{
			string_0 = string_4;
			int_0 = int_2;
			int_1 = int_3;
			string_1 = string_5;
			string_2 = string_6;
			Checked = bool_1;
			CreateCells(Globals.GMain.dtgSocks);
			DataGP g_DataGP = Globals.G_DataGP;
			string sIP = String_0;
			string sCountry = Country;
			DataGridViewCell dataGridViewCell;
			Image oImage = (Image)(dataGridViewCell = base.Cells[1]).Value;
			string sCountryCode = null;
			g_DataGP.Lookup(sIP, ref sCountry, ref oImage, ref sCountryCode, bUnionContryCode: true);
			dataGridViewCell.Value = oImage;
			string_3 = sCountry;
			base.Cells[0].Value = Checked;
			base.Cells[1].ToolTipText = Country;
			base.Cells[2].Value = String_0 + ":" + int_2;
			base.Cells[3].Value = method_0();
			base.Cells[4].Value = Username;
			base.Cells[5].Value = Password;
			base.Cells[6].Value = Country;
			base.Tag = this;
		}

		public string method_0()
		{
			string text = default(string);
			return Version switch
			{
				5 => "SOCKS 5", 
				4 => "SOCKS 4", 
				0 => "WEB PROXY", 
				_ => text, 
			};
		}

		public string method_1(bool bool_1 = true)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(String_0);
			stringBuilder.Append("|" + Port);
			stringBuilder.Append("|" + Conversions.ToString(Version));
			stringBuilder.Append("|" + Username);
			stringBuilder.Append("|" + Password);
			if (bool_1)
			{
				stringBuilder.Append("|" + base.Cells[0].Value.ToString());
			}
			return stringBuilder.ToString();
		}
	}

	public static string string_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool bool_0;

	private List<Class36> list_0;

	private Dictionary<string, Class36> dictionary_0;

	private int int_0;

	[SpecialName]
	private Random _0024STATIC_0024GetRandom_0024202888_0024r;

	[SpecialName]
	private StaticLocalInitFlag _0024STATIC_0024GetRandom_0024202888_0024r_0024Init;

	public bool UseMyIP
	{
		[CompilerGenerated]
		get
		{
			return bool_0;
		}
		[CompilerGenerated]
		set
		{
			bool_0 = value;
		}
	}

	public Class35()
	{
		list_0 = new List<Class36>();
		dictionary_0 = new Dictionary<string, Class36>();
		Globals.GMain.dtgSocks.CellValueChanged += method_0;
		Globals.GMain.dtgSocks.DoubleClick += method_1;
	}

	private void method_0(object sender, DataGridViewCellEventArgs e)
	{
		if (e.ColumnIndex != 0)
		{
			return;
		}
		Class36 @class = (Class36)Globals.GMain.dtgSocks.Rows[e.RowIndex].Tag;
		@class.Checked = Conversions.ToBoolean(Globals.GMain.dtgSocks.Rows[e.RowIndex].Cells[0].Value);
		if (@class.Checked)
		{
			if (!list_0.Contains(@class))
			{
				list_0.Add(@class);
			}
		}
		else
		{
			list_0.Remove(@class);
		}
	}

	private void method_1(object sender, EventArgs e)
	{
		if (Globals.GMain.dtgSocks.SelectedRows.Count == 1)
		{
			Globals.GMain.dtgSocks.SelectedRows[0].Cells[0].Value = Operators.NotObject(Globals.GMain.dtgSocks.SelectedRows[0].Cells[0].Value);
		}
	}

	private void method_2(DataGridViewRow dataGridViewRow_0)
	{
		if (Globals.GMain.chkSkin.Checked)
		{
			DataGridViewCellStyle dataGridViewCellStyle = Globals.GMain.dtgSocks.DefaultCellStyle.Clone();
			if (Conversions.ToBoolean(Operators.AndObject(Operators.CompareObjectEqual(dataGridViewRow_0.Cells[0].Value, true, TextCompare: false), Globals.GMain.chkSkin.Checked)))
			{
				dataGridViewCellStyle.BackColor = VisualStyler.GetSystemColor(KnownColor.ControlLightLight);
			}
			dataGridViewRow_0.DefaultCellStyle = dataGridViewCellStyle;
		}
	}

	public void method_3(string string_1)
	{
		try
		{
			string[] array;
			if (string_1.Contains("|"))
			{
				array = string_1.Split('|');
			}
			else
			{
				if (!string_1.Contains(":"))
				{
					return;
				}
				array = string_1.Split(':');
			}
			if (dictionary_0.ContainsKey(string_1))
			{
				return;
			}
			Class36 @class = null;
			int num = array.Length;
			if (num == 3)
			{
				@class = new Class36(array[0], Conversions.ToInteger(array[1]), Conversions.ToInteger(array[2]), "", "");
			}
			else if (num == 6)
			{
				@class = new Class36(array[0], Conversions.ToInteger(array[1]), Conversions.ToInteger(array[2]), array[3], array[4], Conversions.ToBoolean(array[5]));
				if (Conversions.ToBoolean(array[5]))
				{
					list_0.Add(@class);
				}
			}
			else
			{
				if (num <= 3)
				{
					return;
				}
				@class = new Class36(array[0], Conversions.ToInteger(array[1]), Conversions.ToInteger(array[2]), array[3], array[4]);
			}
			if (!dictionary_0.ContainsKey(@class.method_1(bool_1: false)))
			{
				dictionary_0.Add(@class.method_1(bool_1: false), @class);
			}
			Globals.GMain.dtgSocks.Rows.Add(@class);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	public void method_4(string[] string_1)
	{
		if (string_1.Length > 10)
		{
			foreach (string key in string_1)
			{
				if (dictionary_0.ContainsKey(key))
				{
					Class36 item = dictionary_0[key];
					if (list_0.Contains(item))
					{
						list_0.Remove(item);
					}
					dictionary_0.Remove(key);
				}
			}
			method_5();
		}
		else
		{
			foreach (string string_2 in string_1)
			{
				method_6(string_2);
			}
		}
	}

	private void method_5()
	{
		int num = default(int);
		if (Globals.GMain.dtgSocks.SelectedRows.Count > 0)
		{
			num = Globals.GMain.dtgSocks.SelectedRows[0].Index;
		}
		Globals.GMain.dtgSocks.Rows.Clear();
		if (dictionary_0.Count <= 0)
		{
			return;
		}
		List<DataGridViewRow> list = new List<DataGridViewRow>();
		foreach (Class36 value in dictionary_0.Values)
		{
			list.Add(value);
		}
		Globals.GMain.dtgSocks.Rows.AddRange(list.ToArray());
		if (num > checked(Globals.GMain.dtgSocks.RowCount + 1))
		{
			num = 0;
		}
		Globals.GMain.dtgSocks.FirstDisplayedScrollingRowIndex = num;
	}

	public void method_6(string string_1)
	{
		if (!string.IsNullOrEmpty(string_1) && dictionary_0.ContainsKey(string_1))
		{
			Class36 @class = dictionary_0[string_1];
			Globals.GMain.dtgSocks.Rows.Remove(@class);
			dictionary_0.Remove(string_1);
			if (list_0.Contains(@class))
			{
				list_0.Remove(@class);
			}
		}
	}

	public void method_7()
	{
		dictionary_0.Clear();
		list_0.Clear();
		int_0 = 0;
		Globals.GMain.dtgSocks.Rows.Clear();
	}

	public List<string> method_8()
	{
		List<string> list = new List<string>();
		foreach (Class36 value in dictionary_0.Values)
		{
			list.Add(value.String_0 + "|" + value.Port + "|" + Conversions.ToString(value.Version) + "|" + value.Username + "|" + value.Password);
		}
		return list;
	}

	public int method_9()
	{
		if (Globals.GMain.dtgSocks.InvokeRequired)
		{
			return Conversions.ToInteger(Globals.GMain.dtgSocks.Invoke(new Delegate10(method_9)));
		}
		int num = default(int);
		foreach (Class36 value in dictionary_0.Values)
		{
			if (value.Checked)
			{
				num = checked(num + 1);
			}
		}
		return num;
	}

	public int method_10()
	{
		if (Globals.GMain.dtgSocks.InvokeRequired)
		{
			return Conversions.ToInteger(Globals.GMain.dtgSocks.Invoke(new Delegate10(method_10)));
		}
		return dictionary_0.Count;
	}

	public void method_11(ref byte byte_0, ref string string_1, ref int int_1, ref string string_2, ref string string_3, ref string string_4)
	{
		string_4 = "";
		byte_0 = 0;
		string_1 = "";
		int_1 = 0;
		string_2 = "";
		string_3 = "";
		if (list_0.Count <= 0)
		{
			return;
		}
		checked
		{
			lock (this)
			{
				if (int_0 >= list_0.Count)
				{
					int_0 = 0;
				}
				if (UseMyIP & (int_0 - 1 < 0))
				{
					string_4 = "MyIP";
				}
				else
				{
					Class36 @class = list_0[int_0];
					if (@class.Version == 0)
					{
						byte_0 = 1;
						string_1 = @class.String_0;
						int_1 = @class.Port;
						string_2 = @class.Username;
						string_3 = @class.Password;
					}
					else
					{
						byte_0 = (byte)@class.Version;
						string_1 = @class.String_0;
						int_1 = @class.Port;
						string_2 = @class.Username;
						string_3 = @class.Password;
					}
					string_4 = @class.String_0 + ":" + Conversions.ToString(@class.Port);
				}
				int_0++;
			}
		}
	}

	public void method_12(ref Http http_0, ref string string_1)
	{
		string_1 = "";
		http_0.ProxyDomain = "";
		http_0.ProxyPort = 0;
		http_0.ProxyLogin = "";
		http_0.ProxyPassword = "";
		http_0.SocksVersion = 0;
		http_0.SocksHostname = "";
		http_0.SocksPort = 0;
		http_0.SocksUsername = "";
		http_0.SocksPassword = "";
		if (list_0.Count <= 0)
		{
			return;
		}
		checked
		{
			lock (this)
			{
				if (int_0 >= list_0.Count)
				{
					int_0 = 0;
				}
				if (UseMyIP & (int_0 - 1 < 0))
				{
					string_1 = "MyIP";
				}
				else
				{
					Class36 @class = list_0[int_0];
					if (@class.Version == 0)
					{
						http_0.ProxyDomain = @class.String_0;
						http_0.ProxyPort = @class.Port;
						http_0.ProxyLogin = @class.Username;
						http_0.ProxyPassword = @class.Password;
					}
					else
					{
						http_0.SocksVersion = @class.Version;
						http_0.SocksHostname = @class.String_0;
						http_0.SocksPort = @class.Port;
						http_0.SocksUsername = @class.Username;
						http_0.SocksPassword = @class.Password;
					}
					string_1 = @class.String_0 + ":" + Conversions.ToString(@class.Port);
				}
				int_0++;
			}
		}
	}

	public bool method_13(ref Http http_0, ref string string_1, List<string> list_1)
	{
		string_1 = "";
		http_0.ProxyDomain = "";
		http_0.ProxyPort = 0;
		http_0.ProxyLogin = "";
		http_0.ProxyPassword = "";
		http_0.SocksVersion = 0;
		http_0.SocksHostname = "";
		http_0.SocksPort = 0;
		http_0.SocksUsername = "";
		http_0.SocksPassword = "";
		List<Class36> list = new List<Class36>();
		foreach (Class36 item in list_0)
		{
			if (!list_1.Contains(item.String_0 + ":" + Conversions.ToString(item.Port)))
			{
				list.Add(item);
			}
		}
		if ((list_0.Count > 0) & (list.Count == 0))
		{
			return false;
		}
		checked
		{
			lock (this)
			{
				if (int_0 >= list.Count)
				{
					int_0 = 0;
				}
				if (UseMyIP & (int_0 - 1 < 0))
				{
					string_1 = "MyIP";
				}
				else
				{
					Class36 @class = list[int_0];
					if (@class.Version == 0)
					{
						http_0.ProxyDomain = @class.String_0;
						http_0.ProxyPort = @class.Port;
						http_0.ProxyLogin = @class.Username;
						http_0.ProxyPassword = @class.Password;
					}
					else
					{
						http_0.SocksVersion = @class.Version;
						http_0.SocksHostname = @class.String_0;
						http_0.SocksPort = @class.Port;
						http_0.SocksUsername = @class.Username;
						http_0.SocksPassword = @class.Password;
					}
					string_1 = @class.String_0 + ":" + Conversions.ToString(@class.Port);
				}
				int_0++;
			}
			return true;
		}
	}

	private int method_14(int int_1, int int_2)
	{
		if (_0024STATIC_0024GetRandom_0024202888_0024r_0024Init == null)
		{
			Interlocked.CompareExchange(ref _0024STATIC_0024GetRandom_0024202888_0024r_0024Init, new StaticLocalInitFlag(), null);
		}
		bool lockTaken = false;
		try
		{
			Monitor.Enter(_0024STATIC_0024GetRandom_0024202888_0024r_0024Init, ref lockTaken);
			if (_0024STATIC_0024GetRandom_0024202888_0024r_0024Init.State == 0)
			{
				_0024STATIC_0024GetRandom_0024202888_0024r_0024Init.State = 2;
				_0024STATIC_0024GetRandom_0024202888_0024r = new Random();
			}
			else if (_0024STATIC_0024GetRandom_0024202888_0024r_0024Init.State == 2)
			{
				throw new IncompleteInitialization();
			}
		}
		finally
		{
			_0024STATIC_0024GetRandom_0024202888_0024r_0024Init.State = 1;
			if (lockTaken)
			{
				Monitor.Exit(_0024STATIC_0024GetRandom_0024202888_0024r_0024Init);
			}
		}
		int_2 = checked(int_2 + 1);
		return _0024STATIC_0024GetRandom_0024202888_0024r.Next((int_1 > int_2) ? int_2 : int_1, (int_1 > int_2) ? int_1 : int_2);
	}

	public void method_15()
	{
		try
		{
			if (File.Exists(Globals.SOCKS_PATH))
			{
				File.Delete(Globals.SOCKS_PATH);
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (Class36 value in dictionary_0.Values)
			{
				stringBuilder.Append(value.method_1().Replace("\n", " ") + "\r\n");
			}
			if (!string.IsNullOrEmpty(stringBuilder.ToString()))
			{
				File.AppendAllText(Globals.SOCKS_PATH, stringBuilder.ToString());
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	public void method_16()
	{
		if (File.Exists(Globals.SOCKS_PATH))
		{
			string[] array = File.ReadAllLines(Globals.SOCKS_PATH);
			foreach (string string_ in array)
			{
				method_3(string_);
			}
		}
	}
}
