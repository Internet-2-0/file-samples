using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0;

internal sealed class Class37
{
	private delegate void Delegate11();

	private delegate void Delegate12(List<string> urls);

	private delegate void Delegate13(string url);

	public struct Struct4
	{
		public int int_0;

		public int int_1;

		public int int_2;

		public int int_3;

		public int int_4;

		public int int_5;

		public int int_6;

		public int int_7;
	}

	private Struct4 struct4_0;

	private Dictionary<string, string> dictionary_0;

	private List<string> list_0;

	private List<string> list_1;

	public Class37()
	{
		dictionary_0 = new Dictionary<string, string>();
		list_0 = new List<string>();
		list_1 = new List<string>();
		struct4_0 = default(Struct4);
	}

	public Dictionary<string, string> method_0()
	{
		return dictionary_0;
	}

	public int method_1()
	{
		return dictionary_0.Count;
	}

	public bool method_2(string string_0)
	{
		if (dictionary_0.ContainsValue(string_0))
		{
			return true;
		}
		string key = Class23.smethod_14(string_0);
		if (dictionary_0.ContainsKey(key))
		{
			return true;
		}
		bool result = default(bool);
		return result;
	}

	public int method_3(List<string> list_2)
	{
		int try0001_dispatch = -1;
		int num = default(int);
		List<string> list = default(List<string>);
		int num2 = default(int);
		int num3 = default(int);
		int num5 = default(int);
		List<string>.Enumerator enumerator = default(List<string>.Enumerator);
		string current = default(string);
		string text = default(string);
		bool flag = default(bool);
		string[] array = default(string[]);
		string[] array2 = default(string[]);
		int num6 = default(int);
		string text2 = default(string);
		int result = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				checked
				{
					switch (try0001_dispatch)
					{
					default:
						num = 1;
						list = new List<string>();
						goto IL_000a;
					case 1075:
						{
							num2 = num;
							switch ((num3 <= -2) ? 1 : num3)
							{
							case 1:
								break;
							default:
								goto end_IL_0001;
							}
							int num4 = unchecked(num2 + 1);
							num2 = 0;
							switch (num4)
							{
							case 1:
								break;
							case 2:
								goto IL_000a;
							case 3:
								goto IL_0012;
							case 4:
								goto IL_0030;
							case 6:
								goto IL_003e;
							case 7:
								goto IL_0049;
							case 9:
								goto IL_004e;
							case 10:
								goto IL_0062;
							case 12:
								goto IL_007e;
							case 13:
								goto IL_00b9;
							case 15:
								goto IL_00d5;
							case 16:
								goto IL_00eb;
							case 18:
								goto IL_0107;
							case 19:
								goto IL_012f;
							case 21:
								goto IL_014b;
							case 22:
								goto IL_0160;
							case 24:
								goto IL_017c;
							case 25:
								goto IL_0191;
							case 27:
								goto IL_01ad;
							case 28:
								goto IL_01c2;
							case 30:
								goto IL_01de;
							case 31:
								goto IL_01fa;
							case 32:
								goto IL_0223;
							case 33:
								goto IL_023e;
							case 34:
								goto IL_024d;
							case 37:
							case 38:
							case 39:
								goto IL_0268;
							case 35:
								goto IL_0273;
							case 40:
							case 41:
								goto IL_028c;
							case 42:
								goto IL_029e;
							case 43:
								goto IL_02a9;
							case 5:
							case 45:
								goto IL_02b4;
							case 8:
							case 11:
							case 14:
							case 17:
							case 20:
							case 23:
							case 26:
							case 29:
							case 36:
							case 44:
								goto IL_02bc;
							case 46:
								goto IL_02d5;
							case 47:
								goto IL_02e5;
							case 48:
								goto IL_02f3;
							case 49:
								goto IL_030f;
							case 50:
							case 51:
								goto end_IL_0001_2;
							default:
								goto end_IL_0001;
							case 52:
								goto end_IL_0001_3;
							}
							goto default;
						}
						IL_012f:
						num = 19;
						struct4_0.int_5++;
						goto IL_02bc;
						IL_00b9:
						num = 13;
						struct4_0.int_1++;
						goto IL_02bc;
						IL_02a9:
						num = 43;
						num5++;
						goto IL_02bc;
						IL_02bc:
						num = 44;
						struct4_0.int_7++;
						goto IL_02b4;
						IL_000a:
						ProjectData.ClearProjectError();
						num3 = -2;
						goto IL_0012;
						IL_0012:
						num = 3;
						enumerator = list_2.GetEnumerator();
						goto IL_001b;
						IL_001b:
						if (enumerator.MoveNext())
						{
							current = enumerator.Current;
							goto IL_0030;
						}
						goto IL_02d5;
						IL_02b4:
						num = 45;
						goto IL_001b;
						IL_0030:
						num = 4;
						if (!string.IsNullOrEmpty(current))
						{
							goto IL_003e;
						}
						goto IL_02b4;
						IL_003e:
						num = 6;
						text = Class23.smethod_14(current);
						goto IL_0049;
						IL_0049:
						num = 7;
						flag = true;
						goto IL_004e;
						IL_004e:
						num = 9;
						if (flag == !Class23.smethod_13(current))
						{
							goto IL_0062;
						}
						goto IL_007e;
						IL_0062:
						num = 10;
						struct4_0.int_6++;
						goto IL_02bc;
						IL_007e:
						num = 12;
						if (flag == dictionary_0.ContainsValue(current) || flag == dictionary_0.ContainsKey(text) || flag == dictionary_0.ContainsKey(current))
						{
							goto IL_00b9;
						}
						goto IL_00d5;
						IL_02d5:
						num = 46;
						((IDisposable)enumerator).Dispose();
						goto IL_02e5;
						IL_02e5:
						num = 47;
						if (list.Count <= 0)
						{
							break;
						}
						goto IL_02f3;
						IL_00d5:
						num = 15;
						if (flag == dictionary_0.ContainsKey(text))
						{
							goto IL_00eb;
						}
						goto IL_0107;
						IL_00eb:
						num = 16;
						struct4_0.int_1++;
						goto IL_02bc;
						IL_0107:
						num = 18;
						if (flag == Globals.GTrash.method_2(current) || flag == Globals.GTrash.method_2(text))
						{
							goto IL_012f;
						}
						goto IL_014b;
						IL_02f3:
						num = 48;
						struct4_0.int_0 += list.Count;
						goto IL_030f;
						IL_014b:
						num = 21;
						if (flag == Globals.DG_SQLi.method_10(current))
						{
							goto IL_0160;
						}
						goto IL_017c;
						IL_0160:
						num = 22;
						struct4_0.int_2++;
						goto IL_02bc;
						IL_017c:
						num = 24;
						if (flag == Globals.DG_SQLiNoInjectable.method_9(current))
						{
							goto IL_0191;
						}
						goto IL_01ad;
						IL_0191:
						num = 25;
						struct4_0.int_3++;
						goto IL_02bc;
						IL_01ad:
						num = 27;
						if (flag == Globals.DG_FileInclusao.method_10(current))
						{
							goto IL_01c2;
						}
						goto IL_01de;
						IL_01c2:
						num = 28;
						struct4_0.int_4++;
						goto IL_02bc;
						IL_01de:
						num = 30;
						if (Conversions.ToBoolean(Globals.GetObjectValue(Globals.GMain.btnSearchFilter)))
						{
							goto IL_01fa;
						}
						goto IL_028c;
						IL_01fa:
						num = 31;
						array = Globals.GetObjectValue(Globals.GMain.txtSearchFilter).ToString().Split(';');
						goto IL_0223;
						IL_0223:
						num = 32;
						array2 = array;
						num6 = 0;
						goto IL_022d;
						IL_022d:
						if (num6 < array2.Length)
						{
							text2 = array2[num6];
							goto IL_023e;
						}
						goto IL_028c;
						IL_030f:
						num = 49;
						lock (list_0)
						{
							list_0.AddRange(list.ToArray());
						}
						break;
						IL_023e:
						num = 33;
						if (!string.IsNullOrEmpty(text2))
						{
							goto IL_024d;
						}
						goto IL_0268;
						IL_024d:
						num = 34;
						if (current.ToLower().Contains(text2.ToLower()))
						{
							goto IL_0268;
						}
						goto IL_0273;
						IL_0273:
						num = 35;
						struct4_0.int_6++;
						goto IL_02bc;
						IL_0268:
						num = 39;
						num6++;
						goto IL_022d;
						IL_028c:
						num = 41;
						dictionary_0.Add(text, current);
						goto IL_029e;
						IL_029e:
						num = 42;
						list.Add(current);
						goto IL_02a9;
						end_IL_0001_2:
						break;
					}
					num = 51;
					result = num5;
					break;
				}
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 1075;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public void method_4()
	{
		int try0001_dispatch = -1;
		int num = default(int);
		int num2 = default(int);
		int num3 = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					num = 1;
					if (Globals.GMain.dtgQueue.InvokeRequired)
					{
						goto IL_0015;
					}
					goto IL_0038;
				case 491:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_0015;
						case 4:
							goto IL_0038;
						case 5:
							goto IL_0040;
						case 6:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
						case 7:
						case 8:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_0015:
					num = 2;
					Globals.GMain.dtgQueue.Invoke(new Delegate11(method_4));
					goto end_IL_0001_3;
					IL_0038:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_0040;
					IL_0040:
					num = 5;
					lock (list_0)
					{
						if (list_0.Count > 0)
						{
							Globals.GMain.dtgQueue.Rows.AddRange(Array.ConvertAll(list_0.ToArray(), method_10));
							list_0.Clear();
							if (Globals.GMain.method_21() == MainForm.Enum6.const_1)
							{
								Globals.GMain.method_32();
							}
						}
					}
					break;
					end_IL_0001_2:
					break;
				}
				num = 6;
				lock (list_1)
				{
					if (list_1.Count <= 0)
					{
						break;
					}
					foreach (string item in list_1)
					{
						foreach (DataGridViewRow item2 in (IEnumerable)Globals.GMain.dtgQueue.Rows)
						{
							if (item2.Cells[0].Value.Equals(item))
							{
								Globals.GMain.dtgQueue.Rows.Remove(item2);
								break;
							}
						}
					}
					list_1.Clear();
				}
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 491;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	public void method_5(string string_0)
	{
		method_6(new string[1] { string_0 });
	}

	public void method_6(string[] string_0)
	{
		new List<string>();
		lock (list_1)
		{
			foreach (string text in string_0)
			{
				string key = Class23.smethod_14(text);
				if (dictionary_0.ContainsKey(key))
				{
					dictionary_0.Remove(key);
				}
				list_1.Add(text);
			}
		}
	}

	public void method_7()
	{
		dictionary_0 = new Dictionary<string, string>();
		list_0 = new List<string>();
		list_1 = new List<string>();
		Globals.GMain.dtgQueue.Rows.Clear();
	}

	public void method_8()
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					break;
				case 80:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 3:
							goto end_IL_0001_3;
						}
						goto default;
					}
					end_IL_0001_2:
					break;
				}
				num = 2;
				lock (dictionary_0)
				{
					dictionary_0 = null;
				}
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 80;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	public void method_9()
	{
		if (File.Exists(Globals.QUEUE_PATH))
		{
			string[] array = File.ReadAllLines(Globals.QUEUE_PATH);
			string[] array2 = array;
			foreach (string text in array2)
			{
				string key = Class23.smethod_14(text);
				if (!dictionary_0.ContainsKey(key))
				{
					dictionary_0.Add(key, text);
				}
			}
		}
		Globals.GMain.dtgQueue.Rows.AddRange(Array.ConvertAll(dictionary_0.Values.ToArray(), method_10));
	}

	private DataGridViewRow method_10(string string_0)
	{
		DataGridViewRow dataGridViewRow = new DataGridViewRow();
		dataGridViewRow.CreateCells(Globals.GMain.dtgQueue);
		dataGridViewRow.SetValues(string_0);
		return dataGridViewRow;
	}

	public void method_11()
	{
		if (File.Exists(Globals.QUEUE_PATH))
		{
			File.Delete(Globals.QUEUE_PATH);
		}
		File.WriteAllLines(Globals.QUEUE_PATH, dictionary_0.Values.ToArray());
	}

	public void method_12()
	{
		struct4_0 = default(Struct4);
	}

	public Struct4 method_13()
	{
		return struct4_0;
	}
}
