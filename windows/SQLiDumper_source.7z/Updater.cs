using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Chilkat;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

public class Updater
{
	private string XMLPath;

	private static string XMLSection;

	private static string UPDATE_TMP;

	private static string DownloadXML;

	private static string DownloadEXE;

	private UpdateProg __Donloader;

	public Updater()
	{
		XMLPath = Globals.APP_PATH + "\\update.xml";
	}

	public void GenerateXML()
	{
		Class51 @class = new Class51(XMLPath);
		@class.method_6("Version", "Major", Conversions.ToString(Globals.VERSION.Major));
		@class.method_6("Version", "Minor", Conversions.ToString(Globals.VERSION.Minor));
		@class.method_6("Version", "Revision", Conversions.ToString(Globals.VERSION.Build));
		@class.method_6("Download", "RAR", "http://aderisci.com/sqli_dumper/update.dat");
		@class.method_6("Changelog", "TXT", "09/15/2017 - v.9.6\r\n* Added Grids Filters by date\r\n* Fixed Dumper data parser (for some MySQL Error injections)\r\n* Misc: improvements, fixes and optimizations\r\n09/01/2017 - v.9.5\r\n* Fix MySQL Load\\Write File for MySQL v.4.x (Data Dumper)\r\n* Fix Stop Work 'Search Column\\Table' MSG Box Error\r\n* Improved Search column sort\r\n* Improved Search Grids freezing\r\n* Improved ContextMenu poor visibility\r\n* Add Grids Key Control \r\n  CTRL + A to select All\r\n  Delete key to delete selected items\r\n  Enter key to go to dumper\r\n08/26/2017 - v.9.4\r\n* Added Germany, Portuguese and Persian Language\r\n* Added Import menu (queue)\r\n* Added Re-Exploiter menu\r\n* Improved Exploiter, better detection rate\r\n* Improved Data Dump, problem with '?~!' in MySQL Error Basead\r\n* Improved Scanner, IP/Proxy control with blacklisted\r\n* Improved Search Column\\Tables\r\n* Improved Dumper Auto-Setup (detecting HTTP Flow Redirects)\r\n08/12/2017 - v.9.3\r\n* Added XXS support\r\n* Added Import URL Injectables.xml from v.8.x\r\n* Added extra 3 column (search rows)\r\n* Added Exploit from .txt (press Start Exploiter with queue empty)\r\n* Added Statistics Virtualization\r\n* Improved exploiter engine\r\n* Improved analyzer engine\r\n  ~40% better detection\r\n  fixed unique filter by domain\r\n  fixed loadfile bug dection\r\n* Improved Dumper for long time dumping (no more slow, only if request delays)\r\n* Improved RAM\\CPU and Traffic use\r\n* Improved multi thread engine stop\r\n* Improved HTTP Debbuger, better delay control\r\n* Improved GUI Core Load\\UnLoad performance\r\n* Improved Skins (added news, removed some)\r\n* Fixed grids auto scroll\r\n* Fixed open new instancie bug on schema\r\n ** For security reasons, HWID is changed.\r\n ** Contact me via jabber for update, or email me.\r\n ** c4rl0s [at] jabber.ru or c4rl0s.pt [at] gmail.com\r\n ** Sorry for any inconvenience");
		@class.method_9();
	}

	public void Check(bool bMsgBox)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected O, but got Unknown
		try
		{
			Http val = new Http();
			val.UserAgent = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtUserAgent));
			val.Accept = Conversions.ToString(Globals.GetObjectValue(Globals.GMain.txtAccept));
			val.ConnectTimeout = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPTimeout));
			val.ReadTimeout = val.ConnectTimeout;
			val.FollowRedirects = true;
			val.AutoAddHostHeader = true;
			val.AllowGzip = true;
			val.SendCookies = true;
			val.SaveCookies = true;
			val.CookieDir = "memory";
			val.UseIEProxy = false;
			Thread.Sleep(2000);
			string text = default(string);
			if (!string.IsNullOrEmpty(text))
			{
				Class51 @class = new Class51(text, "SQLi_Dumper", ';', 1);
				Version version = new Version(Conversions.ToInteger(@class.method_3("Version", "Major", "0")), Conversions.ToInteger(@class.method_3("Version", "Minor", "0")), Conversions.ToInteger(@class.method_3("Version", "Revision", "0")));
				if (version.CompareTo(Globals.VERSION) > 0)
				{
					using (new Class8(Globals.GMain))
					{
						MessageBox.Show(Globals.translate_0.GetStr(Globals.GMain, 36) + version.ToString() + "\r\n\r\n" + @class.method_3("Changelog", "TXT", ""), "SQLi Dumper Update", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					goto IL_01c2;
				}
			}
			if (bMsgBox)
			{
				using (new Class8(Globals.GMain))
				{
					MessageBox.Show(Globals.translate_0.GetStr(Globals.GMain, 38), "SQLi Dumper Update", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			goto IL_01c2;
			IL_01c2:
			val.Dispose();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.StackTrace);
			ProjectData.ClearProjectError();
		}
		finally
		{
			if (File.Exists(Globals.APP_PATH + "\\update.bin"))
			{
				File.Delete(Globals.APP_PATH + "\\update.bin");
			}
		}
	}

	private void OnPercentDone(object sender, PercentDoneEventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 111:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto IL_0011;
						case 4:
							goto IL_0029;
						case 5:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 6:
						case 7:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					Application.DoEvents();
					goto IL_0011;
					IL_0011:
					num = 3;
					__Donloader.prbDownload.Value = e.PercentDone;
					goto IL_0029;
					IL_0029:
					num = 4;
					if (!__Donloader.Cancel)
					{
						goto end_IL_0001_3;
					}
					break;
					end_IL_0001_2:
					break;
				}
				num = 5;
				e.Abort = true;
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 111;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private void OnReceiveRate(object sender, DataRateEventArgs e)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 109:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 3:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 4:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					__Donloader.Text = Globals.translate_0.GetStr(Globals.GMain, 39) + Globals.FormatBytes((double)e.BytesPerSec) + "\\s";
					break;
					end_IL_0001_2:
					break;
				}
				num = 3;
				Application.DoEvents();
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 109;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}
}
