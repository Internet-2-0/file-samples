using System;
using System.Collections;
using System.Text.RegularExpressions;

public class RegExp : IDisposable
{
	private bool bool_0;

	protected virtual void Dispose(bool b)
	{
		if (bool_0 || !b)
		{
		}
		bool_0 = true;
	}

	public void Dispose()
	{
		Dispose(b: true);
		GC.SuppressFinalize(this);
	}

	public string Replace(string sPattern, string sInput, string sValue)
	{
		Regex regex = new Regex(sPattern, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
		regex.Match(sInput);
		string text = regex.Replace(sInput, sValue);
		if (string.IsNullOrEmpty(text))
		{
			return sInput;
		}
		return text;
	}

	public Hashtable Match(string sPattern, string sData, RegexOptions o)
	{
		Hashtable hashtable = new Hashtable();
		Regex regex = new Regex(sPattern, o);
		Match match = regex.Match(sData);
		while (match.Success)
		{
			RegExpResult regExpResult = new RegExpResult();
			regExpResult.Index = match.Index;
			regExpResult.Value = match.Groups[1].Value;
			hashtable.Add(match.Index.ToString(), regExpResult);
			match = match.NextMatch();
		}
		return hashtable;
	}

	public Hashtable GetData(string sData, string sRegExPattern)
	{
		Hashtable hashtable = Match(sRegExPattern, sData, RegexOptions.IgnoreCase);
		Hashtable hashtable2 = new Hashtable();
		if (hashtable.Count == 0)
		{
			return hashtable2;
		}
		foreach (RegExpResult value in hashtable.Values)
		{
			hashtable2.Add(hashtable2.Count.ToString(), value.Value);
		}
		return hashtable2;
	}

	public string GetItemData(string sData, string sPattern, string sDefautValue = "")
	{
		Regex regex = new Regex(sPattern, RegexOptions.IgnoreCase);
		Match match = regex.Match(sData);
		while (true)
		{
			if (match.Success)
			{
				if (!string.IsNullOrEmpty(match.Groups[1].Value))
				{
					break;
				}
				match = match.NextMatch();
				continue;
			}
			return sDefautValue;
		}
		return match.Groups[1].Value;
	}

	public Hashtable SplitData(string sData, string sFind)
	{
		Hashtable hashtable = new Hashtable();
		string[] array = Regex.Split(sData, sFind);
		foreach (string text in array)
		{
			if (!hashtable.Contains(text))
			{
				hashtable.Add(text, text);
			}
		}
		return hashtable;
	}

	public Hashtable GetLinks(string sUrl, string sData, string sRegExPattern)
	{
		Hashtable hashtable = Match(sRegExPattern, sData, RegexOptions.IgnoreCase);
		Hashtable hashtable2 = new Hashtable();
		if (hashtable.Count == 0)
		{
			return hashtable2;
		}
		if (!string.IsNullOrEmpty(sUrl))
		{
			string[] array = Regex.Split(sUrl, "/");
			string text = array[0] + "//" + array[2];
			foreach (RegExpResult value in hashtable.Values)
			{
				if (value.Value.StartsWith("http://"))
				{
					hashtable2.Add(hashtable2.Count.ToString(), new Link(value.Value, value.Value, value));
					continue;
				}
				if (value.Value.StartsWith("./"))
				{
					value.Value = value.Value.Replace("./", "/");
				}
				if (value.Value.StartsWith("/") | value.Value.StartsWith("./"))
				{
					hashtable2.Add(hashtable2.Count.ToString(), new Link(value.Value, text + value.Value, value));
				}
				else
				{
					hashtable2.Add(hashtable2.Count.ToString(), new Link(value.Value, text + "/" + value.Value, value));
				}
			}
			return hashtable2;
		}
		foreach (RegExpResult value2 in hashtable.Values)
		{
			hashtable2.Add(hashtable2.Count.ToString(), value2.Value);
		}
		return hashtable2;
	}
}
