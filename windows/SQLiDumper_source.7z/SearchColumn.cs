using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using DataBase;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class SearchColumn : Form
{
	public class Engine
	{
		public delegate void DAdd(string sURL, string sMethod, string sSearch, int iCount, List<string> lTables);

		public class Macth
		{
			[CompilerGenerated]
			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			private string string_0;

			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			[CompilerGenerated]
			private int int_0;

			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			[CompilerGenerated]
			private Dictionary<string, Traget> dictionary_0;

			public string Method
			{
				[CompilerGenerated]
				get
				{
					return string_0;
				}
				[CompilerGenerated]
				set
				{
					string_0 = value;
				}
			}

			public int TotalRows
			{
				[CompilerGenerated]
				get
				{
					return int_0;
				}
				[CompilerGenerated]
				set
				{
					int_0 = value;
				}
			}

			public Dictionary<string, Traget> Detalhes
			{
				[CompilerGenerated]
				get
				{
					return dictionary_0;
				}
				[CompilerGenerated]
				set
				{
					dictionary_0 = value;
				}
			}

			public Macth()
			{
				Detalhes = new Dictionary<string, Traget>();
			}
		}

		public class Traget
		{
			[CompilerGenerated]
			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			private string string_0;

			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			[CompilerGenerated]
			private int int_0;

			[CompilerGenerated]
			[DebuggerBrowsable(DebuggerBrowsableState.Never)]
			private List<string> list_0;

			public string Search
			{
				[CompilerGenerated]
				get
				{
					return string_0;
				}
				[CompilerGenerated]
				set
				{
					string_0 = value;
				}
			}

			public int Rows
			{
				[CompilerGenerated]
				get
				{
					return int_0;
				}
				[CompilerGenerated]
				set
				{
					int_0 = value;
				}
			}

			public List<string> Schema
			{
				[CompilerGenerated]
				get
				{
					return list_0;
				}
				[CompilerGenerated]
				set
				{
					list_0 = value;
				}
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private bool bool_0;

		public List<string> Search;

		private Dictionary<string, Macth> dictionary_0;

		private ListViewExt listViewExt_0;

		private ToolStripComboBox toolStripComboBox_0;

		public int MiniRows
		{
			[CompilerGenerated]
			get
			{
				return int_0;
			}
			[CompilerGenerated]
			set
			{
				int_0 = value;
			}
		}

		public bool AddItems
		{
			[CompilerGenerated]
			get
			{
				return bool_0;
			}
			[CompilerGenerated]
			set
			{
				bool_0 = value;
			}
		}

		public Engine(bool bItems, ListViewExt lw, ToolStripComboBox cb)
		{
			Search = new List<string>();
			dictionary_0 = new Dictionary<string, Macth>();
			AddItems = bItems;
			listViewExt_0 = lw;
			toolStripComboBox_0 = cb;
		}

		public void GetItems(ref List<ListViewItem> oItems, ref List<ListViewGroup> oGroups, string sSearch)
		{
			oItems = new List<ListViewItem>();
			oGroups = new List<ListViewGroup>();
			Dictionary<string, Macth> dictionary = new Dictionary<string, Macth>();
			foreach (KeyValuePair<string, Macth> item in dictionary_0)
			{
				foreach (KeyValuePair<string, Traget> detalhe in item.Value.Detalhes)
				{
					if ((string.IsNullOrEmpty(sSearch) || detalhe.Value.Search.Equals(sSearch)) && detalhe.Value.Rows >= MiniRows)
					{
						dictionary.Add(item.Key, item.Value);
						if (!string.IsNullOrEmpty(sSearch))
						{
							item.Value.TotalRows = detalhe.Value.Rows;
						}
						break;
					}
				}
			}
			dictionary = method_1(dictionary);
			foreach (KeyValuePair<string, Macth> item2 in dictionary)
			{
				string text = Class23.smethod_11(item2.Key);
				ListViewGroup listViewGroup = null;
				foreach (ListViewGroup oGroup in oGroups)
				{
					if (oGroup.Header.Equals(text))
					{
						listViewGroup = oGroup;
						break;
					}
				}
				if (listViewGroup == null)
				{
					listViewGroup = new ListViewGroup(text);
					oGroups.Add(listViewGroup);
				}
				ListViewItem listViewItem = new ListViewItem("URL");
				listViewItem.SubItems.Add(item2.Key);
				listViewItem.Group = listViewGroup;
				oItems.Add(listViewItem);
				listViewItem = new ListViewItem("Method");
				listViewItem.SubItems.Add(item2.Value.Method);
				listViewItem.Group = listViewGroup;
				oItems.Add(listViewItem);
				if (string.IsNullOrEmpty(sSearch))
				{
					listViewItem = new ListViewItem("Total Rows");
					listViewItem.SubItems.Add(Strings.FormatNumber(item2.Value.TotalRows, 0));
					listViewItem.Group = listViewGroup;
					oItems.Add(listViewItem);
				}
				item2.Value.Detalhes = method_0(item2.Value.Detalhes);
				foreach (KeyValuePair<string, Traget> detalhe2 in item2.Value.Detalhes)
				{
					if (!string.IsNullOrEmpty(sSearch) && !detalhe2.Value.Search.Equals(sSearch))
					{
						continue;
					}
					if (string.IsNullOrEmpty(sSearch))
					{
						listViewItem = new ListViewItem("Search");
						listViewItem.SubItems.Add(detalhe2.Value.Search);
						listViewItem.Group = listViewGroup;
						oItems.Add(listViewItem);
					}
					listViewItem = new ListViewItem("Rows");
					listViewItem.SubItems.Add(Strings.FormatNumber(detalhe2.Value.Rows, 0));
					listViewItem.Group = listViewGroup;
					oItems.Add(listViewItem);
					foreach (string item3 in detalhe2.Value.Schema)
					{
						listViewItem = new ListViewItem("");
						listViewItem.SubItems.Add(item3);
						listViewItem.Group = listViewGroup;
						oItems.Add(listViewItem);
					}
				}
			}
		}

		public ListViewGroup GetGroupByHeader(ListViewExt lvw, string name)
		{
			foreach (ListViewGroup group in lvw.Groups)
			{
				if (group.Header.Equals(name))
				{
					return group;
				}
			}
			return null;
		}

		public void Sort()
		{
			dictionary_0 = method_1(dictionary_0);
			foreach (KeyValuePair<string, Macth> item in dictionary_0)
			{
				item.Value.Detalhes = method_0(item.Value.Detalhes);
				foreach (KeyValuePair<string, Traget> detalhe in item.Value.Detalhes)
				{
					detalhe.Value.Schema = method_2(detalhe.Value.Schema);
				}
			}
		}

		public void Add(string sURL, string sMethod, string sSearch, int iCount, List<string> lTables)
		{
			if (listViewExt_0.InvokeRequired)
			{
				listViewExt_0.Invoke(new DAdd(Add), sURL, sMethod, sSearch, iCount, lTables);
				return;
			}
			Macth macth;
			if (dictionary_0.ContainsKey(sURL))
			{
				macth = dictionary_0[sURL];
			}
			else
			{
				macth = new Macth();
				dictionary_0.Add(sURL, macth);
			}
			checked
			{
				macth.TotalRows += iCount;
				macth.Method = sMethod;
				Traget traget;
				if (macth.Detalhes.ContainsKey(sSearch))
				{
					traget = macth.Detalhes[sSearch];
					traget.Schema.AddRange(lTables.ToArray());
				}
				else
				{
					traget = new Traget();
					traget.Search = sSearch;
					traget.Rows = iCount;
					traget.Schema = lTables;
					macth.Detalhes.Add(sSearch, traget);
				}
				traget.Schema = method_2(traget.Schema);
				if (!Search.Contains(sSearch))
				{
					Search.Add(sSearch);
				}
				if (!AddItems)
				{
					return;
				}
				lock (listViewExt_0)
				{
					if (!toolStripComboBox_0.Items.Contains(sSearch))
					{
						toolStripComboBox_0.Items.Add(sSearch);
					}
					if ((toolStripComboBox_0.SelectedIndex > 0 && !toolStripComboBox_0.SelectedItem.Equals(sSearch)) || traget.Rows < MiniRows)
					{
						return;
					}
					string text = Class23.smethod_11(sURL);
					ListViewGroup listViewGroup = GetGroupByHeader(listViewExt_0, text);
					Globals.LockWindowUpdate(listViewExt_0.Handle);
					if (listViewGroup == null)
					{
						listViewGroup = new ListViewGroup(text);
						listViewExt_0.Groups.Add(listViewGroup);
						ListViewItem listViewItem = new ListViewItem("URL");
						listViewItem.SubItems.Add(sURL);
						listViewItem.Group = listViewGroup;
						listViewExt_0.Items.Add(listViewItem);
						listViewItem = new ListViewItem("Method");
						listViewItem.SubItems.Add(macth.Method);
						listViewItem.Group = listViewGroup;
						listViewExt_0.Items.Add(listViewItem);
					}
					if (macth.Detalhes.Count > 1)
					{
						ListViewItem listViewItem = new ListViewItem("Total Rows");
						listViewItem.SubItems.Add(Strings.FormatNumber(macth.TotalRows, 0));
						listViewItem.Group = listViewGroup;
						listViewExt_0.Items.Add(listViewItem);
					}
					foreach (KeyValuePair<string, Traget> detalhe in macth.Detalhes)
					{
						if (!detalhe.Value.Search.Equals(sSearch))
						{
							continue;
						}
						ListViewItem listViewItem = new ListViewItem("Search");
						listViewItem.SubItems.Add(detalhe.Value.Search);
						listViewItem.Group = listViewGroup;
						listViewExt_0.Items.Add(listViewItem);
						listViewItem = new ListViewItem("Rows");
						listViewItem.SubItems.Add(Strings.FormatNumber(detalhe.Value.Rows, 0));
						listViewItem.Group = listViewGroup;
						listViewExt_0.Items.Add(listViewItem);
						foreach (string item in detalhe.Value.Schema)
						{
							listViewItem = new ListViewItem("");
							listViewItem.SubItems.Add(item);
							listViewItem.Group = listViewGroup;
							listViewExt_0.Items.Add(listViewItem);
						}
					}
					Globals.LockWindowUpdate(IntPtr.Zero);
				}
			}
		}

		private Dictionary<string, Traget> method_0(Dictionary<string, Traget> dictionary_1)
		{
			Dictionary<string, Traget> dictionary = new Dictionary<string, Traget>();
			int num = 0;
			_ = 0;
			KeyValuePair<string, Traget> keyValuePair = default(KeyValuePair<string, Traget>);
			while (dictionary_1.Count > 0)
			{
				foreach (KeyValuePair<string, Traget> item in dictionary_1)
				{
					if (item.Value.Rows > num)
					{
						num = item.Value.Rows;
						keyValuePair = item;
					}
				}
				dictionary.Add(keyValuePair.Key, keyValuePair.Value);
				dictionary_1.Remove(keyValuePair.Key);
				num = 0;
			}
			return dictionary;
		}

		private Dictionary<string, Macth> method_1(Dictionary<string, Macth> dictionary_1)
		{
			Dictionary<string, Macth> dictionary = new Dictionary<string, Macth>();
			int num = 0;
			_ = 0;
			KeyValuePair<string, Macth> keyValuePair = default(KeyValuePair<string, Macth>);
			while (dictionary_1.Count > 0)
			{
				foreach (KeyValuePair<string, Macth> item in dictionary_1)
				{
					if (item.Value.TotalRows > num)
					{
						num = item.Value.TotalRows;
						keyValuePair = item;
					}
				}
				dictionary.Add(keyValuePair.Key, keyValuePair.Value);
				dictionary_1.Remove(keyValuePair.Key);
				num = 0;
			}
			return dictionary;
		}

		private List<string> method_2(List<string> list_0)
		{
			List<string> list = new List<string>();
			int num = 0;
			_ = 0;
			string item = "";
			while (list_0.Count > 0)
			{
				foreach (string item2 in list_0)
				{
					int num2 = Conversions.ToInteger(checked(item2.Substring(item2.IndexOf("[") + 1, item2.IndexOf("]") - 1)));
					if (num2 > num)
					{
						num = num2;
						item = item2;
					}
				}
				list.Add(item);
				list_0.Remove(item);
				num = 0;
			}
			return list;
		}
	}

	private delegate void Delegate43(object sender, DoWorkEventArgs e);

	private struct Struct8
	{
		public IntPtr intptr_0;

		public IntPtr intptr_1;

		public int int_0;

		public int int_1;

		public int int_2;

		public int int_3;

		public int int_4;
	}

	private IContainer icontainer_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("lvwData")]
	private ListViewExt _lvwData;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("ColumnHeader5")]
	private ColumnHeader columnHeader_0;

	[AccessedThroughProperty("ColumnHeader6")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ColumnHeader columnHeader_1;

	[AccessedThroughProperty("mnuListview")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ContextMenuStrip _mnuListView_1;

	[AccessedThroughProperty("mnuShell")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuShell;

	[AccessedThroughProperty("mnuClipboard")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuClipboard;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("ColumnHeader1")]
	private ColumnHeader columnHeader_2;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("ColumnHeader2")]
	private ColumnHeader columnHeader_3;

	[AccessedThroughProperty("mnuDumper1")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripMenuItem _mnuDumper1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("mnuDumper2")]
	private ToolStripMenuItem _mnuDumper2;

	[CompilerGenerated]
	[AccessedThroughProperty("btnCopy")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripButton _btnCopy;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("btnSort")]
	private ToolStripButton _btnSort;

	[AccessedThroughProperty("cmbMinRows")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripComboBox _cmbMinRows;

	[AccessedThroughProperty("cmbSearch")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private ToolStripComboBox _cmbSearch;

	[AccessedThroughProperty("mnuFocusItem")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ToolStripMenuItem _mnuFocusItem;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("bckSort")]
	[CompilerGenerated]
	private BackgroundWorker backgroundWorker_0;

	private int int_0;

	private Engine engine_0;

	private DataGridView dataGridView_0;

	private Size size_0;

	private bool bool_0;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool bool_1;

	private static int int_1;

	internal virtual ListViewExt lvwData
	{
		[CompilerGenerated]
		get
		{
			return _lvwData;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_3;
			ListViewExt listViewExt = _lvwData;
			if (listViewExt != null)
			{
				listViewExt.SelectedIndexChanged -= value2;
			}
			_lvwData = value;
			listViewExt = _lvwData;
			if (listViewExt != null)
			{
				listViewExt.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual ColumnHeader ColumnHeader5
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_0 = value;
		}
	}

	internal virtual ColumnHeader ColumnHeader6
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_1 = value;
		}
	}

	[field: AccessedThroughProperty("stsMain")]
	public virtual StatusStrip stsMain
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblStatus")]
	public virtual ToolStripStatusLabel lblStatus
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ContextMenuStrip mnuListview
	{
		[CompilerGenerated]
		get
		{
			return _mnuListView_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			CancelEventHandler value2 = method_5;
			ContextMenuStrip mnuListView_ = _mnuListView_1;
			if (mnuListView_ != null)
			{
				mnuListView_.Opening -= value2;
			}
			_mnuListView_1 = value;
			mnuListView_ = _mnuListView_1;
			if (mnuListView_ != null)
			{
				mnuListView_.Opening += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuShell
	{
		[CompilerGenerated]
		get
		{
			return _mnuShell;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_6;
			ToolStripMenuItem toolStripMenuItem = _mnuShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuShell = value;
			toolStripMenuItem = _mnuShell;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuClipboard
	{
		[CompilerGenerated]
		get
		{
			return _mnuClipboard;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_6;
			ToolStripMenuItem toolStripMenuItem = _mnuClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuClipboard = value;
			toolStripMenuItem = _mnuClipboard;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ColumnHeader ColumnHeader1
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_2 = value;
		}
	}

	internal virtual ColumnHeader ColumnHeader2
	{
		[CompilerGenerated]
		get
		{
			return columnHeader_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			columnHeader_3 = value;
		}
	}

	[field: AccessedThroughProperty("mnuDumper")]
	internal virtual ContextMenuStrip mnuDumper
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripMenuItem mnuDumper1
	{
		[CompilerGenerated]
		get
		{
			return _mnuDumper1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_4;
			ToolStripMenuItem toolStripMenuItem = _mnuDumper1;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuDumper1 = value;
			toolStripMenuItem = _mnuDumper1;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuDumper2
	{
		[CompilerGenerated]
		get
		{
			return _mnuDumper2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_4;
			ToolStripMenuItem toolStripMenuItem = _mnuDumper2;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuDumper2 = value;
			toolStripMenuItem = _mnuDumper2;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("btnGoToDumper")]
	internal virtual ToolStripDropDownButton btnGoToDumper
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnCopy
	{
		[CompilerGenerated]
		get
		{
			return _btnCopy;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_2;
			ToolStripButton toolStripButton = _btnCopy;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnCopy = value;
			toolStripButton = _btnCopy;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator1")]
	internal virtual ToolStripSeparator ToolStripSeparator1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripButton btnSort
	{
		[CompilerGenerated]
		get
		{
			return _btnSort;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_9;
			ToolStripButton toolStripButton = _btnSort;
			if (toolStripButton != null)
			{
				toolStripButton.Click -= value2;
			}
			_btnSort = value;
			toolStripButton = _btnSort;
			if (toolStripButton != null)
			{
				toolStripButton.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("ToolStripSeparator2")]
	internal virtual ToolStripSeparator ToolStripSeparator2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripComboBox cmbMinRows
	{
		[CompilerGenerated]
		get
		{
			return _cmbMinRows;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_7;
			ToolStripComboBox toolStripComboBox = _cmbMinRows;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged -= value2;
			}
			_cmbMinRows = value;
			toolStripComboBox = _cmbMinRows;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("tsChecker2")]
	public virtual ToolStrip tsChecker2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("ToolStripLabel1")]
	internal virtual ToolStripLabel ToolStripLabel1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual ToolStripComboBox cmbSearch
	{
		[CompilerGenerated]
		get
		{
			return _cmbSearch;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_7;
			ToolStripComboBox toolStripComboBox = _cmbSearch;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged -= value2;
			}
			_cmbSearch = value;
			toolStripComboBox = _cmbSearch;
			if (toolStripComboBox != null)
			{
				toolStripComboBox.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem mnuFocusItem
	{
		[CompilerGenerated]
		get
		{
			return _mnuFocusItem;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_8;
			ToolStripMenuItem toolStripMenuItem = _mnuFocusItem;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click -= value2;
			}
			_mnuFocusItem = value;
			toolStripMenuItem = _mnuFocusItem;
			if (toolStripMenuItem != null)
			{
				toolStripMenuItem.Click += value2;
			}
		}
	}

	internal virtual BackgroundWorker bckSort
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			DoWorkEventHandler value2 = method_10;
			RunWorkerCompletedEventHandler value3 = method_11;
			BackgroundWorker backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork -= value2;
				backgroundWorker.RunWorkerCompleted -= value3;
			}
			backgroundWorker_0 = value;
			backgroundWorker = backgroundWorker_0;
			if (backgroundWorker != null)
			{
				backgroundWorker.DoWork += value2;
				backgroundWorker.RunWorkerCompleted += value3;
			}
		}
	}

	public bool CanClose
	{
		[CompilerGenerated]
		get
		{
			return bool_1;
		}
		[CompilerGenerated]
		set
		{
			bool_1 = value;
		}
	}

	public SearchColumn()
	{
		base.FormClosing += SearchColumn_FormClosing;
		CanClose = true;
		InitializeComponent();
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	public SearchColumn(bool bExploiter, DataGridView url)
	{
		base.FormClosing += SearchColumn_FormClosing;
		CanClose = true;
		InitializeComponent();
		lvwData.ShowGroups = true;
		lvwData.ShowItemToolTips = true;
		cmbSearch.Items.Add(Globals.translate_0.GetStr(base.Name, "mnuAll", "All"));
		cmbSearch.SelectedIndex = 0;
		dataGridView_0 = url;
		engine_0 = new Engine(bExploiter, lvwData, cmbSearch);
		cmbMinRows.Items.AddRange(new string[7]
		{
			"1k",
			"5k",
			"10k",
			"30k",
			"50k",
			"100k",
			Globals.translate_0.GetStr(base.Name, "mnuAll", "All")
		});
		cmbMinRows.SelectedIndex = checked(cmbMinRows.Items.Count - 1);
		lvwData.ShowGroups = true;
		lvwData.View = View.Details;
		lvwData.HeaderStyle = ColumnHeaderStyle.None;
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
		cmbSearch.Visible = cmbSearch.Items.Count > 2;
		size_0 = base.Size;
		base.FormBorderStyle = FormBorderStyle.None;
		base.Size = new Size(0, 0);
		bool_0 = true;
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new System.ComponentModel.Container();
		this.stsMain = new System.Windows.Forms.StatusStrip();
		this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
		this.mnuDumper = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuDumper2 = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuDumper1 = new System.Windows.Forms.ToolStripMenuItem();
		this.btnGoToDumper = new System.Windows.Forms.ToolStripDropDownButton();
		this.mnuListview = new System.Windows.Forms.ContextMenuStrip(this.icontainer_0);
		this.mnuShell = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuClipboard = new System.Windows.Forms.ToolStripMenuItem();
		this.mnuFocusItem = new System.Windows.Forms.ToolStripMenuItem();
		this.ColumnHeader5 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader6 = new System.Windows.Forms.ColumnHeader();
		this.btnCopy = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
		this.btnSort = new System.Windows.Forms.ToolStripButton();
		this.ToolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
		this.cmbMinRows = new System.Windows.Forms.ToolStripComboBox();
		this.tsChecker2 = new System.Windows.Forms.ToolStrip();
		this.ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
		this.cmbSearch = new System.Windows.Forms.ToolStripComboBox();
		this.lvwData = new ListViewExt();
		this.ColumnHeader1 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader2 = new System.Windows.Forms.ColumnHeader();
		this.bckSort = new System.ComponentModel.BackgroundWorker();
		this.stsMain.SuspendLayout();
		this.mnuDumper.SuspendLayout();
		this.mnuListview.SuspendLayout();
		this.tsChecker2.SuspendLayout();
		base.SuspendLayout();
		this.stsMain.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.stsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.lblStatus });
		this.stsMain.Location = new System.Drawing.Point(0, 538);
		this.stsMain.Name = "stsMain";
		this.stsMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
		this.stsMain.Size = new System.Drawing.Size(488, 22);
		this.stsMain.TabIndex = 3;
		this.stsMain.Text = "StatusStrip1";
		this.lblStatus.Name = "lblStatus";
		this.lblStatus.Size = new System.Drawing.Size(473, 17);
		this.lblStatus.Spring = true;
		this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.mnuDumper.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuDumper.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.mnuDumper2, this.mnuDumper1 });
		this.mnuDumper.Name = "mnuListView";
		this.mnuDumper.OwnerItem = this.btnGoToDumper;
		this.mnuDumper.ShowImageMargin = false;
		this.mnuDumper.Size = new System.Drawing.Size(167, 48);
		this.mnuDumper2.Name = "mnuDumper2";
		this.mnuDumper2.Size = new System.Drawing.Size(166, 22);
		this.mnuDumper2.Text = "New Dumper Instance";
		this.mnuDumper1.Name = "mnuDumper1";
		this.mnuDumper1.Size = new System.Drawing.Size(166, 22);
		this.mnuDumper1.Text = "Dumper Form";
		this.btnGoToDumper.DropDown = this.mnuDumper;
		this.btnGoToDumper.Enabled = false;
		this.btnGoToDumper.Image = ns0.Class6.OpenTopic_16x_24;
		this.btnGoToDumper.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnGoToDumper.Name = "btnGoToDumper";
		this.btnGoToDumper.Size = new System.Drawing.Size(120, 22);
		this.btnGoToDumper.Text = "&Go To Dumper";
		this.mnuListview.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.mnuListview.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.mnuShell, this.mnuClipboard, this.mnuFocusItem });
		this.mnuListview.Name = "mnuListView";
		this.mnuListview.ShowImageMargin = false;
		this.mnuListview.Size = new System.Drawing.Size(133, 70);
		this.mnuShell.Name = "mnuShell";
		this.mnuShell.Size = new System.Drawing.Size(132, 22);
		this.mnuShell.Text = "Shell URL";
		this.mnuClipboard.Name = "mnuClipboard";
		this.mnuClipboard.Size = new System.Drawing.Size(132, 22);
		this.mnuClipboard.Text = "Clipboard URL";
		this.mnuFocusItem.Name = "mnuFocusItem";
		this.mnuFocusItem.Size = new System.Drawing.Size(132, 22);
		this.mnuFocusItem.Text = "Focus Grid Item";
		this.ColumnHeader5.Text = "Description";
		this.ColumnHeader5.Width = 89;
		this.ColumnHeader6.Text = "Value";
		this.ColumnHeader6.Width = 342;
		this.btnCopy.Image = ns0.Class6.clipboard_16xLG;
		this.btnCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnCopy.Name = "btnCopy";
		this.btnCopy.Size = new System.Drawing.Size(87, 22);
		this.btnCopy.Text = "&Clipboard";
		this.ToolStripSeparator1.Name = "ToolStripSeparator1";
		this.ToolStripSeparator1.Size = new System.Drawing.Size(6, 25);
		this.btnSort.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.btnSort.Image = ns0.Class6.GetDynamicValuePropertyactivity_16x_24;
		this.btnSort.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.btnSort.Name = "btnSort";
		this.btnSort.Size = new System.Drawing.Size(56, 22);
		this.btnSort.Text = "&Sort";
		this.ToolStripSeparator2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripSeparator2.Name = "ToolStripSeparator2";
		this.ToolStripSeparator2.Size = new System.Drawing.Size(6, 25);
		this.cmbMinRows.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.cmbMinRows.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbMinRows.Name = "cmbMinRows";
		this.cmbMinRows.Size = new System.Drawing.Size(75, 25);
		this.tsChecker2.AutoSize = false;
		this.tsChecker2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.tsChecker2.ImageScalingSize = new System.Drawing.Size(24, 24);
		this.tsChecker2.Items.AddRange(new System.Windows.Forms.ToolStripItem[8] { this.btnCopy, this.ToolStripSeparator1, this.btnGoToDumper, this.btnSort, this.ToolStripSeparator2, this.cmbMinRows, this.ToolStripLabel1, this.cmbSearch });
		this.tsChecker2.Location = new System.Drawing.Point(0, 0);
		this.tsChecker2.Name = "tsChecker2";
		this.tsChecker2.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
		this.tsChecker2.Size = new System.Drawing.Size(488, 25);
		this.tsChecker2.TabIndex = 4;
		this.tsChecker2.Text = "ToolStrip1";
		this.ToolStripLabel1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.ToolStripLabel1.Name = "ToolStripLabel1";
		this.ToolStripLabel1.Size = new System.Drawing.Size(68, 22);
		this.ToolStripLabel1.Text = "Min.. Rows:";
		this.cmbSearch.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
		this.cmbSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.cmbSearch.Name = "cmbSearch";
		this.cmbSearch.Size = new System.Drawing.Size(75, 23);
		this.lvwData.AccessibleDescription = "";
		this.lvwData.AccessibleName = "";
		this.lvwData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[2] { this.ColumnHeader1, this.ColumnHeader2 });
		this.lvwData.ContextMenuStrip = this.mnuListview;
		this.lvwData.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lvwData.Font = new System.Drawing.Font("Courier New", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.lvwData.ForeColor = System.Drawing.SystemColors.ControlText;
		this.lvwData.FullRowSelect = true;
		this.lvwData.GridLines = true;
		this.lvwData.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
		this.lvwData.HideSelection = false;
		this.lvwData.Location = new System.Drawing.Point(0, 25);
		this.lvwData.Name = "lvwData";
		this.lvwData.ShowItemToolTips = true;
		this.lvwData.Size = new System.Drawing.Size(488, 513);
		this.lvwData.TabIndex = 2;
		this.lvwData.UseCompatibleStateImageBehavior = false;
		this.lvwData.View = System.Windows.Forms.View.Details;
		this.ColumnHeader1.Text = "";
		this.ColumnHeader1.Width = 84;
		this.ColumnHeader2.Text = "";
		this.ColumnHeader2.Width = 369;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(488, 560);
		base.Controls.Add(this.lvwData);
		base.Controls.Add(this.tsChecker2);
		base.Controls.Add(this.stsMain);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
		base.Name = "SearchColumn";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
		this.Text = "Search Column";
		this.stsMain.ResumeLayout(false);
		this.stsMain.PerformLayout();
		this.mnuDumper.ResumeLayout(false);
		this.mnuListview.ResumeLayout(false);
		this.tsChecker2.ResumeLayout(false);
		this.tsChecker2.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	public void ShowMe()
	{
		base.FormBorderStyle = FormBorderStyle.SizableToolWindow;
		base.Size = size_0;
		checked
		{
			base.Top = (int)Math.Round((double)Globals.GMain.Top + (double)Globals.GMain.Height / 2.0 - (double)base.Height / 2.0);
			base.Left = (int)Math.Round((double)Globals.GMain.Left + (double)Globals.GMain.Width / 2.0 - (double)base.Width / 2.0);
			base.Visible = true;
			CanClose = false;
		}
	}

	private void method_0()
	{
		if (base.InvokeRequired)
		{
			Invoke((EventHandler)([SpecialName] [DebuggerHidden] (object sender, EventArgs e) =>
			{
				method_0();
			}));
		}
		else
		{
			lblStatus.Text = Globals.translate_0.GetStr(base.Name, "mnuRowsCount", "Total Rows:") + " " + Strings.FormatNumber(int_0, 0);
		}
	}

	internal void method_1(string string_0, string string_1, string string_2, int int_2, List<string> list_0)
	{
		checked
		{
			try
			{
				engine_0.Add(string_0, string_1, string_2, int_2, list_0);
				int_0 += int_2;
				method_0();
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Class2.Class0_0.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_2(object sender, EventArgs e)
	{
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (ListViewGroup group in lvwData.Groups)
			{
				stringBuilder.AppendLine(group.Header);
				foreach (ListViewItem item in group.Items)
				{
					if (!string.IsNullOrEmpty(item.Text))
					{
						stringBuilder.AppendLine(item.Text + ":" + item.SubItems[1].Text);
					}
					else
					{
						stringBuilder.AppendLine(item.SubItems[1].Text);
					}
				}
				stringBuilder.AppendLine();
			}
			if (!string.IsNullOrEmpty(stringBuilder.ToString()))
			{
				Clipboard.SetText(stringBuilder.ToString());
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Class2.Class0_0.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_3(object sender, EventArgs e)
	{
		btnGoToDumper.Enabled = lvwData.SelectedItems.Count == 1;
	}

	private void method_4(object sender, EventArgs e)
	{
		try
		{
			string string_ = "";
			string string_2 = "";
			List<string> list = new List<string>();
			btnGoToDumper.Enabled = false;
			foreach (ListViewItem item in lvwData.SelectedItems[0].Group.Items)
			{
				switch (item.Text)
				{
				case null:
				case "":
					list.Add(item.SubItems[1].Text);
					break;
				case "Method":
					string_2 = item.SubItems[1].Text;
					break;
				case "URL":
					string_ = item.SubItems[1].Text;
					break;
				}
			}
			if (sender == mnuDumper2)
			{
				Globals.GMain.method_9(string_, string_2, list);
			}
			else
			{
				if (Globals.GMain.DumperForm.Boolean_0)
				{
					return;
				}
				int selectedIndex = default(int);
				switch (Class54.smethod_6(string_2))
				{
				case Types.MySQL_No_Error:
					selectedIndex = 0;
					break;
				case Types.MySQL_With_Error:
					selectedIndex = 1;
					break;
				case Types.MSSQL_No_Error:
					selectedIndex = 2;
					break;
				case Types.MSSQL_With_Error:
					selectedIndex = 3;
					break;
				case Types.Oracle_No_Error:
					selectedIndex = 4;
					break;
				case Types.Oracle_With_Error:
					selectedIndex = 5;
					break;
				case Types.PostgreSQL_No_Error:
					selectedIndex = 6;
					break;
				case Types.PostgreSQL_With_Error:
					selectedIndex = 7;
					break;
				}
				Globals.GMain.DumperForm.method_76();
				Globals.GMain.DumperForm.txtURL.Text = string_;
				Globals.GMain.DumperForm.cmbSqlType.SelectedIndex = selectedIndex;
				foreach (string item2 in list)
				{
					string current = item2.Substring(item2.LastIndexOf(" ")).Trim();
					string[] array = Strings.Split(current, ".");
					if (array.Length > 1)
					{
						Globals.GMain.DumperForm.method_47(array[0]);
						Globals.GMain.DumperForm.method_48(array[0], array[1]);
					}
				}
				Globals.GMain.DumperForm.method_90(null, null);
				Globals.GMain.twMain.SelectedNode = Globals.GMain.treeNode_3;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
		finally
		{
			btnGoToDumper.Enabled = true;
		}
	}

	private void method_5(object sender, CancelEventArgs e)
	{
		e.Cancel = lvwData.SelectedItems.Count == 0;
	}

	private void method_6(object sender, EventArgs e)
	{
		try
		{
			string text = "";
			foreach (ListViewItem item in lvwData.SelectedItems[0].Group.Items)
			{
				string left = item.Text;
				if (Operators.CompareString(left, "URL", TextCompare: false) == 0)
				{
					text = item.SubItems[1].Text;
				}
			}
			if (!string.IsNullOrEmpty(text))
			{
				if (sender == mnuShell)
				{
					Globals.ShellUrl(text.Replace("[t]", "99"));
				}
				else
				{
					Clipboard.SetText(text.Replace("[t]", "99"));
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_7(object sender, EventArgs e)
	{
		try
		{
			switch (cmbMinRows.SelectedIndex)
			{
			case 0:
				engine_0.MiniRows = 1000;
				break;
			case 1:
				engine_0.MiniRows = 5000;
				break;
			case 2:
				engine_0.MiniRows = 10000;
				break;
			case 3:
				engine_0.MiniRows = 30000;
				break;
			case 4:
				engine_0.MiniRows = 50000;
				break;
			case 5:
				engine_0.MiniRows = 100000;
				break;
			case 6:
				engine_0.MiniRows = 0;
				break;
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_8(object sender, EventArgs e)
	{
		try
		{
			string value = "";
			foreach (ListViewItem item in lvwData.SelectedItems[0].Group.Items)
			{
				string left = item.Text;
				if (Operators.CompareString(left, "URL", TextCompare: false) == 0)
				{
					dataGridView_0.FirstDisplayedScrollingRowIndex = item.Index;
					break;
				}
			}
			if (!string.IsNullOrEmpty(value))
			{
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void SearchColumn_FormClosing(object sender, FormClosingEventArgs e)
	{
		e.Cancel = !CanClose;
	}

	internal void method_9(object sender, EventArgs e)
	{
		try
		{
			if (bool_0)
			{
				engine_0.AddItems = false;
				lvwData.Groups.Clear();
				lvwData.Items.Clear();
				btnSort.Enabled = false;
				Application.DoEvents();
				bckSort.RunWorkerAsync();
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void method_10(object sender, DoWorkEventArgs e)
	{
		if (base.InvokeRequired)
		{
			Invoke(new Delegate43(method_10), sender, e);
			return;
		}
		if (!engine_0.AddItems && cmbSearch.Items.Count == 1)
		{
			cmbSearch.Items.AddRange(engine_0.Search.ToArray());
		}
		List<ListViewGroup> oGroups = null;
		List<ListViewItem> oItems = null;
		string sSearch = ((cmbSearch.SelectedIndex != 0) ? Conversions.ToString(cmbSearch.SelectedItem) : "");
		engine_0.GetItems(ref oItems, ref oGroups, sSearch);
		Globals.LockWindowUpdate(lvwData.Handle);
		lvwData.Items.AddRange(oItems.ToArray());
		lvwData.Groups.AddRange(oGroups.ToArray());
		Globals.LockWindowUpdate(IntPtr.Zero);
	}

	private void method_11(object sender, RunWorkerCompletedEventArgs e)
	{
		btnSort.Enabled = true;
		engine_0.AddItems = true;
	}

	protected override void WndProc(ref Message m)
	{
		int try0001_dispatch = -1;
		int num3 = default(int);
		int num2 = default(int);
		int num = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				int msg;
				switch (try0001_dispatch)
				{
				default:
					ProjectData.ClearProjectError();
					num3 = -2;
					goto IL_000a;
				case 96:
					{
						num2 = num;
						switch ((num3 <= -2) ? 1 : num3)
						{
						case 1:
							break;
						default:
							goto end_IL_0001;
						}
						int num4 = num2 + 1;
						num2 = 0;
						switch (num4)
						{
						case 1:
							break;
						case 2:
							goto IL_000a;
						case 4:
							goto IL_001a;
						case 3:
						case 5:
						case 6:
							goto end_IL_0001_2;
						default:
							goto end_IL_0001;
						case 7:
							goto end_IL_0001_3;
						}
						goto default;
					}
					IL_000a:
					num = 2;
					msg = m.Msg;
					if (msg != 70)
					{
						break;
					}
					goto IL_001a;
					IL_001a:
					num = 4;
					smethod_0(this, m.LParam, 0);
					break;
					end_IL_0001_2:
					break;
				}
				num = 6;
				base.WndProc(ref m);
				break;
				end_IL_0001:;
			}
			catch (object obj) when (obj is Exception && num3 != 0 && num2 == 0)
			{
				ProjectData.SetProjectError((Exception)obj);
				try0001_dispatch = 96;
				continue;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			continue;
			end_IL_0001_3:
			break;
		}
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	private static void smethod_0(Form form_0, IntPtr intptr_0, int int_2)
	{
		checked
		{
			try
			{
				Struct8 @struct = default(Struct8);
				object obj = Marshal.PtrToStructure(intptr_0, typeof(Struct8));
				@struct = ((obj != null) ? ((Struct8)obj) : default(Struct8));
				if (@struct.int_1 == 0 || @struct.int_0 == 0)
				{
					return;
				}
				Rectangle rectangle = form_0.RectangleToScreen(form_0.ClientRectangle);
				rectangle.Width += SystemInformation.FrameBorderSize.Width - int_2;
				rectangle.Height += SystemInformation.FrameBorderSize.Height + SystemInformation.CaptionHeight;
				Rectangle workingArea = Screen.GetWorkingArea(form_0.ClientRectangle);
				if (@struct.int_0 >= workingArea.X - 10 && @struct.int_0 <= workingArea.X + 10)
				{
					@struct.int_0 = workingArea.X;
				}
				int num = Screen.GetBounds(Screen.PrimaryScreen.Bounds).Height - workingArea.Height;
				if ((@struct.int_1 >= -10 && workingArea.Y > 0 && @struct.int_1 <= num + 10) || (workingArea.Y <= 0 && @struct.int_1 <= 10))
				{
					if (num > 0)
					{
						@struct.int_1 = workingArea.Y;
					}
					else
					{
						@struct.int_1 = 0;
					}
				}
				if (@struct.int_0 + rectangle.Width <= workingArea.Right + 10 && @struct.int_0 + rectangle.Width >= workingArea.Right - 10)
				{
					@struct.int_0 = workingArea.Right - (rectangle.Width + SystemInformation.FrameBorderSize.Width);
				}
				if (@struct.int_1 + rectangle.Height <= workingArea.Bottom + 10 && @struct.int_1 + rectangle.Height >= workingArea.Bottom - 10)
				{
					@struct.int_1 = workingArea.Bottom - (rectangle.Height + SystemInformation.FrameBorderSize.Height);
				}
				Marshal.StructureToPtr(@struct, intptr_0, fDeleteOld: true);
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerHidden]
	private void method_12(object sender, EventArgs e)
	{
		method_0();
	}
}
