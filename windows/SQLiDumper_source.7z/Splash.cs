using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public sealed class Splash : Form
{
	private IContainer icontainer_0;

	private string string_0;

	public Splash()
	{
		base.Paint += Splash_Paint;
		base.Load += Splash_Load;
		string_0 = "";
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		base.SuspendLayout();
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = System.Drawing.Color.Black;
		this.BackgroundImage = ns0.Class6.about;
		this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
		base.ClientSize = new System.Drawing.Size(284, 268);
		this.ForeColor = System.Drawing.Color.FromArgb(192, 192, 0);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Splash";
		base.Opacity = 0.7;
		base.Padding = new System.Windows.Forms.Padding(14);
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Splash";
		base.ResumeLayout(false);
	}

	public void SetLoading(string sMsg)
	{
		if (!Globals.IS_DUMP_INSTANCE)
		{
			string_0 = sMsg;
			Refresh();
		}
	}

	private void Splash_Paint(object sender, PaintEventArgs e)
	{
		if (!string.IsNullOrEmpty(string_0))
		{
			e.Graphics.DrawString(string_0.ToString(), new Font("Courier New", 9f, FontStyle.Bold), new SolidBrush(ForeColor), new Point(11, 165));
		}
	}

	private void Splash_Load(object sender, EventArgs e)
	{
		base.UseWaitCursor = true;
		Cursor = Cursors.WaitCursor;
		base.Size = checked(new Size((int)Math.Round((double)Class6.about.Size.Width / 1.2), (int)Math.Round((double)Class6.about.Size.Height / 1.2)));
	}
}
