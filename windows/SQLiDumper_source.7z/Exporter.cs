using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[DesignerGenerated]
public class Exporter : Form
{
	public enum enFileTytpe
	{
		const_0,
		HTML,
		const_2
	}

	private IContainer icontainer_0;

	[AccessedThroughProperty("OK_Button")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Button _OK_Button;

	[AccessedThroughProperty("Cancel_Button")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Button _Cancel_Button;

	[CompilerGenerated]
	[AccessedThroughProperty("rdbOpt1")]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private RadioButton _rdbOpt1;

	[AccessedThroughProperty("bwSave")]
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private BackgroundWorker backgroundWorker_0;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("rdpType_2")]
	private RadioButton _rdpType_2;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[AccessedThroughProperty("rdpType_1")]
	private RadioButton _rdpType_1;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	[AccessedThroughProperty("rdpType_3")]
	private RadioButton _rdpType_3;

	private string string_0;

	private string string_1;

	private bool bool_0;

	private enFileTytpe enFileTytpe_0;

	private string string_2;

	private DataGridView dataGridView_0;

	internal virtual Button OK_Button
	{
		[CompilerGenerated]
		get
		{
			return _OK_Button;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_2;
			Button oK_Button = _OK_Button;
			if (oK_Button != null)
			{
				oK_Button.Click -= value2;
			}
			_OK_Button = value;
			oK_Button = _OK_Button;
			if (oK_Button != null)
			{
				oK_Button.Click += value2;
			}
		}
	}

	internal virtual Button Cancel_Button
	{
		[CompilerGenerated]
		get
		{
			return _Cancel_Button;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_3;
			Button cancel_Button = _Cancel_Button;
			if (cancel_Button != null)
			{
				cancel_Button.Click -= value2;
			}
			_Cancel_Button = value;
			cancel_Button = _Cancel_Button;
			if (cancel_Button != null)
			{
				cancel_Button.Click += value2;
			}
		}
	}

	[field: AccessedThroughProperty("grbDelimiter")]
	internal virtual GroupBox grbDelimiter
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual RadioButton rdbOpt1
	{
		[CompilerGenerated]
		get
		{
			return _rdbOpt1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_4;
			EventHandler value3 = method_4;
			RadioButton radioButton = _rdbOpt1;
			if (radioButton != null)
			{
				radioButton.CheckedChanged -= value2;
				radioButton.CheckedChanged -= value3;
			}
			_rdbOpt1 = value;
			radioButton = _rdbOpt1;
			if (radioButton != null)
			{
				radioButton.CheckedChanged += value2;
				radioButton.CheckedChanged += value3;
			}
		}
	}

	[field: AccessedThroughProperty("rdbOpt2")]
	internal virtual RadioButton rdbOpt2
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtDeli")]
	internal virtual TextBox txtDeli
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual BackgroundWorker bwSave
	{
		[CompilerGenerated]
		get
		{
			return backgroundWorker_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			backgroundWorker_0 = value;
		}
	}

	[field: AccessedThroughProperty("grbColumns")]
	internal virtual GroupBox grbColumns
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lsColumns")]
	internal virtual CheckedListBox lsColumns
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("grbType")]
	internal virtual GroupBox grbType
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	internal virtual RadioButton rdpType_2
	{
		[CompilerGenerated]
		get
		{
			return _rdpType_2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_5;
			RadioButton radioButton = _rdpType_2;
			if (radioButton != null)
			{
				radioButton.CheckedChanged -= value2;
			}
			_rdpType_2 = value;
			radioButton = _rdpType_2;
			if (radioButton != null)
			{
				radioButton.CheckedChanged += value2;
			}
		}
	}

	internal virtual RadioButton rdpType_1
	{
		[CompilerGenerated]
		get
		{
			return _rdpType_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_5;
			RadioButton radioButton = _rdpType_1;
			if (radioButton != null)
			{
				radioButton.CheckedChanged -= value2;
			}
			_rdpType_1 = value;
			radioButton = _rdpType_1;
			if (radioButton != null)
			{
				radioButton.CheckedChanged += value2;
			}
		}
	}

	internal virtual RadioButton rdpType_3
	{
		[CompilerGenerated]
		get
		{
			return _rdpType_3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[CompilerGenerated]
		set
		{
			EventHandler value2 = method_5;
			RadioButton radioButton = _rdpType_3;
			if (radioButton != null)
			{
				radioButton.CheckedChanged -= value2;
			}
			_rdpType_3 = value;
			radioButton = _rdpType_3;
			if (radioButton != null)
			{
				radioButton.CheckedChanged += value2;
			}
		}
	}

	[field: AccessedThroughProperty("Panel1")]
	internal virtual Panel Panel1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public Exporter(DataGridView grid)
	{
		base.FormClosing += Exporter_FormClosing;
		base.Load += Exporter_Load;
		InitializeComponent();
		dataGridView_0 = grid;
		Globals.AddMouseMoveForm(this);
		Globals.translate_0.Add(this, icontainer_0);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.OK_Button = new System.Windows.Forms.Button();
		this.Cancel_Button = new System.Windows.Forms.Button();
		this.grbDelimiter = new System.Windows.Forms.GroupBox();
		this.txtDeli = new System.Windows.Forms.TextBox();
		this.rdbOpt2 = new System.Windows.Forms.RadioButton();
		this.rdbOpt1 = new System.Windows.Forms.RadioButton();
		this.bwSave = new System.ComponentModel.BackgroundWorker();
		this.grbColumns = new System.Windows.Forms.GroupBox();
		this.lsColumns = new System.Windows.Forms.CheckedListBox();
		this.grbType = new System.Windows.Forms.GroupBox();
		this.rdpType_3 = new System.Windows.Forms.RadioButton();
		this.rdpType_2 = new System.Windows.Forms.RadioButton();
		this.rdpType_1 = new System.Windows.Forms.RadioButton();
		this.Panel1 = new System.Windows.Forms.Panel();
		this.grbDelimiter.SuspendLayout();
		this.grbColumns.SuspendLayout();
		this.grbType.SuspendLayout();
		this.Panel1.SuspendLayout();
		base.SuspendLayout();
		this.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.OK_Button.Location = new System.Drawing.Point(168, 12);
		this.OK_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.OK_Button.Name = "OK_Button";
		this.OK_Button.Size = new System.Drawing.Size(132, 30);
		this.OK_Button.TabIndex = 3;
		this.OK_Button.Text = "OK";
		this.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.Cancel_Button.Location = new System.Drawing.Point(7, 12);
		this.Cancel_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.Cancel_Button.Name = "Cancel_Button";
		this.Cancel_Button.Size = new System.Drawing.Size(132, 30);
		this.Cancel_Button.TabIndex = 4;
		this.Cancel_Button.Text = "Exit";
		this.grbDelimiter.Controls.Add(this.txtDeli);
		this.grbDelimiter.Controls.Add(this.rdbOpt2);
		this.grbDelimiter.Controls.Add(this.rdbOpt1);
		this.grbDelimiter.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbDelimiter.Location = new System.Drawing.Point(0, 66);
		this.grbDelimiter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbDelimiter.Name = "grbDelimiter";
		this.grbDelimiter.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbDelimiter.Size = new System.Drawing.Size(307, 105);
		this.grbDelimiter.TabIndex = 0;
		this.grbDelimiter.TabStop = false;
		this.grbDelimiter.Text = "Delimiter";
		this.txtDeli.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.txtDeli.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.txtDeli.Location = new System.Drawing.Point(153, 60);
		this.txtDeli.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.txtDeli.Name = "txtDeli";
		this.txtDeli.Size = new System.Drawing.Size(150, 26);
		this.txtDeli.TabIndex = 2;
		this.txtDeli.Text = ":";
		this.rdbOpt2.AutoSize = true;
		this.rdbOpt2.Checked = true;
		this.rdbOpt2.Location = new System.Drawing.Point(9, 65);
		this.rdbOpt2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdbOpt2.Name = "rdbOpt2";
		this.rdbOpt2.Size = new System.Drawing.Size(89, 24);
		this.rdbOpt2.TabIndex = 1;
		this.rdbOpt2.TabStop = true;
		this.rdbOpt2.Text = "Custom";
		this.rdbOpt2.UseVisualStyleBackColor = true;
		this.rdbOpt1.AutoSize = true;
		this.rdbOpt1.Location = new System.Drawing.Point(9, 29);
		this.rdbOpt1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdbOpt1.Name = "rdbOpt1";
		this.rdbOpt1.Size = new System.Drawing.Size(99, 24);
		this.rdbOpt1.TabIndex = 0;
		this.rdbOpt1.Text = "Char Tab";
		this.rdbOpt1.UseVisualStyleBackColor = true;
		this.bwSave.WorkerReportsProgress = true;
		this.bwSave.WorkerSupportsCancellation = true;
		this.grbColumns.Controls.Add(this.lsColumns);
		this.grbColumns.Dock = System.Windows.Forms.DockStyle.Fill;
		this.grbColumns.Location = new System.Drawing.Point(0, 171);
		this.grbColumns.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbColumns.Name = "grbColumns";
		this.grbColumns.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbColumns.Size = new System.Drawing.Size(307, 222);
		this.grbColumns.TabIndex = 1;
		this.grbColumns.TabStop = false;
		this.grbColumns.Text = "Columns";
		this.lsColumns.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lsColumns.FormattingEnabled = true;
		this.lsColumns.Items.AddRange(new object[5] { "Email", "Password", "MailBoxCount", "Host", "Date" });
		this.lsColumns.Location = new System.Drawing.Point(4, 24);
		this.lsColumns.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.lsColumns.Name = "lsColumns";
		this.lsColumns.Size = new System.Drawing.Size(299, 193);
		this.lsColumns.TabIndex = 0;
		this.grbType.Controls.Add(this.rdpType_3);
		this.grbType.Controls.Add(this.rdpType_2);
		this.grbType.Controls.Add(this.rdpType_1);
		this.grbType.Dock = System.Windows.Forms.DockStyle.Top;
		this.grbType.Location = new System.Drawing.Point(0, 0);
		this.grbType.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbType.Name = "grbType";
		this.grbType.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.grbType.Size = new System.Drawing.Size(307, 66);
		this.grbType.TabIndex = 6;
		this.grbType.TabStop = false;
		this.grbType.Text = "File Type";
		this.rdpType_3.AutoSize = true;
		this.rdpType_3.Location = new System.Drawing.Point(226, 29);
		this.rdpType_3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdpType_3.Name = "rdpType_3";
		this.rdpType_3.Size = new System.Drawing.Size(67, 24);
		this.rdpType_3.TabIndex = 2;
		this.rdpType_3.Text = "XML";
		this.rdpType_3.UseVisualStyleBackColor = true;
		this.rdpType_2.AutoSize = true;
		this.rdpType_2.Location = new System.Drawing.Point(128, 29);
		this.rdpType_2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdpType_2.Name = "rdpType_2";
		this.rdpType_2.Size = new System.Drawing.Size(77, 24);
		this.rdpType_2.TabIndex = 1;
		this.rdpType_2.Text = "HTML";
		this.rdpType_2.UseVisualStyleBackColor = true;
		this.rdpType_1.AutoSize = true;
		this.rdpType_1.Checked = true;
		this.rdpType_1.Location = new System.Drawing.Point(9, 29);
		this.rdpType_1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.rdpType_1.Name = "rdpType_1";
		this.rdpType_1.Size = new System.Drawing.Size(98, 24);
		this.rdpType_1.TabIndex = 0;
		this.rdpType_1.TabStop = true;
		this.rdpType_1.Text = "PlainText";
		this.rdpType_1.UseVisualStyleBackColor = true;
		this.Panel1.Controls.Add(this.OK_Button);
		this.Panel1.Controls.Add(this.Cancel_Button);
		this.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
		this.Panel1.Location = new System.Drawing.Point(0, 393);
		this.Panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		this.Panel1.Name = "Panel1";
		this.Panel1.Size = new System.Drawing.Size(307, 55);
		this.Panel1.TabIndex = 7;
		base.AcceptButton = this.OK_Button;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.CancelButton = this.Cancel_Button;
		base.ClientSize = new System.Drawing.Size(307, 448);
		base.ControlBox = false;
		base.Controls.Add(this.grbColumns);
		base.Controls.Add(this.Panel1);
		base.Controls.Add(this.grbDelimiter);
		base.Controls.Add(this.grbType);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Exporter";
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Data Exporter";
		this.grbDelimiter.ResumeLayout(false);
		this.grbDelimiter.PerformLayout();
		this.grbColumns.ResumeLayout(false);
		this.grbType.ResumeLayout(false);
		this.grbType.PerformLayout();
		this.Panel1.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	private string method_0(string string_3)
	{
		return SecurityElement.Escape(string_3);
	}

	private void method_1(string string_3)
	{
		StreamWriter streamWriter = null;
		checked
		{
			try
			{
				bool_0 = true;
				streamWriter = new StreamWriter(string_3);
				int num = lsColumns.Items.Count - 1;
				bool flag = default(bool);
				for (int i = 0; i <= num; i++)
				{
					if (!lsColumns.GetItemChecked(i))
					{
						continue;
					}
					switch (enFileTytpe_0)
					{
					case enFileTytpe.const_0:
						if (flag)
						{
							streamWriter.Write(Operators.ConcatenateObject(string_2, lsColumns.Items[i]));
							break;
						}
						streamWriter.Write(method_0(Globals.APP_VERSION));
						streamWriter.WriteLine();
						streamWriter.Write(DateAndTime.Now.ToString());
						streamWriter.WriteLine();
						streamWriter.WriteLine();
						streamWriter.Write(RuntimeHelpers.GetObjectValue(lsColumns.Items[i]));
						break;
					case enFileTytpe.HTML:
						if (!flag)
						{
							streamWriter.WriteLine("<html>");
							streamWriter.WriteLine("<title>" + method_0(Globals.APP_VERSION) + "</title>");
							streamWriter.WriteLine("<body>");
							streamWriter.WriteLine("<table border>");
							streamWriter.WriteLine("<tr>");
						}
						streamWriter.WriteLine(Operators.ConcatenateObject(Operators.ConcatenateObject("<td>", lsColumns.Items[i]), "</td>"));
						break;
					case enFileTytpe.const_2:
						if (!flag)
						{
							streamWriter.WriteLine("<DocumentElement>");
							streamWriter.WriteLine("<AppVersion>" + method_0(Globals.APP_VERSION) + "</AppVersion>");
						}
						break;
					}
					flag = true;
				}
				switch (enFileTytpe_0)
				{
				case enFileTytpe.const_0:
					streamWriter.WriteLine();
					break;
				case enFileTytpe.HTML:
					streamWriter.WriteLine("</tr>");
					break;
				}
				flag = false;
				int num2 = dataGridView_0.Rows.Count - 1;
				for (int j = 0; j <= num2; j++)
				{
					int num3 = lsColumns.Items.Count - 1;
					for (int k = 0; k <= num3; k++)
					{
						if (lsColumns.GetItemChecked(k))
						{
							string text = Conversions.ToString(dataGridView_0.Rows[j].Cells[k + 1].Value);
							switch (enFileTytpe_0)
							{
							case enFileTytpe.const_0:
								if (flag)
								{
									streamWriter.Write(string_2 + text);
								}
								else
								{
									streamWriter.Write(text);
								}
								break;
							case enFileTytpe.HTML:
								if (!flag)
								{
									streamWriter.WriteLine("<tr>");
								}
								streamWriter.WriteLine("<td>" + SecurityElement.Escape(text) + "</td>");
								break;
							case enFileTytpe.const_2:
								if (!flag)
								{
									streamWriter.WriteLine("<item>");
								}
								streamWriter.WriteLine(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("<", lsColumns.Items[k]), ">"), method_0(text)), "</"), lsColumns.Items[k]), ">"));
								break;
							}
						}
						flag = true;
					}
					switch (enFileTytpe_0)
					{
					case enFileTytpe.const_0:
						streamWriter.WriteLine();
						break;
					case enFileTytpe.HTML:
						streamWriter.WriteLine("</tr>");
						break;
					case enFileTytpe.const_2:
						streamWriter.WriteLine("</item>");
						break;
					}
					flag = false;
				}
				switch (enFileTytpe_0)
				{
				case enFileTytpe.HTML:
					streamWriter.WriteLine("</body>");
					streamWriter.WriteLine("</html>");
					break;
				case enFileTytpe.const_2:
					streamWriter.WriteLine("</DocumentElement>");
					break;
				case enFileTytpe.const_0:
					break;
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				ProjectData.ClearProjectError();
			}
			finally
			{
				streamWriter?.Close();
			}
		}
	}

	private void method_2(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				int num = lsColumns.Items.Count - 1;
				bool flag = default(bool);
				for (int i = 0; i <= num; i++)
				{
					if (lsColumns.GetItemChecked(i))
					{
						flag = true;
					}
				}
				if (unchecked(0 - (flag ? 1 : 0)) == 0)
				{
					Interaction.Beep();
					Interaction.MsgBox("Selected the column(s).");
					return;
				}
				if (rdbOpt1.Checked)
				{
					string_2 = "\t";
				}
				else
				{
					string_2 = txtDeli.Text;
				}
				using SaveFileDialog saveFileDialog = new SaveFileDialog();
				saveFileDialog.Title = "Save as..";
				saveFileDialog.FileName = string_1;
				saveFileDialog.InitialDirectory = string_0;
				bool flag2;
				if ((flag2 = true) == rdpType_1.Checked)
				{
					enFileTytpe_0 = enFileTytpe.const_0;
					saveFileDialog.Filter = "Text File|*.txt";
					saveFileDialog.FileName = Path.ChangeExtension(saveFileDialog.FileName, "txt");
				}
				else if (flag2 == rdpType_2.Checked)
				{
					enFileTytpe_0 = enFileTytpe.HTML;
					saveFileDialog.Filter = "HTML File|*.html";
					saveFileDialog.FileName = Path.ChangeExtension(saveFileDialog.FileName, "html");
				}
				else if (flag2 == rdpType_3.Checked)
				{
					enFileTytpe_0 = enFileTytpe.const_2;
					saveFileDialog.Filter = "XML File|*.xml";
					saveFileDialog.FileName = Path.ChangeExtension(saveFileDialog.FileName, "xml");
				}
				if (saveFileDialog.ShowDialog() == DialogResult.OK)
				{
					Cursor = Cursors.WaitCursor;
					Application.DoEvents();
					string_0 = saveFileDialog.FileName.Substring(0, saveFileDialog.FileName.LastIndexOf("\\"));
					string_1 = saveFileDialog.FileName.Substring(saveFileDialog.FileName.LastIndexOf("\\") + 1);
					method_1(saveFileDialog.FileName);
					Cursor = Cursors.Default;
					MessageBox.Show("Data export completed successfully.", Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_3(object sender, EventArgs e)
	{
		base.DialogResult = DialogResult.Cancel;
		Close();
	}

	private void method_4(object sender, EventArgs e)
	{
		txtDeli.Enabled = rdbOpt2.Checked;
	}

	private void Exporter_FormClosing(object sender, FormClosingEventArgs e)
	{
		checked
		{
			try
			{
				Class50.smethod_4(dataGridView_0.Name, "LastPath", string_0);
				Class50.smethod_4(dataGridView_0.Name, "LastFileName", string_1);
				Class50.smethod_3(this);
				int num = lsColumns.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					string text = Conversions.ToString(lsColumns.Items[i]);
					Class50.smethod_4(lsColumns.Name, text, lsColumns.GetItemChecked(i).ToString());
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void Exporter_Load(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				Class50.smethod_2(this);
				string_0 = Class50.smethod_5(dataGridView_0.Name, "LastPath", Globals.APP_PATH);
				string_1 = Class50.smethod_5(dataGridView_0.Name, "LastFileName", "Checkeds");
				lsColumns.Items.Clear();
				int num = dataGridView_0.Columns.Count - 1;
				for (int i = 1; i <= num; i++)
				{
					string headerText = dataGridView_0.Columns[i].HeaderText;
					lsColumns.Items.Add(headerText);
					lsColumns.SetItemChecked(i - 1, Conversions.ToBoolean(Class50.smethod_5(lsColumns.Name, headerText, (i < 3).ToString())));
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void method_5(object sender, EventArgs e)
	{
		Globals.LockWindowUpdate(base.Handle);
		grbDelimiter.Visible = rdpType_1.Checked;
		Globals.LockWindowUpdate(IntPtr.Zero);
	}
}
