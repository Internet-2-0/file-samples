using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using DataBase;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

[Serializable]
public class HTTPExt
{
	private static bool DEBUG_MSG;

	private AppDomain __AppDomain;

	private object __Instance;

	private Type __Type;

	private Assembly __Asm;

	private MethodInfo __Setup;

	private MethodInfo __QuickGet;

	private MethodInfo __CheckKeyword;

	private MethodInfo __CheckSyntaxError;

	private MethodInfo __ParseHtmlData;

	private MethodInfo __WasRedirected;

	private MethodInfo __Status;

	private MethodInfo __ContextSize;

	private MethodInfo __TotalCall;

	private MethodInfo __TotalSize;

	private MethodInfo __WebServer;

	private MethodInfo __AcceptCookies;

	private MethodInfo __Abort;

	private MethodInfo __AddQuickHeader;

	private MethodInfo __TryUnionBasead;

	private MethodInfo __QuickPost;

	private bool __FullIsolated;

	private bool __SkipHttpLog;

	private long __LogID;

	private Stopwatch __Stopwatch;

	public bool FollowRedirects { get; set; }

	public string Proxy { get; set; }

	public int TotalRequest { get; set; }

	public int TotalRequestFailed { get; set; }

	public int TimeOut { get; set; }

	public string LoginUser { get; set; }

	public string LoginPassword { get; set; }

	public HTTPExt(bool bFullIsolated, bool bSkipLog = false)
	{
		FollowRedirects = true;
		Proxy = "";
		TotalRequest = 0;
		TotalRequestFailed = 0;
		TimeOut = Conversions.ToInteger(Globals.GetObjectValue(Globals.GMain.numHTTPTimeout));
		LoginUser = "";
		LoginPassword = "";
		try
		{
			__FullIsolated = bFullIsolated;
			__SkipHttpLog = bSkipLog;
			AppDomainSetup info = new AppDomainSetup
			{
				ApplicationBase = AppDomain.CurrentDomain.BaseDirectory
			};
			__AppDomain = AppDomain.CreateDomain("SQLi_Dumper_" + Guid.NewGuid().ToString(), null, info);
			__Asm = Assembly.GetExecutingAssembly();
			__Type = __Asm.GetType("DUX4.Main");
			__Instance = RuntimeHelpers.GetObjectValue(Activator.CreateInstance(__Type));
			if (__FullIsolated)
			{
				__Setup = __Type.GetMethod("Setup");
				__QuickGet = __Type.GetMethod("QuickGetIsolated");
				__CheckKeyword = __Type.GetMethod("CheckKeyword");
				__CheckSyntaxError = __Type.GetMethod("CheckSyntaxError");
				__ParseHtmlData = __Type.GetMethod("ParseHtmlData");
				__WasRedirected = __Type.GetMethod("WasRedirected");
				__Status = __Type.GetMethod("Status");
				__ContextSize = __Type.GetMethod("ContextSize");
				__TotalCall = __Type.GetMethod("TotalCall");
				__TotalSize = __Type.GetMethod("TotalSize");
				__WebServer = __Type.GetMethod("WebServer");
				__AcceptCookies = __Type.GetMethod("AcceptCookies");
				__Abort = __Type.GetMethod("Abort");
				__TryUnionBasead = __Type.GetMethod("TryUnionBasead");
				__AddQuickHeader = __Type.GetMethod("AddQuickHeader");
				__QuickPost = __Type.GetMethod("QuickPost");
			}
			else
			{
				__QuickGet = __Type.GetMethod("QuickGet");
			}
		}
		catch (Exception)
		{
		}
	}

	public bool AddQuickHeader(string name, string value)
	{
		bool result = default(bool);
		try
		{
			result = Conversions.ToBoolean(__AddQuickHeader.Invoke(RuntimeHelpers.GetObjectValue(__Instance), new object[2] { name, value }));
			return result;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public void Abort()
	{
		try
		{
			__Abort.Invoke(RuntimeHelpers.GetObjectValue(__Instance), null);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
	}

	public void SetAcceptCookies(bool b)
	{
		try
		{
			__AcceptCookies.Invoke(RuntimeHelpers.GetObjectValue(__Instance), new object[1] { b });
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
	}

	private void Setup()
	{
		try
		{
			Class35 g_SOCKS = Globals.G_SOCKS;
			string string_ = Proxy;
			byte byte_ = default(byte);
			string string_2 = default(string);
			int int_ = default(int);
			string string_3 = default(string);
			string string_4 = default(string);
			g_SOCKS.method_11(ref byte_, ref string_2, ref int_, ref string_3, ref string_4, ref string_);
			Proxy = string_;
			object[] parameters = new object[11]
			{
				TimeOut,
				FollowRedirects,
				Globals.GetObjectValue(Globals.GMain.txtUserAgent),
				Globals.GetObjectValue(Globals.GMain.txtAccept),
				LoginUser,
				LoginPassword,
				byte_,
				string_2,
				int_,
				string_3,
				string_4
			};
			__Setup.Invoke(RuntimeHelpers.GetObjectValue(__Instance), parameters);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
	}

	public int WebServer()
	{
		int result = default(int);
		try
		{
			result = Conversions.ToInteger(__WebServer.Invoke(RuntimeHelpers.GetObjectValue(__Instance), null));
			return result;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public int MaxCaller()
	{
		int result = default(int);
		try
		{
			result = Conversions.ToInteger(__TotalCall.Invoke(RuntimeHelpers.GetObjectValue(__Instance), null));
			return result;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public long TotalSize()
	{
		long result = default(long);
		try
		{
			result = Conversions.ToLong(__TotalSize.Invoke(RuntimeHelpers.GetObjectValue(__Instance), null));
			return result;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public bool WasRedirected()
	{
		bool result = default(bool);
		try
		{
			result = Conversions.ToBoolean(__WasRedirected.Invoke(RuntimeHelpers.GetObjectValue(__Instance), null));
			return result;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public int Status()
	{
		int result = default(int);
		try
		{
			result = Conversions.ToInteger(__Status.Invoke(RuntimeHelpers.GetObjectValue(__Instance), null));
			return result;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public long ContextSize()
	{
		long result = default(long);
		try
		{
			result = Conversions.ToLong(__ContextSize.Invoke(RuntimeHelpers.GetObjectValue(__Instance), null));
			return result;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public bool CheckKeyword(string url, string Keyword)
	{
		checked
		{
			bool result = default(bool);
			try
			{
				Setup();
				object[] parameters = new object[2] { url, Keyword };
				AddLog(url);
				object objectValue = RuntimeHelpers.GetObjectValue(__CheckKeyword.Invoke(RuntimeHelpers.GetObjectValue(__Instance), parameters));
				UpdateLog(url);
				if (objectValue != null)
				{
					TotalRequest++;
					result = Conversions.ToBoolean(objectValue);
					return result;
				}
				TotalRequestFailed++;
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				_ = 0;
				ProjectData.ClearProjectError();
			}
			return result;
		}
	}

	public Types CheckSyntaxError(string url)
	{
		checked
		{
			Types result = default(Types);
			try
			{
				Setup();
				object[] parameters = new object[1] { url };
				AddLog(url);
				object objectValue = RuntimeHelpers.GetObjectValue(__CheckSyntaxError.Invoke(RuntimeHelpers.GetObjectValue(__Instance), parameters));
				UpdateLog(url);
				if (objectValue != null)
				{
					TotalRequest++;
					result = unchecked((Types)Conversions.ToInteger(objectValue));
					return result;
				}
				TotalRequestFailed++;
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				_ = 0;
				ProjectData.ClearProjectError();
			}
			return result;
		}
	}

	public string ParseHtmlData(string url, Types dbType)
	{
		checked
		{
			string result = default(string);
			try
			{
				Setup();
				object[] parameters = new object[3]
				{
					url,
					dbType,
					Class54.string_0
				};
				AddLog(url);
				object objectValue = RuntimeHelpers.GetObjectValue(__ParseHtmlData.Invoke(RuntimeHelpers.GetObjectValue(__Instance), parameters));
				UpdateLog(url);
				if (objectValue != null)
				{
					TotalRequest++;
					result = Conversions.ToString(objectValue);
					return result;
				}
				TotalRequestFailed++;
				result = null;
				return result;
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				_ = 0;
				ProjectData.ClearProjectError();
			}
			return result;
		}
	}

	public string QuickGet(string url)
	{
		string result = null;
		checked
		{
			try
			{
				Setup();
				object[] parameters = new object[1] { url };
				AddLog(url);
				object objectValue = RuntimeHelpers.GetObjectValue(__QuickGet.Invoke(RuntimeHelpers.GetObjectValue(__Instance), parameters));
				UpdateLog(url);
				if (objectValue != null && Conversions.ToString(objectValue) != "")
				{
					TotalRequest++;
					result = Conversions.ToString(objectValue);
				}
				else
				{
					TotalRequestFailed++;
				}
			}
			catch (Exception)
			{
			}
			return result;
		}
	}

	public string QuickGet(string url, object o)
	{
		string result = "";
		checked
		{
			try
			{
				object[] parameters = new object[2] { url, o };
				AddLog(url);
				object objectValue = RuntimeHelpers.GetObjectValue(__QuickGet.Invoke(RuntimeHelpers.GetObjectValue(__Instance), parameters));
				UpdateLog(url);
				if (objectValue != null && Conversions.ToString(objectValue) != "")
				{
					TotalRequest++;
					result = Conversions.ToString(objectValue);
				}
				else
				{
					TotalRequestFailed++;
				}
			}
			catch (Exception)
			{
			}
			return result;
		}
	}

	public string QuickPost(string sUrl, Dictionary<string, string> r)
	{
		string result = default(string);
		return result;
	}

	public int TryUnionBasead(string url, string key, Types dbType)
	{
		int result = -1;
		try
		{
			object[] parameters = new object[3]
			{
				url,
				key,
				(int)dbType
			};
			AddLog(url);
			object objectValue = RuntimeHelpers.GetObjectValue(__TryUnionBasead.Invoke(RuntimeHelpers.GetObjectValue(__Instance), parameters));
			UpdateLog(url);
			checked
			{
				if (objectValue != null)
				{
					TotalRequest++;
					result = Conversions.ToInteger(objectValue);
				}
				else
				{
					TotalRequestFailed++;
				}
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	public void Dispose()
	{
		try
		{
			AppDomain.Unload(__AppDomain);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
		finally
		{
			__AppDomain = null;
			__Instance = null;
		}
	}

	private void AddLog(string url)
	{
		try
		{
			if (!__SkipHttpLog)
			{
				__Stopwatch = Stopwatch.StartNew();
				__LogID = Globals.GMain.method_207(url, Proxy);
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			_ = 0;
			ProjectData.ClearProjectError();
		}
	}

	private void UpdateLog(string url)
	{
		try
		{
			if (__SkipHttpLog)
			{
				return;
			}
			string string_ = Strings.FormatNumber(__Stopwatch.Elapsed.TotalMilliseconds / 1000.0, 2);
			int num = Status();
			string text;
			if (num > 0 && num != 999999)
			{
				HttpStatusCode httpStatusCode = default(HttpStatusCode);
				try
				{
					httpStatusCode = (HttpStatusCode)num;
				}
				catch (Exception projectError)
				{
					ProjectData.SetProjectError(projectError);
					ProjectData.ClearProjectError();
				}
				text = ((Operators.CompareString(num.ToString(), httpStatusCode.ToString(), TextCompare: false) != 0) ? (Conversions.ToString(num) + " " + httpStatusCode) : Conversions.ToString(num));
			}
			else
			{
				text = Conversions.ToString(num) + " Unknown";
			}
			long num2 = ContextSize();
			if (num2 <= 0)
			{
			}
			if (num > 0 && Globals.GStatistics != null)
			{
				Globals.GStatistics.method_1(Class26.Enum1.const_3, text, 1);
			}
			Globals.GMain.method_206(__LogID, url, Globals.FormatBytes(num2), string_, text, Proxy);
		}
		catch (Exception projectError2)
		{
			ProjectData.SetProjectError(projectError2);
			_ = 0;
			ProjectData.ClearProjectError();
		}
	}
}
