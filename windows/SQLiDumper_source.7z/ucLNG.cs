using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
public class ucLNG : UserControl
{
	private IContainer icontainer_0;

	[field: AccessedThroughProperty("TableLayoutPanel1")]
	internal virtual TableLayoutPanel TableLayoutPanel1
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("txtValue")]
	internal virtual TextBox txtValue
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblSection")]
	internal virtual Label lblSection
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblKey")]
	internal virtual Label lblKey
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	[field: AccessedThroughProperty("lblIndex")]
	internal virtual Label lblIndex
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public string Section => lblSection.Text;

	public string Key => lblKey.Text;

	public string Value => txtValue.Text;

	public ucLNG(int index, string section, string key, string value)
	{
		InitializeComponent();
		lblSection.Text = section;
		lblKey.Text = key;
		txtValue.Text = value;
		lblIndex.Text = Conversions.ToString(index);
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.TableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
		this.txtValue = new System.Windows.Forms.TextBox();
		this.lblSection = new System.Windows.Forms.Label();
		this.lblKey = new System.Windows.Forms.Label();
		this.lblIndex = new System.Windows.Forms.Label();
		this.TableLayoutPanel1.SuspendLayout();
		base.SuspendLayout();
		this.TableLayoutPanel1.ColumnCount = 4;
		this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.30303f));
		this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.09925f));
		this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.2367f));
		this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.36102f));
		this.TableLayoutPanel1.Controls.Add(this.lblIndex, 0, 0);
		this.TableLayoutPanel1.Controls.Add(this.txtValue, 3, 0);
		this.TableLayoutPanel1.Controls.Add(this.lblSection, 1, 0);
		this.TableLayoutPanel1.Controls.Add(this.lblKey, 2, 0);
		this.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
		this.TableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
		this.TableLayoutPanel1.Name = "TableLayoutPanel1";
		this.TableLayoutPanel1.RowCount = 1;
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100f));
		this.TableLayoutPanel1.Size = new System.Drawing.Size(913, 32);
		this.TableLayoutPanel1.TabIndex = 0;
		this.txtValue.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtValue.Location = new System.Drawing.Point(382, 3);
		this.txtValue.Name = "txtValue";
		this.txtValue.Size = new System.Drawing.Size(528, 26);
		this.txtValue.TabIndex = 0;
		this.lblSection.AutoSize = true;
		this.lblSection.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lblSection.Location = new System.Drawing.Point(51, 0);
		this.lblSection.Name = "lblSection";
		this.lblSection.Size = new System.Drawing.Size(159, 32);
		this.lblSection.TabIndex = 1;
		this.lblSection.Text = "lblSection";
		this.lblSection.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblKey.AutoSize = true;
		this.lblKey.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lblKey.Location = new System.Drawing.Point(216, 0);
		this.lblKey.Name = "lblKey";
		this.lblKey.Size = new System.Drawing.Size(160, 32);
		this.lblKey.TabIndex = 2;
		this.lblKey.Text = "lblKey";
		this.lblKey.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.lblIndex.AutoSize = true;
		this.lblIndex.Dock = System.Windows.Forms.DockStyle.Fill;
		this.lblIndex.Location = new System.Drawing.Point(3, 0);
		this.lblIndex.Name = "lblIndex";
		this.lblIndex.Size = new System.Drawing.Size(42, 32);
		this.lblIndex.TabIndex = 3;
		this.lblIndex.Text = "0";
		this.lblIndex.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.Controls.Add(this.TableLayoutPanel1);
		base.Name = "ucLNG";
		base.Size = new System.Drawing.Size(913, 32);
		this.TableLayoutPanel1.ResumeLayout(false);
		this.TableLayoutPanel1.PerformLayout();
		base.ResumeLayout(false);
	}
}
