using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

public class Translate
{
	private List<string> __Languages;

	private int __Index;

	private Class51 class51_0;

	public static long LOCALE_ILANGUAGE;

	public static long LOCALE_SLANGUAGE;

	public static long LOCALE_SENGLANGUAGE;

	public static long LOCALE_SABBREVLANGNAME;

	public static long LOCALE_SNATIVELANGNAME;

	public static long LOCALE_ICOUNTRY;

	public static long LOCALE_SCOUNTRY;

	public static long LOCALE_SENGCOUNTRY;

	public static long LOCALE_SABBREVCTRYNAME;

	public static long LOCALE_SNATIVECTRYNAME;

	public static long LOCALE_IDEFAULTLANGUAGE;

	public static long LOCALE_IDEFAULTCOUNTRY;

	public static long LOCALE_IDEFAULTCODEPAGE;

	public static long LOCALE_IDEFAULTANSICODEPAGE;

	public static long LOCALE_IDEFAULTMACCODEPAGE;

	public static long LOCALE_SLIST;

	public static long LOCALE_IMEASURE;

	public static long LOCALE_SDECIMAL;

	public static long LOCALE_STHOUSAND;

	public static long LOCALE_SGROUPING;

	public static long LOCALE_IDIGITS;

	public static long LOCALE_ILZERO;

	public static long LOCALE_INEGNUMBER;

	public static long LOCALE_SNATIVEDIGITS;

	public static long LOCALE_SCURRENCY;

	public static long LOCALE_SINTLSYMBOL;

	public static long LOCALE_SMONDECIMALSEP;

	public static long LOCALE_SMONTHOUSANDSEP;

	public static long LOCALE_SMONGROUPING;

	public static long LOCALE_ICURRDIGITS;

	public static long LOCALE_IINTLCURRDIGITS;

	public static long LOCALE_ICURRENCY;

	public static long LOCALE_INEGCURR;

	public static long LOCALE_SDATE;

	public static long LOCALE_STIME;

	public static long LOCALE_SSHORTDATE;

	public static long LOCALE_SLONGDATE;

	public static long LOCALE_STIMEFORMAT;

	public static long LOCALE_IDATE;

	public static long LOCALE_ILDATE;

	public static long LOCALE_ITIME;

	public static long LOCALE_ITIMEMARKPOSN;

	public static long LOCALE_ICENTURY;

	public static long LOCALE_ITLZERO;

	public static long LOCALE_IDAYLZERO;

	public static long LOCALE_IMONLZERO;

	public static long LOCALE_S1159;

	public static long LOCALE_S2359;

	public static long LOCALE_ICALENDARTYPE;

	public static long LOCALE_IOPTIONALCALENDAR;

	public static long LOCALE_IFIRSTDAYOFWEEK;

	public static long LOCALE_IFIRSTWEEKOFYEAR;

	public static long LOCALE_SDAYNAME1;

	public static long LOCALE_SDAYNAME2;

	public static long LOCALE_SDAYNAME3;

	public static long LOCALE_SDAYNAME4;

	public static long LOCALE_SDAYNAME5;

	public static long LOCALE_SDAYNAME6;

	public static long LOCALE_SDAYNAME7;

	public static long LOCALE_SABBREVDAYNAME1;

	public static long LOCALE_SABBREVDAYNAME2;

	public static long LOCALE_SABBREVDAYNAME3;

	public static long LOCALE_SABBREVDAYNAME4;

	public static long LOCALE_SABBREVDAYNAME5;

	public static long LOCALE_SABBREVDAYNAME6;

	public static long LOCALE_SABBREVDAYNAME7;

	public static long LOCALE_SMONTHNAME1;

	public static long LOCALE_SMONTHNAME2;

	public static long LOCALE_SMONTHNAME3;

	public static long LOCALE_SMONTHNAME4;

	public static long LOCALE_SMONTHNAME5;

	public static long LOCALE_SMONTHNAME6;

	public static long LOCALE_SMONTHNAME7;

	public static long LOCALE_SMONTHNAME8;

	public static long LOCALE_SMONTHNAME9;

	public static long LOCALE_SMONTHNAME10;

	public static long LOCALE_SMONTHNAME11;

	public static long LOCALE_SMONTHNAME12;

	public static long LOCALE_SMONTHNAME13;

	public static long LOCALE_SABBREVMONTHNAME1;

	public static long LOCALE_SABBREVMONTHNAME2;

	public static long LOCALE_SABBREVMONTHNAME3;

	public static long LOCALE_SABBREVMONTHNAME4;

	public static long LOCALE_SABBREVMONTHNAME5;

	public static long LOCALE_SABBREVMONTHNAME6;

	public static long LOCALE_SABBREVMONTHNAME7;

	public static long LOCALE_SABBREVMONTHNAME8;

	public static long LOCALE_SABBREVMONTHNAME9;

	public static long LOCALE_SABBREVMONTHNAME10;

	public static long LOCALE_SABBREVMONTHNAME11;

	public static long LOCALE_SABBREVMONTHNAME12;

	public static long LOCALE_SABBREVMONTHNAME13;

	public static long LOCALE_SPOSITIVESIGN;

	public static long LOCALE_SNEGATIVESIGN;

	public static long LOCALE_IPOSSIGNPOSN;

	public static long LOCALE_INEGSIGNPOSN;

	public static long LOCALE_IPOSSYMPRECEDES;

	public static long LOCALE_IPOSSEPBYSPACE;

	public static long LOCALE_INEGSYMPRECEDES;

	public static long LOCALE_INEGSEPBYSPACE;

	public static long LOCALE_FONTSIGNATURE;

	public static long LOCALE_SISO639LANGNAME;

	public static long LOCALE_SISO3166CTRYNAME;

	public static long LOCALE_IDEFAULTEBCDICCODEPAGE;

	public static long LOCALE_IPAPERSIZE;

	public static long LOCALE_SENGCURRNAME;

	public static long LOCALE_SNATIVECURRNAME;

	public static long LOCALE_SYEARMONTH;

	public static long LOCALE_SSORTNAME;

	public static long LOCALE_IDIGITSUBSTITUTION;

	public Translate()
	{
		__Languages = new List<string>();
		__Index = -1;
		__Languages = new List<string>();
		if (!File.Exists(Globals.LNG_PATH + "\\Portuguese.xml"))
		{
			File.WriteAllText(Globals.LNG_PATH + "\\Portuguese.xml", Class6.Portuguese);
		}
		if (!File.Exists(Globals.LNG_PATH + "\\Russian.xml"))
		{
			File.WriteAllText(Globals.LNG_PATH + "\\Russian.xml", Class6.Russian);
		}
		if (!File.Exists(Globals.LNG_PATH + "\\German.xml"))
		{
			File.WriteAllText(Globals.LNG_PATH + "\\German.xml", Class6.German);
		}
		if (!File.Exists(Globals.LNG_PATH + "\\Persian.xml"))
		{
			File.WriteAllText(Globals.LNG_PATH + "\\Persian.xml", Class6.Persian);
		}
		if (!File.Exists(Globals.LNG_PATH + "\\French.xml"))
		{
			File.WriteAllText(Globals.LNG_PATH + "\\French.xml", Class6.French);
		}
		string[] files = Directory.GetFiles(Globals.LNG_PATH, "*.xml");
		foreach (string item in files)
		{
			__Languages.Add(item);
		}
	}

	public bool SetLanguage(string n)
	{
		checked
		{
			int num = __Languages.Count - 1;
			int num2 = 0;
			while (true)
			{
				if (num2 <= num)
				{
					string path = __Languages[num2];
					if (Path.GetFileNameWithoutExtension(path).Equals(n))
					{
						break;
					}
					num2++;
					continue;
				}
				return SetLanguage(0);
			}
			return SetLanguage(num2);
		}
	}

	public bool SetLanguage(int i)
	{
		if (i <= checked(__Languages.Count - 1) && i != __Index)
		{
			class51_0 = new Class51(__Languages[i]);
			__Index = i;
			return true;
		}
		bool result = default(bool);
		return result;
	}

	public List<string> GetLanguages()
	{
		List<string> list = new List<string>();
		foreach (string _Language in __Languages)
		{
			list.Add(Path.GetFileNameWithoutExtension(_Language));
		}
		return list;
	}

	public string GetLanguage()
	{
		if (__Index <= checked(__Languages.Count - 1))
		{
			return Path.GetFileNameWithoutExtension(__Languages[__Index]);
		}
		return "";
	}

	public void Add(Form oForm, IContainer oComp)
	{
		try
		{
			object o = oForm;
			List<object> list = FindAllControls(ref o);
			oForm = (Form)o;
			List<object> list2 = list;
			if (oComp != null && oComp.Components != null)
			{
				list2.AddRange(FindAllComponents(oComp.Components));
			}
			checked
			{
				foreach (object item in list2)
				{
					object objectValue = RuntimeHelpers.GetObjectValue(item);
					if (objectValue == null)
					{
						continue;
					}
					string text = Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Name", new object[0], null, null, null));
					string text2 = Conversions.ToString(NewLateBinding.LateGet(objectValue, null, "Text", new object[0], null, null, null));
					if (string.IsNullOrEmpty(text))
					{
						continue;
					}
					bool flag;
					if ((flag = true) == objectValue is ListViewExt || flag == objectValue is ListViewExt)
					{
						int num = ((ListViewExt)objectValue).Columns.Count - 1;
						for (int i = 0; i <= num; i++)
						{
							((ListViewExt)objectValue).Columns[i].Text = Globals.FormatStr(Class50.smethod_5(oForm.Name + "." + text, i.ToString(), ((ListViewExt)objectValue).Columns[i].Text, class51_0));
						}
					}
					else if (flag == objectValue is DataGridView)
					{
						int num2 = 0;
						int num3 = ((DataGridView)objectValue).ColumnCount - 1;
						for (int j = 0; j <= num3; j++)
						{
							if (((DataGridView)objectValue).Columns[j].CellType == typeof(DataGridViewTextBoxCell))
							{
								((DataGridView)objectValue).Columns[j].HeaderText = Globals.FormatStr(Class50.smethod_5(oForm.Name + "." + text, num2.ToString(), ((DataGridView)objectValue).Columns[j].HeaderText, class51_0));
								num2++;
							}
						}
					}
					else if (flag == objectValue is TabControl)
					{
						int num4 = ((TabControl)objectValue).TabPages.Count - 1;
						for (int k = 0; k <= num4; k++)
						{
							((TabControl)objectValue).TabPages[k].Text = Globals.FormatStr(Class50.smethod_5(oForm.Name + "." + text, k.ToString(), ((TabControl)objectValue).TabPages[k].Text, class51_0));
						}
					}
					else
					{
						if (string.IsNullOrEmpty(text2))
						{
							continue;
						}
						text2 = Globals.FormatStr(Class50.smethod_5(oForm.Name, text, text2, class51_0));
						if (!string.IsNullOrEmpty(text2))
						{
							NewLateBinding.LateSet(objectValue, null, "Text", new object[1] { text2 }, null, null);
							if (objectValue is ToolStripItem)
							{
								((ToolStripItem)objectValue).ToolTipText = text2;
							}
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			Interaction.MsgBox(ex2.Message, (MsgBoxStyle)Conversions.ToInteger("Translate Error"));
			SetLanguage("English");
			ProjectData.ClearProjectError();
		}
	}

	public void Save()
	{
	}

	public string GetStr(string n, int i, string sDefValue = "")
	{
		if (__Index == -1)
		{
			return sDefValue;
		}
		string text = Class50.smethod_5(n, i.ToString(), sDefValue, class51_0);
		if (text.EndsWith(":"))
		{
			text += " ";
		}
		if (string.IsNullOrEmpty(text))
		{
			Interaction.MsgBox("GetStr(" + n + ", " + i + ") NOT FOUND STRING!");
		}
		return Globals.FormatStr(text);
	}

	public string GetStr(Form f, int i, string sDefValue = "")
	{
		if (string.IsNullOrEmpty(f.Name))
		{
			return sDefValue;
		}
		return GetStr(f.Name + ".Strings", i, sDefValue);
	}

	public string GetStr(string form, string name, string sDefValue = "")
	{
		if (string.IsNullOrEmpty(name) | string.IsNullOrEmpty(form))
		{
			return sDefValue;
		}
		return Class50.smethod_5(form, name, sDefValue, class51_0);
	}

	private List<object> FindAllControls(ref object o)
	{
		List<object> list = new List<object>();
		Control.ControlCollection controlCollection = ((!(o is Form)) ? ((Control)o).Controls : ((Form)o).Controls);
		foreach (Control item in controlCollection)
		{
			bool flag;
			if ((flag = true) == item is ToolStrip)
			{
				foreach (object item2 in ((ToolStrip)item).Items)
				{
					object objectValue = RuntimeHelpers.GetObjectValue(item2);
					if (objectValue is ToolStripButton || objectValue is ToolStripLabel)
					{
						list.Add(RuntimeHelpers.GetObjectValue(objectValue));
					}
				}
			}
			else if (flag == item is ContextMenuStrip)
			{
				foreach (object item3 in ((ContextMenuStrip)item).Items)
				{
					object objectValue2 = RuntimeHelpers.GetObjectValue(item3);
					if (objectValue2 is ToolStripButton || objectValue2 is ToolStripLabel)
					{
						list.Add(RuntimeHelpers.GetObjectValue(objectValue2));
					}
					list.Add(RuntimeHelpers.GetObjectValue(objectValue2));
				}
			}
			else if (flag == item is DataGridView)
			{
				list.Add(item);
			}
			else if (flag == item is TabControl)
			{
				list.Add(item);
				object o2 = item;
				List<object> collection = FindAllControls(ref o2);
				Control control = (Control)o2;
				list.AddRange(collection);
			}
			else if (flag == item is TabPage)
			{
				object o2 = item;
				List<object> collection = FindAllControls(ref o2);
				Control control = (Control)o2;
				list.AddRange(collection);
			}
			else if (flag == item.HasChildren)
			{
				if (item is GroupBox)
				{
					list.Add(item);
				}
				object o2 = item;
				List<object> collection = FindAllControls(ref o2);
				Control control = (Control)o2;
				list.AddRange(collection);
			}
			else if (flag == item.Controls.Count > 0)
			{
				object o2 = item;
				List<object> collection = FindAllControls(ref o2);
				Control control = (Control)o2;
				list.AddRange(collection);
			}
			else
			{
				list.Add(item);
			}
		}
		return list;
	}

	private List<object> FindAllComponents(ComponentCollection c)
	{
		List<object> list = new List<object>();
		foreach (object item in c)
		{
			object objectValue = RuntimeHelpers.GetObjectValue(item);
			bool flag;
			if ((flag = true) != objectValue is ToolStrip && flag != objectValue is ContextMenuStrip)
			{
				continue;
			}
			foreach (object item2 in (IEnumerable)NewLateBinding.LateGet(objectValue, null, "Items", new object[0], null, null, null))
			{
				object objectValue2 = RuntimeHelpers.GetObjectValue(item2);
				if (objectValue2 is ToolStripButton || objectValue2 is ToolStripLabel || objectValue2 is ToolStripMenuItem)
				{
					list.Add(RuntimeHelpers.GetObjectValue(objectValue2));
				}
			}
		}
		return list;
	}

	public string OSLanguage()
	{
		string result;
		try
		{
			long systemDefaultLCID = GetSystemDefaultLCID();
			result = GetUserLocaleInfo(systemDefaultLCID, 4097L);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			result = "English";
			ProjectData.ClearProjectError();
		}
		return result;
	}

	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	public static extern long GetThreadLocale();

	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	public static extern long GetSystemDefaultLCID();

	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	public static extern long GetLocaleInfoA(long Locale, long LCType, [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpLCData, long cchData);

	public string GetUserLocaleInfo(long dwLocaleID, long dwLCType)
	{
		string lpLCData = default(string);
		long localeInfoA = GetLocaleInfoA(dwLocaleID, dwLCType, ref lpLCData, Strings.Len(lpLCData));
		checked
		{
			if (localeInfoA != 0)
			{
				lpLCData = Strings.Space((int)localeInfoA);
				localeInfoA = GetLocaleInfoA(dwLocaleID, dwLCType, ref lpLCData, Strings.Len(lpLCData));
				if (localeInfoA != 0)
				{
					return Strings.Left(lpLCData, (int)(localeInfoA - 1));
				}
			}
			string result = default(string);
			return result;
		}
	}
}
