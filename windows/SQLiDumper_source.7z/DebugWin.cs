using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
public class DebugWin : Form
{
	private IContainer icontainer_0;

	[field: AccessedThroughProperty("txtOutput")]
	internal virtual TextBox txtOutput
	{
		get; [MethodImpl(MethodImplOptions.Synchronized)]
		set;
	}

	public DebugWin()
	{
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.txtOutput = new System.Windows.Forms.TextBox();
		base.SuspendLayout();
		this.txtOutput.Dock = System.Windows.Forms.DockStyle.Fill;
		this.txtOutput.Font = new System.Drawing.Font("Courier New", 10f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.txtOutput.Location = new System.Drawing.Point(0, 0);
		this.txtOutput.Multiline = true;
		this.txtOutput.Name = "txtOutput";
		this.txtOutput.ReadOnly = true;
		this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.txtOutput.Size = new System.Drawing.Size(826, 510);
		this.txtOutput.TabIndex = 0;
		this.txtOutput.WordWrap = false;
		base.AutoScaleDimensions = new System.Drawing.SizeF(9f, 20f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(826, 510);
		base.Controls.Add(this.txtOutput);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
		base.Name = "DebugWin";
		this.Text = "Debug";
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	public void Append(string text)
	{
		txtOutput.AppendText(text + "\r\n");
	}
}
