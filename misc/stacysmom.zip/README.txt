This is a publicity stunt done by the Malcore team. 

None of the files in this folder are malicious (if they are it wasn't me), they are just intended to look that way.

Hashes of files in this folder:
- a33a361b45aa3a7b6515ff7771af52632697e30ce7e63aa3a271f4f05a5ea28d  ./.fi/ch_1.lnk
- 6f567d8eea0e83dadea8d14068d40d9445151e24358d20b977e9b7c64d03927e  ./.fi/ed_9.lnk
- 05b3222358004e9704320764f7515283b8d2b09f0248f931c057d23a255a566c  ./.fi/ff_3.lnk
- 041afe89d68bb845ffde722354c13261ddb1bb46776fec0efa180a95fbc994b8  ./autorun.ini
- a3f4edfb57534da9eca838ad64cc73b1a661b3349368bcc6d5097edfd9a602a3  ./cliCk ME fOR inSTrucTioNs.pdf.lnk
- 7ff8e302fec63de5a35b03ef09aff6f5b722de23131b0f82da8f4203efac9d20  ./just_m_logo.ico
- 3aebd76e2877d35949eb21f27eeaad514b21810291628454a92f86de7264b225  ./stacy.exe

Of course always remain cautions when executing unknown files out of a USB you found on the ground at a hacking conference.